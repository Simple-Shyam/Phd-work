/*
 * Run.java
 *
 * Created on June 13, 2002, 10:04 PM
 */

package readmidasdata;

/**
 *
 * @author  karlen
 * @version 
 */
public class Run {

    /** Creates new Run */
    public Run() {
        MainFrame gui = new MainFrame();
        gui.setTitle("Read Midas Data");
        gui.setSize(600,600);
        gui.show();
    }

    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) {
        new Run();
    }

}
