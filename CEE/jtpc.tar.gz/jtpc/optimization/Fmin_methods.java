package optimization;

public interface Fmin_methods {

   double f_to_minimize(double x);

}
