/*
 * XYFitter.java
 *
 * Created on April 19, 2002, 2:17 PM
 */

package tpctracker;
import tpcsimulator.PadMesh;
import optimization.*;
import org.freehep.math.minuit.FCNBase;
import org.freehep.math.minuit.FunctionMinimum;
import org.freehep.math.minuit.MnMigrad;
import org.freehep.math.minuit.MnUserParameters;


/** xy fitting algorithm for data recorded by pads described by a mesh.
 *  Fitting is done on a row by row basis. With the first row being defined by
 *  the vertical extent of the first pad, and subsequent rows likewise defined.
 *
 * @author  karlen
 * @version
 */
public class XYFitter implements Uncmin_methods{
    
    PadMesh padMesh;
    final int nParam = 4;
    double param[] = new double[nParam];   // x0,phi,sigma,1/r: holds best fit result
    double paramDummy[] = new double[nParam]; // same as above: used for passing to evaluating routine
    double typicalSize[] = new double[nParam]; // typical sizes for values of above
    boolean fixed[] = new boolean[nParam]; // specifies which are fixed
    int nParamFit; // number of parameters to float in fit
    int paramForX[] = new int[nParam+1]; // specifies parameter number for given x index
    int xForParam[] = new int[nParam]; // specifies x index for given parameter number
    double totGain;
    double pNoise;
    double sigmaSlope;
    int fitMethod;
    double covariance[][]; // covariance matrix from fit
    int fitRows[]; // specifies the rows to be fit
    double z0, dzdy; // for variable sigma along track length
    
    /** Creates new XYFitter */
    public XYFitter(PadMesh padMesh) {
        this.padMesh = padMesh;
        setParam(0,0.,false);  // x0
        setParam(1,0.,false);  // phi
        setParam(2,1.,false);  // sigma
        setParam(3,0.,true); // 1/r
        setPNoise(0.01); // probability of a noise hit
        setGain(3000.); // required to calculate the proper errors
        setSigmaSlope(0.); // for fitting with a sigma that varies along the track length
        setMethod(4); // deault fit method = Minuit
        setFitRows(); // set all rows to be fit
        setVarSigma(0.,0.); // parameters that define z0 and dzdy for fit in which sigma varies along the length
        covariance = new double[nParam+1][];
        for (int i=0; i<=nParam; i++) {
            covariance[i] = new double[nParam+1];
        }
        setTypicalSize();
    }
    
    /** Creates new XYFitter */
    public XYFitter(PadMesh padMesh, XYFitterParam xyfp) {
        this.padMesh = padMesh;
        setParam(xyfp);
        setFitRows();
        covariance = new double[nParam+1][];
        for (int i=0; i<=nParam; i++) {
            covariance[i] = new double[nParam+1];
        }
        setTypicalSize();
    }
    
    /** needed because class is extended: */
    XYFitter() {
    }
    
    public int getFitterMultiplicity() { return 1;}
    
    void setTypicalSize() {
        typicalSize[0] = 10.;
        typicalSize[1] = 1.;
        typicalSize[2] = 1.;
        typicalSize[3] = 1.E-5;
    }
    
    public void setParam(XYFitterParam xyfp) {
        setParam(0,xyfp.getParam(0),xyfp.isFixed(0));  // x0
        setParam(1,xyfp.getParam(1),xyfp.isFixed(1));  // phi
        setParam(2,xyfp.getParam(2),xyfp.isFixed(2));  // sigma
        setParam(3,xyfp.getParam(3),xyfp.isFixed(3));  // 1/r
        setPNoise(xyfp.getPNoise()); // probability of a noise hit
        setGain(xyfp.getGain()); // required to calculate the proper errors
        setSigmaSlope(xyfp.getSigmaSlope());
        setMethod(xyfp.getMethod()); // fit method
    }
    
    public void setParam(int iParam, double value, boolean fixed) {
        if (iParam >= 0 && iParam < nParam) {
            param[iParam] = value;
            this.fixed[iParam] = fixed;
        }
    }
    
    public double getParam(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return param[iParam];
        } else {
            return -9999.;
        }
    }
    
    public void setVarSigma(double z0, double dzdy){
        this.z0 = z0;
        this.dzdy = dzdy;
    }
    
    public double[] getParam() {
        return param;
    }
    
    public void setFitRows(int[] fitRows) {
        this.fitRows = fitRows;
    }
    
    public int[] getFitRows() { return fitRows; }
    
    public void setFitRows() {
        int nr = padMesh.getNRow();
        fitRows = new int[nr];
        for (int ir=0; ir < nr; ir++) {
            fitRows[ir] = ir;
        }
    }
    
    public double[][] getCovariance() { return covariance; }
    
    public double getError(int iParam) {
        int i = xForParam[iParam];
        if (fitMethod == 4)i = iParam;
        if (i >= 0) {
            return Math.sqrt(covariance[i][i]);
        } else {
            return -9999.;
        }
    }
    public double getCorrelation(int iParam, int jParam) {
        int i = xForParam[iParam];
        int j = xForParam[jParam];
        if (fitMethod == 4)i = iParam;
        if (fitMethod == 4)j = jParam;
        if (Math.min(i,j) >= 0) {
            if (j > i) {
                return covariance[j][i]/Math.sqrt(covariance[j][j]*covariance[i][i]);
            } else if ( i > j ) {
                return covariance[i][j]/Math.sqrt(covariance[j][j]*covariance[i][i]);
            } else {
                return 1.;
            }
        } else {
            return -9999.;
        }
    }
    
    public void setGain(double gain) { totGain = gain; }
    public double getGain() { return totGain;}
    
    public void setPNoise(double noise) { pNoise = noise; }
    public double getPNoise() { return pNoise; }
    
    public void setSigmaSlope(double slope) { sigmaSlope = slope; }
    public double getSigmaSlope() { return sigmaSlope; }
    
    public void setMethod(int method) { fitMethod = method; }
    public int getMethod() { return fitMethod; }
    
    public boolean isFixed(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return fixed[iParam];
        } else {
            return false;
        }
    }
    
    /** Methods for jMinuit minimization */
    
    FCNBase negLogLike = new FCNBase() {
        public double valueOf(double[] par) {
            padMesh.setVarSigma(z0,dzdy,sigmaSlope);
            return -1.*padMesh.calcLogLikelihood(par,totGain,pNoise,fitRows);
        }
    };
    
    public boolean doMinuitFit() {
        
        MnUserParameters myParameters = new MnUserParameters();
        myParameters.add("x0", param[0], 0.1);
        myParameters.add("phi0", param[1], 0.01);
        myParameters.add("sigma", param[2], 0.1);
        myParameters.add("1/r", param[3], 0.0001);
        
        MnMigrad migrad = new MnMigrad(negLogLike, myParameters);
        migrad.setErrorDef(0.5);
        for (int i=0; i<4; i++){
            if(fixed[i])migrad.fix(i);
        }
        
        FunctionMinimum min = null;
        boolean exception=false;
        try {
            min = migrad.minimize();
        } catch (RuntimeException e) {
            exception=true;
        }
        
        boolean status = !exception && min.isValid();
        
        if (status){
            int ii=-1;
            for (int i=0; i<4; i++){
                if(!fixed[i])ii++;
                param[i]=min.userParameters().value(i);
                int jj=-1;
                for (int j=0; j<4; j++){
                    if(!fixed[j])jj++;
                    if (!fixed[i]&&!fixed[j]){
                        covariance[i][j]=min.userCovariance().get(ii,jj);
                    }
                    else covariance[i][j] = 0;
                }
            }
        } else {
            for (int i=0; i<4; i++){
                for (int j=0; j<4; j++){
                    covariance[i][j] = 999.*999.;
                }
            }
        }       
        
        return status;
        
    }
    
    /** Methods required to interface with UNCMIN package
     */
    
    public double f_to_minimize(double[] x) {
        /** Calculate the  neg. log likelihood of the observed charge fractions in each row.
         * Use the binomial nature of the problem to define the likelihood.
         */
        
        for (int i = 0; i < nParam; i++) paramDummy[i] = param[i];
        for (int iParamFit = 1; iParamFit <= nParamFit; iParamFit++) {
            int iParam = paramForX[iParamFit];
            paramDummy[iParam] = x[iParamFit];
        }
        
        padMesh.setVarSigma(z0,dzdy,sigmaSlope);
        return -1.*padMesh.calcLogLikelihood(paramDummy,totGain,pNoise,fitRows);
    }
    
    public void gradient(double[] x,double[] g) {
    }
    
    public void hessian(double[] x,double[][] h) {
    }
    
    public boolean doFit() {
        
        if (fitMethod == 4) {
            return doMinuitFit();
        } else {
            
            // Determine the number of parameters being fit and the correspondance between
            // param[] index and x[] index.
            nParamFit=0;
            for (int iParam = 0; iParam < nParam; iParam++) {
                xForParam[iParam] = -1;
                if (!fixed[iParam]) {
                    nParamFit++;
                    paramForX[nParamFit] = iParam;
                    xForParam[iParam] = nParamFit;
                }
            }
            
            if (nParamFit > fitRows.length) {
                System.out.println("Too many fit parameters for the number of rows! \n");
                return false;
            }
            /** From the UNCMIN documentation
             *
             *@param typsiz     Typical size for each component of x
             *@param fscale     Estimate of the scale of the objective function
             *@param method     Algorithm to use to solve the minimization problem
             *                    = 1  line search
             *                    = 2  double dogleg
             *                    = 3  More-Hebdon
             *@param iexp       = 1 if the optimization function f_to_minimize
             *                  is expensive to evaluate, = 0 otherwise.  If iexp = 1,
             *                  then the Hessian will be evaluated by secant update
             *                  rather than analytically or by finite differences.
             *@param  msg       Message to inhibit certain automatic checks and output
             *@param  ndigit    Number of good digits in the minimization function
             *@param  itnlim    Maximum number of allowable iterations
             *@param  iagflg    = 0 if an analytic gradient is not supplied
             *@param  iahflg    = 0 if an analytic Hessian is not supplied
             *@param  dlt       Trust region radius
             *@param  gradtl    Tolerance at which the gradient is considered close enough
             *                  to zero to terminate the algorithm
             *@param  stepmx    Maximum allowable step size
             *@param  steptl    Relative step size at which successive iterates
             *                  are considered close enough to terminate the algorithm
             *@param xpls       The final estimate of the minimum point
             *@param fpls       The value of f_to_minimize at xpls
             *@param gpls       The gradient at the local minimum xpls
             *@param itrmcd     Termination code
             *                      ITRMCD =  0:  Optimal solution found
             *                      ITRMCD =  1:  Terminated with gradient small,
             *                                  X is probably optimal
             *                      ITRMCD =  2:  Terminated with stepsize small,
             *                                  X is probably optimal
             *                      ITRMCD =  3:  Lower point cannot be found,
             *                                  X is probably optimal
             *                      ITRMCD =  4:  Iteration limit (150) exceeded
             *                      ITRMCD =  5:  Too many large steps,
             *                                  function may be unbounded
             *@param a          Workspace for the Hessian (or its estimate)
             *                  and its Cholesky decomposition
             *@param udiag      Workspace for the diagonal of the Hessian
             */
            
            int n=nParamFit;
            int info[] = new int[2];
            double x0[] = new double[nParamFit+1];
            double x[] = new double[nParamFit+1];
            double f[] = new double[2];
            
            double g[] = new double[nParamFit+1];
            double a[][] = new double[nParamFit+1][nParamFit+1];
            double udiag[] = new double[nParamFit+1];
            
            double typsiz[] = new double[nParamFit+1];
            double fscale[] = new double[2];
            int method[] = new int[2];
            int iexp[] = new int[2];
            int msg[] = new int[2];
            int ndigit[] = new int[2];
            int itnlim[] = new int[2];
            int iagflg[] = new int[2];
            int iahflg[] = new int[2];
            double dlt[] = new double[2];
            double gradtl[] = new double[2];
            double stepmx[] = new double[2];
            double steptl[] = new double[2];
            
            for (int iParamFit = 1; iParamFit <= nParamFit; iParamFit++) {
                int iParam = paramForX[iParamFit];
                x0[iParamFit] = param[iParam];
                typsiz[iParamFit] = typicalSize[iParam];
            }
            
            Uncmin_f77.dfault_f77(n,x0,typsiz,fscale,method,iexp,
            msg,ndigit,itnlim,iagflg,iahflg,dlt,gradtl,stepmx,steptl);
            
            for (int iParamFit = 1; iParamFit <= nParamFit; iParamFit++) {
                int iParam = paramForX[iParamFit];
                x0[iParamFit] = param[iParam];
                typsiz[iParamFit] = typicalSize[iParam];
            }
            
            iagflg[1] = 0;
            iahflg[1] = 0;
            iexp[1] = 0;
            method[1] = fitMethod;
            
            fscale[1] = 100.;
            ndigit[1] = 10;
            itnlim[1] = 300;
            gradtl[1] = 1.E-4;
            stepmx[1] = 20.;
            steptl[1] = 1.E-6;
            
            msg[1] = 9; // reduce verbage of output... set to 9
            
            
            Uncmin_f77.optif9_f77(n,x0,this,typsiz,fscale,method,iexp,
            msg,ndigit,itnlim,iagflg,iahflg,dlt,gradtl,stepmx,steptl,
            x,f,g,info,a,udiag);
            
            for (int iParamFit = 1; iParamFit <= nParamFit; iParamFit++) {
                int iParam = paramForX[iParamFit];
                param[iParam] = x[iParamFit];
            }
            
            // evaluate Hessian (is not correct after calling optif !)
            
            double sx[] = new double[nParamFit+1];
            for (int iParam = 1; iParam <= nParamFit; iParam++) sx[iParam] = 10.;
            double epsm = 1.12e-16;
            double rnf = Math.max(Math.pow(10.0,-ndigit[1]),epsm);
            double wrk1[] = new double[nParamFit+1];
            double wrk2[] = new double[nParamFit+1];
            Uncmin_f77.sndofd_f77(n,x,this,f,a,sx,rnf,wrk1,wrk2);
            
            // calculate covariance matrix, by inverting Hessian by hand:
            
            if (nParamFit == 4) {
                double denom = -a[1][1]*a[2][2]*a[3][3]*a[4][4]
                +a[1][1]*a[2][2]*a[4][3]*a[4][3]
                +a[1][1]*a[3][2]*a[3][2]*a[4][4]
                -2.*a[1][1]*a[3][2]*a[4][2]*a[4][3]
                +a[1][1]*a[4][2]*a[4][2]*a[3][3]
                +a[2][1]*a[2][1]*a[3][3]*a[4][4]
                -a[2][1]*a[2][1]*a[4][3]*a[4][3]
                -2.*a[2][1]*a[3][2]*a[3][1]*a[4][4]
                +2.*a[2][1]*a[3][2]*a[4][1]*a[4][3]
                +2.*a[2][1]*a[4][2]*a[3][1]*a[4][3]
                -2.*a[2][1]*a[4][2]*a[4][1]*a[3][3]
                +a[2][2]*a[3][1]*a[3][1]*a[4][4]
                -2.*a[3][1]*a[2][2]*a[4][1]*a[4][3]
                -a[3][1]*a[3][1]*a[4][2]*a[4][2]
                +2.*a[3][1]*a[4][2]*a[4][1]*a[3][2]
                +a[2][2]*a[4][1]*a[4][1]*a[3][3]
                -a[4][1]*a[4][1]*a[3][2]*a[3][2];
                
                covariance[1][1] = (-a[2][2]*a[3][3]*a[4][4] + a[2][2]*a[4][3]*a[4][3] + a[3][2]*a[3][2]*a[4][4]
                -2.*a[3][2]*a[4][2]*a[4][3] + a[4][2]*a[4][2]*a[3][3])/denom;
                
                covariance[2][1] = -(-a[2][1]*a[3][3]*a[4][4] + a[2][1]*a[4][3]*a[4][3] + a[3][2]*a[3][1]*a[4][4]
                -a[3][2]*a[4][1]*a[4][3] - a[4][2]*a[3][1]*a[4][3] + a[4][2]*a[4][1]*a[3][3])/denom;
                
                covariance[2][2] = (-a[1][1]*a[3][3]*a[4][4] + a[1][1]*a[4][3]*a[4][3] + a[3][1]*a[3][1]*a[4][4]
                -2.*a[3][1]*a[4][1]*a[4][3] + a[4][1]*a[4][1]*a[3][3])/denom;
                
                covariance[3][1] = (-a[2][1]*a[3][2]*a[4][4] + a[2][1]*a[4][2]*a[4][3] + a[2][2]*a[3][1]*a[4][4]
                -a[2][2]*a[4][1]*a[4][3] - a[3][1]*a[4][2]*a[4][2] + a[4][2]*a[4][1]*a[3][2])/denom;
                
                covariance[3][2] = -(-a[1][1]*a[3][2]*a[4][4] + a[1][1]*a[4][2]*a[4][3] + a[3][1]*a[2][1]*a[4][4]
                -a[3][1]*a[4][1]*a[4][2] - a[4][1]*a[2][1]*a[4][3] + a[4][1]*a[4][1]*a[3][2])/denom;
                
                covariance[3][3] = -(a[1][1]*a[2][2]*a[4][4] - a[1][1]*a[4][2]*a[4][2] - a[2][1]*a[2][1]*a[4][4]
                +2.*a[2][1]*a[4][1]*a[4][2] - a[4][1]*a[4][1]*a[2][2])/denom;
                
                covariance[4][1] = (a[2][1]*a[3][2]*a[4][3] - a[2][1]*a[4][2]*a[3][3] - a[2][2]*a[3][1]*a[4][3]
                +a[2][2]*a[4][1]*a[3][3] + a[3][2]*a[3][1]*a[4][2] - a[4][1]*a[3][2]*a[3][2])/denom;
                
                covariance[4][2] = -(a[1][1]*a[3][2]*a[4][3] - a[1][1]*a[4][2]*a[3][3] - a[3][1]*a[2][1]*a[4][3]
                +a[3][1]*a[3][1]*a[4][2] + a[4][1]*a[2][1]*a[3][3] - a[4][1]*a[3][1]*a[3][2])/denom;
                
                covariance[4][3] = (a[1][1]*a[2][2]*a[4][3] - a[1][1]*a[4][2]*a[3][2] - a[2][1]*a[2][1]*a[4][3]
                +a[2][1]*a[3][1]*a[4][2] + a[4][1]*a[2][1]*a[3][2] - a[4][1]*a[2][2]*a[3][1])/denom;
                
                covariance[4][4] = -(a[1][1]*a[2][2]*a[3][3] - a[1][1]*a[3][2]*a[3][2] - a[2][1]*a[2][1]*a[3][3]
                +2.*a[2][1]*a[3][1]*a[3][2] - a[2][2]*a[3][1]*a[3][1])/denom;
                
            } else if (nParamFit == 3) {
                double denom = -a[3][1]*a[3][1]*a[2][2] + 2.*a[2][1]*a[3][1]*a[3][2]
                - a[1][1]*a[3][2]*a[3][2] -a[2][1]*a[2][1]*a[3][3] + a[1][1]*a[2][2]*a[3][3];
                covariance[1][1] = (a[2][2]*a[3][3]-a[3][2]*a[3][2])/denom;
                covariance[2][1] = (a[3][1]*a[3][2]-a[2][1]*a[3][3])/denom;
                covariance[2][2] = (a[1][1]*a[3][3]-a[3][1]*a[3][1])/denom;
                covariance[3][1] = (a[2][1]*a[3][2]-a[3][1]*a[2][2])/denom;
                covariance[3][2] = (a[2][1]*a[3][1]-a[3][2]*a[1][1])/denom;
                covariance[3][3] = (a[1][1]*a[2][2]-a[2][1]*a[2][1])/denom;
            } else if (nParamFit == 2) {
                double denom = a[1][1]*a[2][2] - a[2][1]*a[2][1];
                covariance[1][1] = a[2][2]/denom;
                covariance[2][1] = -a[2][1]/denom;
                covariance[2][2] = a[1][1]/denom;
            } else {
                covariance[1][1] = 1./a[1][1];
            }
            
            return (info[1] <= 3);
        }
    }
    
}