/*
 * YZFitter.java
 *
 * Created on Feb 2, 2004
 */

package tpctracker;
import tpcsimulator.PadMesh;

/** yz fitting algorithm for data recorded by pads described by a mesh.
 *  Fitting is done by a simple linear least squares fit
 *
 * @author  karlen
 * @version
 */
public class YZFitter {
    
    PadMesh padMesh;
    final int nParam = 2;
    double param[] = new double[nParam];   // z0, tan lambda: holds best fit result
    boolean fixed[] = new boolean[nParam]; // specifies which are fixed
    int nParamFit; // number of parameters to float in fit
    double covariance[][]; // covariance matrix from fit
    int fitRows[]; // specifies the rows to be fit
    int fitMethod; // not yet used
    double residual[];
    
    /** Creates new YZFitter */
    public YZFitter(PadMesh padMesh) {
        this.padMesh = padMesh;
        setParam(0,0.,false);  // z0
        setParam(1,0.,false);  // tanlambda
        setMethod(1); // fit method
        setFitRows(); // set all rows to be fit
        covariance = new double[nParam][];
        for (int i=0; i<nParam; i++) {
            covariance[i] = new double[nParam];
        }
    }
        
    public void setParam(int iParam, double value, boolean fixed) {
        if (iParam >= 0 && iParam < nParam) {
            param[iParam] = value;
            this.fixed[iParam] = fixed;
        }
    }
    
    public double getParam(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return param[iParam];
        } else {
            return -9999.;
        }
    }
    
    public double[] getParam() {
        return param;
    }
    
    public void setFitRows(int[] fitRows) {
        this.fitRows = fitRows;
    }
    
    public void setFitRows() {
        int nr = padMesh.getNRow();
        fitRows = new int[nr];
        for (int ir=0; ir < nr; ir++) {
            fitRows[ir] = ir;
        }
    }
    
    public double[][] getCovariance() { return covariance; }
    
    public double getError(int iParam) {
        int i = iParam;
        if (i >= 0 && i < nParam) {
            return Math.sqrt(covariance[i][i]);
        } else {
            return -9999.;
        }
    }
    
    public double getCorrelation(int iParam, int jParam) {
        int i = iParam;
        int j = jParam;
        if (Math.min(i,j) >= 0 && Math.max(i,j) < nParam) {
            return covariance[i][j]/Math.sqrt(covariance[j][j]*covariance[i][i]);
        } else {
            return -9999.;
        }
    }
        
    public void setMethod(int method) { fitMethod = method; }
    public int getMethod() { return fitMethod; }
    
    public boolean isFixed(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return fixed[iParam];
        } else {
            return false;
        }
    }
    
    public boolean doFit() {
        
        // do a linear least squares fit, assuming sigma on z is constant (=1)
        // formulas from num recipies followed
        // only single track finding is incorporated: use first time found on row
        
        param[0] = -9999.;
        param[1] = -9999.;
        
        double[][] yzData = padMesh.getYZData();       
        int nRow = fitRows.length;
        
        double s = 0., sY = 0., sZ = 0., sYY = 0., sYZ = 0.;
        for (int iR = 0; iR < nRow; iR++) {
            int iRow = fitRows[iR];
            double y = yzData[iRow][0];
            double z = yzData[iRow][1];
            if (z > 0) {
                s += 1.;
                sY += y;
                sZ += z;
                sYY += y*y;
                sYZ += y*z;
            }
        }
        double d = s*sYY -sY*sY;
        if (d == 0.) return false;

        param[0] = (sYY*sZ - sY*sYZ)/d;
        param[1] = (s*sYZ -sY*sZ)/d;
        
        covariance[0][0] = sYY/d;
        covariance[1][1] = s/d;
        covariance[0][1] = -sY/d;
        covariance[1][0] = -sY/d;
        
        // work out the residuals:
        int nRes = yzData.length;
        residual = new double[nRes];
        for (int iRes = 0; iRes < nRes; iRes++) {
            residual[iRes] = yzData[iRes][1] - (param[0]+param[1]*yzData[iRes][0]);
        }

        return true;
    }
    
    public double getResidual(int iRow) {return residual[iRow];}
    
}