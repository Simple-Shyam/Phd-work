/*
 * XYFitterParam2.java
 *
 * Created on August 10, 2004
 */

package tpctracker;
import java.io.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class XYFitterParam2 implements Serializable {

    final int nParam = 6;
    double param[] = new double[nParam];   // x01,phi1,sigma1,x02,phi2,sigma2
    boolean fixed[] = new boolean[nParam]; // specifies which are fixed
    double totGain;
    double pNoise;
    int fitMethod;
    int fitNumber;
    int meshIndex;
    
    /** Creates new XYFitterParam */
    public XYFitterParam2() {
        setParam(0,0.2,false);  // x01
        setParam(1,0.,false);  // phi1
        setParam(2,0.5,true);  // sigma1
        setParam(3,-0.2,false);  // x02
        setParam(4,0.,false);  // phi2
        setParam(5,0.5,true);  // sigma2
        setPNoise(0.0); // probability of a noise hit
        setGain(3000.); // required to calculate the proper errors
        setMethod(2); // fit method
        setNumber(0);
        meshIndex = -1;
    }
    
    public void setParam(int iParam, double value, boolean fixed) {
        if (iParam >= 0 && iParam < nParam) {
            param[iParam] = value;
            this.fixed[iParam] = fixed;
        }
    }
    public double getParam(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return param[iParam];
        } else {
            return -9999.;
        }
    }
    public boolean isFixed(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return fixed[iParam];
        } else {
            return false;
        }
    }
    
    public void setGain(double gain) { totGain = gain; }
    public double getGain() { return totGain;}
    
    public void setPNoise(double noise) { pNoise = noise; }
    public double getPNoise() { return pNoise; }
    
    public void setMethod(int method) { fitMethod = method; }
    public int getMethod() { return fitMethod; }
    
    public void setMeshIndex(int index) { meshIndex = index; }
    public int getMeshIndex() { return meshIndex; }
    
    public void setNumber(int number) { fitNumber = number; }
    public int getNumber() { return fitNumber; }
}