/*
 * XYFitterParam.java
 *
 * Created on May 22, 2002, 10:09 PM
 */

package tpctracker;
import java.io.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class XYFitterParam implements Serializable {
    
    static final long serialVersionUID = 8838097857446621486L;

    final int nParam = 4;
    double param[] = new double[nParam];   // x0,phi,sigma,1/r
    boolean fixed[] = new boolean[nParam]; // specifies which are fixed
    double totGain;
    double pNoise;
    double sigmaSlope;
    int fitMethod;
    int fitNumber;
    int meshIndex;
    
    /** Creates new XYFitterParam */
    public XYFitterParam() {
        setParam(0,0.,false);  // x0
        setParam(1,0.,false);  // phi
        setParam(2,1.,false);  // sigma
        setParam(3,0.,true);  // 1/r
        setPNoise(0.0); // probability of a noise hit
        setGain(3000.); // required to calculate the proper errors
        setSigmaSlope(0.); // assumed variation of sigma^2 vs time bins
        setMethod(4); // fit method
        setNumber(0);
        meshIndex = -1;
    }
    
    public void setParam(int iParam, double value, boolean fixed) {
        if (iParam >= 0 && iParam < nParam) {
            param[iParam] = value;
            this.fixed[iParam] = fixed;
        }
    }
    public double getParam(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return param[iParam];
        } else {
            return -9999.;
        }
    }
    public boolean isFixed(int iParam) {
        if (iParam >= 0 && iParam < nParam) {
            return fixed[iParam];
        } else {
            return false;
        }
    }
    
    public void setGain(double gain) { totGain = gain; }
    public double getGain() { return totGain;}
    
    public void setPNoise(double noise) { pNoise = noise; }
    public double getPNoise() { return pNoise; }
    
    public void setSigmaSlope(double slope) { sigmaSlope = slope; }
    public double getSigmaSlope() { return sigmaSlope; }
    
    public void setMethod(int method) { fitMethod = method; }
    public int getMethod() { return fitMethod; }
    
    public void setMeshIndex(int index) { meshIndex = index; }
    public int getMeshIndex() { return meshIndex; }
    
    public void setNumber(int number) { fitNumber = number; }
    public int getNumber() { return fitNumber; }
}