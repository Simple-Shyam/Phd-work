/*
 * UVicTpc2Analyzer.java
 *
 * Created on January 24, 2005, 11:55 AM
 */

import tpcanalyzer.*;
import tparameter.*;
import tpcsimulator.*;
import tpctracker.*;
import hep.aida.*;

/**
 *
 * @author  karlen
 */
public class UVicTpc2Analyzer extends TpcAnalyzer {
    
    ParameterList pL;
    StringParameter parameterFileComment;
    IntegerParameter runNumber,preScale,nBadChannels,nBinsZeroed,firstChannelNoise,lastChannelNoise;
    IntegerParameter firstChannelResponse,lastChannelResponse,nBadChannelsForRuns;
    IntegerArrayParameter badChannels;
    IntegerMatrixParameter badChannelsForRuns;
    BooleanParameter doNoiseStudy,doEfficiencyStudy,doResolutionStudy,doTwoTrackStudy;
    BooleanParameter correctSpike,correctOverFlow,fitStraight,twoParFit;
    BooleanParameter doChannelResponseStudy,storePulseDetails,fitResRow,addNoise;
    BooleanParameter timeSlice;
    IntegerParameter timeSliceLow,timeSliceHigh;
    IntegerParameter minSpike,widthSpike,lowOverFlow,highOverFlow,overFlow;
    IntegerParameter startBinPedestal,minPulseLength,numPadsPeak,numBinsPeak;
    DoubleParameter pulseRatio,noiseLevel;
    IntegerParameter minHitRow,minHitLevel;
    IntegerParameter seedRow0,seedRow1,minHitTrack, nSkipRows;
    DoubleParameter seedPadWidth,maxX0,maxAvgPeak,fitSigma,fitGain,fitNoise;
    DoubleParameter delSpike,minSignalSize,sigmaSlope,sigmaOffset;
    DoubleParameter seedX01,seedPhi01,seedSigma1,seedX02,seedPhi02,seedSigma2;
    IntegerArrayParameter skipRows;
    IntegerParameter nEffRows,nFitRows,nResRows;
    IntegerArrayParameter effRows,fitRows,resRows;
    BooleanParameter doDEdxStudy;
    IntegerParameter nDEdxSkipRows,nDEdxTrunc;
    IntegerArrayParameter dEdxSkipRows,dEdxTrunc;
    
    PadMesh padMesh;
    
    double[] timeInRow, sumInRow, peakInRow, signalInRow, rowSumInRow;
    double[] leftBefore,leftAfter,rightBefore,rightAfter,rDEdxInRow;
    int[] numClusterInRow,numPadHitInRow;
    int iTup,iEvt;
    IHistogram1D[] noiseHist;
    
    java.util.Random rand;
    
    /** Creates new MyTpcAnalyzer */
    public UVicTpc2Analyzer() {
        setName("UVic Tpc2 Analyzer (version 1.5)");
        pL = getParameterList();
        eventVetoSetup();
        findTrackSetup();
        noiseStudySetup();
        efficiencyStudySetup();
        resolutionStudySetup();
        twoTrackStudySetup();
        dEdxStudySetup();
        
        timeInRow = new double[300];
        sumInRow = new double[300];
        peakInRow = new double[300];
        signalInRow = new double[300];
        rowSumInRow = new double[300];
        leftBefore = new double[300];
        leftAfter = new double[300];
        rightBefore = new double[300];
        rightAfter = new double[300];
        numClusterInRow = new int[300];
        numPadHitInRow = new int [300];
        iEvt = 0;
    }
    
    public String doAnalysis(boolean fillTuple) {
        
        // to simplify things, only allow one fitter (1track or 2track):
        
        if (doTwoTrackStudy.getValue()) {
            doResolutionStudy.setValue(false);
        }
        
        // need to create a new fitter for every event analyzed: interactive
        // may decide to switch from one fitter to another
        
        if (doResolutionStudy.getValue() || doTwoTrackStudy.getValue()) {
            if (doResolutionStudy.getValue())
                xyFitter = new XYFitter(getPadMesh());
            else
                xyFitter = new XYFitter2(getPadMesh());
            xyFitter.setPNoise(fitNoise.getValue());
            xyFitter.setGain(fitGain.getValue());
        } else xyFitter = null;
        
        
        if (iEvt++%preScale.getValue() != 0)return "skipped (pre-scale)";
        
        padMesh = getPadMesh();
        iTup = 0;
        if (fillTuple) {
            tuple.fill(iTup++,tpcData.getRunNumber());
            tuple.fill(iTup++,tpcData.getEventNumber());
            tuple.fill(iTup++,tpcData.getEventTime());
            if (doResolutionStudy.getValue()) {
                if (tpcData.hasTruth()) {
                    double[] truth = tpcData.getTruth();
                    tuple.fill(iTup++,truth[0]);
                    tuple.fill(iTup++,truth[5]);
                    double kE = truth[4]; double tanl = truth[3]; double mm = 0.107;
                    double tpt = Math.sqrt((kE*kE+2.*mm*kE)/(1+tanl*tanl));
                    tuple.fill(iTup++,kE);
                    tuple.fill(iTup++,tpt);
                } else {
                    for (int i=0; i<4; i++) tuple.fill(iTup++,-9999.);
                }
            }
        }
        
        // setup badChan array:
        int[] badChanList = badChannels.getValue();
        int nBadChan = badChanList.length;
        for (int iC = 0; iC < nChannel; iC++) {
            badChannel[iC] = false;
        }
        padMesh.padGroupSetEnabled(true);
        for (int iBC = 0; iBC < nBadChan; iBC++) {
            badChannel[badChanList[iBC]] = true;
            padMesh.padGroupSetEnabled(badChanList[iBC],false);
        }
        int[][] badChanListForRuns = badChannelsForRuns.getValue();
        int nBadChanForRuns = badChanListForRuns.length;
        int iRun = tpcData.getRunNumber();
        for (int iBCFR = 0; iBCFR < nBadChanForRuns; iBCFR++) {
            if (iRun >= badChanListForRuns[iBCFR][1] && iRun <= badChanListForRuns[iBCFR][2]){
                int iBadC = badChanListForRuns[iBCFR][0];
                badChannel[iBadC] = true;
                padMesh.padGroupSetEnabled(iBadC,false);
            }
        }
        
        // copy iData into data, correct for possible overflows and spikes
        copyData();
        // shift for a baseline of zero
        shiftForPedestal();
        
        // study the noise in each channel
        if (doNoiseStudy.getValue())noiseStudy(fillTuple);
        
        // prepare for tracking studies
        if (doResolutionStudy.getValue() || doTwoTrackStudy.getValue()) {
            // put the data into pad groups of the pad mesh
            assignChargeToPadGroups(fillTuple);
            
            // skip analysis if event vetoed
            if (eventVeto()) return "vetoed";
        }
        if (doResolutionStudy.getValue()) {
            // get a starting point for track fit
            if (!findTrack()) return "no track";
        }
        if (doTwoTrackStudy.getValue()) {
            // use constants provided for track seeds
            seedParam[0] = seedX01.getValue();
            seedParam[1] = seedPhi01.getValue();
            seedParam[2] = seedSigma1.getValue();
            seedParam[3] = seedX02.getValue();
            seedParam[4] = seedPhi02.getValue();
            seedParam[5] = seedSigma2.getValue();
            seedParam[6] = fitGain.getValue();
            seedParam[7] = fitNoise.getValue();
        }
        
        // fill efficiency ntuple elements
        if (doEfficiencyStudy.getValue()) efficiencyStudy(fillTuple);
        
        // do track fit studies for resolution
        int status = 0;
        if (doResolutionStudy.getValue()) {
            status = resolutionStudy(fillTuple);
            if (fillTuple) tuple.fill(iTup++,status);
        }
        
        int status2 = 0;
        if (doTwoTrackStudy.getValue()) {
            status2 = twoTrackStudy(fillTuple);
            if (fillTuple) tuple.fill(iTup++,status2);
        }
        status += status2;
        
        // all events included in ntuple if effeciency study requested. Otherwise only status = 0.
        if (fillTuple && (doEfficiencyStudy.getValue() || status == 0)) {
            tuple.addRow();
        }
        
        return "success";
    }
    
    public void defineBasicParameters(ParameterList pL) {
        // default parent constructor calls this method to set up parameters used by assignChargeToPadGroups
        // since that method is overwritten in this class, it makes sense to overwrite this method too
        pL.setCategory("General settings");
        //              ----------------
        parameterFileComment = new StringParameter(pL,"Desc:","no description",
        "Enter a short description of this parameter set",true);
        runNumber = new IntegerParameter(pL, "Run number", 1, "",
        "Set number to be assigned to this file", false);
        nBadChannels = new IntegerParameter(pL,"# bad chan",2,"",
        "number of bad channels: disregarded in analysis",true);
        int badChan[] = { 0, 1};
        badChannels = new IntegerArrayParameter(pL,nBadChannels,"bad chan",badChan,"chan #",
        "edit list of bad channels",true);
        nBadChannelsForRuns = new IntegerParameter(pL,"# bad chan for runs",2,"",
        "number of bad channels for specific runs", true);
        int badChanForRuns[][] = {{1,100,101},{2,100,102}};
        String labels[] = {"Channel","first run","last run"};
        badChannelsForRuns = new IntegerMatrixParameter(pL, nBadChannelsForRuns, 3, "bad chan for runs",
        badChanForRuns, "chan #", labels, "edit list of bad channels for specific runs", true);
        preScale = new IntegerParameter(pL, "pre-scale", 1,"",
        "enter pre-scale value: only 1 of p-s events are analyzed", true);
        doNoiseStudy = new BooleanParameter(pL, "do noise study", false,
        "create histograms for each channel to identify problem channels",true);
        doEfficiencyStudy = new BooleanParameter(pL, "do efficiency study", true,
        "create ntuple entries to measure hit efficiency",true);
        doResolutionStudy = new BooleanParameter(pL, "do 1 track resolution study", true,
        "perform 1 track fits to determine resolutions, etc.",true);
        doTwoTrackStudy = new BooleanParameter(pL, "do 2 track resolution study", false,
        "perform 2 track fits (turns off 1 track analysis)",true);
        doDEdxStudy = new BooleanParameter(pL, "do dE/dx study", false,
        "fill ntuple for dE/dx quantities - requires 1 track resolution study",true);
        //
        pL.setCategory("Basic pulse finding/fitting");
        //             ----------------------------
        nBinPedestal = new IntegerParameter(pL,"Ped. calc",5,"bins",
        "number of bins for pedestal calculation: if negative, use the last n time bins",true);
        startBinPedestal = new IntegerParameter(pL,"Ped. start",0,"bin",
        "starting bin number for pedestal calculation", true);
        nBinsZeroed = new IntegerParameter(pL, "bins zeroed", 6, "bins",
        "number of initial time bins zeroed", true);
        timeSlice = new BooleanParameter(pL, "Time Slice", false,
        "use only data within the time slice", true);
        timeSliceLow = new IntegerParameter(pL, "Slice Low Edge", 50, "bins",
        "low edge of time slice", true);
        timeSliceHigh = new IntegerParameter(pL, "Slice High Edge",150, "bins",
        "high edge of time slice", true);
        numPadsPeak = new IntegerParameter(pL, "# pads/peak", 4, "",
        "number of neighbouring pads to use for finding peaks", true);
        numBinsPeak = new IntegerParameter(pL, "#bins/peak", 6, "",
        "number of time bins to use for finding peaks", true);
        pulseDelay = new IntegerParameter(pL,"Pulse delay",-5,"bins",
        "delay after peak to use for estimating charge (bins)",true);
        pulseLength = new IntegerParameter(pL,"Pulse length",10,"bins",
        "number of bins to use to average pulse height for estimating charge",true);
        pulseRatio = new DoubleParameter(pL, "Pulse ratio", 1., " ",
        "ratio of before/after peak for induced pulses: used to cancel induced signals", true);
        minPulseLength = new IntegerParameter(pL,"min length", 5, "bins",
        "minimum number of bins available for averaging pulse height",true);
        scaleFactor = new DoubleParameter(pL,"delayed ratio",0.67," ",
        "ratio of relayed pulse height to peak pulse height",true);
        minSignalSize = new DoubleParameter(pL,"min Cluster",200., "",
        "minimum summed signal for cluster hunt algorithm",true);
        gain = new DoubleParameter(pL,"gain",6.,"/fC",
        "number of ADC channels per fC of deposited charge",true);
        pL.setCategory("Selection criteria");
        minElectron = new IntegerParameter(pL,"Min e",7000," ",
        "minimum number of electrons to constitute a signal",true);
        //
        pL.setCategory("Noise simulation");
        addNoise = new BooleanParameter(pL, "add noise", false,
        "add random noise to the pulses", true);
        noiseLevel = new DoubleParameter(pL, "noise level", 2000., "e",
        "standard deviation of the noise to be added", true);
        //
        pL.setCategory("Data error correction");
        correctSpike = new BooleanParameter(pL, "correct spikes", false,
        "remove single time bin spikes from data", true);
        minSpike = new IntegerParameter(pL, "min. spike", 10, "counts",
        "minimum amplitude of spike to correct", true);
        widthSpike = new IntegerParameter(pL, "spike width", 4, "bins",
        "maximum spike width considered", true);
        delSpike = new DoubleParameter(pL, "delta spike", 0.4, " ",
        "minimum ratio of amplitude differences", true);
        //
        correctOverFlow = new BooleanParameter(pL, "correct overflows", true,
        "correct for cases where data has overflowed (STAR)", true);
        lowOverFlow = new IntegerParameter(pL, "low trig", 100, "counts",
        "level below which indicates a possible overflow", true);
        highOverFlow = new IntegerParameter(pL, "high trig", 900, "counts",
        "level that preceeding time bins must have to indicate overflow", true);
        overFlow = new IntegerParameter(pL, "max count", 1024, "counts",
        "amount to add to overflow bins", true);
        pL.resetCategory();
    }
    
    public void copyData() {
        // go through all data, correct for spikes and overflows
        if(correctOverFlow.getValue()){
            int over = overFlow.getValue();
            int lowOver = lowOverFlow.getValue();
            int highOver = highOverFlow.getValue();
            for (int iChan = 0; iChan < nChannel; iChan++) {
                int prevData = over/2;
                for (int jBin = 0; jBin < nTimeBin; jBin++) {
                    data[iChan][jBin] = iData[iChan][jBin];
                    if (prevData > highOver && iData[iChan][jBin] < lowOver) data[iChan][jBin] += over;
                    prevData = iData[iChan][jBin];
                }
            }
        } else {
            for (int iChan = 0; iChan < nChannel; iChan++) {
                for (int jBin = 0; jBin < nTimeBin; jBin++) {
                    data[iChan][jBin] = iData[iChan][jBin];
                }
            }
        }
        // spikes are char0403015 acterized by large change, not preceeded by
        // another such change in previous time bin... then followed
        // by the same behaviour a few time bins later
        if (correctSpike.getValue()) {
            double spikeMin = (double) minSpike.getValue();
            double spikeDel = delSpike.getValue();
            int spikeWidth = widthSpike.getValue();
            
            for (int iChan = 0; iChan < nChannel; iChan++) {
                double dm = data[iChan][1] - data[iChan][0];
                double dm2 = 0.;
                for (int jBin = 2; jBin < nTimeBin-2; jBin++) {
                    dm2 = dm;
                    dm = data[iChan][jBin] - data[iChan][jBin-1];
                    if (Math.abs(dm) > spikeMin && dm2/dm < spikeDel ) {
                        double dp = 0.;
                        double dp2 = data[iChan][jBin+1] - data[iChan][jBin];
                        for (int dj = 0; dj < Math.min(spikeWidth,nTimeBin-jBin-2); dj++) {
                            dp = dp2;
                            dp2 = data[iChan][jBin+dj+2] - data[iChan][jBin+dj+1];
                            if (Math.abs(dp) > spikeMin && dp2/dp < spikeDel && dm*dp < 0.) {
                                for (int ddj = 0; ddj < dj+1; ddj++) {
                                    data[iChan][jBin+ddj] = 0.5*(data[iChan][jBin-1]+data[iChan][jBin+dj+1]);
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void shiftForPedestal() {
        // calculate pedestal for each channel and apply a shift
        // initial time bins are "zeroed"
        // apply time slice if requested
        int nBP = nBinPedestal.getValue();
        int sBP = startBinPedestal.getValue();
        if (nBP < 0) {
            sBP = nTimeBin + nBP;
            nBP *= -1;
        }
        int nBZ = nBinsZeroed.getValue();
        boolean tS = timeSlice.getValue();
        int tSL = Math.min(timeSliceLow.getValue(),nTimeBin);
        int tSH = Math.max(0,timeSliceHigh.getValue()+1);
        
        for (int iChan = 0; iChan < nChannel; iChan++) {
            if (!badChannel[iChan]){
                if (nBP > 0) {
                    double sum = 0;
                    for (int jBin = sBP; jBin < sBP+nBP; jBin++) {
                        sum += data[iChan][jBin];
                    }
                    double avg = sum/nBP;
                    for (int jBin = nBZ; jBin < nTimeBin; jBin++) {
                        data[iChan][jBin] -= avg;
                    }
                    for (int jBin = 0; jBin < nBZ; jBin++) {
                        data [iChan][jBin] = 0.;
                    }
                    if (tS) {
                        for (int jBin = 0; jBin < tSL; jBin++) data[iChan][jBin] = 0.;
                        for (int jBin = tSH; jBin < nTimeBin; jBin++) data[iChan][jBin] = 0.;
                    }
                }
            } else {
                for (int jBin = 0; jBin < nTimeBin; jBin++) {
                    data [iChan][jBin] = 0.;
                }
            }
        }
        // assign pulse data to pads (for interactive pulse display)
        if (padMesh != null)
            for (int iChan = 0; iChan < nChannel; iChan++)
                padMesh.setData(iChan, data[iChan]);
    }
    
    public void assignChargeToPadGroups(boolean fillTuple) {
        // an improved version compared to what is in parent class...
        // keep track of total pulse height for each row
        // remove veto channel code
        if (padMesh == null) return;
        int[][] padGroup = padMesh.getPadGroup();
        padMesh.clear(); // remove any signals in the mesh
        // conversion constant:
        double conv = 1./scaleFactor.getValue()/gain.getValue()/electronCharge;
        int minE = minElectron.getValue();
        int minLen = minPulseLength.getValue();
        // peak finding constants:
        int numPads = numPadsPeak.getValue();
        int delPad = Math.max(1,(numPads+1)/2);
        numPads = delPad*2; // forces numPads to be an even number
        int numBins = numBinsPeak.getValue();
        int delBin = Math.max(1,(numBins+1)/2);
        numBins = delBin*2; // forces numBins to be an even number
        
        // work with one row at a time:
        int nRow = padMesh.getNRow();
        double peakBin = 0.;
        double denom = 0.;
        
        for (int iRow = 0; iRow < nRow; iRow++) {
            
            int nPadGroupInRow = padMesh.padGroupInRow[iRow].length;
            int iPG0 = padMesh.padGroupInRow[iRow][0];
            
            // find clusters of charge spread over numBins in time and numPads in space
            // this is done by first summing the signal in overlapping 2D boxes,
            // ie. reduce the number of grid points in the 2D space
            
            int nPadBox = (nPadGroupInRow+(delPad-1))/delPad;
            int nTimeBox = (nTimeBin+(delBin-1))/delBin;
            double[][] signalBoxes = new double[nPadBox][nTimeBox];
            boolean[][] clusterFound = new boolean[nPadBox][nTimeBox];
            
            int iPadBox = -1;
            for (int iPGOffset = 0; iPGOffset < nPadGroupInRow; iPGOffset += delPad) {
                iPadBox++;
                int iPGStart = iPG0 + iPGOffset;
                int iPGEnd = Math.min(iPG0 + nPadGroupInRow, iPGStart + numPads);
                int iTimeBox = -1;
                for (int iTBStart = 0; iTBStart < nTimeBin; iTBStart += delBin) {
                    iTimeBox++;
                    int iTBEnd = Math.min(nTimeBin,iTBStart+numBins);
                    double sumSignal = 0.;
                    // evaluate total signal in this box
                    for (int iPG = iPGStart; iPG < iPGEnd ; iPG++) {
                        for (int iTB = iTBStart; iTB < iTBEnd; iTB++) sumSignal += data[iPG][iTB];
                    }
                    signalBoxes[iPadBox][iTimeBox] = sumSignal;
                    clusterFound[iPadBox][iTimeBox] = false;
                }
            }
            
            // hunt for the centre of clusters...
            // for the row-wise information (timing for eg) use only the largest cluster (for single track analyses)
            
            double signalSizeMin = -1.*minSignalSize.getValue();
            signalInRow[iRow] = 0.;
            numClusterInRow[iRow] = 0;
            leftBefore[iRow] = 9999.;
            leftAfter[iRow] = 9999.;
            rightBefore[iRow] = -9999.;
            rightAfter[iRow] = -9999.;
            double minAllPeaks = 999.;
            double rowPeakBin = -999.;
            for (int iPBox = 0; iPBox < nPadBox; iPBox++){
                for (int iTBox = 0; iTBox < nTimeBox; iTBox++) {
                    signalInRow[iRow] = Math.min(signalInRow[iRow], signalBoxes[iPBox][iTBox]);
                    if (signalBoxes[iPBox][iTBox] < signalSizeMin) {
                        int[] centre = hunt(signalBoxes,iPBox,iTBox);
                        if (!clusterFound[centre[0]][centre[1]]) {
                            clusterFound[centre[0]][centre[1]] = true;
                            numClusterInRow[iRow]++;
                            // add cluster to padmesh
                            int PG = iPG0 + (centre[0]+1)*delPad;
                            int TB = (centre[1]+1)*delBin;
                            // find the peak time for the pad with the largest pulse:
                            double minPeak = 999.;
                            int iPeakBin = -999;
                            int iPGPeak = -1;
                            for (int iPG = Math.max(iPG0,PG-numPads); iPG < Math.min(iPG0+nPadGroupInRow,PG+numPads);iPG++) {
                                int t0 = Math.max(0,TB-numBins);
                                int t1 = Math.min(nTimeBin,TB+numBins);
                                // only look for the largest pulse
                                double[] peakData = getPeakData(data[iPG],t0,t1,0,1.);
                                if (peakData[1] < minPeak) {
                                    minPeak = peakData[1];
                                    iPeakBin = (int) peakData[2];
                                    iPGPeak = iPG;
                                }
                                // now also evaluate the special sum
                                peakData = getPeakData(data[iPG],t0,t1,iPeakBin,pulseRatio.getValue());
                                if (peakData[1] < minAllPeaks) {
                                    minAllPeaks = peakData[1];
                                    rowPeakBin = peakData[2];
                                    // row wise information for ntuples
                                    sumInRow[iRow] = peakData[0];
                                    peakInRow[iRow] = peakData[1];
                                    timeInRow[iRow] = rowPeakBin;
                                }
                            }
                            
                            // find the charges from this cluster to assign to each pad
                            int time0 = Math.max(iPeakBin + pulseDelay.getValue(),0);
                            int time1 = Math.min(iPeakBin + pulseDelay.getValue() + pulseLength.getValue(),nTimeBin);
                            int timeLength = time1 - time0 + 1;
                            rowSumInRow[iRow]=0.;
                            numPadHitInRow[iRow] = 0;
                            if (iPeakBin >= 0 && timeLength >= minLen) {
                                for (int iPG = Math.max(iPG0,iPGPeak-numPads); iPG < Math.min(iPG0+nPadGroupInRow,iPGPeak+numPads);iPG++) {
                                    double[] peakData = getPeakData(data[iPG],time0,time1,iPeakBin,pulseRatio.getValue());
                                    int nElectron = (int) (-1.*peakData[0]*conv);
                                    if (addNoise.getValue()) nElectron += (int) (noiseLevel.getValue()*rand.nextGaussian());
                                    if (nElectron > minE) {
                                        rowSumInRow[iRow] += peakData[0];
                                        padMesh.addNElectron(iPG,nElectron,iPeakBin);
                                        numPadHitInRow[iRow]++;
                                    }
                                    if (iPG == iPGPeak-1) {
                                        leftBefore[iRow] = peakData[3];
                                        leftAfter[iRow] = peakData[4];
                                    } else if (iPG == iPGPeak+1) {
                                        rightBefore[iRow] = peakData[3];
                                        rightAfter[iRow] = peakData[4];
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (rowPeakBin >=0.) {
                peakBin += rowPeakBin;
                denom += 1.;
            }
        }
        // save the simple average t0 of all rows:
        peakBin /= denom;
        if (storePulseDetails.getValue()) {
            if (fillTuple) tuple.fill(iTup++,peakBin);
        }
    }
    
    int[] hunt(double[][] data, int i0, int j0) {
        // scan around the starting point for the largest value... continue until
        // largest "connected" value is found: not the most efficient, but easy to code
        int[] result = new int[2];
        int ilen = data.length;
        int jlen = data[0].length;
        double minVal = 999.;
        for (int i = Math.max(0,i0-1); i < Math.min(ilen,i0+2); i++) {
            for (int j = Math.max(0,j0-1); j < Math.min(jlen,j0+2); j++) {
                if (data[i][j] < minVal) {
                    minVal = data[i][j];
                    result[0] = i;
                    result[1] = j;
                }
            }
        }
        if (result[0] == i0 && result[1] == j0) return result;
        return hunt(data, result[0], result[1]);
    }
    
    public double[] getPeakInfo(double[] array, int numBins) {
        int nBin = array.length;
        int numSum = Math.min(numBins,nBin);
        int[] binSum = new int[nBin];
        for (int iBin = 0; iBin < nBin; iBin++) binSum[iBin] = 0;
        int runSum = 0;
        for (int iBin = 0; iBin < numSum; iBin++) {
            runSum += array[iBin];
        }
        for (int iBin = 0; iBin < nBin; iBin++) {
            binSum[iBin] = runSum;
            runSum -= array[iBin];
            if (iBin + numSum < nBin) runSum += array[iBin+numSum];
        }
        double minValue = 9.E9;
        double minSum = 9.E9;
        int minBin = -1;
        for (int iBin = 0; iBin < nBin; iBin++) {
            if(binSum[iBin] < minSum) {
                minBin = iBin;
                minSum = binSum[iBin];
                minValue = array[Math.min(iBin+numSum/2,nBin-1)];
            }
        }
        double[] info = new double[3];
        info[0] = minSum;
        info[1] = minValue;
        info[2] = Math.min(minBin + numSum/2., (double) nBin-1);
        
        return info;
    }
    
    public double[] getPeakData(double[] array, int t0, int t1, int tPeak, double ratio) {
        
        // return data about peaks
        // [0] is a weighted sum, designed to cancel out induced signals (for ratio = 2)
        // [1] is the peak value
        // [2] is the peak position
        // [3] is before sum
        // [4] is after sum
        
        double sum = 0.;
        double min = 999.;
        int iPeakBin = -999;
        
        double before = 2./(1.+ratio);
        double after = 2.*ratio/(1.+ratio);
        double bsum = 0.;
        double asum = 0.;
        
        for (int iBin = t0; iBin < t1; iBin++) {
            if (iBin < tPeak) bsum += array[iBin];
            else if (iBin == tPeak) sum += array[iBin];
            else if (iBin > tPeak) asum += array[iBin];
            
            if (array[iBin] < min) {
                min = array[iBin];
                iPeakBin = iBin;
            }
        }
        
        sum += bsum*before + asum*after;
        
        double[] info = new double[5];
        info[0] = sum;
        info[1] = min;
        info[2] = iPeakBin;
        info[3] = bsum;
        info[4] = asum;
        
        return info;
    }
    
    public void noiseStudySetup() {
        pL.setCategory("Noise Study");
        firstChannelNoise = new IntegerParameter(pL, "first channel", 0, "",
        "lowest channel number to produce noise histograms", true);
        lastChannelNoise = new IntegerParameter(pL, "last channel", 255, "",
        "highest channel number to produce noise histograms", true);
        rand = new java.util.Random();
    }
    
    public void efficiencyStudySetup() {
        pL.setCategory("Efficiency Study");
        nEffRows = new IntegerParameter(pL,"# eff rows",2,"",
        "number of rows to use for efficiency study",true);
        int effR[] = { 3, 4};
        effRows = new IntegerArrayParameter(pL,nEffRows,"eff rows",effR,"row",
        "edit row number to include in efficiency study",true);
    }
    
    public void resolutionStudySetup() {
        pL.setCategory("Resolution Study");
        //              ----------------
        storePulseDetails = new BooleanParameter(pL, "store pulse details", false,
        "store row by row pulse details (time, peak, induction info) in ntuple", true);
        maxX0 = new DoubleParameter(pL, "max X0", 26., "mm",
        "maximum absolute value for X0 to be considered for resolution study", true);
        maxAvgPeak = new DoubleParameter(pL, "max avg peak", 500., "",
        "maximum average peak value for event to be considered for resolution study (noise veto)",true);
        nFitRows = new IntegerParameter(pL,"# fit rows",8,"",
        "number of rows to use for reference fit",true);
        int fR[] = { 0, 1, 3, 4, 5, 6, 8, 9};
        fitRows = new IntegerArrayParameter(pL,nFitRows,"fit rows",fR,"row",
        "edit row number to include in reference track fits (res. rows automatically removed in 1 track studies)",true);
        fitSigma = new DoubleParameter(pL,"fit sigma",1.,"mm",
        "initial sigma for track fit",true);
        fitStraight = new BooleanParameter(pL, "fit straight tracks", true,
        "select this option to fit straight tracks (B=0)", true);
        fitResRow = new BooleanParameter(pL, "fit resol. row", false,
        "select this to include the resolution row in the reference track fit", false);
        
        fitGain = new DoubleParameter(pL,"fit gain",3000.,"",
        "gain value for fit",true);
        fitNoise = new DoubleParameter(pL,"fit noise",0.01,"",
        "noise probability for fit",true);
        
        nResRows = new IntegerParameter(pL,"# res rows",4,"",
        "number of rows to study resolution",true);
        int rR[] = { 3, 4, 5, 6};
        resRows = new IntegerArrayParameter(pL,nResRows,"res rows",rR,"row",
        "edit row number to include as a resolution study row",true);
        
        twoParFit = new BooleanParameter(pL, "do 2 par fit study", true,
        "select this option to include the study with sigma fixed by drift time", true);
        sigmaSlope = new DoubleParameter(pL,"sigma slope",1.5609E-4,"mm^2/bin",
        "slope of sigma^2 vs. time bin: used to calculate sigma for 2 par fit",true);
        sigmaOffset = new DoubleParameter(pL,"sigma offset",0.22201,"mm^2",
        "offset of sigma^2 vs. time bin: used to calculate sigma for 2 par fit",true);
        
        doChannelResponseStudy = new BooleanParameter(pL, "do channel response study", false,
        "compare observed and expected signals for each channel",true);
        firstChannelResponse = new IntegerParameter(pL, "first channel", 0, "",
        "lowest channel number to produce response data", true);
        lastChannelResponse = new IntegerParameter(pL, "last channel", 255, "",
        "highest channel number to produce response data", true);
    }
    
    public void twoTrackStudySetup() {
        pL.setCategory("2 Track Study");
        //              ----------------
        seedX01 = new DoubleParameter(pL, "x0_1", -10., "mm",
        "seed x0 (mm) for track 1", true);
        seedPhi01 = new DoubleParameter(pL, "phi0_1", 0., "",
        "seed phi0 (rad) for track 1",true);
        seedSigma1 = new DoubleParameter(pL, "sigma_1", 1., "",
        "sigma (mm) for track 1",true);
        seedX02 = new DoubleParameter(pL, "x0_2", 10., "mm",
        "seed x0 (mm) for track 2", true);
        seedPhi02 = new DoubleParameter(pL, "phi0_2", 0., "",
        "seed phi0 (rad) for track 2",true);
        seedSigma2 = new DoubleParameter(pL, "sigma_2", 1., "",
        "sigma (mm) for track 2",true);
    }
    
    public void dEdxStudySetup() {
        pL.setCategory("dE/dx Study");
        //              -----------
        nDEdxSkipRows = new IntegerParameter(pL,"# of rows to skip",0,"",
        "number of rows to ignore in dE/dx analysis",true);
        int sR[] = {};
        dEdxSkipRows = new IntegerArrayParameter(pL,nDEdxSkipRows,"rows to skip",sR,"row",
        "edit row numbers to be skipped in dE/dx analysis",true);
        nDEdxTrunc = new IntegerParameter(pL,"# of truncations",3,"",
        "number of truncations to consider in dE/dx analysis",true);
        int trunc[] = {0,1,2};
        dEdxTrunc = new IntegerArrayParameter(pL,nDEdxTrunc,"# of rows truncated",trunc,"rows",
        "edit number of rows truncated (max and min) in dE/dx analysis",true);
    }
    
    public int[] getRowsToFit() {
        if (nFitRows.getValue() > 0) return fitRows.getValue();
        else return null;
    }
    
    public void tupleSetup(ITupleFactory tf) {
        String columnString = "int run=0; int event=0; int time=0";
        
        if (doResolutionStudy.getValue()) {
            columnString += "; double tx0 = -999.";
            columnString += "; double code = -999.; double ke = -999.; double tpt = -999."; // particle id code, kinetic energy, pt
        }
        
        if (doNoiseStudy.getValue()) {
            for (int iChan = firstChannelNoise.getValue(); iChan <= lastChannelNoise.getValue(); iChan++) {
                columnString += "; double rms" + iChan + " = -999.";
                columnString += "; double nE" + iChan + " = -999.";
            }
        }
        
        if (doResolutionStudy.getValue() || doTwoTrackStudy.getValue()) {
            if (storePulseDetails.getValue()) {
                columnString += "; double udtb = -999.";
            }
        }
        
        if (doEfficiencyStudy.getValue()) {
            int effR[] = effRows.getValue();
            for (int i=0; i < effR.length; i++) {
                columnString += "; double sigrow" + effR[i] + " = -999.";
                columnString += "; int nclus" + effR[i] + " = -1";
            }
        }
        
        if (doResolutionStudy.getValue()) {
            columnString += "; double apeak=-999.";
            int fR[] = fitRows.getValue();
            for (int i=0; i < fR.length; i++) {
                columnString += "; double rsum" + fR[i] + " = -999.";
                columnString += "; int n" + fR[i] + " = -1";
                if (storePulseDetails.getValue()) {
                    columnString += "; double t" + fR[i] + " = -999.";
                    columnString += "; double sum" + fR[i] + " = -999.";
                    columnString += "; double peak" + fR[i] + " = -999.";
                    columnString += "; double lbef" + fR[i] + " = -999.";
                    columnString += "; double laft" + fR[i] + " = -999.";
                    columnString += "; double rbef" + fR[i] + " = -999.";
                    columnString += "; double raft" + fR[i] + " = -999.";
                }
            }
            columnString += "; int nclmax = 0; int rowclm = -1";
            columnString += "; double z0 = -999.; double tanl = -999.";
            columnString += "; double x0 = -999.; double errx0 = -999.; double phi = -999.";
            columnString += "; double sigma = -999.; double errsig = -999.";
            if (!fitStraight.getValue()) columnString += "; double invR = -999.; double eInvR = -999.";
            
            if (doChannelResponseStudy.getValue()) {
                for (int iChan = firstChannelResponse.getValue(); iChan <= lastChannelResponse.getValue(); iChan++) {
                    columnString += "; double obs" + iChan + " = -999.";
                    columnString += "; double exp" + iChan + " = -999.";
                }
            }
            
            if (doDEdxStudy.getValue()) {
                columnString += "; int nRdEdx = 0";
                int nT = nDEdxTrunc.getValue();
                for (int iT = 0; iT < nT; iT++) {
                    columnString += "; double dEdxy" + iT + "= -999.";
                }
            }
            
            int rR[] = resRows.getValue();
            for (int i=0; i < rR.length; i++) {
                // resolution row not included:
                columnString += "; double dz" + rR[i] + " = -999.";
                columnString += "; double x0n" + rR[i] + " = -999.";
                columnString += "; double dx" + rR[i] + " = -999.";
                columnString += "; double ex" + rR[i] + " = -999.";
                columnString += "; double b" + rR[i] + " = -999.";
                columnString += "; double bn" + rR[i] + " = -999.";
                if(twoParFit.getValue()){
                    columnString += "; double dx2p" + rR[i] + " = -999.";
                }
                // resolution row is included:
                columnString += "; double dzi" + rR[i] + " = -999.";
                columnString += "; double dxi" + rR[i] + " = -999.";
                if(twoParFit.getValue()){
                    columnString += "; double dxi2p" + rR[i] + " = -999.";
                }
            }
            columnString += "; int stat=0";
        }
        
        if (doTwoTrackStudy.getValue()) {
            int fR[] = fitRows.getValue();
            for (int i=0; i < fR.length; i++) {
                columnString += "; double rsum" + fR[i] + " = -999.";
            }
            columnString += "; double x01 = -999.; double errx01 = -999.; double phi1 = -999.; double errph1 = -999.";
            columnString += "; double x02 = -999.; double errx02 = -999.; double phi2 = -999.; double errph2 = -999.";
            columnString += "; int stat=0";
        }
        
        tuple = tf.create( "tuple", "UVic TPC2 analyzer tuple", columnString, "");
        
        if (doNoiseStudy.getValue()) {
            IHistogramFactory hf = af.createHistogramFactory(tree);
            int nHist = lastChannelNoise.getValue() - firstChannelNoise.getValue() + 1;
            if (nHist > 0) {
                noiseHist = new IHistogram1D[nHist];
                for (int iHist = 0; iHist < nHist; iHist++) {
                    int iChan = firstChannelNoise.getValue() + iHist;
                    noiseHist[iHist] = hf.create1D("RMS chan " + iChan,100,0.,50.);
                }
            }
        }
        /*
        if (doResolutionStudy.getValue() || doTwoTrackStudy.getValue()) {
            if (doResolutionStudy.getValue())
                xyFitter = new XYFitter(getPadMesh());
            else
                xyFitter = new XYFitter2(getPadMesh());
            xyFitter.setPNoise(fitNoise.getValue());
            xyFitter.setGain(fitGain.getValue());
        } else xyFitter = null;
         */
        yzFitter = new YZFitter(getPadMesh());
    }
    
    public void noiseStudy(boolean fillTuple) {
        if (fillTuple){
            int tWidth = pulseLength.getValue();
            int tStart = nBinsZeroed.getValue();
            int tRange = startBinPedestal.getValue() - tWidth - tStart;
            int tDelay = pulseDelay.getValue();
            double ratio = pulseRatio.getValue();
            double conv = 1./scaleFactor.getValue()/gain.getValue()/electronCharge;
            int nHist = lastChannelNoise.getValue() - firstChannelNoise.getValue() + 1;
            if (nHist > 0) {
                int first = firstChannelNoise.getValue();
                for (int iHist = 0; iHist < nHist; iHist++) {
                    int iChan = first + iHist;
                    double sum = 0.;
                    double sum2 = 0.;
                    for (int i=0; i<nTimeBin; i++) {
                        sum += data[iChan][i];
                        sum2 += data[iChan][i]*data[iChan][i];
                    }
                    double rms = Math.sqrt(Math.abs(sum2/nTimeBin - (sum*sum)/(nTimeBin*nTimeBin)));
                    noiseHist[iHist].fill(rms);
                    tuple.fill(iTup++,rms);
                    // pick a time at random and look at the signal amplitude there
                    int tRand = tStart + (int) (tRange*rand.nextDouble());
                    double[] peakData = getPeakData(data[iChan],tRand,tRand+tWidth,tRand-tDelay,ratio);
                    double nElectron = (-1.*peakData[0]*conv);
                    tuple.fill(iTup++,nElectron);
                }
            }
        }
    }
    
    public void efficiencyStudy(boolean fillTuple) {
        int[] effR = effRows.getValue();
        if (fillTuple) {
            for (int i=0; i < effR.length; i++) {
                tuple.fill(iTup++,-1.*signalInRow[effR[i]]);  // largest cluster size found in the row
                tuple.fill(iTup++,numClusterInRow[effR[i]]);  // number of clusters found in the row
            }
        }
    }
    
    public int resolutionStudy(boolean fillTuple) {
        // do the complete track fit
        int status = 0;
        if (fillTuple){
            // find average sum in rows: large value is sign of noisy event
            // such events take a long time to fit, so it is best to not fit them
            int[] fitR = fitRows.getValue();
            double avgPeak=0.;
            for (int i = 0; i < fitR.length; i++) avgPeak -= peakInRow[fitR[i]];
            if (fitR.length > 0) avgPeak = avgPeak / fitR.length;
            tuple.fill(iTup++,avgPeak);
            if (avgPeak >= maxAvgPeak.getValue()) status |= 1;
            
            // avoid fitting tracks on the edge, that also can take a long time:
            if (Math.abs(seedParam[0]) >= maxX0.getValue()) status |= 2;
            
            // "raw" info from fitted rows:
            // also find the maximum number of clusters in a row, row number with the maximum:
            int numClusterMax = 0;
            int rowClusterMax = -1;
            for (int i=0; i < fitR.length; i++) {
                if (numClusterInRow[fitR[i]] > numClusterMax) {
                    numClusterMax = numClusterInRow[fitR[i]];
                    if (numClusterMax > 1) rowClusterMax = fitR[i];
                }
                tuple.fill(iTup++,-1*rowSumInRow[fitR[i]]);
                tuple.fill(iTup++, numPadHitInRow[fitR[i]]);
                if (storePulseDetails.getValue()) {
                    tuple.fill(iTup++,timeInRow[fitR[i]]);
                    tuple.fill(iTup++,-1*sumInRow[fitR[i]]);
                    tuple.fill(iTup++,-1*peakInRow[fitR[i]]);
                    tuple.fill(iTup++,leftBefore[fitR[i]]);
                    tuple.fill(iTup++,leftAfter[fitR[i]]);
                    tuple.fill(iTup++,rightBefore[fitR[i]]);
                    tuple.fill(iTup++,rightAfter[fitR[i]]);
                }
            }
            tuple.fill(iTup++,numClusterMax);
            tuple.fill(iTup++,rowClusterMax);
            
            // two parameter track fit in y-z plane:
            double z0 = -9999.;
            yzFitter.setFitRows(fitRows.getValue());
            if (! yzFitter.doFit()) status |= 128;
            if (status == 0) {
                z0 = yzFitter.getParam(0);
                tuple.fill(iTup++,z0); // z0
                tuple.fill(iTup++,yzFitter.getParam(1)); // tan lambda
            } else {
                for (int i=0; i<2; i++) tuple.fill(iTup++,-9999.);
            }
            
            // four parameter track fit in x-y plane:
            xyFitter.setParam(0,seedParam[0],false);
            xyFitter.setParam(1,seedParam[1],false);
            xyFitter.setParam(2,seedParam[2],false);
            xyFitter.setParam(3, 0.,true);
            if(! fitStraight.getValue())xyFitter.setParam(3, 0.,false);
            
            // do an x-y fit with all fit rows: If flag with status bit... skip further fits
            
            xyFitter.setFitRows(fitRows.getValue());
            
            // only try fit if status is zero:
            if (status == 0){
                if (! xyFitter.doFit()) status |= 4;
            }
            
            double x0 = xyFitter.getParam(0);
            double phi = xyFitter.getParam(1);
            double sigma = xyFitter.getParam(2);
            double invR = xyFitter.getParam(3);
            
            if (status == 0) {
                tuple.fill(iTup++,xyFitter.getParam(0));
                tuple.fill(iTup++,xyFitter.getError(0));
                tuple.fill(iTup++,xyFitter.getParam(1));
                tuple.fill(iTup++,xyFitter.getParam(2));
                tuple.fill(iTup++,xyFitter.getError(2));
                
                if (!fitStraight.getValue()){
                    tuple.fill(iTup++,xyFitter.getParam(3));
                    tuple.fill(iTup++,xyFitter.getError(3));
                }
            } else {
                for (int i=0; i<5; i++) tuple.fill(iTup++,-9999.);
                if (!fitStraight.getValue()){
                    for (int i=0; i<2; i++) tuple.fill(iTup++,-9999.);
                }
            }
            
            // look at channel response for all channels: observed & expected values
            if (doChannelResponseStudy.getValue()) {
                double[] expectedElectronInPadGroup = padMesh.getExpectedElectronInPadGroup(xyFitter.getParam(),fitRows.getValue());
                for (int iChan = firstChannelResponse.getValue(); iChan <= lastChannelResponse.getValue(); iChan++) {
                    tuple.fill(iTup++,1.*padMesh.getNElectron(iChan));
                    tuple.fill(iTup++,expectedElectronInPadGroup[iChan]);
                }
            }
            
            if (doDEdxStudy.getValue()){
                dEdxStudy(xyFitter.getParam());
            }
            
            
            int rR[] = resRows.getValue();
            int[] referenceRows;
            
            // loop over resolution rows: remove it from the reference rows (on first pass of next loop)
            for (int iRR = 0; iRR < rR.length; iRR++) {
                // look at residuals for two cases: removing and including the resolution row in the reference fit
                for (int iRefLoop=0; iRefLoop<2; iRefLoop++) {
                    int fR[] = fitRows.getValue();
                    boolean found = false;
                    for (int iFR = 0; iFR < fR.length; iFR++) {if (fR[iFR] == rR[iRR]) found=true;}
                    if (found && iRefLoop==0) {
                        int[] fRX = new int[fR.length - 1];
                        int iPoint = 0;
                        for (int iFR = 0; iFR < fR.length; iFR++) {
                            if (fR[iFR] != rR[iRR]) {
                                fRX[iPoint] = fR[iFR];
                                iPoint++;
                            }
                        }
                        referenceRows = fRX;
                    } else {
                        referenceRows = fR;
                    }
                    
                    // do reference yz fit, and find deviation from it
                    yzFitter.setFitRows(referenceRows);
                    if (! yzFitter.doFit()) status |= 256;
                    tuple.fill(iTup++, yzFitter.getResidual(rR[iRR]));
                    
                    xyFitter.setParam(0,seedParam[0],false);
                    xyFitter.setParam(1,seedParam[1],false);
                    xyFitter.setParam(2,seedParam[2],false);
                    xyFitter.setParam(3, 0.,true);
                    if(! fitStraight.getValue())xyFitter.setParam(3, 0.,false);
                    
                    // do reference xy fit (if status is good)
                    xyFitter.setFitRows(referenceRows);
                    if (status == 0) {
                        if (! xyFitter.doFit()) status |= 8;
                    }
                    
                    x0 = xyFitter.getParam(0);
                    phi = xyFitter.getParam(1);
                    sigma = xyFitter.getParam(2);
                    invR = xyFitter.getParam(3);
                    
                    // b Value of reference fit on this row
                    double bN = padMesh.getBValue(xyFitter.getParam(),rR[iRR]);
                    
                    // fix parameters to do resolution row fit
                    xyFitter.setParam(0,x0,false);
                    xyFitter.setParam(1,phi,true);
                    xyFitter.setParam(2,sigma,true);
                    xyFitter.setParam(3,invR,true);
                    
                    int rR1[] = new int[1];
                    rR1[0] = rR[iRR];
                    xyFitter.setFitRows(rR1);
                    boolean oneRowFitStatus = false;
                    if (status == 0) {
                        oneRowFitStatus = xyFitter.doFit();
                    }
                    
                    if (iRefLoop == 0) {
                        if (status == 0 && oneRowFitStatus) {
                            tuple.fill(iTup++,x0);
                            tuple.fill(iTup++,xyFitter.getParam(0)-x0);
                            tuple.fill(iTup++,xyFitter.getError(0));
                            tuple.fill(iTup++,padMesh.getBValue(xyFitter.getParam(),rR[iRR]));
                            tuple.fill(iTup++,bN);
                        } else {
                            for (int i=0; i<5; i++) tuple.fill(iTup++,-9999.);
                        }
                    } else {
                        if (status == 0 && oneRowFitStatus) {
                            tuple.fill(iTup++,xyFitter.getParam(0)-x0);
                        } else {
                            tuple.fill(iTup++,-9999.);
                        }
                    }
                    
                    // two parameter track fit: calculate sigma from drift time
                    if (twoParFit.getValue()) {
                        double sig2 = sigmaOffset.getValue() + sigmaSlope.getValue()*z0;
                        double sigFix = Math.sqrt(Math.max(0.0001,sig2));
                        xyFitter.setParam(0,seedParam[0],false);
                        xyFitter.setParam(1,seedParam[1],false);
                        xyFitter.setParam(2,sigFix,true);
                        xyFitter.setParam(3, 0., fitStraight.getValue());
                        xyFitter.setFitRows(referenceRows);
                        if (status == 0) {
                            if (! xyFitter.doFit()) status |= 32;
                        }
                        double x02p = xyFitter.getParam(0);
                        double phi2p = xyFitter.getParam(1);
                        double invR2p = xyFitter.getParam(3);
                        
                        xyFitter.setParam(0,x02p,false);
                        xyFitter.setParam(1,phi2p,true);
                        xyFitter.setParam(2,sigFix,true);
                        xyFitter.setParam(3,invR2p,true);
                        rR1[0] = rR[iRR];
                        xyFitter.setFitRows(rR1);
                        if (status == 0) {
                            if (! xyFitter.doFit()) status |= 64;
                        }
                        tuple.fill(iTup++,xyFitter.getParam(0)-x02p);
                    }
                }
            }
        }
        return status;
    }
    
    public int twoTrackStudy(boolean fillTuple) {
        // do studies of 2 laser tracks
        int status = 0;
        if (fillTuple){
            int[] fitR = fitRows.getValue();
            for (int i=0; i < fitR.length; i++) {
                tuple.fill(iTup++,-1*rowSumInRow[fitR[i]]);
            }
            
            xyFitter.setParam(0,seedParam[0],false);
            xyFitter.setParam(1,seedParam[1],false);
            xyFitter.setParam(2,seedParam[2],true);
            xyFitter.setParam(3,seedParam[3],false);
            xyFitter.setParam(4,seedParam[4],false);
            xyFitter.setParam(5,seedParam[5],true);
            
            xyFitter.setFitRows(fitRows.getValue());
            
            if (!xyFitter.doFit()) status = 1;
            
            if (status == 0) {
                tuple.fill(iTup++,xyFitter.getParam(0));
                tuple.fill(iTup++,xyFitter.getError(0));
                tuple.fill(iTup++,xyFitter.getParam(1));
                tuple.fill(iTup++,xyFitter.getError(1));
                tuple.fill(iTup++,xyFitter.getParam(3));
                tuple.fill(iTup++,xyFitter.getError(3));
                tuple.fill(iTup++,xyFitter.getParam(4));
                tuple.fill(iTup++,xyFitter.getError(4));
            } else {
                for (int i=0; i<8; i++) tuple.fill(iTup++,-9999.);
            }
        }
        return status;
    }
    
    public void dEdxStudy(double[] param){
        // conversion constant:
        double conv = 1./scaleFactor.getValue()/gain.getValue()/electronCharge;
        
        // make array of values of rdEdx : the number of electrons / transverse track length across row (mm)
        // the correction for dip angle has to be done at tuple analysis stage: once drift velocity is known
        int nRow = padMesh.getNRow();
        boolean[] useRow = new boolean[nRow];
        for (int iRow=0; iRow<nRow; iRow++){
            useRow[iRow] = true;
        }
        
        int nSkip = nDEdxSkipRows.getValue();
        int[] rowSkip = dEdxSkipRows.getValue();
        for (int i=0; i<nSkip; i++){
            useRow[rowSkip[i]] = false;
        }
        
        int nZero = 0;
        for (int iRow=0; iRow<nRow; iRow++) {
            if (useRow[iRow] && rowSumInRow[iRow]==0.){
                nZero++;
                useRow[iRow] = false;
            }
        }
        
        int nRdEdx = nRow - nSkip - nZero;
        tuple.fill(iTup++,nRdEdx);
        if (nRdEdx > 0){
            double[] rDEdx = new double[nRdEdx];
            int j = -1;
            for (int iRow=0; iRow<nRow; iRow++){
                if(useRow[iRow]){
                    j++;
                    rDEdx[j] = (rowSumInRow[iRow]*conv*-1.)/padMesh.getTransverseTrackLength(param,iRow);
                }
            }
            java.util.Arrays.sort(rDEdx);

            int nTrunc = nDEdxTrunc.getValue();
            int[] trunc = dEdxTrunc.getValue();
            for (int i=0; i<nTrunc; i++){
                int nT = trunc[i];
                if (nRdEdx > 2*nT){
                    double sum = 0;
                    for (int iR=nT; iR<nRdEdx-nT; iR++){
                        sum+=rDEdx[iR];
                    }
                    tuple.fill(iTup++,sum/(nRdEdx-2*nT));
                } else tuple.fill(iTup++,-999.);
            }
        } else {
            int nTrunc = nDEdxTrunc.getValue();
            for (int i=0; i<nTrunc; i++) tuple.fill(iTup++,-999.);
        }   
    }
    
    
    // ---------------- //
    //  EVENT VETO CODE //
    // ---------------- //
    
    public void eventVetoSetup() {
        pL.setCategory("Event veto");
        //             -----------
        minHitRow = new IntegerParameter(pL,"# rows hit",4,"",
        "minimum number of rows hit",true);
        minHitLevel = new IntegerParameter(pL,"min hit",10000,"e",
        "minimum number of electrons to be considered a hit",true);
    }
    
    public boolean eventVeto(){
        // count number of rows with a hit
        int minHit = minHitLevel.getValue();
        int nRow = padMesh.getNRow();
        int hitCount = 0;
        for (int iRow = 0; iRow < nRow; iRow++) {
            int nPadGroupInRow = padMesh.padGroupInRow[iRow].length;
            boolean hit = false;
            int iPadGroupInRow = 0;
            while (!hit && iPadGroupInRow < nPadGroupInRow) {
                int iPadGroup = padMesh.padGroupInRow[iRow][iPadGroupInRow];
                hit = padMesh.getNElectron(iPadGroup) >= minHit;
                iPadGroupInRow++;
            }
            if (hit) hitCount++;
        }
        
        return (hitCount < minHitRow.getValue());
    }
    
    /** Get a rough estimate of track parameters: a starting point for track fits.
     *  Designed with multiplexed PadRowLayouts in mind, but valid for all padMeshes
     */
    
    public void findTrackSetup() {
        pL.setCategory("Track Finder");
        //             -------------
        seedRow0 = new IntegerParameter(pL,"seed row 0",1,"",
        "set row number to seed track finder",true);
        seedRow1 = new IntegerParameter(pL,"seed row 1",8,"",
        "set row number to seed track finder",true);
        seedPadWidth = new DoubleParameter(pL,"seed pad width",2.5,"mm",
        "width of the seed row pads (if <=0 ignored)",true);
        minHitTrack = new IntegerParameter(pL,"min hits",6,"",
        "min # of rows with hits along track defined by seeds",true);
        nSkipRows = new IntegerParameter(pL,"# rows to skip",4,"",
        "number of rows to skip in track finding",true);
        int sR[] = { 2, 4, 5, 7};
        skipRows = new IntegerArrayParameter(pL,nSkipRows,"rows to skip",sR,"row",
        "edit row numbers to be skipped in track finding", true);
    }
    
    public boolean findTrack() {
        // setup and checks
        seedParam[0] = 0.;
        seedParam[1] = 0.;
        seedParam[2] = fitSigma.getValue();
        seedParam[3] = fitGain.getValue();
        seedParam[4] = fitNoise.getValue();
        seedParam[5] = 0.;
        
        int seedRows[] = new int[2];
        seedRows[0] = seedRow0.getValue();
        seedRows[1] = seedRow1.getValue();
        double seedPadW = seedPadWidth.getValue();
        if (Math.min(seedRows[0],seedRows[1]) < 0 ||
        Math.max(seedRows[0],seedRows[1]) >= padMesh.getNRow() ||
        seedRows[0] == seedRows[1]) return false;
        
        // Find padGroup with maximum signal in each of the two seed rows
        int minHit = minHitLevel.getValue();
        int maxNE[] = { 0, 0};
        int seedPadGroup[] = { -1, -1};
        for (int iSeed = 0; iSeed < 2; iSeed++) {
            int nPadGroupInRow = padMesh.padGroupInRow[seedRows[iSeed]].length;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padMesh.padGroupInRow[seedRows[iSeed]][iPadGroupInRow];
                int nE = padMesh.getNElectron(iPadGroup);
                if (nE > maxNE[iSeed] && nE >= minHit) {
                    maxNE[iSeed] = nE;
                    seedPadGroup[iSeed] = iPadGroup;
                }
            }
        }
        if (Math.min(maxNE[0],maxNE[1]) < minHit) return false;
        
        // Loop over all possible pairs of hits (in multiplexed layouts) in
        // the two seed rows and count the number of pads that have hits
        // along the seed track. Select the track with most hits
        
        int padGroup[][] = padMesh.getPadGroup();
        TwoDimenLayout layout = padMesh.getLayout();
        
        // specify which rows to count:
        int nRow = padMesh.getNRow();
        boolean useRow[] = new boolean[nRow];
        for (int iRow = 0; iRow < nRow; iRow++) useRow[iRow] = true;
        int sR[] = skipRows.getValue();
        for (int iSR = 0; iSR < sR.length; iSR++) useRow[sR[iSR]] = false;
        useRow[seedRows[0]] = false;
        useRow[seedRows[1]] = false;
        
        int maxHits = 0;
        double bestX0 = -999.;
        double bestPhi = -999.;
        Location loc,loc0,loc1;
        loc = new Location();
        loc0 = new Location();
        loc1 = new Location();
        // to improve finding efficiency, move seed pad centres by their width both ways for each combination.
        double[] dPW = {0.,-seedPadW/2.,seedPadW};
        int nW = 1; if (seedPadW > 0.001) nW = 3;
        
        int nPadInGroup0 = padGroup[seedPadGroup[0]].length;
        int nPadInGroup1 = padGroup[seedPadGroup[1]].length;
        for (int iPadInGroup0 = 0; iPadInGroup0 < nPadInGroup0; iPadInGroup0++) {
            int iPad0 = padGroup[seedPadGroup[0]][iPadInGroup0];
            layout.getCentre(iPad0,loc0);
            for (int iW0 = 0; iW0 < nW; iW0++) {
                loc0.x += dPW[iW0];
                for (int iPadInGroup1 = 0; iPadInGroup1 < nPadInGroup1; iPadInGroup1++) {
                    int iPad1 = padGroup[seedPadGroup[1]][iPadInGroup1];
                    layout.getCentre(iPad1,loc1);
                    for (int iW1 = 0; iW1 < nW; iW1++) {
                        loc1.x += dPW[iW1];
                        double phi = Math.atan2(loc0.x-loc1.x,loc1.y-loc0.y);
                        double x0 = loc0.x + loc0.y*Math.tan(phi);
                        
                        // loop over rows to count hits along this candidate track
                        // the 2 seed rows count as 2 hits!
                        int nHit = 2;
                        for (int iRow = 0; iRow < nRow; iRow++) {
                            if (useRow[iRow]) {
                                boolean hit = false;
                                int nPadGroupInRow = padMesh.padGroupInRow[iRow].length;
                                int iPadGroupInRow = 0;
                                while (!hit && iPadGroupInRow < nPadGroupInRow) {
                                    int iPadGroup = padMesh.padGroupInRow[iRow][iPadGroupInRow];
                                    int nE = padMesh.getNElectron(iPadGroup);
                                    if (nE >= minHit) {
                                        int nPadInGroup = padGroup[iPadGroup].length;
                                        int iPadInGroup = 0;
                                        while (!hit && iPadInGroup < nPadInGroup) {
                                            int iPad = padGroup[iPadGroup][iPadInGroup];
                                            layout.getCentre(iPad,loc);
                                            // is track going over this pad?
                                            hit |= layout.insideElement(x0-loc.y*Math.tan(phi),loc.y,iPad);
                                            iPadInGroup++;
                                        }
                                    }
                                    iPadGroupInRow++;
                                }
                                if (hit) nHit++;
                            }
                        }
                        if (nHit > maxHits) {
                            maxHits = nHit;
                            bestX0 = x0;
                            bestPhi = phi;
                        }
                    }
                }
            }
        }
        if (maxHits >= minHitTrack.getValue()) {
            seedParam[0] = bestX0;
            seedParam[1] = bestPhi;
            return true;
        } else {
            return false;
        }
    }
    
    /** Main program
     * @param args Arguments
     */
    public static void main(String[] args){
        // start the analysis...
        Start(new UVicTpc2Analyzer(),args);
    }
    
}
