/*
 * HistoryAnalyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class HistoryAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new HistoryAnalyzer());
    }
    /** Creates a new instance of HistoryAnalyzer */
    public HistoryAnalyzer() {
        setName("History analysis (version 1.3)");
        pL = getParameterList();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        plotCuts();
        
        historyAnalysis();
    }
    
    public void historyAnalysis() {
        
        // rsum distributions
        
        IPlotter plotter = plotterFactory.create(runId + " rsum distribution");
        plotter.setTitle("Rsum plots");
        plotter.createRegions(4,2);
        
        int[] trkRows = trackRows.getValue();
        for (int i=0; i < Math.min(8,trkRows.length); i++) {
            int row = trkRows[i];
            IEvaluator eval = tf.createEvaluator("rsum" + row);
            IHistogram1D rsumH = hf.createHistogram1D(runId + " rsum" + row,60,0.,5000.);
            tuple.project(rsumH,eval,standardCuts);
            plotter.region(i).plot(rsumH);
        }
        plotter.show();
        
        // history plots: gain & event rate
        // ----------------------------------------
        
        // find time range by putting time into a cloud
        IEvaluator timeEval = tf.createEvaluator("time");
        ICloud1D timeCloud = hf.createCloud1D("time cloud");
        tuple.project(timeCloud,timeEval,standardCuts);
        IEvaluator relTimeEval = tf.createEvaluator("(time -" + timeCloud.lowerEdge() +")/3600."); // in hours since start of run
        
        plotter = plotterFactory.create(runId + " Gain/Rate/sigma History (vs hr)");
        plotter.setTitle("History plots");
        plotter.createRegions(4,2);
        
        int nbin = 20;
        for (int i=0; i < Math.min(4,trkRows.length); i++) {
            int row = trkRows[i];
            IEvaluator eval = tf.createEvaluator("rsum" + row);
            IProfile1D sumP1D = hf.createProfile1D("rsum" + row + " vs time (hr)",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
            IFilter sumCuts = tf.createFilter(cuts + " && rsum" + row + " < 3000."); // to reduce variance
            tuple.project(sumP1D,relTimeEval,eval,sumCuts);
            IDataPointSet sumDPS = dpsf.create(runId + " rsum" + row,sumP1D);
            sumDPS.scaleErrors(1./Math.sqrt(sumP1D.allEntries()/nbin));
            //result = fitter.fit(sumDPS,"p0");
            plotter.region(i).plot(sumDPS,dpsStyle);
            //plotter.region(i).plot(result.fittedFunction());
        }
        
        int iregion = Math.min(4,trkRows.length);
        // event rate history
        IEvaluator eval = tf.createEvaluator("event");
        ICloud2D eventCloud = hf.createCloud2D("event cloud");
        tuple.project(eventCloud,relTimeEval,eval,standardCuts);
        plotter.region(iregion++).plot(eventCloud);
        
        // sigma history
        eval = tf.createEvaluator("sigma");
        IProfile1D sigP1D = hf.createProfile1D("sigma vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
        tuple.project(sigP1D,relTimeEval,eval,standardCuts);
        IDataPointSet sigDPS = dpsf.create(runId + " sigma vs time",sigP1D);
        sigDPS.scaleErrors(1./Math.sqrt(sigP1D.allEntries()/nbin));
        plotter.region(iregion++).plot(sigDPS,dpsStyle);
        
        // dx history
        int[] resRows = resolutionRows.getValue();
        if (resRows.length > 0) {
            IProfile1D dxnP1D;
            IDataPointSet dxnDPS;
            IFilter dxCuts;
            if(!fitResRow.getValue()){
                eval = tf.createEvaluator("dx" + resRows[0]);
                dxnP1D = hf.createProfile1D("dx" + resRows[0] + " vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
                dxCuts = tf.createFilter(cuts + "&& dx" + resRows[0] +">-100.");
                tuple.project(dxnP1D,relTimeEval,eval,dxCuts);
                dxnDPS = dpsf.create(runId + " dx" + resRows[0] + " vs time",dxnP1D);
            } else {
                eval = tf.createEvaluator("dxi" + resRows[0]);
                dxnP1D = hf.createProfile1D("dxi" + resRows[0] + " vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
                dxCuts = tf.createFilter(cuts + "&& dxi" + resRows[0] +">-100.");
                tuple.project(dxnP1D,relTimeEval,eval,dxCuts);
                dxnDPS = dpsf.create(runId + " dxi" + resRows[0] + " vs time",dxnP1D);
            }
            
            dxnDPS.scaleErrors(1./Math.sqrt(dxnP1D.allEntries()/nbin));
            plotter.region(iregion++).plot(dxnDPS,dpsStyle);
        }
        
        // invR history
        if (curvedTracking.getValue()) {
            eval = tf.createEvaluator("invR");
            IProfile1D invRhP1D = hf.createProfile1D("invR vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
            tuple.project(invRhP1D,relTimeEval,eval,standardCuts);
            IDataPointSet invRhDPS = dpsf.create(runId + " invR vs time",invRhP1D);
            invRhDPS.scaleErrors(1./Math.sqrt(invRhP1D.allEntries()/nbin));
            plotter.region(iregion++).plot(invRhDPS,dpsStyle);
        }
        
        plotter.show();
        
    }
    
}
