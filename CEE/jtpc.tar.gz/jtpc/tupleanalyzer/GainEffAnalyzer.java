/*
 * GainEffAnalyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class GainEffAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new GainEffAnalyzer());
    }
    /** Creates a new instance of GainEffAnalyzer */
    public GainEffAnalyzer() {
        setName("Gain and Efficiency analysis (version 1.0)");
        pL = getParameterList();
        gainEffAnalysisSetup();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        // plotCuts();
        
        gainEffAnalysis();
    }
    
    IntegerParameter nGainEffRows;
    IntegerArrayParameter gainEffRows;
    
    public void gainEffAnalysisSetup() {
        pL.setCategory("Gain and Efficiency Analysis");
        nGainEffRows = new IntegerParameter(pL, "number of effic rows", 2, "",
        "number of rows with information for efficiency study", true);
        int[] gER = {3,4};
        gainEffRows = new IntegerArrayParameter(pL, nGainEffRows, "efficiency rows", gER, "",
        "edit efficiency rows", true);
    }
    
    public void gainEffAnalysis() {
        
        // PLOT[1] history plots: gain & efficiency
        // ----------------------------------------
        
        // find time range by putting time into a cloud
        IEvaluator timeEval = tf.createEvaluator("time");
        ICloud1D timeCloud = hf.createCloud1D("time cloud");
        tuple.project(timeCloud,timeEval,standardCuts);
        IEvaluator relTimeEval = tf.createEvaluator("(time -" + timeCloud.lowerEdge() +")/3600."); // in hours since start of run
        
        IPlotter plotter = plotterFactory.create(runId + " Gain/Eff History (vs hr)");
        plotter.setTitle("History plots");
        plotter.createRegions(3,2);
        
        int nbin = 20;
        int[] gEffRows =gainEffRows.getValue();
        for (int i=0; i < Math.min(2,gEffRows.length); i++) {
            int row = gEffRows[i];
            IEvaluator eval = tf.createEvaluator("sigrow" + row);
            IProfile1D sumP1D = hf.createProfile1D("sigrow" + row + " vs time (hr)",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/3600.);
            IFilter sumCuts = tf.createFilter(cuts + " && sigrow" + row + " < 3000."); // to reduce variance
            tuple.project(sumP1D,relTimeEval,eval,sumCuts);
            IDataPointSet sumDPS = dpsf.create(runId + " sigrow" + row,sumP1D);
            sumDPS.scaleErrors(1./Math.sqrt(sumP1D.allEntries()/nbin));
            plotter.region(i).plot(sumDPS,dpsStyle);
        }
        
        IHistogram1D[] sigrowH = new IHistogram1D[2];
        for (int i=0; i < Math.min(2,gEffRows.length); i++) {
            int row = gEffRows[i];
            IEvaluator eval = tf.createEvaluator("sigrow" + row);
            sigrowH[i] = hf.createHistogram1D(runId + " sigrow" + row,60,0.,3000.);
            tuple.project(sigrowH[i],eval,standardCuts);
            plotter.region(i+2).plot(sigrowH[i]);
            System.out.println(runId + " Row " + row + " mean amplitude=" + sigrowH[i].mean() + " rms=" + sigrowH[i].rms());
        }
        
        for (int i=0; i < Math.min(2,gEffRows.length); i++) {
            int row = gEffRows[i];
            IEvaluator eval = tf.createEvaluator("nclus" + row);
            IHistogram1D nclusH= hf.createHistogram1D(runId + " nclus" + row,10,0,10);
            tuple.project(nclusH,eval,standardCuts);
            plotter.region(i+4).plot(nclusH);
            double nZero = nclusH.binHeight(0);
            double nOne = nclusH.binHeight(1);
            double all = nclusH.sumAllBinHeights();
            double eff = 1. - nZero/all;
            double feff = ((int) (eff*1000.))/10.;
            double mult = (all - nZero - nOne)/all;
            double fmult = ((int) (mult*1000.))/10.;
            System.out.println(runId + " Row " + row + " efficiency = " + feff + "%,  multi cluster rate = " + fmult + "%");
            
        }
        
        plotter.show();
        
    }
    
}
