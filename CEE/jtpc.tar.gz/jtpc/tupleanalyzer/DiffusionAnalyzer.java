/*
 * DiffusionAnalyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;


/**
 *
 * @author  karlen
 */
public class DiffusionAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new DiffusionAnalyzer());
    }
    /** Creates a new instance of DiffusionAnalyzer */
    public DiffusionAnalyzer() {
        setName("Diffusion analysis (version 1.8)");
        pL = getParameterList();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        plotCuts();
        
        diffusionAnalysis();
    }
    
    public void diffusionAnalysis() {
        
        // diffusion fitting:
        int nDiffBin = nDriftBin.getValue(); 
        double diffBinMin = driftMin.getValue(); 
        double diffBinMax = driftMax.getValue();
 
        // fitting sigma**2 parameters:
        int sig2Bin = 25; double sig2M = 0.5;
        if (magField.getValue() >= 2500) {sig2Bin = 30; sig2M = 0.6;}
        else if (magField.getValue() >= 1500) {sig2Bin = 30; sig2M = 0.9;}
        else if (magField.getValue() >= 900) {sig2Bin = 30; sig2M = 1.2;}
        else if (magField.getValue() >= 450) {sig2Bin = 30; sig2M = 1.5;}
        else if (magField.getValue() >= 100) {sig2Bin = 30; sig2M = 5;}
        else {sig2Bin = 30; sig2M = 15.0;}
        
        IPlotter plotter = plotterFactory.create(runId + " Diffusion");
        plotter.setTitle("Diffusion");
        plotter.createRegions(2,2);
        
        IEvaluator z0Eval = tf.createEvaluator("z0");
        IEvaluator sig2Eval = tf.createEvaluator("sigma*sigma");
        
        ICloud2D sig2Cloud = hf.createCloud2D("sig2 cloud");
        tuple.project(sig2Cloud,z0Eval,sig2Eval,standardCuts);
        
        plotter.region(0).plot(sig2Cloud);
        
        // fit sigma**2 as a function of drift distance
        int ip=0;
        IDataPointSet sigma2DPS= dpsf.create("sigma**2 vs drift",2);
        for (int i=0; i < nDiffBin; i++) {
            double low = diffBinMin + (diffBinMax-diffBinMin)*i/nDiffBin;
            double high = low + (diffBinMax-diffBinMin)/nDiffBin;
            IHistogram1D sig2H = hf.createHistogram1D("sigma2",sig2Bin,0.,sig2M);
            IFilter timeCuts = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high);
            tuple.project(sig2H,sig2Eval,timeCuts);
            int temp = sig2H.allEntries();
            if (temp > 5){
                gauss.setParameter("a",sig2H.maxBinHeight()); fitter.fitParameterSettings("a").setStepSize(0.5);
                gauss.setParameter("mean",sig2H.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",sig2H.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                gauss.setParameter("background",0.); fitter.fitParameterSettings("background").setStepSize(0.05);
                IFitResult result = fitter.fit(sig2H,gauss);
                if (i==0 || i== nDiffBin-1) {
                    int iReg = 3;
                    if (i==0) iReg = 2;
                    plotter.region(iReg).plot(sig2H);
                    plotter.region(iReg).plot(result.fittedFunction());
                }
                
                // result = fitter.fit(sig2H,"g");
                String[] pars = result.fittedParameterNames();
                double val = result.fittedParameter(pars[1]);
                double err = Math.sqrt( result.covMatrixElement(1,1) );
                sigma2DPS.addPoint();
                sigma2DPS.point(ip).coordinate(0).setValue((low+high)/2.);
                sigma2DPS.point(ip).coordinate(1).setValue(val);
                sigma2DPS.point(ip).coordinate(1).setErrorMinus(err);
                sigma2DPS.point(ip).coordinate(1).setErrorPlus(err);
                ip++;
            }
        }
        
        plotter.region(1).plot(sigma2DPS,dpsStyle);
        if (sigma2DPS.size()>1) {
            IFitResult result = fitter.fit(sigma2DPS,"p1");
            plotter.region(1).plot(result.fittedFunction());
            System.out.println("");
            System.out.println("Diffusion fit results:");
            String[] pars = result.fittedParameterNames();
            System.out.println("*** Chi2 "+result.quality());
            for ( int i = 0; i < pars.length; i++ )
                System.out.println(" -"+i+"- "+pars[i]+"  "+result.fittedParameter(pars[i])+" +/- "+Math.sqrt( result.covMatrixElement(i,i)));
            
            double diff = Math.sqrt(Math.abs(result.fittedParameter(pars[1]))/driftVelocity.getValue());
            double ediff = Math.sqrt( result.covMatrixElement(1,1))/result.fittedParameter(pars[1])*diff;
            if(result.fittedParameter(pars[1]) < 0.) diff *=-1.;
            
            double defoc =  Math.sqrt(Math.abs(result.fittedParameter(pars[0])));
            double edefoc = Math.sqrt( result.covMatrixElement(0,0))/result.fittedParameter(pars[0])/2.*defoc;
            
            double fdiff = ((int) (diff*10000))/10.;
            double fediff = ((int) (ediff*10000))/10.;
            double fdefoc = ((int) (defoc*10000))/10.;
            double fedefoc = ((int) (edefoc*10000))/10.;
            
            System.out.println(" ... diffusion constant: " + fdiff + "+/-" + fediff + " um / sqrt(cm)");
            System.out.println(" ... defocussing:        " + fdefoc + "+/-" + fedefoc + " um");
        }
        
        plotter.show();
        
        
        
        // ****************************************************************************************************************
        
        plotter = plotterFactory.create(runId + " Attachment & curvature");
        plotter.setTitle("Attachment and curvature");
        plotter.createRegions(3,2);
        
        int nbin = 20;
        int[] trkRows = trackRows.getValue();
        if (trkRows.length > 0) {
            for (int i=0; i < Math.min(3, trkRows.length); i++) {
                int iRow = trkRows[i];
                IEvaluator eval = tf.createEvaluator("rsum" + iRow);
                IProfile1D sumP1D = hf.createProfile1D("rsum" + iRow + " vs drift",nbin,sig2Cloud.lowerEdgeX(),sig2Cloud.upperEdgeX());
                tuple.project(sumP1D,z0Eval,eval,standardCuts);
                IDataPointSet sumDPS = dpsf.create(runId + " rsum" + iRow + " vs drift",sumP1D);
                sumDPS.scaleErrors(1./Math.sqrt(sumP1D.allEntries()/nbin));
                //result = fitter.fit(sumDPS,"p0");
                plotter.region(i).plot(sumDPS,dpsStyle);
                //plotter.region(i).plot(result.fittedFunction());
            }
        }
        
        IHistogram1D z0H = hf.createHistogram1D(runId + " drift time",nbin,sig2Cloud.lowerEdgeX(),sig2Cloud.upperEdgeX());
        tuple.project(z0H,z0Eval,standardCuts);
        plotter.region(3).plot(z0H);
        
        if(curvedTracking.getValue()) {
            IEvaluator eval = tf.createEvaluator("invR*1000.");
            IHistogram1D invRH = hf.createHistogram1D(runId + " inverse R * 1000",20,-2.,2.);
            tuple.project(invRH,eval,standardCuts);
            plotter.region(4).plot(invRH);
            if (invRH.allEntries()>5) {
                IFitResult result = fitter.fit(invRH,"g");
                plotter.region(4).plot(result.fittedFunction());
            }
            
         /* pull distribution of 1/r:
         eval = tf.createEvaluator("invR/eInvR");
         IHistogram1D pullRH = hf.createHistogram1D(run + " Pull inverse R",12,-3.,3.);
         tuple.project(pullRH,eval,standardCuts);
         result = fitter.fit(pullRH,"g");
         plotter.region(5).plot(pullRH);
         plotter.region(5).plot(result.fittedFunction());
          */
            
            // 1/r vs drift time
            
            IProfile1D invRP1D = hf.createProfile1D("invR vs drift",nbin,sig2Cloud.lowerEdgeX(),sig2Cloud.upperEdgeX());
            tuple.project(invRP1D,z0Eval,eval,standardCuts);
            IDataPointSet invRDPS = dpsf.create(runId + " invR vs drift",invRP1D);
            invRDPS.scaleErrors(1./Math.sqrt(invRP1D.allEntries()/nbin));
            
            plotter.region(5).plot(invRDPS,dpsStyle);
            if (invRDPS.size()>1){
                IFitResult result = fitter.fit(invRDPS,"p1");
                plotter.region(5).plot(result.fittedFunction());
            }
            
        }
        
        
        plotter.show();
        
        
    }
    
}
