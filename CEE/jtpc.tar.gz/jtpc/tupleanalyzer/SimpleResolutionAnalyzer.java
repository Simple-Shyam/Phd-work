/*
 * SimpleResolutionAnalyzer.java
 * - used for files that only include resolution row in reference track fit
 *
 * Created on January 26, 2006, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class SimpleResolutionAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new SimpleResolutionAnalyzer());
    }
    /** Creates a new instance of ResolutionAnalyzer */
    public SimpleResolutionAnalyzer() {
        setName("Simple Resolution analysis (version 1.3)");
        pL = getParameterList();
        resolutionAnalysisSetup();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        // plotCuts();
        
        resolutionAnalysis();
    }
    
    BooleanParameter rphiAnalysis,zAnalysis,rowByRowResults,secondFit,nCutRowbyRow;
    DoubleParameter padPitch,maxPhi,maxTanL;
    IntegerParameter nPhiBin,nTanLBin,nPitchBin,minEntries;
    double[] yRow;
    
    public void resolutionAnalysisSetup() {
        pL.setCategory("Resolution Analysis");
        rphiAnalysis = new BooleanParameter(pL, "Do r-phi resolution study", true,
        "check this box to see r-phi resolution plots", true);
        zAnalysis = new BooleanParameter(pL, "Do z resolution study", true,
        "check this box to see z resolution plots", true);
        rowByRowResults = new BooleanParameter(pL, "Show results for each row", true,
        "check this box to show row by row plots", true);
        nCutRowbyRow = new BooleanParameter(pL, "Apply npad cut for row by row results", false,
        "check  this box if you want to require npad > 1 for systematic studies", true);
        minEntries = new IntegerParameter(pL, "minimum entries", 20, "",
        "minimum number of entries in a histogram to fit for mean and std dev", true);
        secondFit = new BooleanParameter(pL, "secondary fits included", false,
        "check this box if two track fits were performed (for comparison)",true);
        padPitch = new DoubleParameter(pL, "pad pitch", 2., "mm",
        "enter the pad Pitch", true);
        nPitchBin = new IntegerParameter(pL, "n b bins", 20, "",
        "enter the number of bins in b for resol vs b plots", true);
        nPhiBin = new IntegerParameter(pL, "n phi bins",12, "",
        "number of phi bins to show resolution vs. phi",true);
        maxPhi = new DoubleParameter(pL, "max phi", 0.15, "rad",
        "maximum |phi| for resolution vs. phi",true);
        nTanLBin = new IntegerParameter(pL, "n tanl bins",12, "",
        "number of phi bins to show resolution vs. tanl",true);
        maxTanL = new DoubleParameter(pL, "max tanl", 0.3, "rad",
        "maximum |tanl| for resolution vs. tanl",true);
        
        // y centres of each row: needed to calculate x coordinate along row for systematic studies (info not in ntuple)
        yRow = new double[80];
        for (int i=0; i<32; i++) yRow[i]=275.5-8*i;
        for (int i=0; i<32; i++) yRow[i+32]=-27.5-8*i;
        for (int i=0; i<8; i++) yRow[i+64]=324.5-6*i;
        for (int i=0; i<8; i++) yRow[i+72]=-282.5-6*i;
    }
    
    public void resolutionAnalysis() {
        
        // r-phi resolution studies
        // ------------------------
        
        boolean rbr = rowByRowResults.getValue();
        int minHistEntries = minEntries.getValue();
        
        if (rphiAnalysis.getValue()){
            int nsigbin = nDriftBin.getValue();
            int nPhi = nPhiBin.getValue();
            int nTanL = nTanLBin.getValue();
            double sigbinmin = driftMin.getValue();
            double sigbinmax = driftMax.getValue();
            
            // fitting dx parameters
            int ndxbin = 30; double dxm = 3.0;
            
            int[] resRows = resolutionRows.getValue();
            IHistogram1D dxiHAll= hf.createHistogram1D(runId + " dxi all",ndxbin,-dxm,dxm);
            IHistogram1D pullxiHAll = hf.createHistogram1D(runId + " pull dxi for all rows",12,-3.,3.);
            IHistogram1D[] dxiH = new IHistogram1D[resRows.length];
            IHistogram1D[] dxitHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dxiPhiHAll = new IHistogram1D[nPhi];
            IHistogram1D[] dxiTanLHAll = new IHistogram1D[nTanL];
            for (int i=0; i<nsigbin; i++) dxitHAll[i] = hf.createHistogram1D("dxiN tbin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nPhi; i++) dxiPhiHAll[i] = hf.createHistogram1D("dxiN Phibin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nTanL; i++) dxiTanLHAll[i] = hf.createHistogram1D("dxiN TanLbin" + i,ndxbin,-dxm,dxm);
            for (int ir=0; ir < resRows.length; ir++) {
                int row = resRows[ir];
                dxiH[ir] = hf.createHistogram1D(runId + " dxi" + resRows[ir],ndxbin,-dxm,dxm);
            }
            IDataPointSet[] resolDPS = new IDataPointSet[resRows.length];
            
            int nbBin = nPitchBin.getValue(); // number of bins to divide plots vs b into
            IHistogram1D[] dxiBHAll = new IHistogram1D[nbBin];
            for (int i=0; i<nbBin; i++) dxiBHAll[i] = hf.createHistogram1D("dxi vs b All",ndxbin,-dxm,dxm);
            IHistogram1D[] dxiBNHAll = new IHistogram1D[nbBin];
            for (int i=0; i<nbBin; i++) dxiBNHAll[i] = hf.createHistogram1D("dxi vs b All n>1",ndxbin,-dxm,dxm);
            
            int nnBin = 4; // number of pads hit in a row to divide resolution plots
            IHistogram1D[] dxiNHAll = new IHistogram1D[nnBin];
            for (int i=0; i<nnBin; i++) dxiNHAll[i] = hf.createHistogram1D("dxi for n="+(i+1)+" All",ndxbin,-dxm,dxm);
            
            IHistogram1D[] bNHAll = new IHistogram1D[nnBin];
            for (int i=0; i<nnBin; i++) bNHAll[i] = hf.createHistogram1D("b for n="+(i+1)+" All",nbBin,-padPitch.getValue()/2.,padPitch.getValue()/2.);
            
            IHistogram1D[] phiNHAll = new IHistogram1D[nnBin];
            for (int i=0; i<nnBin; i++) phiNHAll[i] = hf.createHistogram1D("phi for n="+(i+1)+" All",nPhiBin.getValue(),-maxPhi.getValue(),maxPhi.getValue());
            
            for (int ir=0; ir < resRows.length; ir++) {
                
                int row = resRows[ir];
                IPlotter plotter = null;
                if (rbr) {
                    plotter = plotterFactory.create(runId + " Resolution row " + row);
                    plotter.setTitle("Resolution");
                    plotter.createRegions(4,2);
                }
                
                IEvaluator dxiEval = tf.createEvaluator("dxi" + row);
                
                IFilter rangeCuts = tf.createFilter(cuts + " && abs(dxi" + row + ")<" + dxm);
                tuple.project(dxiH[ir],dxiEval,rangeCuts);
                tuple.project(dxiHAll,dxiEval,rangeCuts);
                
                IEvaluator eval = tf.createEvaluator("dxi" + row + "/sqrt(exi" + row + "*exi" + row + " + errx0*errx0)");
                IHistogram1D pullxiH = hf.createHistogram1D(runId + " pull x for row " + row,12,-3.,3.);
                tuple.project(pullxiH,eval,standardCuts);
                tuple.project(pullxiHAll,eval,standardCuts);
                if (pullxiH.allEntries()>minHistEntries){
                    IFitResult result = fitter.fit(pullxiH,"g");
                    // plotter.region(1).plot(pullxH);
                    // plotter.region(1).plot(result.fittedFunction());
                    String[] pars = result.fittedParameterNames();
                    System.out.println("Pull dist for row " + row + " mean = " +
                    result.fittedParameter(pars[1]) + " +/-" +
                    Math.sqrt( result.covMatrixElement(1,1) ) + " s.d. = " +
                    Math.abs(result.fittedParameter(pars[2])) + " +/-  " +
                    Math.sqrt( result.covMatrixElement(2,2) ) );
                }
                
                // fill histos for resolution vs phi
                double phiMax = Math.abs(maxPhi.getValue());
                double delta = 2.*phiMax/nPhi;
                double lowPhi = -1.*phiMax-delta;
                double highPhi = -1.*phiMax;
                for (int i=0; i < nPhi; i++) {
                    lowPhi += delta;
                    highPhi += delta;
                    IFilter phiCutsI = tf.createFilter(cuts + " && phi >=" + lowPhi + " && phi < " + highPhi + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxiPhiHAll[i],dxiEval,phiCutsI);
                }
                
                // fill histos for resolution vs tanL
                double tanLMax = Math.abs(maxTanL.getValue());
                delta = 2.*tanLMax/nTanL;
                double lowTanL = -1.*tanLMax-delta;
                double highTanL = -1.*tanLMax;
                for (int i=0; i < nTanL; i++) {
                    lowTanL += delta;
                    highTanL += delta;
                    IFilter tanLCutsI = tf.createFilter(cuts + " && tanl >=" + lowTanL + " && tanl < " + highTanL + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxiTanLHAll[i],dxiEval,tanLCutsI);
                }
                
                // fill histos for resolution vs npads hits
                for (int i=0; i < nnBin; i++) {
                    IFilter nCutsI = tf.createFilter(cuts + " && n"+row+"=="+(i+1)  + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxiNHAll[i],dxiEval,nCutsI);
                }
                
                // fill histo b distribution for different n pads hit
                IEvaluator bEval = tf.createEvaluator("bn" + row);
                for (int i=0; i < nnBin; i++) {
                    IFilter nCutsI = tf.createFilter(cuts + " && n"+row+"=="+(i+1));
                    tuple.project(bNHAll[i],bEval,nCutsI);
                }
                
                // fill histo phi distribution for different n pads hit
                IEvaluator phiEval = tf.createEvaluator("phi");
                for (int i=0; i < nnBin; i++) {
                    IFilter nCutsI = tf.createFilter(cuts + " && n"+row+"=="+(i+1));
                    tuple.project(phiNHAll[i],phiEval,nCutsI);
                }
                
                // fit resol and bias as a function of drift distance
                resolDPS[ir]= dpsf.create(runId + " resol(" + row + ") vs drift",2);
                IDataPointSet dxZ0DPS= dpsf.create(runId + " bias vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCutsI = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxitHAll[i],dxiEval,timeCutsI);
                    
                    if (rbr) {
                        IHistogram1D dxitH = hf.createHistogram1D("dxi",ndxbin,-dxm,dxm);
                        tuple.project(dxitH,dxiEval,timeCutsI);
                        gauss.setParameter("a",dxitH.maxBinHeight());
                        gauss.setParameter("mean",dxitH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxitH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxitH.allEntries()>minHistEntries) {
                            IFitResult result = fitter.fit(dxitH,gauss);
                            //result = fitter.fit(dxtH,"g");
                            String[] pars = result.fittedParameterNames();
                            
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxZ0DPS.addPoint();ii++;
                            dxZ0DPS.point(ii).coordinate(0).setValue((low+high)/2.);
                            dxZ0DPS.point(ii).coordinate(1).setValue(val);
                            dxZ0DPS.point(ii).coordinate(1).setErrorMinus(err);
                            dxZ0DPS.point(ii).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2));
                            
                            resolDPS[ir].addPoint();
                            resolDPS[ir].point(ii).coordinate(0).setValue((low+high)/2.);
                            resolDPS[ir].point(ii).coordinate(1).setValue(valx);
                            resolDPS[ir].point(ii).coordinate(1).setErrorMinus(errx);
                            resolDPS[ir].point(ii).coordinate(1).setErrorPlus(errx);
                            
                            
                        }
                    }
                }
                if (rbr) {
                    plotter.region(0).plot(dxZ0DPS,dpsStyle);
                    plotter.region(1).plot(resolDPS[ir],dpsStyle);
                }
                
                // plot dx and sd(dx) vs local x
                if (rbr) {
                    int nx0Bin = 20;
                    double x0BinMin = -x0Range.getValue();
                    double x0BinMax = x0Range.getValue();
                    
                    String ncut = "";
                    if (nCutRowbyRow.getValue())ncut = " n>1";
                    IDataPointSet dxiX0DPS= dpsf.create(runId + " bias vs local x" + ncut,2);
                    IDataPointSet resX0DPS= dpsf.create(runId + " resol vs local x" + ncut,2);
                    int iii=-1;
                    for (int i=0; i < nx0Bin; i++) {
                        double low = x0BinMin + (x0BinMax-x0BinMin)*i/nx0Bin;
                        double high = low + (x0BinMax-x0BinMin)/nx0Bin;
                        double y = yRow[row];
                        IHistogram1D dxiX0H = hf.createHistogram1D("dxi",ndxbin,-dxm,dxm);
                        // IFilter x0Cuts = tf.createFilter(cuts + " && x0 >=" + low + " && x0 < " + high + " && abs(dxi" + row + ")<" + dxm);
                        IFilter x0Cuts = tf.createFilter(cuts + " && x0-tan(phi)*"+y+" >=" + low + " && x0-tan(phi)*"+y+" < " + high + " && abs(dxi" + row + ")<" + dxm);
                        if (nCutRowbyRow.getValue()) x0Cuts = tf.createFilter(cuts + "&& n"+row+">1" + " && x0-tan(phi)*"+y+" >=" + low + " && x0-tan(phi)*"+y+" < " + high + " && abs(dxi" + row + ")<" + dxm);
                        tuple.project(dxiX0H,dxiEval,x0Cuts);
                        gauss.setParameter("a",dxiX0H.maxBinHeight());
                        gauss.setParameter("mean",dxiX0H.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiX0H.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxiX0H.allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dxiX0H,gauss);
                            // result = fitter.fit(dxX0H,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                                double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            if(result.isValid() && Math.abs(val)<10. && valx<10.){
                                dxiX0DPS.addPoint();iii++;
                                dxiX0DPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                dxiX0DPS.point(iii).coordinate(1).setValue(val);
                                dxiX0DPS.point(iii).coordinate(1).setErrorMinus(err);
                                dxiX0DPS.point(iii).coordinate(1).setErrorPlus(err);

                                resX0DPS.addPoint();
                                resX0DPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                resX0DPS.point(iii).coordinate(1).setValue(valx);
                                resX0DPS.point(iii).coordinate(1).setErrorMinus(errx);
                                resX0DPS.point(iii).coordinate(1).setErrorPlus(errx);
                            }
                        }
                    }
                    
                    plotter.region(2).plot(dxiX0DPS,dpsStyle);
                    plotter.region(3).plot(resX0DPS,dpsStyle);
                    
                    // plot dx and sd(dx) vs b
                    
                    double bBinMin = -padPitch.getValue()/2.;
                    double bBinMax = padPitch.getValue()/2.;
                    
                    IDataPointSet dxBDPS= dpsf.create(runId + " bias vs b" + ncut,2);
                    IDataPointSet resBDPS= dpsf.create(runId + " resol vs b" + ncut,2);
                    
                    iii=-1;
                    for (int i=0; i < nbBin; i++) {
                        double low = bBinMin + (bBinMax-bBinMin)*i/nbBin;
                        double high = low + (bBinMax-bBinMin)/nbBin;
                        IHistogram1D dxiBH = hf.createHistogram1D("dxi vs b ",ndxbin,-dxm,dxm);
                        IFilter bCuts = tf.createFilter(cuts + " && bn"+row+" >=" + low + " && bn"+row+" < " + high + " && abs(dxi" + row + ")<" + dxm);
                        IFilter bnCuts = tf.createFilter(cuts + " && n"+row+" >1 && bn"+row+" >=" + low + " && bn"+row+" < " + high + " && abs(dxi" + row + ")<" + dxm);
                        if (nCutRowbyRow.getValue())tuple.project(dxiBH,dxiEval,bnCuts);
                        else tuple.project(dxiBH,dxiEval,bCuts);
                        tuple.project(dxiBHAll[i],dxiEval,bCuts);
                        tuple.project(dxiBNHAll[i],dxiEval,bnCuts);
                        gauss.setParameter("a",dxiBH.maxBinHeight());
                        gauss.setParameter("mean",dxiBH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiBH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxiBH.allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dxiBH,gauss);
                            // result = fitter.fit(dxBH,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                                                            double valx = Math.abs(result.fittedParameter(pars[2]));
                                double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            if(result.isValid() && Math.abs(val)<10. && valx<10.){
                                dxBDPS.addPoint();iii++;
                                dxBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                dxBDPS.point(iii).coordinate(1).setValue(val);
                                dxBDPS.point(iii).coordinate(1).setErrorMinus(err);
                                dxBDPS.point(iii).coordinate(1).setErrorPlus(err);

                                resBDPS.addPoint();
                                resBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                resBDPS.point(iii).coordinate(1).setValue(valx);
                                resBDPS.point(iii).coordinate(1).setErrorMinus(errx);
                                resBDPS.point(iii).coordinate(1).setErrorPlus(errx);
                            }
                        }
                    }
                    
                    plotter.region(4).plot(dxBDPS,dpsStyle);
                    plotter.region(5).plot(resBDPS,dpsStyle);
                    
                    
                    // plot dx and sd(dx) vs phi
                    
                    double phiBinMin = 0.;
                    double phiBinMax = maxPhi.getValue();
                    
                    IDataPointSet dxPhiDPS= dpsf.create(runId + " bias vs phi" + ncut,2);
                    IDataPointSet resPhiDPS= dpsf.create(runId + " resol vs phi" + ncut,2);
                    
                    iii=-1;
                    for (int i=0; i < nPhi; i++) {
                        double low = phiBinMin + (phiBinMax-phiBinMin)*i/nPhi;
                        double high = low + (phiBinMax-phiBinMin)/nPhi;
                        IHistogram1D dxiPhiH = hf.createHistogram1D("dxi vs phi ",ndxbin,-dxm,dxm);
                        IFilter phiCuts = tf.createFilter(cuts + " && phi >=" + low + " && phi < " + high + " && abs(dxi" + row + ")<" + dxm);
                        if(nCutRowbyRow.getValue())phiCuts = tf.createFilter(cuts + "&& n"+row+">1" +  " && phi >=" + low + " && phi < " + high + " && abs(dxi" + row + ")<" + dxm);
                        tuple.project(dxiPhiH,dxiEval,phiCuts);
                        gauss.setParameter("a",dxiPhiH.maxBinHeight());
                        gauss.setParameter("mean",dxiPhiH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiPhiH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxiPhiH.allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dxiPhiH,gauss);
                            // result = fitter.fit(dxBH,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );                               
                                double valx = Math.abs(result.fittedParameter(pars[2]));
                                double errx = Math.sqrt( result.covMatrixElement(2,2) );
                                
                            if(result.isValid() && Math.abs(val)<10. && valx<10.){
                                dxPhiDPS.addPoint();iii++;
                                dxPhiDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                dxPhiDPS.point(iii).coordinate(1).setValue(val);
                                dxPhiDPS.point(iii).coordinate(1).setErrorMinus(err);
                                dxPhiDPS.point(iii).coordinate(1).setErrorPlus(err);

                                resPhiDPS.addPoint();
                                resPhiDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                                resPhiDPS.point(iii).coordinate(1).setValue(valx);
                                resPhiDPS.point(iii).coordinate(1).setErrorMinus(errx);
                                resPhiDPS.point(iii).coordinate(1).setErrorPlus(errx);
                            }
                        }
                    }
                    
                    plotter.region(6).plot(dxPhiDPS,dpsStyle);
                    plotter.region(7).plot(resPhiDPS,dpsStyle);
                    
                    
                    plotter.show();
                }
            }
            
            if (resRows.length > 1) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " Residuals all rows");
                plotter.setTitle("Residuals All Rows");
                plotter.createRegions(3,2);
                
                for (int ir=0; ir < Math.min(6,resRows.length); ir++) {
                    
                    gauss.setParameter("a",dxiH[ir].maxBinHeight());
                    gauss.setParameter("mean",dxiH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxiH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                    plotter.region(ir).plot(dxiH[ir]);
                    if (dxiH[ir].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dxiH[ir],gauss);
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " Resolution all rows");
                plotter.setTitle("Resolution All Rows");
                plotter.createRegions(2,2);
                
                gauss.setParameter("a",dxiHAll.maxBinHeight());
                gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",0.2); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dxiHAll);
                if (dxiHAll.allEntries()>minHistEntries){
                    IFitResult result = fitter.fit(dxiHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                plotter.region(1).plot(pullxiHAll);
                if (pullxiHAll.allEntries()>minHistEntries){
                    IFitResult result = fitter.fit(pullxiHAll,"g");
                    plotter.region(1).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet resolDPSAll= dpsf.create(runId + " resol vs drift",2);
                IDataPointSet resol2DPSAll= dpsf.create(runId + " resol2 vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    
                    gauss.setParameter("a",dxitHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxitHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxitHAll[i].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dxitHAll[i],gauss);
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        resolDPSAll.addPoint();ii++;
                        resolDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        resolDPSAll.point(ii).coordinate(1).setValue(valx);
                        resolDPSAll.point(ii).coordinate(1).setErrorMinus(errx);
                        resolDPSAll.point(ii).coordinate(1).setErrorPlus(errx);
                        resol2DPSAll.addPoint();
                        resol2DPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        resol2DPSAll.point(ii).coordinate(1).setValue(valx*valx);
                        resol2DPSAll.point(ii).coordinate(1).setErrorMinus(2.*valx*errx);
                        resol2DPSAll.point(ii).coordinate(1).setErrorPlus(2.*valx*errx);
                        
                    }
                }
                
                plotter.region(2).plot(resolDPSAll,dpsStyle);
                
                //result = fitter.fit(resol2DPSAll,"p1");
                plotter.region(3).plot(resol2DPSAll,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                plotter.show();
                
                
                plotter = af.createPlotterFactory().create(runId + " Extra Resolution plots");
                plotter.setTitle("Resolution vs Phi, b etc");
                plotter.createRegions(3,2);
                
                // plot resolution as a function of phi and tanl
                
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet resolPhiDPSAll= dpsf.create(runId + " resol vs phi",2);
                ii=-1;
                double phiMax = Math.abs(maxPhi.getValue());
                double delta = 2.*phiMax/nPhi;
                double midPhi = -1.*phiMax-delta/2.;
                for (int i=0; i < nPhi; i++) {
                    midPhi += delta;
                    
                    gauss.setParameter("a",dxiPhiHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxiPhiHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxiPhiHAll[i].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dxiPhiHAll[i],gauss);
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        resolPhiDPSAll.addPoint();ii++;
                        resolPhiDPSAll.point(ii).coordinate(0).setValue(midPhi);
                        resolPhiDPSAll.point(ii).coordinate(1).setValue(valx);
                        resolPhiDPSAll.point(ii).coordinate(1).setErrorMinus(errx);
                        resolPhiDPSAll.point(ii).coordinate(1).setErrorPlus(errx);
                        
                    }
                }
                
                plotter.region(0).plot(resolPhiDPSAll,dpsStyle);
                
                IDataPointSet resolTanLDPSAll= dpsf.create(runId + " resol vs tanl",2);
                ii=-1;
                double tanLMax = Math.abs(maxTanL.getValue());
                delta = 2.*tanLMax/nTanL;
                double midTanL = -1.*tanLMax-delta/2.;
                for (int i=0; i < nTanL; i++) {
                    midTanL += delta;
                    
                    gauss.setParameter("a",dxiTanLHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxiTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxiTanLHAll[i].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dxiTanLHAll[i],gauss);
                        //result = fitter.fit(dxTanLHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        resolTanLDPSAll.addPoint();ii++;
                        resolTanLDPSAll.point(ii).coordinate(0).setValue(midTanL);
                        resolTanLDPSAll.point(ii).coordinate(1).setValue(valx);
                        resolTanLDPSAll.point(ii).coordinate(1).setErrorMinus(errx);
                        resolTanLDPSAll.point(ii).coordinate(1).setErrorPlus(errx);
                        
                    }
                }
                
                plotter.region(1).plot(resolTanLDPSAll,dpsStyle);
                
                if (rbr) {
                    double bBinMin = -padPitch.getValue()/2.;
                    double bBinMax = padPitch.getValue()/2.;
                    
                    IDataPointSet dxBDPS= dpsf.create(runId + " bias vs b All rows",2);
                    IDataPointSet resBDPS= dpsf.create(runId + " resol vs b All rows",2);
                    IDataPointSet dxBNDPS= dpsf.create(runId + " bias vs b All rows, n>1",2);
                    IDataPointSet resBNDPS= dpsf.create(runId + " resol vs b All rows, n>1",2);
                    
                    int iii=-1;int jjj=-1;
                    for (int i=0; i < nbBin; i++) {
                        double low = bBinMin + (bBinMax-bBinMin)*i/nbBin;
                        double high = low + (bBinMax-bBinMin)/nbBin;
                        
                        gauss.setParameter("a",dxiBHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dxiBHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiBHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxiBHAll[i].allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dxiBHAll[i],gauss);
                            
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxBDPS.addPoint();iii++;
                            dxBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                            dxBDPS.point(iii).coordinate(1).setValue(val);
                            dxBDPS.point(iii).coordinate(1).setErrorMinus(err);
                            dxBDPS.point(iii).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            resBDPS.addPoint();
                            resBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                            resBDPS.point(iii).coordinate(1).setValue(valx);
                            resBDPS.point(iii).coordinate(1).setErrorMinus(errx);
                            resBDPS.point(iii).coordinate(1).setErrorPlus(errx);
                            
                        }
                        
                        gauss.setParameter("a",dxiBNHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dxiBNHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiBNHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxiBNHAll[i].allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dxiBNHAll[i],gauss);
                            
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxBNDPS.addPoint();jjj++;
                            dxBNDPS.point(jjj).coordinate(0).setValue((low+high)/2.);
                            dxBNDPS.point(jjj).coordinate(1).setValue(val);
                            dxBNDPS.point(jjj).coordinate(1).setErrorMinus(err);
                            dxBNDPS.point(jjj).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            resBNDPS.addPoint();
                            resBNDPS.point(jjj).coordinate(0).setValue((low+high)/2.);
                            resBNDPS.point(jjj).coordinate(1).setValue(valx);
                            resBNDPS.point(jjj).coordinate(1).setErrorMinus(errx);
                            resBNDPS.point(jjj).coordinate(1).setErrorPlus(errx);
                            
                        }
                        
                    }
                    
                    plotter.region(2).plot(dxBDPS,dpsStyle);
                    plotter.region(3).plot(resBDPS,dpsStyle);
                    plotter.region(4).plot(dxBNDPS,dpsStyle);
                    plotter.region(5).plot(resBNDPS,dpsStyle);
                }
                
                plotter.show();
                
                
                plotter = af.createPlotterFactory().create(runId + " dxi distributions for different b");
                plotter.setTitle("dxi distributions vs b");
                plotter.createRegions(5,2);
                for (int i=0; i<10; i++){
                    plotter.region(i).plot(dxiBHAll[i]);
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " dxi distributions for different b for n>1");
                plotter.setTitle("dxi distributions vs b n>1");
                plotter.createRegions(5,2);
                for (int i=0; i<10; i++){
                    plotter.region(i).plot(dxiBNHAll[i]);
                    if (dxiBNHAll[i].allEntries()>minHistEntries){
                        gauss.setParameter("a",dxiBNHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dxiBNHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiBNHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        IFitResult result = fitter.fit(dxiBNHAll[i],gauss);
                        plotter.region(i).plot(result.fittedFunction());
                    }
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " dxi distributions for different n");
                plotter.setTitle("dxi distributions vs n");
                plotter.createRegions(2,2);
                for (int i=0; i<nnBin; i++){
                    plotter.region(i).plot(dxiNHAll[i]);
                    if (dxiNHAll[i].allEntries()>minHistEntries){
                        gauss.setParameter("a",dxiNHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dxiNHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiNHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        IFitResult result = fitter.fit(dxiNHAll[i],gauss);
                        plotter.region(i).plot(result.fittedFunction());
                    }
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " b distributions for different n");
                plotter.setTitle("b distributions vs n");
                plotter.createRegions(2,2);
                for (int i=0; i<nnBin; i++){
                    plotter.region(i).plot(bNHAll[i]);
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " phi distributions for different n");
                plotter.setTitle("phi distributions vs n");
                plotter.createRegions(2,2);
                for (int i=0; i<nnBin; i++){
                    plotter.region(i).plot(phiNHAll[i]);
                }
                plotter.show();
                
            }
            
            if (mc.getValue()) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " mc info");
                plotter.setTitle("MC info");
                plotter.createRegions(2,2);
                
                IEvaluator eval = tf.createEvaluator("x0-tx0");
                IHistogram1D residHist = hf.createHistogram1D(runId + "true resid",ndxbin, -dxm/2., dxm/2.);
                tuple.project(residHist, eval, standardCuts);
                
                gauss.setParameter("a",residHist.maxBinHeight());
                gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",0.2); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(residHist);
                if (residHist.allEntries()>minHistEntries){
                    IFitResult result = fitter.fit(residHist,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet residDPSAll= dpsf.create(runId + " sigma resid vs drift",2);
                IDataPointSet residCorDPSAll= dpsf.create(runId + " single row resolution vs drift",2);
                double cor = Math.sqrt(6.);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCuts = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high);
                    IHistogram1D residtH = hf.createHistogram1D("resid",ndxbin,-dxm/2.,dxm/2.);
                    tuple.project(residtH,eval,timeCuts);
                    gauss.setParameter("a",residtH.maxBinHeight());
                    gauss.setParameter("background",0.);
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",0.05); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (residtH.allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(residtH,gauss);
                        //result = fitter.fit(dxtHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double val = Math.abs(result.fittedParameter(pars[2]));
                        double err = Math.sqrt( result.covMatrixElement(2,2));
                        residDPSAll.addPoint();ii++;
                        residDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        residDPSAll.point(ii).coordinate(1).setValue(val);
                        residDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                        residDPSAll.point(ii).coordinate(1).setErrorPlus(err);
                        
                        residCorDPSAll.addPoint();
                        residCorDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        residCorDPSAll.point(ii).coordinate(1).setValue(val*cor);
                        residCorDPSAll.point(ii).coordinate(1).setErrorMinus(err*cor);
                        residCorDPSAll.point(ii).coordinate(1).setErrorPlus(err*cor);
                        
                    }
                }
                
                plotter.region(2).plot(residDPSAll,dpsStyle);
                plotter.region(3).plot(residCorDPSAll,dpsStyle);
                
                plotter.show();
                
            }
            
        }
        
        
        // z resolution studies
        // ----------------------
        
        
        if (zAnalysis.getValue()){
            
            // fitting dz parameters
            int nsigbin = nDriftBin.getValue();
            int nTanL = nTanLBin.getValue();
            double sigbinmin = driftMin.getValue();
            double sigbinmax = driftMax.getValue();
            int ndzbin = 20; double dzm = 4.;
            int[] resRows = resolutionRows.getValue();
            
            IHistogram1D dziHAll= hf.createHistogram1D(runId + " dzi all",ndzbin,-dzm,dzm);
            IHistogram1D[] dziH = new IHistogram1D[resRows.length];
            IHistogram1D[] dzitHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dziTanLHAll = new IHistogram1D[nTanL];
            for (int i=0; i<nsigbin; i++) dzitHAll[i] = hf.createHistogram1D("dziN tbin" + i,ndzbin,-dzm,dzm);
            for (int i=0; i<nTanL; i++) dziTanLHAll[i] = hf.createHistogram1D("dziN TanL bin" + i,ndzbin,-dzm,dzm);
            for (int ir=0; ir < resRows.length; ir++) {
                int row = resRows[ir];
                dziH[ir] = hf.createHistogram1D(runId + " dzi" + resRows[ir],ndzbin,-dzm,dzm);
            }
            IDataPointSet[] zresolDPS = new IDataPointSet[resRows.length];
            
            for (int ir=0; ir < resRows.length; ir++) {
                
                int row = resRows[ir];
                IPlotter plotter = null;
                if (rbr) {
                    plotter = plotterFactory.create(runId + " z Resolution row " + row);
                    plotter.setTitle("z Resolution");
                    plotter.createRegions(3,2);
                }
                
                IEvaluator dziEval = tf.createEvaluator("dzi" + row);
                
                IFilter rangeCuts = tf.createFilter(cuts + " && abs(dzi" + row + ")<" + dzm);
                tuple.project(dziH[ir],dziEval,rangeCuts);
                tuple.project(dziHAll,dziEval,rangeCuts);
                
                // fit sigma as a function of drift distance
                zresolDPS[ir]= dpsf.create(runId + " z resol(" + row + ") vs drift",2);
                IDataPointSet zresol2DPS= dpsf.create(runId + " z resol**2 vs drift",2);
                IDataPointSet dzZ0DPS= dpsf.create(runId + " z bias vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCutsI = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dzi" + row + ")<" + dzm);
                    tuple.project(dzitHAll[i],dziEval,timeCutsI);
                    
                    if (rbr) {
                        IHistogram1D dzitH = hf.createHistogram1D("dzi",ndzbin,-dzm,dzm);
                        tuple.project(dzitH,dziEval,timeCutsI);
                        gauss.setParameter("a",dzitH.maxBinHeight());
                        gauss.setParameter("mean",dzitH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                        gauss.setParameter("sigma",dzitH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dzitH.allEntries()>minHistEntries){
                            IFitResult result = fitter.fit(dzitH,gauss);
                            String[] pars = result.fittedParameterNames();
                            
                            if (i<4) {
                                plotter.region(2+i).plot(dzitH);
                                plotter.region(2+i).plot(result.fittedFunction());
                            }
                            
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dzZ0DPS.addPoint();ii++;
                            dzZ0DPS.point(ii).coordinate(0).setValue((low+high)/2.);
                            dzZ0DPS.point(ii).coordinate(1).setValue(val);
                            dzZ0DPS.point(ii).coordinate(1).setErrorMinus(err);
                            dzZ0DPS.point(ii).coordinate(1).setErrorPlus(err);
                            
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2));
                            
                            zresolDPS[ir].addPoint();
                            zresolDPS[ir].point(ii).coordinate(0).setValue((low+high)/2.);
                            zresolDPS[ir].point(ii).coordinate(1).setValue(valx);
                            zresolDPS[ir].point(ii).coordinate(1).setErrorMinus(errx);
                            zresolDPS[ir].point(ii).coordinate(1).setErrorPlus(errx);
                            zresol2DPS.addPoint();
                            zresol2DPS.point(ii).coordinate(0).setValue((low+high)/2.);
                            zresol2DPS.point(ii).coordinate(1).setValue(valx*valx);
                            zresol2DPS.point(ii).coordinate(1).setErrorMinus(2.*valx*errx);
                            zresol2DPS.point(ii).coordinate(1).setErrorPlus(2.*valx*errx);
                        }
                    }
                }
                if (rbr) {
                    plotter.region(0).plot(dzZ0DPS,dpsStyle);
                    plotter.region(1).plot(zresolDPS[ir],dpsStyle);
                }
                
                //result = fitter.fit(zresol2DPS,"p1");
                //plotter.region(3).plot(zresol2DPS,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                
                if (rbr) plotter.show();
                
                double tanLMax = Math.abs(maxTanL.getValue());
                for (int i=0; i < nTanL; i++) {
                    double low = -tanLMax + 2*tanLMax*i/nTanL;
                    double high = low + 2*tanLMax/nTanL;
                    IFilter tanLCutsI = tf.createFilter(cuts + " && tanl >=" + low + " && tanl < " + high + " && abs(dzi" + row + ")<" + dzm);
                    tuple.project(dziTanLHAll[i],dziEval,tanLCutsI);
                }
            }
            
            
            if (resRows.length > 1) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " z Residuals all rows");
                plotter.setTitle("z Residuals All Rows");
                plotter.createRegions(3,2);
                
                for (int ir=0; ir < Math.min(6,resRows.length); ir++) {
                    
                    gauss.setParameter("a",dziH[ir].maxBinHeight());
                    gauss.setParameter("mean",dziH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                    gauss.setParameter("sigma",dziH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    plotter.region(ir).plot(dziH[ir]);
                    if (dziH[ir].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dziH[ir],gauss);
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                    
                }
                
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " z Resolution all rows");
                plotter.setTitle("z Resolution All Rows");
                plotter.createRegions(2,2);
                
                gauss.setParameter("a",dziHAll.maxBinHeight());
                gauss.setParameter("mean",dziHAll.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                gauss.setParameter("sigma",dziHAll.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dziHAll);
                if (dziHAll.allEntries()>minHistEntries){
                    IFitResult result = fitter.fit(dziHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet zresolDPSAll= dpsf.create(runId + " z resol vs drift",2);
                IDataPointSet zresol2DPSAll= dpsf.create(runId + " z resol2 vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    
                    gauss.setParameter("a",dzitHAll[i].maxBinHeight());
                    gauss.setParameter("mean",dzitHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dzitHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dzitHAll[i].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dzitHAll[i],gauss);
                        
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        zresolDPSAll.addPoint();ii++;
                        zresolDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        zresolDPSAll.point(ii).coordinate(1).setValue(valx);
                        zresolDPSAll.point(ii).coordinate(1).setErrorMinus(errx);
                        zresolDPSAll.point(ii).coordinate(1).setErrorPlus(errx);
                        zresol2DPSAll.addPoint();
                        zresol2DPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        zresol2DPSAll.point(ii).coordinate(1).setValue(valx*valx);
                        zresol2DPSAll.point(ii).coordinate(1).setErrorMinus(2.*valx*errx);
                        zresol2DPSAll.point(ii).coordinate(1).setErrorPlus(2.*valx*errx);
                    }
                }
                
                plotter.region(2).plot(zresolDPSAll,dpsStyle);
                
                //result = fitter.fit(zresol2DPSAll,"p1");
                plotter.region(3).plot(zresol2DPSAll,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                
                
                IDataPointSet zresolTanLDPSAll= dpsf.create(runId + " z resol vs tanL",2);
                ii=-1;
                double tanLMax = Math.abs(maxTanL.getValue());
                for (int i=0; i < nTanL; i++) {
                    double low = -tanLMax + 2*tanLMax*i/nTanL;
                    double high = low + 2*tanLMax/nTanL;
                    
                    gauss.setParameter("a",dziTanLHAll[i].maxBinHeight());
                    gauss.setParameter("mean",dziTanLHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dziTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dziTanLHAll[i].allEntries()>minHistEntries){
                        IFitResult result = fitter.fit(dziTanLHAll[i],gauss);
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        zresolTanLDPSAll.addPoint();ii++;
                        zresolTanLDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        zresolTanLDPSAll.point(ii).coordinate(1).setValue(valx);
                        zresolTanLDPSAll.point(ii).coordinate(1).setErrorMinus(errx);
                        zresolTanLDPSAll.point(ii).coordinate(1).setErrorPlus(errx);
                    }
                }
                
                plotter.region(1).plot(zresolTanLDPSAll,dpsStyle);
                
                plotter.show();
            }
            
            
        }
        
        if(secondFit.getValue()){
            // two fits performed - compare the track parameters etc.
            
            int nyBin;
            double yMin,yMax;
            IEvaluator yEval;
            IHistogram1D yH;
            String yvar;
            
            // --- x0
            
            IPlotter plotter = af.createPlotterFactory().create(runId + " two fit comparison - x0");
            plotter.setTitle("Two fit comparison - x0");
            plotter.createRegions(3,2);
            
            yvar = "x0b-x0";
            nyBin = 20;
            yMin = -2.;
            yMax = 2.;
            
            yEval = tf.createEvaluator(yvar);
            yH = hf.createHistogram1D(yvar,nyBin,yMin,yMax);
            tuple.project(yH,yEval,standardCuts);
            plotter.region(0).plot(yH);
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minHistEntries){
                IFitResult result = fitter.fit(yH,gauss);
                plotter.region(0).plot(result.fittedFunction());
            }
            
            plotter.region(2).plot(profilePlot(yvar,nyBin,yMin,yMax,"x0",20,-x0Range.getValue(),x0Range.getValue(),cuts,false),dpsStyle);
            plotter.region(3).plot(profilePlot(yvar,nyBin,yMin,yMax,"phi",nPhiBin.getValue(),0.,maxPhi.getValue(),cuts,false),dpsStyle);
            plotter.region(4).plot(profilePlot(yvar,nyBin,yMin,yMax,"z0",nDriftBin.getValue(),driftMin.getValue(),driftMax.getValue(),cuts,false),dpsStyle);
            plotter.region(5).plot(profilePlot(yvar,nyBin,yMin,yMax,"tanl",nTanLBin.getValue(),-maxTanL.getValue(),maxTanL.getValue(),cuts,false),dpsStyle);
            
            plotter.show();
            
            // --- z0
            
            plotter = af.createPlotterFactory().create(runId + " two fit comparison - z0");
            plotter.setTitle("Two fit comparison - z0");
            plotter.createRegions(3,2);
            
            yvar = "z0b-z0";
            nyBin = 20;
            yMin = -5.;
            yMax = 5.;
            
            yEval = tf.createEvaluator(yvar);
            yH = hf.createHistogram1D(yvar,nyBin,yMin,yMax);
            tuple.project(yH,yEval,standardCuts);
            plotter.region(0).plot(yH);
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minHistEntries){
                IFitResult result = fitter.fit(yH,gauss);
                plotter.region(0).plot(result.fittedFunction());
            }
            
            plotter.region(2).plot(profilePlot(yvar,nyBin,yMin,yMax,"x0",20,-x0Range.getValue(),x0Range.getValue(),cuts,false),dpsStyle);
            plotter.region(3).plot(profilePlot(yvar,nyBin,yMin,yMax,"phi",nPhiBin.getValue(),0.,maxPhi.getValue(),cuts,false),dpsStyle);
            plotter.region(4).plot(profilePlot(yvar,nyBin,yMin,yMax,"z0",nDriftBin.getValue(),driftMin.getValue(),driftMax.getValue(),cuts,false),dpsStyle);
            plotter.region(5).plot(profilePlot(yvar,nyBin,yMin,yMax,"tanl",nTanLBin.getValue(),-maxTanL.getValue(),maxTanL.getValue(),cuts,false),dpsStyle);
            
            plotter.show();
            
            // --- phi
            
            plotter = af.createPlotterFactory().create(runId + " two fit comparison - phi");
            plotter.setTitle("Two fit comparison - phi");
            plotter.createRegions(3,2);
            
            yvar = "phib-phi";
            nyBin = 20;
            yMin = -0.02;
            yMax = 0.02;
            
            yEval = tf.createEvaluator(yvar);
            yH = hf.createHistogram1D(yvar,nyBin,yMin,yMax);
            tuple.project(yH,yEval,standardCuts);
            plotter.region(0).plot(yH);
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minHistEntries){
                IFitResult result = fitter.fit(yH,gauss);
                plotter.region(0).plot(result.fittedFunction());
            }
            
            plotter.region(2).plot(profilePlot(yvar,nyBin,yMin,yMax,"x0",20,-x0Range.getValue(),x0Range.getValue(),cuts,false),dpsStyle);
            plotter.region(3).plot(profilePlot(yvar,nyBin,yMin,yMax,"phi",nPhiBin.getValue(),0.,maxPhi.getValue(),cuts,false),dpsStyle);
            plotter.region(4).plot(profilePlot(yvar,nyBin,yMin,yMax,"z0",nDriftBin.getValue(),driftMin.getValue(),driftMax.getValue(),cuts,false),dpsStyle);
            plotter.region(5).plot(profilePlot(yvar,nyBin,yMin,yMax,"tanl",nTanLBin.getValue(),-maxTanL.getValue(),maxTanL.getValue(),cuts,false),dpsStyle);
            
            plotter.show();
            
            // --- sigma
            
            plotter = af.createPlotterFactory().create(runId + " two fit comparison - sigma");
            plotter.setTitle("Two fit comparison - sigma");
            plotter.createRegions(3,2);
            
            yvar = "sigmab-sigma";
            nyBin = 20;
            yMin = -1.;
            yMax = 1.;
            
            yEval = tf.createEvaluator(yvar);
            yH = hf.createHistogram1D(yvar,nyBin,yMin,yMax);
            tuple.project(yH,yEval,standardCuts);
            plotter.region(0).plot(yH);
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minHistEntries){
                IFitResult result = fitter.fit(yH,gauss);
                plotter.region(0).plot(result.fittedFunction());
            }
            
            plotter.region(2).plot(profilePlot(yvar,nyBin,yMin,yMax,"x0",20,-x0Range.getValue(),x0Range.getValue(),cuts,false),dpsStyle);
            plotter.region(3).plot(profilePlot(yvar,nyBin,yMin,yMax,"phi",nPhiBin.getValue(),0.,maxPhi.getValue(),cuts,false),dpsStyle);
            plotter.region(4).plot(profilePlot(yvar,nyBin,yMin,yMax,"z0",nDriftBin.getValue(),driftMin.getValue(),driftMax.getValue(),cuts,false),dpsStyle);
            plotter.region(5).plot(profilePlot(yvar,nyBin,yMin,yMax,"tanl",nTanLBin.getValue(),-maxTanL.getValue(),maxTanL.getValue(),cuts,false),dpsStyle);
            
            plotter.show();
            
            // --- tanl
            
            plotter = af.createPlotterFactory().create(runId + " two fit comparison - tanl");
            plotter.setTitle("Two fit comparison - tanl");
            plotter.createRegions(3,2);
            
            yvar = "tanlb-tanl";
            nyBin = 20;
            yMin = -0.01;
            yMax = 0.01;
            
            yEval = tf.createEvaluator(yvar);
            yH = hf.createHistogram1D(yvar,nyBin,yMin,yMax);
            tuple.project(yH,yEval,standardCuts);
            plotter.region(0).plot(yH);
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minHistEntries){
                IFitResult result = fitter.fit(yH,gauss);
                plotter.region(0).plot(result.fittedFunction());
            }
            
            plotter.region(2).plot(profilePlot(yvar,nyBin,yMin,yMax,"x0",20,-x0Range.getValue(),x0Range.getValue(),cuts,false),dpsStyle);
            plotter.region(3).plot(profilePlot(yvar,nyBin,yMin,yMax,"phi",nPhiBin.getValue(),0.,maxPhi.getValue(),cuts,false),dpsStyle);
            plotter.region(4).plot(profilePlot(yvar,nyBin,yMin,yMax,"z0",nDriftBin.getValue(),driftMin.getValue(),driftMax.getValue(),cuts,false),dpsStyle);
            plotter.region(5).plot(profilePlot(yvar,nyBin,yMin,yMax,"tanl",nTanLBin.getValue(),-maxTanL.getValue(),maxTanL.getValue(),cuts,false),dpsStyle);
            
            plotter.show();
            
        }
        
    }
    
    public IDataPointSet profilePlot(String yvar, int nyBin, double yMin, double yMax, String xvar, int nxBin, double xMin, double xMax, String cuts, boolean doPlot){
        
        IPlotter plotter = null;
        int nPlot = 0;
        if (doPlot) {
            plotter = plotterFactory.create("details:"+yvar);
            plotter.setTitle("details:"+yvar);
            if(nyBin<5){
                plotter.createRegions(2,2);
                nPlot = nyBin;
            } else if (nyBin<9){
                plotter.createRegions(4,2);
                nPlot = nyBin;
            } else {
                plotter.createRegions(4,3);
                nPlot = Math.min(12,nyBin);
            }
        }
        
        IDataPointSet dPS= dpsf.create(yvar+" vs. "+xvar,2);
        IEvaluator yEval = tf.createEvaluator(yvar);
        
        double del = (xMax-xMin)/nxBin;
        double low = xMin-del;
        double high = xMin;
        int ii=-1;
        for (int i=0; i<nxBin; i++){
            low += del; high += del;
            IFilter xCuts = tf.createFilter(cuts+"&&"+xvar+">="+low+"&&"+xvar+"<"+high);
            IHistogram1D yH = hf.createHistogram1D(yvar+" histogram",nyBin,yMin,yMax);
            tuple.project(yH,yEval,xCuts);
            
            gauss.setParameter("a",yH.maxBinHeight());
            gauss.setParameter("mean",yH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
            gauss.setParameter("sigma",yH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
            if (yH.allEntries()>minEntries.getValue()){
                IFitResult result = fitter.fit(yH,gauss);
                
                String[] pars = result.fittedParameterNames();
                double valx = result.fittedParameter(pars[1]);
                double errx = Math.sqrt( result.covMatrixElement(1,1));
                
                dPS.addPoint();ii++;
                dPS.point(ii).coordinate(0).setValue((low+high)/2.);
                dPS.point(ii).coordinate(1).setValue(valx);
                dPS.point(ii).coordinate(1).setErrorMinus(errx);
                dPS.point(ii).coordinate(1).setErrorPlus(errx);
                
                if(doPlot && i<nPlot){
                    plotter.region(i).plot(yH);
                    plotter.region(i).plot(result.fittedFunction());
                }
            }
            
        }
        if (doPlot)plotter.show();
        return dPS;
        
    }
}
