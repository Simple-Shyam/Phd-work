/*
 * ResolutionAnalyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class ResolutionAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new ResolutionAnalyzer());
    }
    /** Creates a new instance of ResolutionAnalyzer */
    public ResolutionAnalyzer() {
        setName("Resolution analysis (version 1.7)");
        pL = getParameterList();
        resolutionAnalysisSetup();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        // plotCuts();
        
        resolutionAnalysis();
    }
    
    BooleanParameter rphiAnalysis,zAnalysis,rowByRowResults;
    DoubleParameter padPitch,maxPhi,maxTanL;
    IntegerParameter nPhiBin,nTanLBin,nPitchBin;
    
    public void resolutionAnalysisSetup() {
        pL.setCategory("Resolution Analysis");
        rphiAnalysis = new BooleanParameter(pL, "Do r-phi resolution study", true,
        "check this box to see r-phi resolution plots", true);
        zAnalysis = new BooleanParameter(pL, "Do z resolution study", true,
        "check this box to see z resolution plots", true);
        rowByRowResults = new BooleanParameter(pL, "Show results for each row", true,
        "check this box to show row by row plots", true);
        padPitch = new DoubleParameter(pL, "pad pitch", 2., "mm",
        "enter the pad Pitch", true);
        nPitchBin = new IntegerParameter(pL, "n b bins", 20, "",
        "enter the number of bins in b for resol vs b plots", true);
        nPhiBin = new IntegerParameter(pL, "n phi bins",12, "",
        "number of phi bins to show resolution vs. phi",true);
        maxPhi = new DoubleParameter(pL, "max phi", 0.15, "rad",
        "maximum |phi| for resolution vs. phi",true);
        nTanLBin = new IntegerParameter(pL, "n tanl bins",12, "",
        "number of phi bins to show resolution vs. tanl",true);
        maxTanL = new DoubleParameter(pL, "max tanl", 0.3, "rad",
        "maximum |tanl| for resolution vs. tanl",true);
    }
    
    public void resolutionAnalysis() {
        
        // r-phi resolution studies
        // ------------------------
        
        boolean rbr = rowByRowResults.getValue();
        
        if (rphiAnalysis.getValue()){
            int nsigbin = nDriftBin.getValue();
            int nPhi = nPhiBin.getValue();
            int nTanL = nTanLBin.getValue();
            double sigbinmin = driftMin.getValue();
            double sigbinmax = driftMax.getValue();
            
            // fitting dx parameters
            int ndxbin = 20; double dxm = 0.4;
            if (magField.getValue() == 900) {ndxbin = 20; dxm = 0.6;}
            if (magField.getValue() == 450) {ndxbin = 20; dxm = 1.;}
            if (magField.getValue() == 0) {ndxbin = 20; dxm = 2.0;}
            
            int[] resRows = resolutionRows.getValue();
            IHistogram1D dxHAll= hf.createHistogram1D(runId + " dx all",ndxbin,-dxm,dxm);
            IHistogram1D dxiHAll= hf.createHistogram1D(runId + " dxi all",ndxbin,-dxm,dxm);
            IHistogram1D pullxHAll = hf.createHistogram1D(runId + " pull dx for all rows",12,-3.,3.);
            IHistogram1D[] dxH = new IHistogram1D[resRows.length];
            IHistogram1D[] dxiH = new IHistogram1D[resRows.length];
            IHistogram1D[] dxtHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dxitHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dxPhiHAll = new IHistogram1D[nPhi];
            IHistogram1D[] dxiPhiHAll = new IHistogram1D[nPhi];
            IHistogram1D[] dxTanLHAll = new IHistogram1D[nTanL];
            IHistogram1D[] dxiTanLHAll = new IHistogram1D[nTanL];
            for (int i=0; i<nsigbin; i++) dxtHAll[i] = hf.createHistogram1D("dxN tbin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nsigbin; i++) dxitHAll[i] = hf.createHistogram1D("dxiN tbin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nPhi; i++) dxPhiHAll[i] = hf.createHistogram1D("dxN Phibin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nPhi; i++) dxiPhiHAll[i] = hf.createHistogram1D("dxiN Phibin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nTanL; i++) dxTanLHAll[i] = hf.createHistogram1D("dxN TanLbin" + i,ndxbin,-dxm,dxm);
            for (int i=0; i<nTanL; i++) dxiTanLHAll[i] = hf.createHistogram1D("dxiN TanLbin" + i,ndxbin,-dxm,dxm);
            for (int ir=0; ir < resRows.length; ir++) {
                int row = resRows[ir];
                dxH[ir] = hf.createHistogram1D(runId + " dx" + row,ndxbin,-dxm,dxm);
                dxiH[ir] = hf.createHistogram1D(runId + " dxi" + resRows[ir],ndxbin,-dxm,dxm);
            }
            IDataPointSet[] resolDPS = new IDataPointSet[resRows.length];
            
            int nbBin = nPitchBin.getValue(); // number of bins to divide plots vs b into
            IHistogram1D[] dxBHAll = new IHistogram1D[nbBin];
            IHistogram1D[] dxiBHAll = new IHistogram1D[nbBin];
            for (int i=0; i<nbBin; i++) dxBHAll[i] = hf.createHistogram1D("dx vs b All",ndxbin,-dxm,dxm);
            for (int i=0; i<nbBin; i++) dxiBHAll[i] = hf.createHistogram1D("dx vs b All",ndxbin,-dxm,dxm);
            
            for (int ir=0; ir < resRows.length; ir++) {
                
                int row = resRows[ir];
                IPlotter plotter = null;
                if (rbr) {
                    plotter = plotterFactory.create(runId + " Resolution row " + row);
                    plotter.setTitle("Resolution");
                    plotter.createRegions(3,2);
                }
                
                IEvaluator dxEval = tf.createEvaluator("dx" + row);
                IEvaluator dxiEval = tf.createEvaluator("dxi" + row);
                
                IFilter rangeCuts = tf.createFilter(cuts + " && abs(dx" + row + ")<" + dxm);
                tuple.project(dxH[ir],dxEval,rangeCuts);
                tuple.project(dxHAll,dxEval,rangeCuts);
                rangeCuts = tf.createFilter(cuts + " && abs(dxi" + row + ")<" + dxm);
                tuple.project(dxiH[ir],dxiEval,rangeCuts);
                tuple.project(dxiHAll,dxiEval,rangeCuts);
                
                IEvaluator eval = tf.createEvaluator("dx" + row + "/sqrt(ex" + row + "*ex" + row + " + errx0*errx0)");
                IHistogram1D pullxH = hf.createHistogram1D(runId + " pull x for row " + row,12,-3.,3.);
                tuple.project(pullxH,eval,standardCuts);
                tuple.project(pullxHAll,eval,standardCuts);
                if (pullxH.allEntries()>5){
                    IFitResult result = fitter.fit(pullxH,"g");
                    // plotter.region(1).plot(pullxH);
                    // plotter.region(1).plot(result.fittedFunction());
                    String[] pars = result.fittedParameterNames();
                    System.out.println("Pull dist for row " + row + " mean = " +
                    Math.abs(result.fittedParameter(pars[1])) + " +/-" +
                    Math.sqrt( result.covMatrixElement(1,1) ) + " s.d. = " +
                    Math.abs(result.fittedParameter(pars[2])) + " +/-  " +
                    Math.sqrt( result.covMatrixElement(2,2) ) );
                }
                
                // fill histos for resolution vs phi
                double phiMax = Math.abs(maxPhi.getValue());
                double delta = 2.*phiMax/nPhi;
                double lowPhi = -1.*phiMax-delta;
                double highPhi = -1.*phiMax;
                for (int i=0; i < nPhi; i++) {
                    lowPhi += delta;
                    highPhi += delta;
                    IFilter phiCuts = tf.createFilter(cuts + " && phi >=" + lowPhi + " && phi < " + highPhi + " && abs(dx" + row + ")<" + dxm);
                    tuple.project(dxPhiHAll[i],dxEval,phiCuts);
                    IFilter phiCutsI = tf.createFilter(cuts + " && phi >=" + lowPhi + " && phi < " + highPhi + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxiPhiHAll[i],dxiEval,phiCutsI);
                }
                
                // fill histos for resolution vs tanL
                double tanLMax = Math.abs(maxTanL.getValue());
                delta = 2.*tanLMax/nTanL;
                double lowTanL = -1.*tanLMax-delta;
                double highTanL = -1.*tanLMax;
                for (int i=0; i < nTanL; i++) {
                    lowTanL += delta;
                    highTanL += delta;
                    IFilter tanLCuts = tf.createFilter(cuts + " && tanl >=" + lowTanL + " && tanl < " + highTanL + " && abs(dx" + row + ")<" + dxm);
                    tuple.project(dxTanLHAll[i],dxEval,tanLCuts);
                    IFilter tanLCutsI = tf.createFilter(cuts + " && tanl >=" + lowTanL + " && tanl < " + highTanL + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxiTanLHAll[i],dxiEval,tanLCutsI);
                }
                
                
                // fit sigma as a function of drift distance
                resolDPS[ir]= dpsf.create(runId + " resol(" + row + ") vs drift",2);
                IDataPointSet resol2DPS= dpsf.create(runId + " resol**2 vs drift",2);
                IDataPointSet dxZ0DPS= dpsf.create(runId + " bias vs drift",2);
                int ii=-1; int jj=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCuts = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dx" + row + ")<" + dxm);
                    tuple.project(dxtHAll[i],dxEval,timeCuts);
                    IFilter timeCutsI = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dxi" + row + ")<" + dxm);
                    tuple.project(dxitHAll[i],dxiEval,timeCutsI);
                    
                    if (rbr) {
                        IHistogram1D dxtH = hf.createHistogram1D("dx",ndxbin,-dxm,dxm);
                        tuple.project(dxtH,dxEval,timeCuts);
                        gauss.setParameter("a",dxtH.maxBinHeight());
                        gauss.setParameter("mean",dxtH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxtH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxtH.allEntries()>5) {
                            IFitResult result = fitter.fit(dxtH,gauss);
                            //result = fitter.fit(dxtH,"g");
                            String[] pars = result.fittedParameterNames();
                            
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxZ0DPS.addPoint();ii++;
                            dxZ0DPS.point(ii).coordinate(0).setValue((low+high)/2.);
                            dxZ0DPS.point(ii).coordinate(1).setValue(val);
                            dxZ0DPS.point(ii).coordinate(1).setErrorMinus(err);
                            dxZ0DPS.point(ii).coordinate(1).setErrorPlus(err);
                            
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2));
                            
                            IHistogram1D dxitH = hf.createHistogram1D("dxi",ndxbin,-dxm,dxm);
                            tuple.project(dxitH,dxiEval,timeCutsI);
                            gauss.setParameter("a",dxitH.maxBinHeight());
                            gauss.setParameter("mean",dxitH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                            gauss.setParameter("sigma",dxitH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                            if (dxitH.allEntries()>5){
                                result = fitter.fit(dxitH,gauss);
                                //result = fitter.fit(dxitH,"g");
                                double vali = Math.abs(result.fittedParameter(pars[2]));
                                double erri = Math.sqrt( result.covMatrixElement(2,2));
                                
                                
                                // to estimate the resolution use geometric mean of residual with and without resolution row included
                                val = Math.sqrt(valx*vali);
                                err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                                
                                resolDPS[ir].addPoint();jj++;
                                resolDPS[ir].point(jj).coordinate(0).setValue((low+high)/2.);
                                resolDPS[ir].point(jj).coordinate(1).setValue(val);
                                resolDPS[ir].point(jj).coordinate(1).setErrorMinus(err);
                                resolDPS[ir].point(jj).coordinate(1).setErrorPlus(err);
                                resol2DPS.addPoint();
                                resol2DPS.point(jj).coordinate(0).setValue((low+high)/2.);
                                resol2DPS.point(jj).coordinate(1).setValue(val*val);
                                resol2DPS.point(jj).coordinate(1).setErrorMinus(2.*val*err);
                                resol2DPS.point(jj).coordinate(1).setErrorPlus(2.*val*err);
                            }
                        }
                    }
                }
                if (rbr) {
                    plotter.region(0).plot(dxZ0DPS,dpsStyle);
                    plotter.region(1).plot(resolDPS[ir],dpsStyle);
                }
                
                //result = fitter.fit(resol2DPS,"p1");
                //plotter.region(3).plot(resol2DPS,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                
                
                // plot dx and sd(dx) vs x0
                if (rbr) {
                    int nx0Bin = 12;
                    double x0BinMin = -24.;
                    double x0BinMax = 24.;
                    
                    IDataPointSet dxX0DPS= dpsf.create(runId + " bias vs x0",2);
                    IDataPointSet resX0DPS= dpsf.create(runId + " resol vs x0",2);
                    int iii=-1; int jjj=-1;
                    for (int i=0; i < nx0Bin; i++) {
                        double low = x0BinMin + (x0BinMax-x0BinMin)*i/nx0Bin;
                        double high = low + (x0BinMax-x0BinMin)/nx0Bin;
                        IHistogram1D dxX0H = hf.createHistogram1D("dx",ndxbin,-dxm,dxm);
                        IFilter x0Cuts = tf.createFilter(cuts + " && x0 >=" + low + " && x0 < " + high + " && abs(dx" + row + ")<" + dxm);
                        tuple.project(dxX0H,dxEval,x0Cuts);
                        gauss.setParameter("a",dxX0H.maxBinHeight());
                        gauss.setParameter("mean",dxX0H.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxX0H.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxX0H.allEntries()>5){
                            IFitResult result = fitter.fit(dxX0H,gauss);
                            // result = fitter.fit(dxX0H,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxX0DPS.addPoint();iii++;
                            dxX0DPS.point(iii).coordinate(0).setValue((low+high)/2.);
                            dxX0DPS.point(iii).coordinate(1).setValue(val);
                            dxX0DPS.point(iii).coordinate(1).setErrorMinus(err);
                            dxX0DPS.point(iii).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            IHistogram1D dxiX0H = hf.createHistogram1D("dxi",ndxbin,-dxm,dxm);
                            x0Cuts = tf.createFilter(cuts + " && x0 >=" + low + " && x0 < " + high + " && abs(dxi" + row + ")<" + dxm);
                            tuple.project(dxiX0H,dxiEval,x0Cuts);
                            gauss.setParameter("a",dxiX0H.maxBinHeight());
                            gauss.setParameter("mean",dxiX0H.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                            gauss.setParameter("sigma",dxiX0H.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                            if (dxiX0H.allEntries()>5){
                                result = fitter.fit(dxiX0H,gauss);
                                // result = fitter.fit(dxiX0H,"g");
                                pars = result.fittedParameterNames();
                                
                                double vali = Math.abs(result.fittedParameter(pars[2]));
                                double erri = Math.sqrt( result.covMatrixElement(2,2) );
                                
                                // to estimate the resolution use geometric mean of residual with and without resolution row included
                                val = Math.sqrt(valx*vali);
                                err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                                
                                resX0DPS.addPoint();jjj++;
                                resX0DPS.point(jjj).coordinate(0).setValue((low+high)/2.);
                                resX0DPS.point(jjj).coordinate(1).setValue(val);
                                resX0DPS.point(jjj).coordinate(1).setErrorMinus(err);
                                resX0DPS.point(jjj).coordinate(1).setErrorPlus(err);
                            }
                        }
                    }
                    
                    plotter.region(2).plot(dxX0DPS,dpsStyle);
                    plotter.region(3).plot(resX0DPS,dpsStyle);
                    
                    // plot dx and sd(dx) vs b
                    
                    double bBinMin = -padPitch.getValue()/2.;
                    double bBinMax = padPitch.getValue()/2.;
                    
                    IDataPointSet dxBDPS= dpsf.create(runId + " bias vs b",2);
                    IDataPointSet resBDPS= dpsf.create(runId + " resol vs b",2);
                    
                    iii=-1; jjj=-1;
                    for (int i=0; i < nbBin; i++) {
                        double low = bBinMin + (bBinMax-bBinMin)*i/nbBin;
                        double high = low + (bBinMax-bBinMin)/nbBin;
                        IHistogram1D dxBH = hf.createHistogram1D("dx vs b ",ndxbin,-dxm,dxm);
                        IFilter bCuts = tf.createFilter(cuts + " && b"+row+" >=" + low + " && b"+row+" < " + high + " && abs(dx" + row + ")<" + dxm);
                        tuple.project(dxBH,dxEval,bCuts);
                        tuple.project(dxBHAll[i],dxEval,bCuts);
                        gauss.setParameter("a",dxBH.maxBinHeight());
                        gauss.setParameter("mean",dxBH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxBH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxBH.allEntries()>5){
                            IFitResult result = fitter.fit(dxBH,gauss);
                            // result = fitter.fit(dxBH,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxBDPS.addPoint();iii++;
                            dxBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                            dxBDPS.point(iii).coordinate(1).setValue(val);
                            dxBDPS.point(iii).coordinate(1).setErrorMinus(err);
                            dxBDPS.point(iii).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            IHistogram1D dxiBH = hf.createHistogram1D("dxi vs b ",ndxbin,-dxm,dxm);
                            bCuts = tf.createFilter(cuts + " && b"+row+" >=" + low + " && b"+row+" < " + high + " && abs(dxi" + row + ")<" + dxm);
                            tuple.project(dxiBH,dxiEval,bCuts);
                            tuple.project(dxiBHAll[i],dxiEval,bCuts);
                            gauss.setParameter("a",dxiBH.maxBinHeight());
                            gauss.setParameter("mean",dxiBH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                            gauss.setParameter("sigma",dxiBH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                            if (dxiBH.allEntries()>5){
                                result = fitter.fit(dxiBH,gauss);
                                // result = fitter.fit(dxiBH,"g");
                                pars = result.fittedParameterNames();
                                
                                double vali = Math.abs(result.fittedParameter(pars[2]));
                                double erri = Math.sqrt( result.covMatrixElement(2,2) );
                                
                                // to estimate the resolution use geometric mean of residual with and without resolution row included
                                val = Math.sqrt(valx*vali);
                                err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                                
                                resBDPS.addPoint();jjj++;
                                resBDPS.point(jjj).coordinate(0).setValue((low+high)/2.);
                                resBDPS.point(jjj).coordinate(1).setValue(val);
                                resBDPS.point(jjj).coordinate(1).setErrorMinus(err);
                                resBDPS.point(jjj).coordinate(1).setErrorPlus(err);
                            }
                        }
                    }
                    
                    plotter.region(4).plot(dxBDPS,dpsStyle);
                    plotter.region(5).plot(resBDPS,dpsStyle);
                    
                    
                    IFilter standardCutsEx = tf.createFilter(cuts + " && dx" + row + ">-998."); // remove bad fits
                    int nxbin = 12;
                    IEvaluator x0Eval = tf.createEvaluator("x0");
                    IProfile1D dxP1D = hf.createProfile1D(runId + " dx" + row + " vs x0",nxbin,-24.,24.);
                    tuple.project(dxP1D,x0Eval,dxEval,standardCutsEx);
                    IDataPointSet dxDPS = dpsf.create("dx" + row + " vs x0",dxP1D);
                    dxDPS.scaleErrors(1./Math.sqrt(dxP1D.allEntries()/nxbin));
                    // result = fitter.fit(dxDPS,"p0");
                    // plotter.region(4).plot(dxDPS,dpsStyle);
                    // plotter.region(4).plot(result.fittedFunction());
                    
                    IEvaluator z0Eval = tf.createEvaluator("z0");
                    IEvaluator sig2Eval = tf.createEvaluator("sigma*sigma");
                    ICloud2D sig2Cloud = hf.createCloud2D("sig2 cloud");
                    tuple.project(sig2Cloud,z0Eval,sig2Eval,standardCuts);
                    
                    standardCutsEx = tf.createFilter(cuts + " && abs(ex" + row + ")<10."); // remove bad fits?
                    eval = tf.createEvaluator("ex" + row);
                    IHistogram1D exH1D = hf.createHistogram1D(runId + " ex" + row,20,0.,0.4);
                    tuple.project(exH1D,eval,standardCutsEx);
                    IProfile1D exP1D = hf.createProfile1D(runId + " ex" + row + " vs udtb",nsigbin,sig2Cloud.lowerEdgeX(),sig2Cloud.upperEdgeX());
                    tuple.project(exP1D,z0Eval,eval,standardCutsEx);
                    IDataPointSet exDPS = dpsf.create("ex" + row + " vs udtb",exP1D);
                    exDPS.scaleErrors(1./Math.sqrt(exP1D.allEntries()/nsigbin));
                    // result = fitter.fit(exDPS,"p1");
                    // plotter.region(5).plot(exDPS,dpsStyle);
                    // plotter.region(5).plot(result.fittedFunction());
                    
                    plotter.show();
                }
            }
            
            if (resRows.length > 1) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " Residuals all rows");
                plotter.setTitle("Residuals All Rows");
                plotter.createRegions(2,2);
                
                for (int ir=0; ir < Math.min(4,resRows.length); ir++) {
                    
                    gauss.setParameter("a",dxH[ir].maxBinHeight());
                    gauss.setParameter("mean",dxH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                    // result = fitter.fit(dxH,"g");
                    plotter.region(ir).plot(dxH[ir]);
                    if (dxH[ir].allEntries()>5){
                        IFitResult result = fitter.fit(dxH[ir],gauss);
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                    
                    gauss.setParameter("a",dxiH[ir].maxBinHeight());
                    gauss.setParameter("mean",dxiH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxiH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                    // result = fitter.fit(dxiH[ir],"g");
                    plotter.region(ir).plot(dxiH[ir]);
                    if (dxiH[ir].allEntries()>5){
                        IFitResult result = fitter.fit(dxiH[ir],gauss);
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                }
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " Resolution all rows");
                plotter.setTitle("Resolution All Rows");
                plotter.createRegions(2,2);
                
                //result = fitter.fit(dxHAll,"g");
                gauss.setParameter("a",dxHAll.maxBinHeight());
                gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",0.2); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dxHAll);
                if (dxHAll.allEntries()>5){
                    IFitResult result = fitter.fit(dxHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                //result = fitter.fit(dxiHAll,"g");
                gauss.setParameter("a",dxiHAll.maxBinHeight());
                gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",0.2); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dxiHAll);
                if (dxiHAll.allEntries()>5){
                    IFitResult result = fitter.fit(dxiHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                plotter.region(1).plot(pullxHAll);
                if (pullxHAll.allEntries()>5){
                    IFitResult result = fitter.fit(pullxHAll,"g");
                    plotter.region(1).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet resolDPSAll= dpsf.create(runId + " resol vs drift",2);
                IDataPointSet resol2DPSAll= dpsf.create(runId + " resol2 vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    
                    gauss.setParameter("a",dxtHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxtHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxtHAll[i].allEntries()>5){
                        IFitResult result = fitter.fit(dxtHAll[i],gauss);
                        //result = fitter.fit(dxtHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        gauss.setParameter("a",dxitHAll[i].maxBinHeight());
                        gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxitHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dxitHAll[i].allEntries()>5){
                            result = fitter.fit(dxitHAll[i],gauss);
                            //result = fitter.fit(dxtHAll[i],"g");
                            pars = result.fittedParameterNames();
                            double vali = Math.abs(result.fittedParameter(pars[2]));
                            double erri = Math.sqrt( result.covMatrixElement(2,2));
                            
                            // to estimate the resolution use geometric mean of residual with and without resolution row included
                            double val = Math.sqrt(valx*vali);
                            double err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                            
                            resolDPSAll.addPoint();ii++;
                            resolDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                            resolDPSAll.point(ii).coordinate(1).setValue(val);
                            resolDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                            resolDPSAll.point(ii).coordinate(1).setErrorPlus(err);
                            resol2DPSAll.addPoint();
                            resol2DPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                            resol2DPSAll.point(ii).coordinate(1).setValue(val*val);
                            resol2DPSAll.point(ii).coordinate(1).setErrorMinus(2.*val*err);
                            resol2DPSAll.point(ii).coordinate(1).setErrorPlus(2.*val*err);
                        }
                    }
                }
                
                plotter.region(2).plot(resolDPSAll,dpsStyle);
                
                //result = fitter.fit(resol2DPSAll,"p1");
                plotter.region(3).plot(resol2DPSAll,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                plotter.show();
                
                
                plotter = af.createPlotterFactory().create(runId + " Extra Resolution plots");
                plotter.setTitle("Resolution vs Phi");
                plotter.createRegions(2,2);                
                
                // plot resolution as a function of phi and tanl
                
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet resolPhiDPSAll= dpsf.create(runId + " resol vs phi",2);
                ii=-1;
                double phiMax = Math.abs(maxPhi.getValue());
                double delta = 2.*phiMax/nPhi;
                double midPhi = -1.*phiMax-delta/2.;
                for (int i=0; i < nPhi; i++) {
                    midPhi += delta;
                    
                    gauss.setParameter("a",dxPhiHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxPhiHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxPhiHAll[i].allEntries()>5){
                        IFitResult result = fitter.fit(dxPhiHAll[i],gauss);
                        //result = fitter.fit(dxPhiHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        gauss.setParameter("a",dxiPhiHAll[i].maxBinHeight());
                        gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiPhiHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dxiPhiHAll[i].allEntries()>5){
                            result = fitter.fit(dxiPhiHAll[i],gauss);
                            //result = fitter.fit(dxPhiHAll[i],"g");
                            pars = result.fittedParameterNames();
                            double vali = Math.abs(result.fittedParameter(pars[2]));
                            double erri = Math.sqrt( result.covMatrixElement(2,2));
                            
                            // to estimate the resolution use geometric mean of residual with and without resolution row included
                            double val = Math.sqrt(valx*vali);
                            double err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                            
                            resolPhiDPSAll.addPoint();ii++;
                            resolPhiDPSAll.point(ii).coordinate(0).setValue(midPhi);
                            resolPhiDPSAll.point(ii).coordinate(1).setValue(val);
                            resolPhiDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                            resolPhiDPSAll.point(ii).coordinate(1).setErrorPlus(err);

                        }
                    }
                }
                
                plotter.region(0).plot(resolPhiDPSAll,dpsStyle);
                
                IDataPointSet resolTanLDPSAll= dpsf.create(runId + " resol vs tanl",2);
                ii=-1;
                double tanLMax = Math.abs(maxTanL.getValue());
                delta = 2.*tanLMax/nTanL;
                double midTanL = -1.*tanLMax-delta/2.;
                for (int i=0; i < nTanL; i++) {
                    midTanL += delta;
                    
                    gauss.setParameter("a",dxTanLHAll[i].maxBinHeight());
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dxTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dxTanLHAll[i].allEntries()>5){
                        IFitResult result = fitter.fit(dxTanLHAll[i],gauss);
                        //result = fitter.fit(dxTanLHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        gauss.setParameter("a",dxiTanLHAll[i].maxBinHeight());
                        gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxiTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dxiTanLHAll[i].allEntries()>5){
                            result = fitter.fit(dxiTanLHAll[i],gauss);
                            //result = fitter.fit(dxPhiHAll[i],"g");
                            pars = result.fittedParameterNames();
                            double vali = Math.abs(result.fittedParameter(pars[2]));
                            double erri = Math.sqrt( result.covMatrixElement(2,2));
                            
                            // to estimate the resolution use geometric mean of residual with and without resolution row included
                            double val = Math.sqrt(valx*vali);
                            double err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                            
                            resolTanLDPSAll.addPoint();ii++;
                            resolTanLDPSAll.point(ii).coordinate(0).setValue(midTanL);
                            resolTanLDPSAll.point(ii).coordinate(1).setValue(val);
                            resolTanLDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                            resolTanLDPSAll.point(ii).coordinate(1).setErrorPlus(err);

                        }
                    }
                }
                
                plotter.region(2).plot(resolTanLDPSAll,dpsStyle);
                
                if (rbr) {
                    double bBinMin = -padPitch.getValue()/2.;
                    double bBinMax = padPitch.getValue()/2.;
                    
                    IDataPointSet dxBDPS= dpsf.create(runId + " bias vs b All rows",2);
                    IDataPointSet resBDPS= dpsf.create(runId + " resol vs b All rows",2);
                    
                    int iii=-1; int jjj=-1;
                    for (int i=0; i < nbBin; i++) {
                        double low = bBinMin + (bBinMax-bBinMin)*i/nbBin;
                        double high = low + (bBinMax-bBinMin)/nbBin;
                
                        gauss.setParameter("a",dxBHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dxBHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dxBHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                        if (dxBHAll[i].allEntries()>5){
                            IFitResult result = fitter.fit(dxBHAll[i],gauss);
                            // result = fitter.fit(dxBH,"g");
                            String[] pars = result.fittedParameterNames();
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dxBDPS.addPoint();iii++;
                            dxBDPS.point(iii).coordinate(0).setValue((low+high)/2.);
                            dxBDPS.point(iii).coordinate(1).setValue(val);
                            dxBDPS.point(iii).coordinate(1).setErrorMinus(err);
                            dxBDPS.point(iii).coordinate(1).setErrorPlus(err);
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2) );
                            
                            gauss.setParameter("a",dxiBHAll[i].maxBinHeight());
                            gauss.setParameter("mean",dxiBHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                            gauss.setParameter("sigma",dxiBHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                            if (dxiBHAll[i].allEntries()>5){
                                result = fitter.fit(dxiBHAll[i],gauss);
                                // result = fitter.fit(dxiBH,"g");
                                pars = result.fittedParameterNames();
                                
                                double vali = Math.abs(result.fittedParameter(pars[2]));
                                double erri = Math.sqrt( result.covMatrixElement(2,2) );
                                
                                // to estimate the resolution use geometric mean of residual with and without resolution row included
                                val = Math.sqrt(valx*vali);
                                err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                                
                                resBDPS.addPoint();jjj++;
                                resBDPS.point(jjj).coordinate(0).setValue((low+high)/2.);
                                resBDPS.point(jjj).coordinate(1).setValue(val);
                                resBDPS.point(jjj).coordinate(1).setErrorMinus(err);
                                resBDPS.point(jjj).coordinate(1).setErrorPlus(err);
                            }
                        }
                    }
                    
                    plotter.region(1).plot(dxBDPS,dpsStyle);
                    plotter.region(3).plot(resBDPS,dpsStyle);
                }
                
                plotter.show();
            }
            
            if (mc.getValue()) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " mc info");
                plotter.setTitle("MC info");
                plotter.createRegions(2,2);
                
                IEvaluator eval = tf.createEvaluator("x0-tx0");
                IHistogram1D residHist = hf.createHistogram1D(runId + "true resid",ndxbin, -dxm/2., dxm/2.);
                tuple.project(residHist, eval, standardCuts);
                
                gauss.setParameter("a",residHist.maxBinHeight());
                gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",0.2); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(residHist);
                if (residHist.allEntries()>5){
                    IFitResult result = fitter.fit(residHist,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet residDPSAll= dpsf.create(runId + " sigma resid vs drift",2);
                IDataPointSet residCorDPSAll= dpsf.create(runId + " single row resolution vs drift",2);
                double cor = Math.sqrt(6.);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCuts = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high);
                    IHistogram1D residtH = hf.createHistogram1D("resid",ndxbin,-dxm/2.,dxm/2.);
                    tuple.project(residtH,eval,timeCuts);
                    gauss.setParameter("a",residtH.maxBinHeight());
                    gauss.setParameter("background",0.);
                    gauss.setParameter("mean",0.); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",0.05); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (residtH.allEntries()>5){
                        IFitResult result = fitter.fit(residtH,gauss);
                        //result = fitter.fit(dxtHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double val = Math.abs(result.fittedParameter(pars[2]));
                        double err = Math.sqrt( result.covMatrixElement(2,2));
                        residDPSAll.addPoint();ii++;
                        residDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        residDPSAll.point(ii).coordinate(1).setValue(val);
                        residDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                        residDPSAll.point(ii).coordinate(1).setErrorPlus(err);
                        
                        residCorDPSAll.addPoint();
                        residCorDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                        residCorDPSAll.point(ii).coordinate(1).setValue(val*cor);
                        residCorDPSAll.point(ii).coordinate(1).setErrorMinus(err*cor);
                        residCorDPSAll.point(ii).coordinate(1).setErrorPlus(err*cor);
                        
                    }
                }
                
                plotter.region(2).plot(residDPSAll,dpsStyle);
                plotter.region(3).plot(residCorDPSAll,dpsStyle);
                
                plotter.show();
                
            }
            
        }
        
        
        // z resolution studies
        // ----------------------
        
        
        if (zAnalysis.getValue()){
            
            // fitting dz parameters
            int nsigbin = nDriftBin.getValue();
            int nTanL = nTanLBin.getValue();
            double sigbinmin = driftMin.getValue();
            double sigbinmax = driftMax.getValue();
            int ndzbin = 20; double dzm = 2.;
            int[] resRows = resolutionRows.getValue();
            
            IHistogram1D dzHAll= hf.createHistogram1D(runId + " dz all",ndzbin,-dzm,dzm);
            IHistogram1D dziHAll= hf.createHistogram1D(runId + " dzi all",ndzbin,-dzm,dzm);
            IHistogram1D[] dzH = new IHistogram1D[resRows.length];
            IHistogram1D[] dziH = new IHistogram1D[resRows.length];
            IHistogram1D[] dztHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dzitHAll = new IHistogram1D[nsigbin];
            IHistogram1D[] dzTanLHAll = new IHistogram1D[nTanL];
            IHistogram1D[] dziTanLHAll = new IHistogram1D[nTanL];
            for (int i=0; i<nsigbin; i++) dztHAll[i] = hf.createHistogram1D("dzN tbin" + i,ndzbin,-dzm,dzm);
            for (int i=0; i<nsigbin; i++) dzitHAll[i] = hf.createHistogram1D("dziN tbin" + i,ndzbin,-dzm,dzm);
            for (int i=0; i<nTanL; i++) dzTanLHAll[i] = hf.createHistogram1D("dzN TanL bin" + i,ndzbin,-dzm,dzm);
            for (int i=0; i<nTanL; i++) dziTanLHAll[i] = hf.createHistogram1D("dziN TanL bin" + i,ndzbin,-dzm,dzm);
            for (int ir=0; ir < resRows.length; ir++) {
                int row = resRows[ir];
                dzH[ir] = hf.createHistogram1D(runId + " dz" + row,ndzbin,-dzm,dzm);
                dziH[ir] = hf.createHistogram1D(runId + " dzi" + resRows[ir],ndzbin,-dzm,dzm);
            }
            IDataPointSet[] zresolDPS = new IDataPointSet[resRows.length];
            
            for (int ir=0; ir < resRows.length; ir++) {
                
                int row = resRows[ir];
                IPlotter plotter = null;
                if (rbr) {
                    plotter = plotterFactory.create(runId + " z Resolution row " + row);
                    plotter.setTitle("z Resolution");
                    plotter.createRegions(3,2);
                }
                
                IEvaluator dzEval = tf.createEvaluator("dz" + row);
                IEvaluator dziEval = tf.createEvaluator("dzi" + row);
                
                IFilter rangeCuts = tf.createFilter(cuts + " && abs(dz" + row + ")<" + dzm);
                tuple.project(dzH[ir],dzEval,rangeCuts);
                tuple.project(dzHAll,dzEval,rangeCuts);
                rangeCuts = tf.createFilter(cuts + " && abs(dzi" + row + ")<" + dzm);
                tuple.project(dziH[ir],dziEval,rangeCuts);
                tuple.project(dziHAll,dziEval,rangeCuts);
                
                // fit sigma as a function of drift distance
                zresolDPS[ir]= dpsf.create(runId + " z resol(" + row + ") vs drift",2);
                IDataPointSet zresol2DPS= dpsf.create(runId + " z resol**2 vs drift",2);
                IDataPointSet dzZ0DPS= dpsf.create(runId + " z bias vs drift",2);
                int ii=-1; int jj=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    IFilter timeCuts = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dz" + row + ")<" + dzm);
                    tuple.project(dztHAll[i],dzEval,timeCuts);
                    IFilter timeCutsI = tf.createFilter(cuts + " && z0 >=" + low + " && z0 < " + high + " && abs(dzi" + row + ")<" + dzm);
                    tuple.project(dzitHAll[i],dziEval,timeCutsI);
                    
                    if (rbr) {
                        IHistogram1D dztH = hf.createHistogram1D("dz",ndzbin,-dzm,dzm);
                        tuple.project(dztH,dzEval,timeCuts);
                        gauss.setParameter("a",dztH.maxBinHeight());
                        gauss.setParameter("mean",dztH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                        gauss.setParameter("sigma",dztH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dztH.allEntries()>5){
                            IFitResult result = fitter.fit(dztH,gauss);
                            //result = fitter.fit(dztH,"g");
                            String[] pars = result.fittedParameterNames();
                            
                            if (i<4) {
                                plotter.region(2+i).plot(dztH);
                                plotter.region(2+i).plot(result.fittedFunction());
                            }
                            
                            double val = result.fittedParameter(pars[1]);
                            double err = Math.sqrt( result.covMatrixElement(1,1) );
                            dzZ0DPS.addPoint();ii++;
                            dzZ0DPS.point(ii).coordinate(0).setValue((low+high)/2.);
                            dzZ0DPS.point(ii).coordinate(1).setValue(val);
                            dzZ0DPS.point(ii).coordinate(1).setErrorMinus(err);
                            dzZ0DPS.point(ii).coordinate(1).setErrorPlus(err);
                            
                            
                            double valx = Math.abs(result.fittedParameter(pars[2]));
                            double errx = Math.sqrt( result.covMatrixElement(2,2));
                            
                            IHistogram1D dzitH = hf.createHistogram1D("dzi",ndzbin,-dzm,dzm);
                            tuple.project(dzitH,dziEval,timeCutsI);
                            gauss.setParameter("a",dzitH.maxBinHeight());
                            gauss.setParameter("mean",dzitH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                            gauss.setParameter("sigma",dzitH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                            if (dzitH.allEntries()>5){
                                result = fitter.fit(dzitH,gauss);
                                //result = fitter.fit(dzitH,"g");
                                double vali = Math.abs(result.fittedParameter(pars[2]));
                                double erri = Math.sqrt( result.covMatrixElement(2,2));
                                
                                
                                // to estimate the resolution use geometric mean of residual with and without resolution row included
                                val = Math.sqrt(valx*vali);
                                err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                                
                                zresolDPS[ir].addPoint();jj++;
                                zresolDPS[ir].point(jj).coordinate(0).setValue((low+high)/2.);
                                zresolDPS[ir].point(jj).coordinate(1).setValue(val);
                                zresolDPS[ir].point(jj).coordinate(1).setErrorMinus(err);
                                zresolDPS[ir].point(jj).coordinate(1).setErrorPlus(err);
                                zresol2DPS.addPoint();
                                zresol2DPS.point(jj).coordinate(0).setValue((low+high)/2.);
                                zresol2DPS.point(jj).coordinate(1).setValue(val*val);
                                zresol2DPS.point(jj).coordinate(1).setErrorMinus(2.*val*err);
                                zresol2DPS.point(jj).coordinate(1).setErrorPlus(2.*val*err);
                            }
                        }
                    }
                }
                if (rbr) {
                    plotter.region(0).plot(dzZ0DPS,dpsStyle);
                    plotter.region(1).plot(zresolDPS[ir],dpsStyle);
                }
                
                //result = fitter.fit(zresol2DPS,"p1");
                //plotter.region(3).plot(zresol2DPS,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                
                if (rbr) plotter.show();
                
                double tanLMax = Math.abs(maxTanL.getValue());
                for (int i=0; i < nTanL; i++) {
                    double low = -tanLMax + 2*tanLMax*i/nTanL;
                    double high = low + 2*tanLMax/nTanL;
                    IFilter tanLCuts = tf.createFilter(cuts + " && tanl >=" + low + " && tanl < " + high + " && abs(dz" + row + ")<" + dzm);
                    tuple.project(dzTanLHAll[i],dzEval,tanLCuts);
                    IFilter tanLCutsI = tf.createFilter(cuts + " && tanl >=" + low + " && tanl < " + high + " && abs(dzi" + row + ")<" + dzm);
                    tuple.project(dziTanLHAll[i],dziEval,tanLCutsI);
                }
            }
            
            
            if (resRows.length > 1) {
                
                IPlotter plotter = af.createPlotterFactory().create(runId + " z Residuals all rows");
                plotter.setTitle("z Residuals All Rows");
                plotter.createRegions(2,2);
                
                for (int ir=0; ir < Math.min(4,resRows.length); ir++) {
                    
                    gauss.setParameter("a",dzH[ir].maxBinHeight());
                    gauss.setParameter("mean",dzH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                    gauss.setParameter("sigma",dzH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    plotter.region(ir).plot(dzH[ir]);
                    if (dzH[ir].allEntries()>5){
                        IFitResult result = fitter.fit(dzH[ir],gauss);
                        // result = fitter.fit(dzH,"g");
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                    
                    gauss.setParameter("a",dziH[ir].maxBinHeight());
                    gauss.setParameter("mean",dziH[ir].mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                    gauss.setParameter("sigma",dziH[ir].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    plotter.region(ir).plot(dziH[ir]);
                    if (dziH[ir].allEntries()>5){
                        IFitResult result = fitter.fit(dziH[ir],gauss);
                        // result = fitter.fit(dziH[ir],"g");
                        plotter.region(ir).plot(result.fittedFunction());
                    }
                }
                
                plotter.show();
                
                plotter = af.createPlotterFactory().create(runId + " z Resolution all rows");
                plotter.setTitle("z Resolution All Rows");
                plotter.createRegions(2,2);
                
                //result = fitter.fit(dzHAll,"g");
                gauss.setParameter("a",dzHAll.maxBinHeight());
                gauss.setParameter("mean",dzHAll.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
                gauss.setParameter("sigma",dzHAll.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dzHAll);
                if (dzHAll.allEntries()>5){
                    IFitResult result = fitter.fit(dzHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                //result = fitter.fit(dziHAll,"g");
                gauss.setParameter("a",dziHAll.maxBinHeight());
                gauss.setParameter("mean",dziHAll.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                gauss.setParameter("sigma",dziHAll.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                
                plotter.region(0).plot(dziHAll);
                if (dziHAll.allEntries()>5){
                    IFitResult result = fitter.fit(dziHAll,gauss);
                    plotter.region(0).plot(result.fittedFunction());
                }
                
                // fit sigma as a function of drift distance
                fitter.fitParameterSettings("mean").setStepSize(0.2);
                fitter.fitParameterSettings("sigma").setStepSize(0.1);
                IDataPointSet zresolDPSAll= dpsf.create(runId + " z resol vs drift",2);
                IDataPointSet zresol2DPSAll= dpsf.create(runId + " z resol2 vs drift",2);
                int ii=-1;
                for (int i=0; i < nsigbin; i++) {
                    double low = sigbinmin + (sigbinmax-sigbinmin)*i/nsigbin;
                    double high = low + (sigbinmax-sigbinmin)/nsigbin;
                    
                    gauss.setParameter("a",dztHAll[i].maxBinHeight());
                    gauss.setParameter("mean",dztHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dztHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dztHAll[i].allEntries()>5){
                        IFitResult result = fitter.fit(dztHAll[i],gauss);
                        //result = fitter.fit(dztHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        gauss.setParameter("a",dzitHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dzitHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dzitHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dzitHAll[i].allEntries()>5){
                            result = fitter.fit(dzitHAll[i],gauss);
                            //result = fitter.fit(dztHAll[i],"g");
                            pars = result.fittedParameterNames();
                            double vali = Math.abs(result.fittedParameter(pars[2]));
                            double erri = Math.sqrt( result.covMatrixElement(2,2));
                            
                            // to estimate the resolution use geometric mean of residual with and without resolution row included
                            double val = Math.sqrt(valx*vali);
                            double err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                            
                            zresolDPSAll.addPoint();ii++;
                            zresolDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                            zresolDPSAll.point(ii).coordinate(1).setValue(val);
                            zresolDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                            zresolDPSAll.point(ii).coordinate(1).setErrorPlus(err);
                            zresol2DPSAll.addPoint();
                            zresol2DPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                            zresol2DPSAll.point(ii).coordinate(1).setValue(val*val);
                            zresol2DPSAll.point(ii).coordinate(1).setErrorMinus(2.*val*err);
                            zresol2DPSAll.point(ii).coordinate(1).setErrorPlus(2.*val*err);
                        }
                    }
                }
                
                plotter.region(2).plot(zresolDPSAll,dpsStyle);
                
                //result = fitter.fit(zresol2DPSAll,"p1");
                plotter.region(3).plot(zresol2DPSAll,dpsStyle);
                //plotter.region(3).plot(result.fittedFunction());
                
                
                IDataPointSet zresolTanLDPSAll= dpsf.create(runId + " z resol vs tanL",2);
                ii=-1;
                double tanLMax = Math.abs(maxTanL.getValue());
                for (int i=0; i < nTanL; i++) {
                    double low = -tanLMax + 2*tanLMax*i/nTanL;
                    double high = low + 2*tanLMax/nTanL;
                    
                    gauss.setParameter("a",dzTanLHAll[i].maxBinHeight());
                    gauss.setParameter("mean",dzTanLHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",dzTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                    if (dzTanLHAll[i].allEntries()>5){
                        IFitResult result = fitter.fit(dzTanLHAll[i],gauss);
                        //result = fitter.fit(dzTanLHAll[i],"g");
                        String[] pars = result.fittedParameterNames();
                        double valx = Math.abs(result.fittedParameter(pars[2]));
                        double errx = Math.sqrt( result.covMatrixElement(2,2));
                        
                        gauss.setParameter("a",dziTanLHAll[i].maxBinHeight());
                        gauss.setParameter("mean",dziTanLHAll[i].mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                        gauss.setParameter("sigma",dziTanLHAll[i].rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
                        if (dziTanLHAll[i].allEntries()>5){
                            result = fitter.fit(dziTanLHAll[i],gauss);
                            //result = fitter.fit(dzTanLHAll[i],"g");
                            pars = result.fittedParameterNames();
                            double vali = Math.abs(result.fittedParameter(pars[2]));
                            double erri = Math.sqrt( result.covMatrixElement(2,2));
                            
                            // to estimate the resolution use geometric mean of residual with and without resolution row included
                            double val = Math.sqrt(valx*vali);
                            double err = 0.5*val*Math.sqrt(errx*errx/valx/valx + erri*erri/vali/vali);
                            
                            zresolTanLDPSAll.addPoint();ii++;
                            zresolTanLDPSAll.point(ii).coordinate(0).setValue((low+high)/2.);
                            zresolTanLDPSAll.point(ii).coordinate(1).setValue(val);
                            zresolTanLDPSAll.point(ii).coordinate(1).setErrorMinus(err);
                            zresolTanLDPSAll.point(ii).coordinate(1).setErrorPlus(err);
                        }
                    }
                }
                
                plotter.region(1).plot(zresolTanLDPSAll,dpsStyle);
                
                plotter.show();
            }
            
            
        }
        
        
    }
    
}
