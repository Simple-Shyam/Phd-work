/*
 * TupleAnalyzer.java
 *
 * Created on January 25, 2005, 11:47 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;

/**
 *
 * @author  karlen
 */
public class TupleAnalyzer {
    
    ParameterList pL;
    
    /** Creates a new instance of TupleAnalyzer */
    public TupleAnalyzer() {
        pL = new ParameterList("Tuple Analyzer parameters");
        defineBasicParameters(pL);
        defineCutParameters(pL);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Start(new TupleAnalyzer());
    }
    
    public void doAnalysis(){
        // dummy analysis of ntuple:
        setCuts();
        plotCuts();
    }
    
    public ParameterList getParameterList() {return pL;}
    
    public void updateParameterList(ParameterList newPL) {
        pL.update(newPL);
    }
    
    public IntegerParameter magField, year;
    public BooleanParameter mc, selRun, curvedTracking, fitResRow;
    public StringParameter location, gas, runSelection;
    public DoubleParameter driftVelocity,driftMin,driftMax;
    public DoubleParameter x0Range, phiRange, sigmaRange, tanlRange;
    public IntegerParameter nTrackRows,nResolutionRows,nDriftBin;
    public IntegerArrayParameter trackRows,resolutionRows;
    
    
    public void defineBasicParameters(ParameterList pL) {
        pL.setCategory("Basic parameters");
        //             ---------------------
        magField = new IntegerParameter(pL,"Magnetic Field",4000,"mT",
        "magnetic field in mT",true);
        gas = new StringParameter(pL, "Gas", "p5",
        "specify gas type: p5 or tdr", true);
        mc = new BooleanParameter(pL, "Monte Carlo file", false,
        "specify if data set is Monte Carlo (has truth information)", true);
        runSelection = new StringParameter(pL, "Run selection", "run != -0.1",
        "specify run selection (can be overidden by auto select)", true);
        selRun = new BooleanParameter(pL, "Auto run select", false,
        "specify if run selection to be made using location, year, gas, field", true);
        location = new StringParameter(pL, "Location", "desy",
        "specify location of data taking: desy or triumf", true);
        year = new IntegerParameter(pL, "Year", 2003, "",
        "specify year that data was taken: 2003 or 2004", true);
        
        nTrackRows = new IntegerParameter(pL,"# track rows",8,"",
        "number of rows used for defining the tracks",true);
        int tR[] = {0,1,3,4,6,7,9,10};
        trackRows = new IntegerArrayParameter(pL,nTrackRows,"tracking rows",tR,"row #",
        "edit list of tracking rows",true);
        nResolutionRows = new IntegerParameter(pL,"# resolution rows",8,"",
        "number of rows used to determine the resolution",true);
        resolutionRows = new IntegerArrayParameter(pL,nResolutionRows,"resolution rows",tR,"row #",
        "edit list of resolution rows",true);
        
        fitResRow = new BooleanParameter(pL, "fit resol. row", false,
        "select this to simply use the resolution row in the reference track fit", true);
        
        curvedTracking = new BooleanParameter(pL,"curved tracking",true,
        "specify if the track fit was done with curved tracking", true);
        
        driftVelocity = new DoubleParameter(pL, "drift velocity", 0.19, "cm/time bin",
        "enter the approximate drift velocity in cm/time bin", true);
        
        driftMin = new DoubleParameter(pL, "min drift time", 10., "ticks",
        "minimum drift time for plots (in TDC counts)", true);
        driftMax = new DoubleParameter(pL, "max drift time", 150., "ticks",
        "maximum drift time for plots (in TDC counts)", true);
        nDriftBin = new IntegerParameter(pL, "number of bins for drift time", 7, "",
        "number of divisions along drift direction for plots", true);
        
        x0Range = new DoubleParameter(pL, "range for x0", 30., "mm", 
        "enter maximum value of x0 for plots", true);
        phiRange = new DoubleParameter(pL, "range for phi", 0.2, "rad", 
        "enter maximum value of phi for plots", true);
        sigmaRange = new DoubleParameter(pL, "range for sigma", 4., "mm", 
        "enter maximum value of sigma for plots", true);
        tanlRange = new DoubleParameter(pL, "range for tanl", 0.4, "bin/mm", 
        "enter maximum value of tanl for plots", true);
        
        pL.resetCategory();
    }
    
    StringParameter[] cutList = new StringParameter[7];
    BooleanParameter[] autoCut = new BooleanParameter[7];
    
    public void defineCutParameters(ParameterList pL) {
        pL.setCategory("Cut parameters");
        //              --------------
        
        cutList[0] = new StringParameter(pL, "fiducial cut", "abs(x0) < 24.",
        "specify the fiducial region cut", true);
        cutList[1] = new StringParameter(pL, "vertical cut", "abs(phi) < 0.1",
        "cut to select vertical tracks", true);
        cutList[2] = new StringParameter(pL, "sigma cut", "sigma > 0.15 && sigma < 1.0",
        "require reasonable sigma - to ensure a good track fit", true);
        autoCut[2] = new BooleanParameter(pL, "autoset sigma cut", true,
        "automatically change the sigma cuts depending on the magnetic field", true);
        cutList[3] = new StringParameter(pL, "error cut", "errx0 < 0.2 && errsig < 0.2",
        "require reasonable error estimates - ensure a good track fit", true);
        autoCut[3] = new BooleanParameter(pL, "autoset error cut", true,
        "automatically change the error cuts depending on the magnetic field", true);
        cutList[4] = new StringParameter(pL, "z0 cuts", "abs(tanl) < 0.3 && z0 > 10. && z0 < 150.",
        "z0 fiducial cut and cut to select vertical in yz plane", true);
        cutList[5] = new StringParameter(pL, "return code", "stat == 0",
        "cut on status from the tpcanalyzer",true);
        cutList[6] = new StringParameter(pL, "cluster cut", "nclmax == 1",
        "cut on the maximum number of clusters", true);
        
    }
    
    // Cuts
    // ****
    
    public String[] cut;
    public String cuts;
    public String runcuts;
    
    public IFilter runCuts, standardCuts;
    
    public void setCuts(){
        int nCut = cutList.length;
        cut = new String[nCut];
        for (int i=0; i<nCut; i++){
            cut[i] = cutList[i].getValue();
        }
        
        if (autoCut[2].getValue()) {
            if (magField.getValue() >= 1500) {
                cut[2] = "sigma > 0.15 && sigma < 1.";
            }
            else if (magField.getValue() == 900) {
                cut[2] = "sigma > 0.2 && sigma < 1.4";
            }
            else if (magField.getValue() == 450) {
                cut[2] = "sigma > 0.2 && sigma < 2";
            }
            else if (magField.getValue() == 0) {
                cut[2] = "sigma > 0.3 && sigma < 4";
            }
        }
        if (autoCut[3].getValue()) {
            if (magField.getValue() >= 900) {
                cut[3]= "errx0 < 0.2 && errsig < 0.2";
            }
            else if (magField.getValue() == 450) {
                cut[3] = "errx0 < 0.3 && errsig < 0.3";
            }
            else if (magField.getValue() == 0) {
                cut[3] = "errx0 < 0.4 && errsig < 0.4";
            }
        }
        
        runcuts = runSelection.getValue();
        
        if (selRun.getValue()) {
            runcuts = "run == 0.1234"; // as a check that some run is selected
            if (location.getValue() == "desy" && gas.getValue() == "p5" && year.getValue() == 2003) {
                if (magField.getValue() == 0) {runcuts = "(run == 39 || run == 43)";}
                else if (magField.getValue() == 900) {runcuts = "run == 50";}
                else if (magField.getValue() == 1500) {runcuts = "run == 44";}
                else if (magField.getValue() == 2500) {runcuts = "(run == 48 || run == 49)";}
                else if (magField.getValue() == 3500) {runcuts = "(run == 41 || run == 42)";}
                else if (magField.getValue() == 4500) {runcuts = "(run == 40 || run == 51)";}
                else if (magField.getValue() == 4501) {runcuts = "run==40";}
                else if (magField.getValue() == 4502) {runcuts = "run==51";}
                else if (magField.getValue() == 5300) {runcuts = "(run == 45 || run == 46 || run == 47)";}
            }
            else if (location.getValue() == "desy" && gas.getValue() == "tdr" && year.getValue() == 2003) {
                if (magField.getValue() == 0) {runcuts = "run == 59";}
                else if (magField.getValue() == 1500) {runcuts = "run == 52";}
                else if (magField.getValue() == 2500) {runcuts = "run == 53";}
                else if (magField.getValue() == 4500) {runcuts = "run >= 55 && run <= 58";}
                else if (magField.getValue() == 5300) {runcuts = "run == 54";}
            }
            else if (location.getValue() == "triumf" && gas.getValue() == "p5" && year.getValue() == 2003) {
                if (magField.getValue() == 0) {runcuts = "run == 35";}
                else if (magField.getValue() == 900) {runcuts = "(run == 33 || run == 36)";}
            }
            else if (location.getValue() == "triumf" && gas.getValue() == "tdr" && year.getValue() == 2003) {
                if (magField.getValue() == 0) {runcuts = "run == 38";}
                else if (magField.getValue() == 900) {runcuts = "run == 37";}
            }
        }
        
        cuts = runcuts;
        for (int i=0; i<cut.length; i++) {
            cuts += " && ";
            cuts += cut[i];
        }
        
        runCuts = tf.createFilter(runcuts);
        standardCuts = tf.createFilter(cuts);
    }
    
    public void printCuts() {
        System.out.println("");
        System.out.println("Cuts:");
        System.out.println("-----");
        System.out.println("runCuts = " + runCuts.expression());
        System.out.println("standardCuts = " + standardCuts.expression());
    }
    
    public String getCuts() {
        return standardCuts.expression();
    }
    
    public void plotCuts() {
        // PLOT: XO, ERRX0, PHI, SIGMA, ERRSIG, Z0, TANL, DZ
        // -------------------------------------------------
        
        IEvaluator eval = tf.createEvaluator("x0");
        IHistogram1D x0HistR = hf.createHistogram1D(runId + " x0 (raw)",60, -x0Range.getValue(), x0Range.getValue());
        IHistogram1D x0HistC = hf.createHistogram1D(runId + " x0 (cut)",60, -x0Range.getValue(), x0Range.getValue());
        tuple.project(x0HistR, eval, runCuts);
        tuple.project(x0HistC, eval, standardCuts);
        
        eval = tf.createEvaluator("errx0");
        IHistogram1D errx0HistR = hf.createHistogram1D(runId + " errx0 (raw)",40, 0., 0.6);
        IHistogram1D errx0HistC = hf.createHistogram1D(runId + " errx0 (cut)",40, 0., 0.6);
        tuple.project(errx0HistR, eval, runCuts);
        tuple.project(errx0HistC, eval, standardCuts);
        
        eval = tf.createEvaluator("phi");
        IHistogram1D phiHistR = hf.createHistogram1D(runId + " phi (raw)",40, -phiRange.getValue(), phiRange.getValue());
        IHistogram1D phiHistC = hf.createHistogram1D(runId + " phi (cut)",40, -phiRange.getValue(), phiRange.getValue());
        tuple.project(phiHistR, eval, runCuts);
        tuple.project(phiHistC, eval, standardCuts);
        
        eval = tf.createEvaluator("sigma");
        IHistogram1D sigmaHistR = hf.createHistogram1D(runId + " sigma (raw)",40, 0., sigmaRange.getValue());
        IHistogram1D sigmaHistC = hf.createHistogram1D(runId + " sigma (cut)",40, 0., sigmaRange.getValue());
        tuple.project(sigmaHistR, eval, runCuts);
        tuple.project(sigmaHistC, eval, standardCuts);
        
        eval = tf.createEvaluator("errsig");
        IHistogram1D errsigHistR = hf.createHistogram1D(runId + " errsig (raw)",40, 0., sigmaRange.getValue()/10.);
        IHistogram1D errsigHistC = hf.createHistogram1D(runId + " errsig (cut)",40, 0., sigmaRange.getValue()/10.);
        tuple.project(errsigHistR, eval, runCuts);
        tuple.project(errsigHistC, eval, standardCuts);
        
        eval = tf.createEvaluator("z0");
        IHistogram1D z0HistR = hf.createHistogram1D(runId + " z0 (raw)",45, 0., driftMax.getValue());
        IHistogram1D z0HistC = hf.createHistogram1D(runId + " z0 (cut)",45, 0., driftMax.getValue());
        tuple.project(z0HistR, eval, runCuts);
        tuple.project(z0HistC, eval, standardCuts);
        
        eval = tf.createEvaluator("tanl");
        IHistogram1D tanlHistR = hf.createHistogram1D(runId + " tanL (raw)",40, -tanlRange.getValue(), tanlRange.getValue());
        IHistogram1D tanlHistC = hf.createHistogram1D(runId + " tanL (cut)",40, -tanlRange.getValue(), tanlRange.getValue());
        tuple.project(tanlHistR, eval, runCuts);
        tuple.project(tanlHistC, eval, standardCuts);
        
        IHistogram1D dzHistR = hf.createHistogram1D(runId + " dZ (raw)",40, -6., 6.);
        IHistogram1D dzHistC = hf.createHistogram1D(runId + " dZ (cut)",40, -6., 6.);
        int[] resRows = resolutionRows.getValue();
        for (int i=0; i < resRows.length; i++) {
            if(!fitResRow.getValue()){
                eval = tf.createEvaluator("dz"+resRows[i]);
            } else {
                eval = tf.createEvaluator("dzi"+resRows[i]);
            }
            tuple.project(dzHistR, eval, runCuts);
            tuple.project(dzHistC, eval, standardCuts);
        }
        
        IPlotter plotter = plotterFactory.create(runId + " general (raw)");
        plotter.setTitle("general (raw)");
        plotter.createRegions(4,2);
        plotter.region(0).plot(x0HistR);
        plotter.region(1).plot(errx0HistR);
        if (errx0HistR.allEntries()>5){
            IFitResult result = fitter.fit(errx0HistR,"g");
            plotter.region(1).plot(result.fittedFunction());
        }
        plotter.region(2).plot(sigmaHistR);
        if (sigmaHistR.allEntries()>5){
            IFitResult result = fitter.fit(sigmaHistR,"g");
            plotter.region(2).plot(result.fittedFunction());
        }
        plotter.region(3).plot(errsigHistR);
        if (errsigHistR.allEntries()>5){
            IFitResult result = fitter.fit(errsigHistR,"g");
            plotter.region(3).plot(result.fittedFunction());
        }
        plotter.region(4).plot(phiHistR);
        plotter.region(5).plot(z0HistR);
        plotter.region(6).plot(tanlHistR);
        plotter.region(7).plot(dzHistR);
        if (dzHistR.allEntries()>5){
            IFitResult result = fitter.fit(dzHistR,"g");
            plotter.region(7).plot(result.fittedFunction());
        }
        
        plotter.show();
        
        plotter = plotterFactory.create(runId + " general (cut)");
        plotter.setTitle("general (cut)");
        plotter.createRegions(4,2);
        plotter.region(0).plot(x0HistC);
        plotter.region(1).plot(errx0HistC);
        if (errx0HistC.allEntries()>5){
            IFitResult result = fitter.fit(errx0HistC,"g");
            plotter.region(1).plot(result.fittedFunction());
        }
        plotter.region(2).plot(sigmaHistC);
        if (sigmaHistC.allEntries()>5){
            IFitResult result = fitter.fit(sigmaHistC,"g");
            plotter.region(2).plot(result.fittedFunction());
        }
        plotter.region(3).plot(errsigHistC);
        if (errsigHistC.allEntries()>5){
            IFitResult result = fitter.fit(errsigHistC,"g");
            plotter.region(3).plot(result.fittedFunction());
        }
        plotter.region(4).plot(phiHistC);
        plotter.region(5).plot(z0HistC);
        plotter.region(6).plot(tanlHistC);
        plotter.region(7).plot(dzHistC);
        if (dzHistC.allEntries()>5){
            IFitResult result = fitter.fit(dzHistC,"g");
            plotter.region(7).plot(result.fittedFunction());
        }
        
        plotter.show();
        
        // Exclusive cuts plots:
        
        // find event number range by putting it into a cloud
        IEvaluator eventEval = tf.createEvaluator("event");
        ICloud1D evCloud = hf.createCloud1D("event cloud");
        tuple.project(evCloud,eventEval,tf.createFilter(runcuts));
        double lowEvent = evCloud.lowerEdge();
        double highEvent = evCloud.upperEdge();
        
        plotter = plotterFactory.create(runId + " exclusive cuts");
        plotter.setTitle("exclusive cuts");
        plotter.createRegions(4,2);
        for (int i=0; i<cut.length; i++) {
            IHistogram1D eventH = hf.createHistogram1D(runId + "event cut" + i,50, lowEvent, highEvent);
            tuple.project(eventH, eventEval, tf.createFilter(runcuts+" && "+cut[i]));
            plotter.region(i).plot(eventH);
        }
        IHistogram1D eventH = hf.createHistogram1D(runId + "event no cuts",50, lowEvent, highEvent);
        tuple.project(eventH, eventEval, tf.createFilter(runcuts));
        plotter.region(cut.length).plot(eventH);
        
        plotter.show();
        
    }
    
    String dataFile;
    public void setDataFile(String file){
        dataFile = file;
    }
    
    public String runId;
    public void setToken(String token){
        runId = token;
    }
    
    public IAnalysisFactory  af;
    public ITree tree;
    public ITuple tuple;
    public IHistogramFactory hf;
    public IDataPointSetFactory dpsf;
    public IFitFactory fitf;
    public IFitter fitter;
    public ITupleFactory tf;
    public IFunctionFactory ff;
    public IPlotterFactory plotterFactory;
    public IPlotterStyle dpsStyle;
    public IFunction gauss;
    
    public void setupAida() {
        
        af  = IAnalysisFactory.create();
        // The line below is the AIDA way to open a data set.
        try {
            tree = af.createTreeFactory().create(dataFile);
        } catch (Exception e) {
            System.out.println("Error opening data file: " + e);
            return;
        }
        // We use instead the following JAS3 specific way to open a tree so that we can access the
        // already opened tree.
        // tree = (ITree) ((Studio) Application.getApplication()).getLookup().lookup(ITree.class);
        
        tuple = (ITuple) tree.find("tuple");
        hf = af.createHistogramFactory(tree);
        dpsf = af.createDataPointSetFactory(tree);
        fitf = af.createFitFactory();
        fitter = fitf.createFitter("Chi2","uncmin"); // NEED TO FIGURE OUT HOW TO GET MINUIT TO WORK!
        tf = af.createTupleFactory(tree);
        ff = af.createFunctionFactory(tree);
        plotterFactory = af.createPlotterFactory();
        dpsStyle = plotterFactory.createPlotterStyle();
        dpsStyle.dataStyle().setParameter("showHistogramBars","false");
        dpsStyle.dataStyle().setParameter("showDataPoints","true");
        gauss = ff.createFunctionFromScript("gauss",1,"background+a*exp(-(x[0]-mean)*(x[0]-mean)/sigma/sigma/2.)","a,mean,sigma,background","A Gaussian");
        
    }
    
    String name;
    
    public String toString(){return name;}
    public void setName(String name) {
        this.name = name;
    }
    
    /** Handle startup: either batch or interactive
     *
     */
    public static void Start(TupleAnalyzer tupleAnalyzer){
        Interactive(tupleAnalyzer);
    }
    
    /** Interactive
     *
     */
    public static void Interactive(TupleAnalyzer tupleAnalyzer){
        // try to read from last.tupleanalyzer to see if we can load the previous files
        String dFileName = "";
        String aFileName = "";
        try {
            File inputFile = new File("last.tupleanalyzer");
            FileInputStream fis = new FileInputStream(inputFile);
            BufferedReader r = new BufferedReader(new InputStreamReader(fis));
            dFileName = r.readLine();
            aFileName = r.readLine();
        } catch (IOException except) {  }
        
        // construct the Analysis GUI and display it
        if (dFileName != null && dFileName.length() > 1
        && aFileName != null && aFileName.length() > 1) {
            TupleAnalyzerControlFrame taCF = new TupleAnalyzerControlFrame(tupleAnalyzer,dFileName,aFileName);
            taCF.show();
        } else {
            TupleAnalyzerControlFrame taCF = new TupleAnalyzerControlFrame(tupleAnalyzer);
            taCF.show();
        }
    }
    
}
