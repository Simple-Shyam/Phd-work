/*
 * Laser2Analyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class Laser2Analyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new Laser2Analyzer());
    }
    /** Creates a new instance of Laser1Analyzer */
    public Laser2Analyzer() {
        setName("Double laser analysis (version 1.3)");
        pL = getParameterList();
        defineCut2Parameters(pL);
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        
        laser2Analysis();
    }
    
    public void defineBasicParameters(ParameterList pL){
        nTrackRows = new IntegerParameter(pL,"# track rows",8,"",
        "number of rows used for defining the tracks",true);
        int tR[] = {0,1,3,4,6,7,9,10};
        trackRows = new IntegerArrayParameter(pL,nTrackRows,"tracking rows",tR,"row #",
        "edit list of tracking rows",true);
        pL.resetCategory();
    }
    
    public void defineCutParameters(ParameterList pL){
        //default cuts not used here
    }
    
    public void defineCut2Parameters(ParameterList pL) {
        // overwrite the standard set of cuts for single track analyses
        pL.setCategory("Cut 2 parameters");
        //              --------------
        cutList = new StringParameter[4];
        cutList[0] = new StringParameter(pL, "fiducial cut", "abs(x01) < 24 && abs(x02) < 24",
        "specify the fiducial region cut", true);
        cutList[1] = new StringParameter(pL, "vertical cut", "abs(phi1) < 0.1 && abs(phi2) < 0.1",
        "cut to select vertical tracks", true);
        cutList[2] = new StringParameter(pL, "return code", "stat == 0",
        "cut on status from the tpcanalyzer",true);
        cutList[3] = new StringParameter(pL, "runs", "run != 0.27",
        "specify runs", true);
    }
    
    public void setCuts(){
        int nCut = cutList.length;
        cut = new String[nCut];
        for (int i=0; i<nCut; i++){
            cut[i] = cutList[i].getValue();
        }
        
        cuts = cut[0];
        for (int i=1; i<cut.length; i++) {
            cuts += " && ";
            cuts += cut[i];
        }
        
        standardCuts = tf.createFilter(cuts);
    }
    
    
    int nTimeBin = 10; // number of time bins in history plots
    double maxRSum = 5000.; // maximum Rsum to enter plots
    
    public void laser2Analysis() {
        
        // XO, ERRX0, PHI, SIGMA, ERRSIG, Z0, TANL, DZ
        // -------------------------------------------
        
        IEvaluator eval = tf.createEvaluator("x01");
        IHistogram1D x01Hist = hf.createHistogram1D(runId + " x01",1000, -7.5, 7.5);
        tuple.project(x01Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("errx01");
        IHistogram1D errx01Hist = hf.createHistogram1D(runId + " errx01",40, 0., 0.4);
        tuple.project(errx01Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("phi1");
        IHistogram1D phi1Hist = hf.createHistogram1D(runId + " phi1",100, -0.05, 0.05);
        tuple.project(phi1Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("x02");
        IHistogram1D x02Hist = hf.createHistogram1D(runId + " x02",1000, -7.5, 7.5);
        tuple.project(x02Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("errx02");
        IHistogram1D errx02Hist = hf.createHistogram1D(runId + " errx02",40, 0., 0.4);
        tuple.project(errx02Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("phi2");
        IHistogram1D phi2Hist = hf.createHistogram1D(runId + " phi2",100, -0.05, 0.05);
        tuple.project(phi2Hist, eval, standardCuts);
        
        IPlotter plotter = plotterFactory.create(runId + " general");
        plotter.setTitle("general");
        plotter.createRegions(3,2);
        plotter.region(0).plot(x01Hist);
        // IFitResult result = fitter.fit(x01Hist,"g");
        gauss.setParameter("a",x01Hist.maxBinHeight());
        gauss.setParameter("mean",x01Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
        gauss.setParameter("sigma",x01Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
        if (x01Hist.allEntries()>5){
            IFitResult result = fitter.fit(x01Hist,gauss);
            plotter.region(0).plot(result.fittedFunction());
        }
        plotter.region(2).plot(errx01Hist);
        if (errx01Hist.allEntries()>5){
            IFitResult result = fitter.fit(errx01Hist,"g");
            plotter.region(2).plot(result.fittedFunction());
        }
        plotter.region(4).plot(phi1Hist);
        // result = fitter.fit(phi1Hist,"g");
        gauss.setParameter("a",phi1Hist.maxBinHeight());
        gauss.setParameter("mean",phi1Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.001);
        gauss.setParameter("sigma",phi1Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
        if (phi1Hist.allEntries()>5){
            IFitResult result = fitter.fit(phi1Hist,gauss);
            plotter.region(4).plot(result.fittedFunction());
        }
        plotter.region(1).plot(x02Hist);
        // result = fitter.fit(x02Hist,"g");
        gauss.setParameter("a",x02Hist.maxBinHeight());
        gauss.setParameter("mean",x02Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
        gauss.setParameter("sigma",x02Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
        if (x02Hist.allEntries()>5){
            IFitResult result = fitter.fit(x02Hist,gauss);
            plotter.region(1).plot(result.fittedFunction());
        }
        plotter.region(3).plot(errx02Hist);
        if (errx02Hist.allEntries()>5){
            IFitResult result = fitter.fit(errx02Hist,"g");
            plotter.region(3).plot(result.fittedFunction());
        }
        plotter.region(5).plot(phi2Hist);
        // result = fitter.fit(phi2Hist,"g");
        gauss.setParameter("a",phi2Hist.maxBinHeight());
        gauss.setParameter("mean",phi2Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.001);
        gauss.setParameter("sigma",phi2Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
        if (phi2Hist.allEntries()>5){
            IFitResult result = fitter.fit(phi2Hist,gauss);
            plotter.region(5).plot(result.fittedFunction());
        }
        
        plotter.show();
        
        
        
        
        // History plots: track parameters
        // -------------------------------
        
        // find time range by putting time into a cloud
        IEvaluator timeEval = tf.createEvaluator("time");
        ICloud1D timeCloud = hf.createCloud1D("time cloud");
        tuple.project(timeCloud,timeEval,standardCuts);
        IEvaluator relTimeEval = tf.createEvaluator("(time -" + timeCloud.lowerEdge() +")/60."); // in hours since start of run
        
        plotter = plotterFactory.create(runId + " Track Param History");
        plotter.setTitle("History plots");
        plotter.createRegions(2,2);
        
        int nbin = nTimeBin;
        
        
        // x01 history
        eval = tf.createEvaluator("x01");
        IProfile1D x01P1D = hf.createProfile1D("x01 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(x01P1D,relTimeEval,eval,standardCuts);
        IDataPointSet x01DPS = dpsf.create(runId + " x01 vs time",x01P1D);
        x01DPS.scaleErrors(1./Math.sqrt(x01P1D.allEntries()/nbin));
        plotter.region(0).plot(x01DPS,dpsStyle);
        
        // phi1 history
        eval = tf.createEvaluator("phi1");
        IProfile1D phi1P1D = hf.createProfile1D("phi1 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(phi1P1D,relTimeEval,eval,standardCuts);
        IDataPointSet phi1DPS = dpsf.create(runId + " phi1 vs time",phi1P1D);
        phi1DPS.scaleErrors(1./Math.sqrt(phi1P1D.allEntries()/nbin));
        plotter.region(1).plot(phi1DPS,dpsStyle);
        
        // x02 history
        eval = tf.createEvaluator("x02");
        IProfile1D x02P1D = hf.createProfile1D("x02 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(x02P1D,relTimeEval,eval,standardCuts);
        IDataPointSet x02DPS = dpsf.create(runId + " x02 vs time",x02P1D);
        x02DPS.scaleErrors(1./Math.sqrt(x02P1D.allEntries()/nbin));
        plotter.region(2).plot(x02DPS,dpsStyle);
        
        // phi2 history
        eval = tf.createEvaluator("phi2");
        IProfile1D phi2P1D = hf.createProfile1D("phi2 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(phi2P1D,relTimeEval,eval,standardCuts);
        IDataPointSet phi2DPS = dpsf.create(runId + " phi2 vs time",phi2P1D);
        phi2DPS.scaleErrors(1./Math.sqrt(phi2P1D.allEntries()/nbin));
        plotter.region(3).plot(phi2DPS,dpsStyle);
        
        
        
        plotter.show();
        
        // Amplitude for each fit row
        // --------------------------
        
        plotter = plotterFactory.create(runId + " Amplitude");
        plotter.setTitle("Amplitude");
        plotter.createRegions(4,2);
        
        int[] trkRows = trackRows.getValue();
        for (int i=0; i < Math.min(8,trkRows.length); i++) {
            int row = trkRows[i];
            eval = tf.createEvaluator("rsum" + row);
            IHistogram1D rsumHist = hf.createHistogram1D(runId + " rsum" + row,50, 0., maxRSum);
            IFilter rSumCuts = tf.createFilter(cuts + "&& rsum" + row + "<" + maxRSum);
            tuple.project(rsumHist, eval, rSumCuts);
            plotter.region(i).plot(rsumHist);
            gauss.setParameter("a",rsumHist.maxBinHeight());
            gauss.setParameter("mean",rsumHist.mean()); fitter.fitParameterSettings("mean").setStepSize(1.);
            gauss.setParameter("sigma",rsumHist.rms()); fitter.fitParameterSettings("sigma").setStepSize(1.);
            if (rsumHist.allEntries()>5){
                IFitResult result = fitter.fit(rsumHist,gauss);
                plotter.region(i).plot(result.fittedFunction());
            }
        }
        
        plotter.show();
        
        // History plots: Amplitude
        // ------------------------
        
        plotter = plotterFactory.create(runId + " Amplitude History");
        plotter.setTitle("Amplitude History");
        plotter.createRegions(4,2);
        
        nbin = nTimeBin;
        for (int i=0; i < Math.min(8,trkRows.length); i++) {
            int row = trkRows[i];
            eval = tf.createEvaluator("rsum" + row);
            IProfile1D sumP1D = hf.createProfile1D("rsum" + row + " vs time (hr)",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
            IFilter rSumCuts = tf.createFilter(cuts + "&& rsum" + row + "<" + maxRSum);
            tuple.project(sumP1D,relTimeEval,eval,rSumCuts);
            IDataPointSet sumDPS = dpsf.create(runId + " rsum" + row,sumP1D);
            sumDPS.scaleErrors(1./Math.sqrt(sumP1D.allEntries()/nbin));
            plotter.region(i).plot(sumDPS,dpsStyle);
            if (sumDPS.size()>1){
                IFitResult result = fitter.fit(sumDPS,"p0");
                plotter.region(i).plot(result.fittedFunction());
            }
        }
        
        plotter.show();
        
    }
    
}

