/*
 * Laser1Analyzer.java
 *
 * Created on January 25, 2005, 11:53 AM
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;

/**
 *
 * @author  karlen
 */
public class Laser1Analyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new Laser1Analyzer());
    }
    /** Creates a new instance of Laser1Analyzer */
    public Laser1Analyzer() {
        setName("Single laser analysis (version 1.3)");
        pL = getParameterList();
    }
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        // plotCuts();
        
        laser1Analysis();
    }
    
    int nTimeBin = 10; // number of time bins in history plots
    double maxRSum = 5000.; // maximum Rsum to enter plots
    
    public void laser1Analysis() {
        
        // XO, ERRX0, PHI, SIGMA, ERRSIG, Z0, TANL, DZ
        // -------------------------------------------
        
        
        IEvaluator eval = tf.createEvaluator("x0");
        IHistogram1D x0Hist = hf.createHistogram1D(runId + " x0",1000, -7.5, 7.5);
        tuple.project(x0Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("errx0");
        IHistogram1D errx0Hist = hf.createHistogram1D(runId + " errx0",40, 0., 0.4);
        tuple.project(errx0Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("phi");
        IHistogram1D phiHist = hf.createHistogram1D(runId + " phi",100, -0.15, 0.15);
        tuple.project(phiHist, eval, standardCuts);
        
        eval = tf.createEvaluator("sigma");
        IHistogram1D sigmaHist = hf.createHistogram1D(runId + " sigma",100, 0., 4.);
        tuple.project(sigmaHist, eval, standardCuts);
        
        eval = tf.createEvaluator("errsig");
        IHistogram1D errsigHist = hf.createHistogram1D(runId + " errsig",100, 0., 0.4);
        tuple.project(errsigHist, eval, standardCuts);
        
        eval = tf.createEvaluator("z0");
        IHistogram1D z0Hist = hf.createHistogram1D(runId + " z0",180, 0., 180.);
        tuple.project(z0Hist, eval, standardCuts);
        
        eval = tf.createEvaluator("tanl");
        IHistogram1D tanlHist = hf.createHistogram1D(runId + " tanL",50, -0.05, 0.05);
        tuple.project(tanlHist, eval, standardCuts);
        
        IPlotter plotter = plotterFactory.create(runId + " general");
        plotter.setTitle("general");
        plotter.createRegions(3,2);
        plotter.region(0).plot(x0Hist);
        //xx IFitResult result = fitter.fit(x0Hist,"g");
        gauss.setParameter("a",x0Hist.maxBinHeight());
        gauss.setParameter("mean",x0Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
        gauss.setParameter("sigma",x0Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.01);
        if (x0Hist.allEntries()>5){
            IFitResult result = fitter.fit(x0Hist,gauss);
            plotter.region(0).plot(result.fittedFunction());
        }
        plotter.region(1).plot(errx0Hist);
        if(errx0Hist.allEntries()>5) {
            IFitResult result = fitter.fit(errx0Hist,"g");
            plotter.region(1).plot(result.fittedFunction());
        }
        plotter.region(2).plot(sigmaHist);
        // result = fitter.fit(sigmaHist,"g");
        gauss.setParameter("a",sigmaHist.maxBinHeight());
        gauss.setParameter("mean",sigmaHist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
        gauss.setParameter("sigma",sigmaHist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.1);
        if (sigmaHist.allEntries()>5){
            IFitResult result = fitter.fit(sigmaHist,gauss);
            plotter.region(2).plot(result.fittedFunction());
        }
        plotter.region(3).plot(errsigHist);
        if (errsigHist.allEntries()>5){
            IFitResult result = fitter.fit(errsigHist,"g");
            plotter.region(3).plot(result.fittedFunction());
        }
        plotter.region(4).plot(phiHist);
        // result = fitter.fit(phiHist,"g");
        gauss.setParameter("a",phiHist.maxBinHeight());
        gauss.setParameter("mean",phiHist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.001);
        gauss.setParameter("sigma",phiHist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
        if (phiHist.allEntries()>5){
            IFitResult result = fitter.fit(phiHist,gauss);
            plotter.region(4).plot(result.fittedFunction());
        }
        plotter.region(5).plot(z0Hist);
        //result = fitter.fit(z0Hist,"g");
        gauss.setParameter("a",z0Hist.maxBinHeight());
        gauss.setParameter("mean",z0Hist.mean()); fitter.fitParameterSettings("mean").setStepSize(0.1);
        gauss.setParameter("sigma",z0Hist.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.1);
        //if (z0Hist.allEntries()>5){
        //    IFitResult result = fitter.fit(z0Hist,gauss);
        //    plotter.region(5).plot(result.fittedFunction());
        //}
        // plotter.region(6).plot(tanlHist);
        // result = fitter.fit(tanlHist,"g");
        // plotter.region(6).plot(result.fittedFunction());
        
        plotter.show();
        
        
        
        
        // History plots: track parameters
        // -------------------------------
        
        // find time range by putting time into a cloud
        IEvaluator timeEval = tf.createEvaluator("time");
        ICloud1D timeCloud = hf.createCloud1D("time cloud");
        tuple.project(timeCloud,timeEval,standardCuts);
        IEvaluator relTimeEval = tf.createEvaluator("(time -" + timeCloud.lowerEdge() +")/60."); // in hours since start of run
        
        plotter = plotterFactory.create(runId + " Track Param History");
        plotter.setTitle("History plots");
        plotter.createRegions(2,2);
        
        int nbin = nTimeBin;
        
        // x0 history
        eval = tf.createEvaluator("x0");
        IProfile1D x0P1D = hf.createProfile1D("x0 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(x0P1D,relTimeEval,eval,standardCuts);
        IDataPointSet x0DPS = dpsf.create(runId + " x0 vs time",x0P1D);
        x0DPS.scaleErrors(1./Math.sqrt(x0P1D.allEntries()/nbin));
        plotter.region(0).plot(x0DPS,dpsStyle);
        
        // phi history
        eval = tf.createEvaluator("phi");
        IProfile1D phiP1D = hf.createProfile1D("phi vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(phiP1D,relTimeEval,eval,standardCuts);
        IDataPointSet phiDPS = dpsf.create(runId + " phi vs time",phiP1D);
        phiDPS.scaleErrors(1./Math.sqrt(phiP1D.allEntries()/nbin));
        plotter.region(1).plot(phiDPS,dpsStyle);
        
        // sigma history
        eval = tf.createEvaluator("sigma");
        IProfile1D sigmaP1D = hf.createProfile1D("sigma vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(sigmaP1D,relTimeEval,eval,standardCuts);
        IDataPointSet sigmaDPS = dpsf.create(runId + " sigma vs time",sigmaP1D);
        sigmaDPS.scaleErrors(1./Math.sqrt(sigmaP1D.allEntries()/nbin));
        plotter.region(2).plot(sigmaDPS,dpsStyle);
        
        // z0 history
        eval = tf.createEvaluator("z0");
        IProfile1D z0P1D = hf.createProfile1D("z0 vs time",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
        tuple.project(z0P1D,relTimeEval,eval,standardCuts);
        IDataPointSet z0DPS = dpsf.create(runId + " z0 vs time",z0P1D);
        z0DPS.scaleErrors(1./Math.sqrt(z0P1D.allEntries()/nbin));
        plotter.region(3).plot(z0DPS,dpsStyle);
        
        
        
        plotter.show();
        
        // Amplitude for each fit row
        // --------------------------
        
        plotter = plotterFactory.create(runId + " Amplitude");
        plotter.setTitle("Amplitude");
        plotter.createRegions(4,2);
        
        int[] trkRows = trackRows.getValue();
        for (int i=0; i < Math.min(8,trkRows.length); i++) {
            int row = trkRows[i];
            eval = tf.createEvaluator("rsum" + row);
            IHistogram1D rsumHist = hf.createHistogram1D(runId + " rsum" + row,50, 0., maxRSum);
            IFilter rSumCuts = tf.createFilter(cuts + "&& rsum" + row + "<" + maxRSum);
            tuple.project(rsumHist, eval, rSumCuts);
            plotter.region(i).plot(rsumHist);
            gauss.setParameter("a",rsumHist.maxBinHeight());
            gauss.setParameter("mean",rsumHist.mean()); fitter.fitParameterSettings("mean").setStepSize(1.);
            gauss.setParameter("sigma",rsumHist.rms()); fitter.fitParameterSettings("sigma").setStepSize(1.);
            if (rsumHist.allEntries()>5){
                IFitResult result = fitter.fit(rsumHist,gauss);
                plotter.region(i).plot(result.fittedFunction());
            }
        }
        
        plotter.show();
        
        // History plots: Amplitude
        // ------------------------
        
        plotter = plotterFactory.create(runId + " Amplitude History");
        plotter.setTitle("Amplitude History");
        plotter.createRegions(4,2);
        
        nbin = nTimeBin;
        for (int i=0; i < Math.min(8,trkRows.length); i++) {
            int row = trkRows[i];
            eval = tf.createEvaluator("rsum" + row);
            IProfile1D sumP1D = hf.createProfile1D("rsum" + row + " vs time (hr)",nbin,0.,(timeCloud.upperEdge()-timeCloud.lowerEdge()+0.001)/60.);
            IFilter rSumCuts = tf.createFilter(cuts + "&& rsum" + row + "<" + maxRSum);
            tuple.project(sumP1D,relTimeEval,eval,rSumCuts);
            IDataPointSet sumDPS = dpsf.create(runId + " rsum" + row,sumP1D);
            sumDPS.scaleErrors(1./Math.sqrt(sumP1D.allEntries()/nbin));
            plotter.region(i).plot(sumDPS,dpsStyle);
            if (sumDPS.size()>1){
                IFitResult result = fitter.fit(sumDPS,"p0");
                plotter.region(i).plot(result.fittedFunction());
            }
        }
        
        plotter.show();
        
    }
    
}


