/*
 * DEdxAnalyzer.java
 *
 * Created on April 4, 2005
 */

package tupleanalyzer;

import hep.aida.*;
import java.io.*;
import tparameter.*;
import tupleanalyzer.*;


/**
 *
 * @author  karlen
 */
public class DEdxAnalyzer extends TupleAnalyzer {
    
    ParameterList pL;
    
    public static void main(String[] args) {
        Start(new DEdxAnalyzer());
    }
    /** Creates a new instance of DiffusionAnalyzer */
    public DEdxAnalyzer() {
        setName("DEdx analysis (version 1.5)");
        pL = getParameterList();
        dEdxAnalysisSetup();
    }
    
    IntegerParameter dEdxTrunc,nPBins;
    DoubleArrayParameter pBins;
    DoubleParameter dEdxMax;
    BooleanParameter attachAnalysis;
    IntegerParameter nAttachmentRows;
    
    public void dEdxAnalysisSetup() {
        pL.setCategory("dE/dx Analysis");
        dEdxTrunc = new IntegerParameter(pL, "Truncation choice", 1, "",
        "select which truncation calculation to use", true);
        nPBins = new IntegerParameter(pL, "Number of p bins", 8, "",
        "Enter the number of momentum bins (+1)", true);
        double[] pB = {1.,2.,3.,4.,5.,6.,8.,10.};
        pBins = new DoubleArrayParameter(pL, nPBins, "p bin edges", pB, "GeV/c",
        "Enter the edges of the momentum bins", true);
        dEdxMax = new DoubleParameter(pL, "maximum dEdx for fitting", 80000., "e/mm",
        "Enter the maximum dEdx used for fitting distribution to Gaussian", true);
        
        pL.setCategory("Attachment Analysis");
        attachAnalysis = new BooleanParameter(pL, "Do attachment study", false,
        "check this box if attachment study is to be done", true);
        nAttachmentRows = new IntegerParameter(pL,"number of rows for study",0,"",
        "enter number of rows used for attachment study",true);
    }
    
    
    public void doAnalysis(){
        // analysis of ntuple:
        
        setCuts();
        //plotCuts();
        
        dEdxAnalysis();
    }
    
    public void dEdxAnalysis() {
        
        IPlotter plotter = plotterFactory.create(runId + " dE/dx");
        plotter.setTitle("dE/dx");
        plotter.createRegions(2,2);
        
        double vd = driftVelocity.getValue()*10.; // in mm/time bin
        double vd2 = vd*vd;
        double mag = magField.getValue()/1000.; // in Tesla
        int trunc = dEdxTrunc.getValue();
        
        int nBin = nPBins.getValue()-1;
        double[] edges = pBins.getValue();
        double[] low = new double[nBin];
        double[] high = new double[nBin];
        int[] res = new int[nBin];
        for (int i=0;i<nBin;i++){
            low[i]=edges[i];
            high[i]=edges[i+1];
        }
        double dEdxM = dEdxMax.getValue();
        
        IEvaluator pEval = tf.createEvaluator("0.3*"+mag+"/abs(invR)/1000.*sqrt(1.+tanl*tanl*"+vd2+")");
        IEvaluator dEdxEval = tf.createEvaluator("dEdxy"+trunc+"/sqrt(1.+tanl*tanl*"+vd2+")");
        
        if(curvedTracking.getValue()){
            ICloud2D dEdxCloud = hf.createCloud2D("dEdx cloud");
            IFilter rangeCuts = tf.createFilter(cuts +
            " && 0.3*" + mag + "/abs(invR)/1000.*sqrt(1.+tanl*tanl*" + vd2 + ") <" + high[nBin-1] +
            " && dEdxy" + trunc + "/sqrt(1.+tanl*tanl*"+vd2+") <" + dEdxM);
            tuple.project(dEdxCloud,pEval,dEdxEval,rangeCuts);
            
            plotter.region(0).plot(dEdxCloud);
        }
        
        IHistogram1D dEdxAllH = hf.createHistogram1D("dEdx all p",40,0.,dEdxM);
        tuple.project(dEdxAllH,dEdxEval,standardCuts);
        plotter.region(3).plot(dEdxAllH);
        
        // fit corrected dEdx as a function of momentum
        if (curvedTracking.getValue()){
            int ip=0;
            IDataPointSet dEdxDPS= dpsf.create("dEdx vs p",2);
            for (int i=0; i < nBin; i++) {
                IHistogram1D dEdxH = hf.createHistogram1D("dEdx",40,0.,dEdxM);
                IFilter pCuts = tf.createFilter(cuts +
                " && 0.3*"+mag+"/abs(invR)/1000.*sqrt(1.+tanl*tanl*"+vd2+") >=" + low[i] +
                " && 0.3*"+mag+"/abs(invR)/1000.*sqrt(1.+tanl*tanl*"+vd2+") < " + high[i]);
                tuple.project(dEdxH,dEdxEval,pCuts);
                int temp = dEdxH.allEntries();
                if (temp > 5){
                    gauss.setParameter("a",dEdxH.maxBinHeight()); fitter.fitParameterSettings("a").setStepSize(0.5);
                    gauss.setParameter("mean",dEdxH.mean()); fitter.fitParameterSettings("mean").setStepSize(10.);
                    gauss.setParameter("sigma",dEdxH.rms()); fitter.fitParameterSettings("sigma").setStepSize(10.);
                    gauss.setParameter("background",0.); fitter.fitParameterSettings("background").setStepSize(1.);
                    IFitResult result = fitter.fit(dEdxH,gauss);
                    // if (i==0 || i== nBin-1) {
                    if (i==0) {
                        int iReg = 3;
                        if (i==0) iReg = 2;
                        plotter.region(iReg).plot(dEdxH);
                        plotter.region(iReg).plot(result.fittedFunction());
                    }
                    
                    String[] pars = result.fittedParameterNames();
                    double val = result.fittedParameter(pars[1]);
                    double err = Math.sqrt( result.covMatrixElement(1,1) );
                    dEdxDPS.addPoint();
                    dEdxDPS.point(ip).coordinate(0).setValue((low[i]+high[i])/2.);
                    dEdxDPS.point(ip).coordinate(1).setValue(val);
                    dEdxDPS.point(ip).coordinate(1).setErrorMinus(err);
                    dEdxDPS.point(ip).coordinate(1).setErrorPlus(err);
                    ip++;
                    
                    double sig = result.fittedParameter(pars[2]);
                    res[i] = (int) (sig*1000./val);
                    
                }
            }
            
            plotter.region(1).plot(dEdxDPS,dpsStyle);
        }
        
        plotter.show();
        
        if (mc.getValue()){
            plotter = plotterFactory.create(runId + " MC info");
            plotter.setTitle("MC");
            plotter.createRegions(2,2);
            
            IEvaluator tpEval = tf.createEvaluator("tpt*sqrt(1.+tanl*tanl*"+vd2+")");
            
            if(curvedTracking.getValue()){
                ICloud2D pCloud = hf.createCloud2D("p cloud");
                IFilter rangeCuts = tf.createFilter(cuts +
                " && 0.3*" + mag + "/abs(invR)/1000.*sqrt(1.+tanl*tanl*" + vd2 + ") <" + high[nBin-1] +
                " && tpt*sqrt(1.+tanl*tanl*"+vd2+")< 20.");
                tuple.project(pCloud,pEval,tpEval,rangeCuts);
                
                plotter.region(0).plot(pCloud);
            }
            
            // show true p as a function of reconstructed momentum
            if (curvedTracking.getValue()){
                int ip=0;
                IDataPointSet tpDPS= dpsf.create("true p vs p",2);
                for (int i=0; i < nBin; i++) {
                    IHistogram1D tpH = hf.createHistogram1D("true p",40,0.,high[i]*2.);
                    IFilter pCuts = tf.createFilter(cuts +
                    " && 0.3*"+mag+"/abs(invR)/1000.*sqrt(1.+tanl*tanl*"+vd2+") >=" + low[i] +
                    " && 0.3*"+mag+"/abs(invR)/1000.*sqrt(1.+tanl*tanl*"+vd2+") < " + high[i]);
                    tuple.project(tpH,tpEval,pCuts);
                    int temp = tpH.allEntries();
                    if (temp > 5){
                        
                        if (i==0 || i== nBin-1) {
                            int iReg = 3;
                            if (i==0) iReg = 2;
                            plotter.region(iReg).plot(tpH);
                            
                        }
                        
                        double val = tpH.mean();
                        double sig = tpH.rms(); // error bars show spread, not error in mean
                        tpDPS.addPoint();
                        tpDPS.point(ip).coordinate(0).setValue((low[i]+high[i])/2.);
                        tpDPS.point(ip).coordinate(1).setValue(val);
                        tpDPS.point(ip).coordinate(1).setErrorMinus(sig);
                        tpDPS.point(ip).coordinate(1).setErrorPlus(sig);
                        ip++;
                        
                    }
                }
                plotter.region(1).plot(tpDPS,dpsStyle);
            }
            
            plotter.show();
            
        }
        
        int sum=0;
        for (int i=0; i<nBin; i++) {
            sum+=res[i];
            System.out.println("" + low[i] + "< p <" + high[i] + " resolution = " + res[i]/10. + "%");
        }
        System.out.println("average resolution = " + sum/nBin/10. + "%");
        
        if (attachAnalysis.getValue()){
            
            
            IPlotter plotter2 = plotterFactory.create(runId + " att distributions");
            plotter2.setTitle("att");
            plotter2.createRegions(3,2);
            
            plotter = plotterFactory.create(runId + " Attachment");
            plotter.setTitle("Attachment");
            plotter.createRegions(2,2);
            
            // create and fill cloud of dE/dx vs drift time
            ICloud2D attachCloud = hf.createCloud2D("attach cloud");
            for (int i=0; i<nAttachmentRows.getValue(); i++){
                IEvaluator attEval = tf.createEvaluator("att"+i+"/sqrt(1.+tanl*tanl*"+vd2+")");
                IEvaluator z0Eval = tf.createEvaluator("z0+tanl*yatt"+i);
                IFilter attCuts = tf.createFilter(cuts + " && att"+i+">-9990. && att"+i+"/sqrt(1.+tanl*tanl*"+vd2+")<"+dEdxMax.getValue());
                tuple.project(attachCloud,z0Eval,attEval,attCuts);
            }
            
            plotter.region(0).plot(attachCloud);
            
            // fit dE/dx as a function of drift distance
            // use the mean of the distribution with the top 10% removed
            
            int ip=0;
            IDataPointSet attachDPS= dpsf.create("attach vs drift",2);
            for (int i=0; i < nDriftBin.getValue(); i++) {
                double z0Low = driftMin.getValue() + (driftMax.getValue()-driftMin.getValue())*i/nDriftBin.getValue();
                double z0High = z0Low + (driftMax.getValue()-driftMin.getValue())/nDriftBin.getValue();
                IHistogram1D attH = hf.createHistogram1D("att",20,0.,dEdxMax.getValue());
                ICloud1D attC1D = hf.createCloud1D("att cloud");
                for (int j=0; j<nAttachmentRows.getValue(); j++){
                    IFilter timeCuts = tf.createFilter(cuts + " && yatt"+j+">-500 && z0+tanl*yatt"+j+">=" + z0Low + " && z0+tanl*yatt"+j+"<" + z0High);
                    IEvaluator attEval = tf.createEvaluator("att"+j+"/sqrt(1.+tanl*tanl*"+vd2+")");
                    tuple.project(attH,attEval,timeCuts);
                    tuple.project(attC1D,attEval,timeCuts);
                }
                
                int nAtt = attC1D.entries();
                double[] attVal = new double[nAtt];
                for (int j=0; j< nAtt; j++)attVal[j] = attC1D.value(j);
                java.util.Arrays.sort(attVal);
                double nSum = nAtt*0.9; // sum over lowest 90% of values
                double sumAtt = 0.;
                double sumAtt2 = 0.;
                for (int j=0; j<nSum; j++){
                    sumAtt += attVal[j];
                    sumAtt2 += attVal[j]*attVal[j];
                }
                double meanAtt = sumAtt/nSum;
                double rmsAtt = Math.sqrt(sumAtt2/nSum - meanAtt*meanAtt);                
                
                int temp = attH.allEntries();
                if (temp > 20){
                    gauss.setParameter("a",attH.maxBinHeight()); fitter.fitParameterSettings("a").setStepSize(0.5);
                    gauss.setParameter("mean",attH.mean()); fitter.fitParameterSettings("mean").setStepSize(0.01);
                    gauss.setParameter("sigma",attH.rms()); fitter.fitParameterSettings("sigma").setStepSize(0.001);
                    gauss.setParameter("background",0.); fitter.fitParameterSettings("background").setStepSize(0.05);
                    IFitResult result = fitter.fit(attH,gauss);
                    if (i==0 || i== nDriftBin.getValue()-1) {
                        int iReg = 3;
                        if (i==0) iReg = 2;
                        plotter.region(iReg).plot(attH);
                        plotter.region(iReg).plot(result.fittedFunction());
                    }
                    
                    String[] pars = result.fittedParameterNames();
                    // double val = result.fittedParameter(pars[1]);
                    // double err = Math.sqrt( result.covMatrixElement(1,1) );
                    // double val = attH.mean();
                    // double err = attH.rms()/Math.sqrt(attH.allEntries());
                    
                    double val = meanAtt;
                    double err = rmsAtt/Math.sqrt(nSum);                    
                    
                    attachDPS.addPoint();
                    attachDPS.point(ip).coordinate(0).setValue((z0Low+z0High)/2.);
                    attachDPS.point(ip).coordinate(1).setValue(val);
                    attachDPS.point(ip).coordinate(1).setErrorMinus(err);
                    attachDPS.point(ip).coordinate(1).setErrorPlus(err);
                    ip++;
                    if (i<6){
                        plotter2.region(i).plot(attH);
                    //    plotter2.region(i).plot(result.fittedFunction());
                    }
                }
            }
            
            plotter.region(1).plot(attachDPS,dpsStyle);
            
            plotter.show();
            plotter2.show();
            
            
        }
        
        
    }
    
}
