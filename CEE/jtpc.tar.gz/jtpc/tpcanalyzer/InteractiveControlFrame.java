/*
 * InteractiveControlFrame.java
 *
 * Created on July 10, 2002, 5:20 PM
 */


package tpcanalyzer;

import tpcdata.*;
import tpcsimulator.Tpc;
import tpcsimulator.ExampleFileFilter;
import tpcsimulator.PadMesh;
import tpcsimulator.PadMeshEventFrame;
import tpctracker.FitterControlFrame;
import tpctracker.FitterControlFrame2;
import tparameter.ParameterList;
import java.io.*;
import javax.swing.*;


/**
 *
 * @author  karlen
 * @version
 */
public class InteractiveControlFrame extends javax.swing.JFrame {
    
    Tpc tpc;
    File tpcDir = null;
    File parDir = null;
    boolean tpcReady = false;
    
    File dataDir = null;
    boolean dataReady = false;
    boolean eventAvailable = false;
    TpcData tpcData = null;
    boolean analyzerReady = false;
    boolean fillTuple = false;
    String tFileName,dFileName,aFileName; // holds the names of current files: to be written to last.tpcanalyzer file on exit
    
    TpcAnalyzer tpcAnalyzer;
    
    PadMeshEventFrame padMeshEventFrame = null;
    FitterControlFrame fitterControlFrame = null;
    
    /** Creates new Interactive Control Frame */
    public InteractiveControlFrame(TpcAnalyzer tpcAnalyzer) {
        this.tpcAnalyzer = tpcAnalyzer;
        setTitle("TPC Data Analysis: " + tpcAnalyzer.toString());
        initComponents();
        enableButtons();
        pack();
        tFileName="";
        dFileName="";
        aFileName="";
    }
    
    public InteractiveControlFrame(TpcAnalyzer tpcAnalyzer, String tFileName, String dFileName, String aFileName) {
        this.tpcAnalyzer = tpcAnalyzer;
        setTitle("TPC Data Analysis: " + tpcAnalyzer.toString());
        initComponents();
        enableButtons();
        pack();
        tFileLoad(new File(tFileName));
        dFileLoad(new File(dFileName));
        aFileLoad(new File(aFileName));
    }
    
    void setTpcReady(boolean ready) {
        tpcReady = ready;
        enableButtons();
    }
    
    void setDataReady(boolean ready) {
        dataReady = ready;
        enableButtons();
    }
    
    void setEventAvailable(boolean available) {
        eventAvailable = available;
        enableButtons();
    }
    
    void enableButtons() {
        dataFileButton.setEnabled(tpcReady);
        skipButton.setEnabled(tpcReady && dataReady);
        nextEventProcessButton.setEnabled(tpcReady && dataReady);
        allEventsProcessButton.setEnabled(tpcReady && dataReady);
        displayEventButton.setEnabled(tpcReady && eventAvailable);
        fitterControlButton.setEnabled(tpcReady && eventAvailable && tpcAnalyzer.getFitterMultiplicity()==1);
        fitter2ControlButton.setEnabled(tpcReady && eventAvailable && tpcAnalyzer.getFitterMultiplicity()==2);
        analParamLoadButton.setEnabled(true);
        analParamEditButton.setEnabled(true);
        analParamSaveButton.setEnabled(true);
        redoButton.setEnabled(tpcReady && eventAvailable);
    }
    
    void doAnalysis() {
        eventStatusField.setText("-");
        if (eventAvailable) {
            eventStatusField.setText(tpcAnalyzer.doAnalysis(fillTuple));
            if (fitterControlFrame != null) {
                fitterControlFrame.setSeedParam(tpcAnalyzer.getSeedParam());
                fitterControlFrame.setRowsToFit(tpcAnalyzer.getRowsToFit());
            }
        }
    }
    
    private void tFileLoad(File tFile) {
        tpcDir = tFile.getParentFile();
        try {
            if (tFile.getName().length() > 0) {
                FileInputStream in = new FileInputStream(tFile);
                ObjectInputStream object = new ObjectInputStream(in);
                tpc = (Tpc)object.readObject();
                object.close();
                tpcField.setText(tFile.getAbsolutePath());
                
                if (tpcAnalyzer.setTpc(tpc)){
                    setTpcReady(true);
                } else {
                    setTpcReady(true);
                    tpcField.setText("Selected TPC does not have fittable readout");
                }
                
                // remove windows associated with prior TPC
                if (padMeshEventFrame != null) {
                    padMeshEventFrame.setVisible(false);
                    padMeshEventFrame = null;
                }
                if (fitterControlFrame != null) {
                    fitterControlFrame.setVisible(false);
                    fitterControlFrame = null;
                }
                tFileName = tFile.getAbsolutePath();
            }
        }
        catch (IOException except) {
            tpcField.setText("Cannot read file");
            setTpcReady(false);
        }
        catch (ClassNotFoundException except2) {
            tpcField.setText("Invalid tpc file");
            setTpcReady(false);
        }
        setEventAvailable(false);
    }
    
    private void dFileLoad(File readFile) {
        dataDir = readFile.getParentFile();
        dataFileField.setText(readFile.toString());
        int len = (readFile.getName()).length();
        String ext = readFile.getName().substring(len-3);
        if (ext.equals("mid")){
            tpcData = new MidasTpcData(readFile,false);
        } else if (ext.equals("tek")){
            tpcData = new TekTpcData(readFile,false);
        } else if (ext.equals("irq")){
            tpcData = new IrqTpcData(readFile,false);
        } else if (ext.equals("dsy")){
            tpcData = new DesyTpcData(readFile,false);
        } else if (ext.equals("cpt")){
            tpcData = new CptTpcData(readFile,false);
        } else if (ext.equals(".mc")){
            tpcData = new McTpcData(readFile,false);
        } else if (ext.equals("str")){
            tpcData = new StrTpcData(readFile,false);
        } else if (ext.equals("cio")){
            tpcData = new LcioTpcData(readFile,false);
        } else if (ext.equals("dat")){
            tpcData = new T2KTpcData(readFile,false);
        }
        setDataReady(tpcData.isGood());
        if (tpcData.isGood()) {
            commentsField.setText(tpcData.getComment());
            chanField.setText("" + tpcData.getNChannel());
            timeField.setText("" + tpcData.getNTimeBin());
            runField.setText("" + tpcData.getRunNumber());
            tpcAnalyzer.setTpcData(tpcData);
            dFileName = readFile.getAbsolutePath();
        } else {
            commentsField.setText("Data file header invalid");
            chanField.setText("-");
            timeField.setText("-");
            runField.setText("-");
        }
        setEventAvailable(false);
    }
    
    private void aFileLoad(File afile) {
        parDir = afile.getParentFile();
        try {
            if (afile.getName().length() > 0) {
                FileInputStream in = new FileInputStream(afile);
                ObjectInputStream object = new ObjectInputStream(in);
                ParameterList pL = (ParameterList)object.readObject();
                object.close();
                analParamField.setText(afile.getAbsolutePath());
                tpcAnalyzer.updateParameterList(pL);
                aFileName = afile.getAbsolutePath();
            }
        }
        catch (IOException except) {
            analParamField.setText("Cannot read file");
        }
        catch (ClassNotFoundException except2) {
            analParamField.setText("Invalid par file");
        }
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        mainPanel = new javax.swing.JPanel();
        tpcPanel = new javax.swing.JPanel();
        tpcDefinitionPanel = new java.awt.Panel();
        tpcLabel = new javax.swing.JLabel();
        tpcField = new javax.swing.JTextField();
        tpcButton = new javax.swing.JButton();
        dataPanel = new javax.swing.JPanel();
        dataFilePanel = new javax.swing.JPanel();
        dataFileLabel = new javax.swing.JLabel();
        dataFileField = new javax.swing.JTextField();
        dataFileButton = new javax.swing.JButton();
        commentsPanel = new javax.swing.JPanel();
        commentsLabel = new javax.swing.JLabel();
        commentsField = new javax.swing.JTextField();
        dataParamPanel = new javax.swing.JPanel();
        chanLabel = new javax.swing.JLabel();
        chanField = new javax.swing.JTextField();
        timeLabel = new javax.swing.JLabel();
        timeField = new javax.swing.JTextField();
        runLabel = new javax.swing.JLabel();
        runField = new javax.swing.JTextField();
        analysisPanel = new javax.swing.JPanel();
        analParamPanel = new javax.swing.JPanel();
        analParamLabel = new javax.swing.JLabel();
        analParamField = new javax.swing.JTextField();
        analParamLoadButton = new javax.swing.JButton();
        analParamEditButton = new javax.swing.JButton();
        analParamSaveButton = new javax.swing.JButton();
        nextEventPanel = new javax.swing.JPanel();
        nextEventProcessButton = new javax.swing.JButton();
        redoButton = new javax.swing.JButton();
        skipButton = new javax.swing.JButton();
        nextEventLabel = new javax.swing.JLabel();
        nextEventField = new javax.swing.JTextField();
        eventStatusField = new javax.swing.JTextField();
        displayEventButton = new javax.swing.JButton();
        fitterControlButton = new javax.swing.JButton();
        fitter2ControlButton = new javax.swing.JButton();
        allEventsPanel = new javax.swing.JPanel();
        ntupleLabel = new javax.swing.JLabel();
        ntupleField = new javax.swing.JTextField();
        allEventsProcessButton = new javax.swing.JButton();
        processStatusField = new javax.swing.JTextField();

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        mainPanel.setLayout(new javax.swing.BoxLayout(mainPanel, javax.swing.BoxLayout.Y_AXIS));

        tpcPanel.setLayout(new javax.swing.BoxLayout(tpcPanel, javax.swing.BoxLayout.Y_AXIS));

        tpcPanel.setBorder(new javax.swing.border.TitledBorder("TPC"));
        tpcDefinitionPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        tpcDefinitionPanel.setBackground(new java.awt.Color(204, 204, 204));
        tpcDefinitionPanel.setFont(new java.awt.Font("Dialog", 0, 11));
        tpcDefinitionPanel.setForeground(java.awt.Color.black);
        tpcLabel.setText("TPC definition:");
        tpcDefinitionPanel.add(tpcLabel);

        tpcField.setEditable(false);
        tpcField.setText("unspecified");
        tpcField.setMinimumSize(new java.awt.Dimension(250, 20));
        tpcField.setPreferredSize(new java.awt.Dimension(250, 20));
        tpcDefinitionPanel.add(tpcField);

        tpcButton.setText("load...");
        tpcButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tpcButtonActionPerformed(evt);
            }
        });

        tpcDefinitionPanel.add(tpcButton);

        tpcPanel.add(tpcDefinitionPanel);

        mainPanel.add(tpcPanel);

        dataPanel.setLayout(new javax.swing.BoxLayout(dataPanel, javax.swing.BoxLayout.Y_AXIS));

        dataPanel.setBorder(new javax.swing.border.TitledBorder("Data"));
        dataFilePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        dataFileLabel.setText("Data file:");
        dataFilePanel.add(dataFileLabel);

        dataFileField.setEditable(false);
        dataFileField.setText("unspecified");
        dataFileField.setMinimumSize(new java.awt.Dimension(250, 20));
        dataFileField.setPreferredSize(new java.awt.Dimension(250, 20));
        dataFilePanel.add(dataFileField);

        dataFileButton.setText("load...");
        dataFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataFileButtonActionPerformed(evt);
            }
        });

        dataFilePanel.add(dataFileButton);

        dataPanel.add(dataFilePanel);

        commentsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        commentsLabel.setText("     comment:");
        commentsPanel.add(commentsLabel);

        commentsField.setEditable(false);
        commentsField.setText("-");
        commentsField.setMinimumSize(new java.awt.Dimension(320, 20));
        commentsField.setPreferredSize(new java.awt.Dimension(320, 20));
        commentsPanel.add(commentsField);

        dataPanel.add(commentsPanel);

        dataParamPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        chanLabel.setText("     channels:");
        dataParamPanel.add(chanLabel);

        chanField.setEditable(false);
        chanField.setText("-");
        chanField.setMinimumSize(new java.awt.Dimension(40, 20));
        chanField.setPreferredSize(new java.awt.Dimension(40, 20));
        dataParamPanel.add(chanField);

        timeLabel.setText("     time bins:");
        dataParamPanel.add(timeLabel);

        timeField.setEditable(false);
        timeField.setText("-");
        timeField.setMinimumSize(new java.awt.Dimension(40, 20));
        timeField.setPreferredSize(new java.awt.Dimension(40, 20));
        dataParamPanel.add(timeField);

        runLabel.setText("     run number:");
        dataParamPanel.add(runLabel);

        runField.setEditable(false);
        runField.setText("-");
        runField.setMinimumSize(new java.awt.Dimension(40, 20));
        runField.setPreferredSize(new java.awt.Dimension(40, 20));
        dataParamPanel.add(runField);

        dataPanel.add(dataParamPanel);

        mainPanel.add(dataPanel);

        analysisPanel.setLayout(new javax.swing.BoxLayout(analysisPanel, javax.swing.BoxLayout.Y_AXIS));

        analysisPanel.setBorder(new javax.swing.border.TitledBorder("Analysis"));
        analParamPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        analParamLabel.setText("Analysis parameters: ");
        analParamPanel.add(analParamLabel);

        analParamField.setEditable(false);
        analParamField.setText("default");
        analParamField.setMinimumSize(new java.awt.Dimension(250, 20));
        analParamField.setPreferredSize(new java.awt.Dimension(250, 20));
        analParamPanel.add(analParamField);

        analParamLoadButton.setText("load...");
        analParamLoadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                analParamLoadButtonActionPerformed(evt);
            }
        });

        analParamPanel.add(analParamLoadButton);

        analParamEditButton.setText("edit...");
        analParamEditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                analParamEditButtonActionPerformed(evt);
            }
        });

        analParamPanel.add(analParamEditButton);

        analParamSaveButton.setText("save...");
        analParamSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                analParamSaveButtonActionPerformed(evt);
            }
        });

        analParamPanel.add(analParamSaveButton);

        analysisPanel.add(analParamPanel);

        nextEventPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        nextEventProcessButton.setText("process next event");
        nextEventProcessButton.setEnabled(false);
        nextEventProcessButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextEventProcessButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(nextEventProcessButton);

        redoButton.setText("reprocess");
        redoButton.setEnabled(false);
        redoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(redoButton);

        skipButton.setText("skip 100");
        skipButton.setEnabled(false);
        skipButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                skipButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(skipButton);

        nextEventLabel.setText("Event #:");
        nextEventPanel.add(nextEventLabel);

        nextEventField.setEditable(false);
        nextEventField.setText("-");
        nextEventField.setMinimumSize(new java.awt.Dimension(60, 20));
        nextEventField.setPreferredSize(new java.awt.Dimension(60, 20));
        nextEventPanel.add(nextEventField);

        eventStatusField.setEditable(false);
        eventStatusField.setText("-");
        eventStatusField.setMinimumSize(new java.awt.Dimension(60, 20));
        eventStatusField.setPreferredSize(new java.awt.Dimension(60, 20));
        nextEventPanel.add(eventStatusField);

        displayEventButton.setText("event display");
        displayEventButton.setEnabled(false);
        displayEventButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayEventButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(displayEventButton);

        fitterControlButton.setText("1 track fitter");
        fitterControlButton.setEnabled(false);
        fitterControlButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fitterControlButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(fitterControlButton);

        fitter2ControlButton.setText("2 track fitter");
        fitter2ControlButton.setEnabled(false);
        fitter2ControlButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fitter2ControlButtonActionPerformed(evt);
            }
        });

        nextEventPanel.add(fitter2ControlButton);

        analysisPanel.add(nextEventPanel);

        allEventsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        ntupleLabel.setText("aida file:");
        allEventsPanel.add(ntupleLabel);

        ntupleField.setText("unspecified");
        ntupleField.setMinimumSize(new java.awt.Dimension(160, 20));
        ntupleField.setPreferredSize(new java.awt.Dimension(160, 20));
        allEventsPanel.add(ntupleField);

        allEventsProcessButton.setText("process remaining events");
        allEventsProcessButton.setEnabled(false);
        allEventsProcessButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                allEventsProcessButtonActionPerformed(evt);
            }
        });

        allEventsPanel.add(allEventsProcessButton);

        processStatusField.setEditable(false);
        processStatusField.setText("-");
        processStatusField.setMinimumSize(new java.awt.Dimension(160, 20));
        processStatusField.setPreferredSize(new java.awt.Dimension(160, 20));
        allEventsPanel.add(processStatusField);

        analysisPanel.add(allEventsPanel);

        mainPanel.add(analysisPanel);

        getContentPane().add(mainPanel, java.awt.BorderLayout.CENTER);

    }//GEN-END:initComponents

    private void fitter2ControlButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fitter2ControlButtonActionPerformed
        // Add your handling code here:
      // create a new 2 track fitter if there is none, or if it is not a 2 track fitter
      if (fitterControlFrame == null || fitterControlFrame.getFitterMultiplicity() != 2) {
          PadMesh padMesh = tpcAnalyzer.getPadMesh();
          fitterControlFrame = new FitterControlFrame2(padMesh);
          if (padMeshEventFrame != null) padMeshEventFrame.setFitterControlFrame(fitterControlFrame);
          fitterControlFrame.setupXYFitter();
      }
      fitterControlFrame.setVisible(true);
    }//GEN-LAST:event_fitter2ControlButtonActionPerformed
    
    private void skipButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skipButtonActionPerformed
        // Add your handling code here:
        // Add your handling code here:
        if (tpcData != null) {
            for (int i=0; i < 100; i++) {
                int istat = tpcData.readEvent();
                if (istat == -1) {
                    // error reading event
                    setDataReady(false);
                    setEventAvailable(false);
                    nextEventField.setText("-");
                } else {
                    nextEventField.setText("" + tpcData.getEventNumber());
                    setEventAvailable(true);
                    if (istat == 0) {
                        // end of file
                        setDataReady(false);
                    }
                }
            }
            doAnalysis();
            if(padMeshEventFrame != null)padMeshEventFrame.drawEvent();
        }
    }//GEN-LAST:event_skipButtonActionPerformed
    
  private void analParamSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_analParamSaveButtonActionPerformed
      // Add your handling code here:
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("par");
      filter.setDescription("TPC analysis parameter files");
      chooser.setFileFilter(filter);
      if (parDir != null) chooser.setCurrentDirectory(parDir);
      String fileName = "";
      //**********
      int returnVal = chooser.showSaveDialog(InteractiveControlFrame.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          fileName = chooser.getSelectedFile().getAbsolutePath();
          parDir = chooser.getSelectedFile().getParentFile();
          if (!fileName.endsWith(".par"))
              fileName= fileName+".par";
          try {
              if (fileName.length() > 0) {
                  FileOutputStream in = new FileOutputStream(fileName);
                  ObjectOutputStream iobject = new ObjectOutputStream(in);
                  iobject.writeObject(tpcAnalyzer.getParameterList());
                  analParamField.setText(fileName);
                  iobject.flush();
                  iobject.close();
                  aFileName = fileName;
              }
          }
          catch (IOException except) {
              analParamField.setText("Cannot save file");
          }
      }
  }//GEN-LAST:event_analParamSaveButtonActionPerformed
  
  private void analParamLoadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_analParamLoadButtonActionPerformed
      // Add your handling code here:
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("par");
      filter.setDescription("TPC analysis parameter files");
      chooser.setFileFilter(filter);
      if (parDir != null) chooser.setCurrentDirectory(parDir);
      File afile;
      //**********
      int returnVal = chooser.showOpenDialog(InteractiveControlFrame.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          afile= chooser.getSelectedFile();
          aFileLoad(afile);
      }
  }//GEN-LAST:event_analParamLoadButtonActionPerformed
  
  private void allEventsProcessButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allEventsProcessButtonActionPerformed
      // Add your handling code here:
      processStatusField.setText("-");
      tpcAnalyzer.aidaSetup(ntupleField.getText());
      int nproc = 0;
      fillTuple = true;
      while (dataReady) {
          nextEventProcessButtonActionPerformed(evt);
          nproc++;
      }
      fillTuple = false;
      tpcAnalyzer.aidaCommit();
      processStatusField.setText(" " + nproc + " events processed");
  }//GEN-LAST:event_allEventsProcessButtonActionPerformed
  
  private void redoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoButtonActionPerformed
      // Add your handling code here:
      doAnalysis();
      enableButtons();
  }//GEN-LAST:event_redoButtonActionPerformed
  
  private void fitterControlButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fitterControlButtonActionPerformed
      // Add your handling code here:
      // create a new 1 track fitter if there is none, or if it is not a 1 track fitter
      if (fitterControlFrame == null || fitterControlFrame.getFitterMultiplicity() != 1) {
          PadMesh padMesh = tpcAnalyzer.getPadMesh();
          fitterControlFrame = new FitterControlFrame(padMesh);
          if (padMeshEventFrame != null) padMeshEventFrame.setFitterControlFrame(fitterControlFrame);
          fitterControlFrame.setupXYFitter();
      }
      fitterControlFrame.setVisible(true);
  }//GEN-LAST:event_fitterControlButtonActionPerformed
  
  private void displayEventButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayEventButtonActionPerformed
      // Add your handling code here:
      // setup the event display if necessary
      if (padMeshEventFrame == null) {
          PadMesh padMesh = tpcAnalyzer.getPadMesh();
          padMeshEventFrame = padMesh.getEventFrame();
          padMeshEventFrame.setDemuxEnabled(false);
          padMeshEventFrame.setPulseDataEnabled(true);
          padMeshEventFrame.setSeedTrackEnabled(true);
          if (fitterControlFrame != null) padMeshEventFrame.setFitterControlFrame(fitterControlFrame);
          if (tpcAnalyzer != null) padMeshEventFrame.setTpcAnalyzer(tpcAnalyzer);
      }
      padMeshEventFrame.setVisible(true);
  }//GEN-LAST:event_displayEventButtonActionPerformed
  
  private void analParamEditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_analParamEditButtonActionPerformed
      // Add your handling code here:
      (tpcAnalyzer.getParameterList()).show(this);
  }//GEN-LAST:event_analParamEditButtonActionPerformed
  
  private void nextEventProcessButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextEventProcessButtonActionPerformed
      // Add your handling code here:
      if (tpcData != null) {
          int istat = tpcData.readEvent();
          if (istat == -1) {
              // error reading event
              setDataReady(false);
              setEventAvailable(false);
              nextEventField.setText("-");
          } else {
              nextEventField.setText("" + tpcData.getEventNumber());
              setEventAvailable(true);
              if (istat == 0) {
                  // end of file
                  setDataReady(false);
              }
          }
          doAnalysis();
          if(padMeshEventFrame != null)padMeshEventFrame.drawEvent();
      }
  }//GEN-LAST:event_nextEventProcessButtonActionPerformed
  
  private void dataFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataFileButtonActionPerformed
      // Add your handling code here:
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("mid");
      filter.addExtension("tek");
      filter.addExtension("irq");
      filter.addExtension("dsy");
      filter.addExtension("cpt");
      filter.addExtension("mc");
      filter.addExtension("str");
      filter.addExtension("slcio");
      filter.addExtension("dat");
      filter.setDescription("TPC data files");
      chooser.setFileFilter(filter);
      if (dataDir != null) chooser.setCurrentDirectory(dataDir);
      int returnVal = chooser.showOpenDialog(InteractiveControlFrame.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          File readFile= chooser.getSelectedFile();
          dFileLoad(readFile);
      }
  }//GEN-LAST:event_dataFileButtonActionPerformed
  
  private void tpcButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tpcButtonActionPerformed
      // Add your handling code here:
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("tpc");
      filter.setDescription("TPC files");
      chooser.setFileFilter(filter);
      if (tpcDir != null) chooser.setCurrentDirectory(tpcDir);
      File tFile;
      //**********
      int returnVal = chooser.showOpenDialog(InteractiveControlFrame.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          tFile= chooser.getSelectedFile();
          tFileLoad(tFile);
      }
  }//GEN-LAST:event_tpcButtonActionPerformed
  
  /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        // write out a last.tpcanalyzer file so that we can quickly start from where we left off
        if (tFileName.length() > 1 && dFileName.length() > 1 && aFileName.length() > 1) {
            try {
                File outputFile = new File("last.tpcanalyzer");
                FileOutputStream fos = new FileOutputStream(outputFile);
                Writer w = new BufferedWriter(new OutputStreamWriter(fos));
                w.write(tFileName);
                w.write('\n');
                w.write(dFileName);
                w.write('\n');
                w.write(aFileName);
                w.write('\n');
                w.flush();
                w.close();
            }
            catch (IOException except) { }
        }
        
        System.exit(0);
    }//GEN-LAST:event_exitForm
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel allEventsPanel;
    private javax.swing.JButton allEventsProcessButton;
    private javax.swing.JButton analParamEditButton;
    private javax.swing.JTextField analParamField;
    private javax.swing.JLabel analParamLabel;
    private javax.swing.JButton analParamLoadButton;
    private javax.swing.JPanel analParamPanel;
    private javax.swing.JButton analParamSaveButton;
    private javax.swing.JPanel analysisPanel;
    private javax.swing.JTextField chanField;
    private javax.swing.JLabel chanLabel;
    private javax.swing.JTextField commentsField;
    private javax.swing.JLabel commentsLabel;
    private javax.swing.JPanel commentsPanel;
    private javax.swing.JButton dataFileButton;
    private javax.swing.JTextField dataFileField;
    private javax.swing.JLabel dataFileLabel;
    private javax.swing.JPanel dataFilePanel;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JPanel dataParamPanel;
    private javax.swing.JButton displayEventButton;
    private javax.swing.JTextField eventStatusField;
    private javax.swing.JButton fitter2ControlButton;
    private javax.swing.JButton fitterControlButton;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTextField nextEventField;
    private javax.swing.JLabel nextEventLabel;
    private javax.swing.JPanel nextEventPanel;
    private javax.swing.JButton nextEventProcessButton;
    private javax.swing.JTextField ntupleField;
    private javax.swing.JLabel ntupleLabel;
    private javax.swing.JTextField processStatusField;
    private javax.swing.JButton redoButton;
    private javax.swing.JTextField runField;
    private javax.swing.JLabel runLabel;
    private javax.swing.JButton skipButton;
    private javax.swing.JTextField timeField;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JButton tpcButton;
    private java.awt.Panel tpcDefinitionPanel;
    private javax.swing.JTextField tpcField;
    private javax.swing.JLabel tpcLabel;
    private javax.swing.JPanel tpcPanel;
    // End of variables declaration//GEN-END:variables
    
}