/*
 * TpcAnalyzer.java
 *
 * Created on July 10, 2002, 9:24 PM
 */

package tpcanalyzer;

import tpcsimulator.Tpc;
import tpcsimulator.TpcPart;
import tpcsimulator.PadMesh;
import tpcdata.*;
import tparameter.*;
import tpctracker.*;
import hep.aida.*;
import java.io.*;
import java.text.*;
import java.util.Vector;

/**
 *
 *  Analyzes the bottom most fittable pads in the tpc
 *
 * @author  karlen
 * @version
 */
public class TpcAnalyzer {
    
    Tpc tpc;
    PadMesh padMesh;
    public TpcData tpcData;
    
    public IAnalysisFactory af;
    public ITuple tuple;
    public ITree tree;
    
    public int nChannel;
    public int nTimeBin;
    public int iData[][]; // raw data
    public double data[][]; // pedestal corrected data
    public double seedParam[]; // seed track parameters
    public boolean badChannel[]; // channels to avoid in analysis
    
    public XYFitter xyFitter;
    public YZFitter yzFitter;
    
    ParameterList pL;
    public IntegerParameter nBinPedestal,pulseDelay,pulseLength,minElectron;
    public DoubleParameter scaleFactor,gain;
    
    String name;
    
    public final static double electronCharge = 1.6E-4; // (fC)
    
    /** Creates new TpcAnalyzer */
    public TpcAnalyzer() {
        name = "Default analyzer (version 0.1)";
        pL = new ParameterList("TPC Analyzer parameters");
        defineBasicParameters(pL);
        seedParam = new double[8];
    }
    
    public void defineBasicParameters(ParameterList pL) {
        pL.setCategory("Basic pulse fitting");
        //             ---------------------
        nBinPedestal = new IntegerParameter(pL,"Ped. calc",5,"bins",
        "number of bins for pedestal calculation",true);
        pulseDelay = new IntegerParameter(pL,"Pulse delay",50,"bins",
        "delay after peak to use for estimating charge (bins)",true);
        pulseLength = new IntegerParameter(pL,"Pulse length",100,"bins",
        "number of bins to use to average pulse height for estimating charge",true);
        scaleFactor = new DoubleParameter(pL,"delayed ratio",0.67," ",
        "ratio of relayed pulse height to peak pulse height",true);
        gain = new DoubleParameter(pL,"gain",2.,"/fc",
        "number of ADC channels per fC of deposited charge",true);
        pL.setCategory("Selection criteria");
        minElectron = new IntegerParameter(pL,"Min e",10000," ",
        "minimum number of electrons to constitute a signal",true);
        pL.resetCategory();
    }
    
    public ParameterList getParameterList() {return pL;}
    
    public void updateParameterList(ParameterList newPL) {
        pL.update(newPL);
    }
    
    public boolean setTpc(Tpc tpc) {
        this.tpc = tpc;
        // Find the bottom-most fittable padMesh:
        TpcPart tpcPart = tpc.getBottomPart();
        boolean found = false;
        while (tpcPart != null && !found){
            if( tpcPart.isFittable()) {
                found = true;
            } else
                tpcPart = tpcPart.getPartAbove();
        }
        if (found) {
            padMesh = (PadMesh) tpcPart;
            return true;
        } else {
            padMesh = null;
            return false;
        }
    }
    
    public PadMesh getPadMesh() {return padMesh;}
    
    public double[] getSeedParam() {
        return seedParam;
    }
    
    public int getFitterMultiplicity() {
        if (xyFitter == null) return 0;
        else return xyFitter.getFitterMultiplicity();
    }
    
    // allows specification of rows to fit: if null all rows are fit
    public int[] getRowsToFit() {
        return null;
    }
    
    public void setTpcData(TpcData tpcData) {
        this.tpcData = tpcData;
        nChannel = tpcData.getNChannel();
        nTimeBin = tpcData.getNTimeBin();
        data = new double[nChannel][];
        for (int i = 0; i < nChannel; i++) {
            data[i] = new double[nTimeBin];
        }
        iData = tpcData.getData();
        badChannel = new boolean[nChannel];
        for (int i = 0; i < nChannel; i++) {
            badChannel[i] = false;
        }
    }
    
    public void shiftForPedestal() {
        // calculate pedestal for each channel and apply a shift
        // pedestal is calculated from max of 1st nBP and last nBP averages
        // (this allows events with signals in the 1st time bins to be used)
        // puts shifted data into data array
        int nBP = nBinPedestal.getValue();
        for (int iChan = 0; iChan < nChannel; iChan++) {
            int sumFirst = 0;
            for (int jBin = 0; jBin < nBP; jBin++) {
                sumFirst += iData[iChan][jBin];
            }
            int sumLast = 0;
            for (int jBin = 0; jBin < nBP; jBin++) {
                sumLast += iData[iChan][nTimeBin-1-jBin];
            }
            int sum = Math.max(sumFirst,sumLast);
            double avg = ((double) sum)/nBP;
            for (int jBin = 0; jBin < nTimeBin; jBin++) {
                data[iChan][jBin] = iData[iChan][jBin] - avg;
            }
        }
    }
    
    public void aidaSetup(String filename) {
        af = hep.aida.ref.AnalysisFactory.create();
        try {
            tree = af.createTreeFactory().create(filename,"type=xml;compress=yes");
            ITupleFactory tf = af.createTupleFactory(tree);
            tupleSetup(tf);
        } catch (IOException e) {
            System.err.println(
            "Caught IOException:" + e.getMessage());
        }
    }
    
    public void tupleSetup(ITupleFactory tf) {
        String columnString = "int run=0; int event=0";
        tuple = tf.create( "tuple", "TPC analyzer tuple", columnString, "");
    }
    
    public void aidaCommit() {
        try {
            tree.commit();
        } catch (IOException e) {
            System.err.println(
            "Caught IOException:" + e.getMessage());
        }
    }
    
    public String doAnalysis(boolean fillTuple) {
        // copy iData into data, shifting to a baseline of zero
        shiftForPedestal();
        // put the data into pad groups of the pad mesh
        assignChargeToPadGroups();
        // fill silly ntuple
        if (fillTuple) {
            tuple.fill(0,tpcData.getRunNumber());
            tuple.fill(1,tpcData.getEventNumber());
            tuple.addRow();
        }
        return "done";
    }
    
    public void assignChargeToPadGroups() {
        // just a first stab at this:  overwrite the method in your own analyzer
        if (padMesh == null) return;
        int[][] padGroup = padMesh.getPadGroup();
        padMesh.clear(); // remove any signals in the mesh
        // conversion constant:
        double conv = 1./scaleFactor.getValue()/gain.getValue()/electronCharge;
        int minE = minElectron.getValue();
        // work with one row at a time:
        int nRow = padMesh.getNRow();
        double[] rowData = new double[nTimeBin];
        for (int iRow = 0; iRow < nRow; iRow++) {
            for (int iTB = 0; iTB < nTimeBin; iTB++) rowData[iTB] = 0.;
            int nPadGroupInRow = padMesh.padGroupInRow[iRow].length;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padMesh.padGroupInRow[iRow][iPadGroupInRow];
                int channel = iPadGroup;
                // sum all signals in a row
                for (int iTB = 0; iTB < nTimeBin; iTB++) rowData[iTB] += data[channel][iTB];
                // assign pulse data to pads
                padMesh.setData(iPadGroup, data[channel]);
            }
            //  use row sum to determine peak pulse time for the row:
            int iPeakBin = getPeakBin(rowData);
            //  find average pulse after some delay period for all padGroups
            int time0 = iPeakBin + pulseDelay.getValue();
            int time1 = Math.min(time0 + pulseLength.getValue() - 1,nTimeBin-1);
            int timeLength = time1 - time0 + 1;
            if (iPeakBin >= 0 && timeLength > 5) {
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    int iPadGroup = padMesh.padGroupInRow[iRow][iPadGroupInRow];
                    int channel = iPadGroup;
                    double chanSum = 0.;
                    for (int iT = time0; iT <= time1; iT++) {
                        chanSum += data[channel][iT];
                    }
                    double chanAvg = chanSum/timeLength;
                    int nElectron = (int) (-1.*chanAvg*conv);
                    if (nElectron > minE)
                        padMesh.addNElectron(iPadGroup,nElectron);
                }
            }
        }
        // no seed track finder in this TpcAnalyzer
        seedParam[0] = 0.;
        seedParam[1] = 0.;
        seedParam[2] = 1.;
    }
    
    public int getPeakBin(double[] array) {
        int nBin = array.length;
        double minValue = 9.E9;
        int minBin = -1;
        for (int iBin = 0; iBin < nBin; iBin++) {
            if(array[iBin] < minValue) {
                minBin = iBin;
                minValue = array[iBin];
            }
        }
        return minBin;
    }
    
    /** Main program
     * @param args Arguments
     */
    public static void main(String[] args){
        Start(new TpcAnalyzer(), args);
    }
    
    /** Handle startup: either batch or interactive
     *
     */
    public static void Start(TpcAnalyzer tpcAnalyzer, String[] args){
        if (args.length == 0) Interactive(tpcAnalyzer);
        else Batch(tpcAnalyzer,args);
    }
    
    /** Interactive
     *
     */
    public static void Interactive(TpcAnalyzer tpcAnalyzer){
        // try to read from last.tpcanalyzer to see if we can load the previous files
        String tFileName = "";
        String dFileName = "";
        String aFileName = "";
        try {
            File inputFile = new File("last.tpcanalyzer");
            FileInputStream fis = new FileInputStream(inputFile);
            BufferedReader r = new BufferedReader(new InputStreamReader(fis));
            tFileName = r.readLine();
            dFileName = r.readLine();
            aFileName = r.readLine();
        } catch (IOException except) {  }
        
        // construct the Analysis GUI and display it
        if (tFileName != null && tFileName.length() > 1 
            && dFileName != null && dFileName.length() > 1 
            && aFileName != null && aFileName.length() > 1) {
            InteractiveControlFrame iCF = new InteractiveControlFrame(tpcAnalyzer,tFileName,dFileName,aFileName);
            iCF.show();
        } else {
            InteractiveControlFrame iCF = new InteractiveControlFrame(tpcAnalyzer);
            iCF.show();
        }
    }
    
    /** Batch
     *
     */
    public static void Batch(TpcAnalyzer tpcAnalyzer, String[] args){
        
        String newline = "\n";
        
        if (args.length !=4) {
            System.err.print("TpcAnalyzer error: program requires 4 arguments"
            + newline
            + "Usage: TpcAnalyzer tpcObject.tpc data.mid analysis.par output.aida"
            + newline
            + "note: data.mid can take the form filt01(100-102,104-107).mid"
            + newline);
        } else {
            File tpcFile = new File(args[0]);
            File parFile = new File(args[2]);
            
            try {
                // Create the tpc from the saved tpc object
                FileInputStream in = new FileInputStream(tpcFile);
                ObjectInputStream object = new ObjectInputStream(in);
                tpcAnalyzer.setTpc((Tpc)object.readObject());
                object.close();
                System.out.print("Opened TPC file " + tpcFile.getAbsolutePath()+newline);
                
                // Read in the analysis parameter object
                in = new FileInputStream(parFile);
                object = new ObjectInputStream(in);
                tpcAnalyzer.updateParameterList((ParameterList)object.readObject());
                object.close();
                System.out.print("Opened parameter file " + parFile.getAbsolutePath()+newline);
                
                // process events.
                tpcAnalyzer.aidaSetup(args[3]);
                
                // read the data file(s)
                // need to parse the special commands: (,-)
                Vector datafiles = tpcAnalyzer.getDataFiles(args[1]);
                int nDF = datafiles.size();
                for (int iDF = 0; iDF < nDF; iDF++) {
                    TpcData tpcData = null;
                    File dataFile = (File) datafiles.elementAt(iDF);
                    int len = (dataFile.getName()).length();
                    String ext = dataFile.getName().substring(len-3);
                    if (ext.equals("mid")){
                        tpcData = new MidasTpcData(dataFile,false);
                    } else if (ext.equals("tek")){
                        tpcData = new TekTpcData(dataFile,false);
                    } else if (ext.equals("irq")){
                        tpcData = new IrqTpcData(dataFile,false);
                    } else if (ext.equals("dsy")){
                        tpcData = new DesyTpcData(dataFile,false);
                    } else if (ext.equals("cpt")){
                        tpcData = new CptTpcData(dataFile,false);
                    } else if (ext.equals(".mc")){
                        tpcData = new McTpcData(dataFile,false);
                    } else if (ext.equals("str")){
                        tpcData = new StrTpcData(dataFile,false);
                    } else if (ext.equals("cio")){
                        tpcData = new LcioTpcData(dataFile,false);
                    } else if (ext.equals("dat")){
                        tpcData = new T2KTpcData(dataFile,false);
                    } else {
                        System.out.print("Unrecognized extension: " + ext);
                    }
                    if (tpcData.isGood()) {
                        System.out.print("Opened Data file: " + dataFile.getName()
                        + " : " + tpcData.getComment() + newline);
                        tpcAnalyzer.setTpcData(tpcData);
                    }
                    
                    int nproc = 0;
                    boolean dataReady = true;
                    while (dataReady) {
                        int istat = tpcData.readEvent();
                        if (istat == -1 || istat == 0) {
                            // error reading event or end of file
                            dataReady=false;
                        }
                        if (istat != -1) {
                            System.out.print("Analyzing event # " + tpcData.getEventNumber() + newline);
                            tpcAnalyzer.doAnalysis(true);
                            nproc++;
                        }
                    }
                    tpcAnalyzer.aidaCommit();
                    System.out.print(" " + nproc + " events processed" + newline);
                    
                }
            }
            catch (IOException except) {
                System.err.print("TpcSimulator Batch error: Could not read file" + newline);
                except.printStackTrace();
            }
            catch (ClassNotFoundException except2) {
                System.err.print("TpcSimulator Batch error: Improper data" + newline);
            }
        }
    }
    
    // parse the data files commands, and return a vector of files
    public Vector getDataFiles(String cmd) {
        
        Vector files = new Vector(5,5);
        if (cmd.indexOf("(") == -1) {
            files.add(new File(cmd));
            return files;
        }
        
        int dot = cmd.lastIndexOf(".");
        String ext = cmd.substring(dot); // extension includes the dot
        int leftBracket = cmd.indexOf("(");
        String prefix = cmd.substring(0,leftBracket);
        int rightBracket = cmd.indexOf(")");
        
        int index = leftBracket + 1;
        boolean done = false;
        while (!done) {
            int nextdash = (cmd.substring(index,rightBracket)).indexOf("-");
            int nextcomma = (cmd.substring(index,rightBracket)).indexOf(",");
            if (nextdash == -1 && nextcomma == -1) {
                String fname = prefix.concat(cmd.substring(index,rightBracket));
                files.add(new File(fname.concat(ext)));
                done = true;
            } else if ((nextcomma < nextdash && nextcomma != -1) || nextdash == -1) {
                String fname = prefix.concat(cmd.substring(index,index+nextcomma));
                files.add(new File(fname.concat(ext)));
                index =index + nextcomma + 1;
            } else {
                int istart = Integer.valueOf(cmd.substring(index,index+nextdash)).intValue();
                index = index + nextdash + 1;
                nextcomma = (cmd.substring(index,rightBracket)).indexOf(",");
                String pattern ="";
                for (int i=0; i<nextdash; i++) pattern += "0";
                DecimalFormat numFormat = new DecimalFormat(pattern);
                int iend = 0;
                if (nextcomma == -1) {
                    iend = Integer.valueOf(cmd.substring(index,rightBracket)).intValue();
                    done = true;
                } else {
                    iend = Integer.valueOf(cmd.substring(index,index+nextcomma)).intValue();
                    index = index + nextcomma + 1;
                }
                for (int i = istart; i <= iend; i++) {
                    String fname = prefix.concat("" + numFormat.format(i));
                    files.add(new File(fname.concat(ext)));
                }
            }
        }
        return files;
    }
    
    public String toString(){return name;}
    public void setName(String name) {
        this.name = name;
    }
    
}