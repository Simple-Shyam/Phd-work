/*
 * IntParameter.java
 *
 * Created on September 9, 2002, 10:10 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class IntegerParameter extends Parameter {

    int value;
    String guiUnit,guiHelp;
    transient JTextField field;
    
    /** Creates new IntParameter */
    public IntegerParameter(ParameterList pL, String guiText, int value, String guiUnit, 
    String guiHelp, boolean visible) {
        this.value = value;
        this.guiText = guiText;
        this.guiUnit = guiUnit;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }

    public int getValue() {
        return value;
    }
    
    public void setValue(int value) {
        this.value = value;
        if (field != null) field.setText("" + value);
    }
    
    public void readValue() {
        if (field != null) {
            value = Integer.valueOf(field.getText()).intValue();
        }
    }
    
    void update(Parameter p) {
        IntegerParameter iP = (IntegerParameter) p;
        setValue(iP.getValue());
    }
    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        field = new JTextField("" + value); panel.add(field);
        label = new JLabel(guiUnit); panel.add(label);
        field.setToolTipText(guiHelp);
        Dimension d = new Dimension(60,20);
        field.setMinimumSize(d);
        field.setPreferredSize(d);
        field.setHorizontalAlignment(JTextField.RIGHT);
        return panel;
    }
}
