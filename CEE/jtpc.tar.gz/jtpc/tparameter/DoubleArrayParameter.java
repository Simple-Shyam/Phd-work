/*
 * Double Parameter array.java
 *
 * Created on April 4, 2005
 */

package tparameter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author  karlen
 * @version
 */
public class DoubleArrayParameter extends Parameter {
    
    double[] value;
    IntegerParameter iParameter;
    String guiUnit,guiHelp;
    transient JButton button;
    
    /** Creates new DoubleArrayParameter */
    public DoubleArrayParameter(ParameterList pL, IntegerParameter iParameter, String guiText, double[] value, String guiUnit, String guiHelp, boolean visible) {
        this.value = value;
        this.iParameter = iParameter;
        this.guiText = guiText;
        this.guiUnit = guiUnit;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }
    
    public double[] getValue() {
        return value;
    }
    
    public void setValue(double[] value) {
        this.value = value;
    }
    
    void readValue() {
        iParameter.readValue();
        int nValue = iParameter.getValue();
        // if the requested size of array has changed, make a new array...
        if (nValue != value.length) {
            double[] newValue = new double[nValue];
            for (int iV = 0; iV < Math.min(value.length,nValue); iV++) {
                newValue[iV] = value[iV];
            }
            for (int iV = Math.min(value.length,nValue); iV < nValue; iV++) {
                newValue[iV] = -999;
            }
            value = newValue;
        }
    }
    
    void update(Parameter p) {
        DoubleArrayParameter dAP = (DoubleArrayParameter) p;
        setValue(dAP.getValue());
    }

    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        button = new JButton("Edit..."); panel.add(button);
        button.setToolTipText(guiHelp);
        
        // create frame to edit values
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                readValue();
                JFrame parent = (JFrame) JOptionPane.getFrameForComponent(button);
                DoubleArrayParameterFrame dAPF = new DoubleArrayParameterFrame(parent,guiText,guiUnit,value);
                dAPF.setVisible(true);
            }
        });
        
        return panel;
    }
}
