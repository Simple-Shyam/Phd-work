/*
 * IntParameterarray.java
 *
 * Created on September 9, 2002, 10:10 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author  karlen
 * @version
 */
public class IntegerArrayParameter extends Parameter {
    
    int[] value;
    IntegerParameter iParameter;
    String guiUnit,guiHelp;
    transient JButton button;
    
    /** Creates new IntParameter */
    public IntegerArrayParameter(ParameterList pL,IntegerParameter iParameter,String guiText,int[] value,
    String guiUnit,String guiHelp,boolean visible) {
        this.value = value;
        this.iParameter = iParameter;
        this.guiText = guiText;
        this.guiUnit = guiUnit;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }
    
    public int[] getValue() {
        return value;
    }
    
    public void setValue(int[] value) {
        this.value = value;
    }
    
    public void readValue() {
        iParameter.readValue();
        int nValue = iParameter.getValue();
        // if the requested size of array has changed, make a new array...
        if (nValue != value.length) {
            int[] newValue = new int[nValue];
            for (int iV = 0; iV < Math.min(value.length,nValue); iV++) {
                newValue[iV] = value[iV];
            }
            for (int iV = Math.min(value.length,nValue); iV < nValue; iV++) {
                newValue[iV] = -999;
            }
            value = newValue;
        }
    }
    
    void update(Parameter p) {
        IntegerArrayParameter iAP = (IntegerArrayParameter) p;
        setValue(iAP.getValue());
    }

    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        button = new JButton("Edit..."); panel.add(button);
        button.setToolTipText(guiHelp);
        
        // create frame to edit values
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                readValue();
                JFrame parent = (JFrame) JOptionPane.getFrameForComponent(button);
                IntegerArrayParameterFrame iAPF = new IntegerArrayParameterFrame(parent,guiText,guiUnit,value);
                iAPF.setVisible(true);
            }
        });
        
        return panel;
    }
}
