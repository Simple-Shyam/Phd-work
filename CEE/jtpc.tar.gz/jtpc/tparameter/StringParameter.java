/*
 * IntParameter.java
 *
 * Created on September 9, 2002, 10:10 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class StringParameter extends Parameter {

    String value;
    String guiUnit,guiHelp;
    transient JTextField field;
    
    /** Creates new IntParameter */
    public StringParameter(ParameterList pL, String guiText, String value, String guiHelp, boolean visible) {
        this.value = value;
        this.guiText = guiText;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }

    public String getValue() {
        return value;
    }
    
    public void setValue(String value) {
        this.value = value;
        if (field != null) field.setText(value);
    }
    
    void readValue() {
        if (field != null) {
            value = field.getText();
        }
    }
    
    void update(Parameter p) {
        StringParameter sP = (StringParameter) p;
        setValue(sP.getValue());
    }
    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        field = new JTextField(value); panel.add(field);
        field.setToolTipText(guiHelp);
        Dimension d = new Dimension(250,20);
        field.setMinimumSize(d);
        field.setPreferredSize(d);
        field.setHorizontalAlignment(JTextField.RIGHT);
        return panel;
    }
}
