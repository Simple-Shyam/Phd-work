/*
 * IntegerMatrixParameter.java
 *
 * Created on February 7, 2005
 */

package tparameter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author  karlen
 * @version
 */
public class IntegerMatrixParameter extends Parameter {
    
    int[][] value;
    int nCol;
    IntegerParameter nRow;
    String guiUnit,guiHelp;
    String guiLabels[];
    transient JButton button;
    
    /** Creates new IntParameter */
    public IntegerMatrixParameter(ParameterList pL, IntegerParameter nRow, int nCol, String guiText, int[][] value, String guiUnit, String[] guiLabels, String guiHelp, boolean visible) {
        this.value = value;
        this.nRow = nRow;
        this.nCol = nCol;
        this.guiText = guiText;
        this.guiUnit = guiUnit;
        this.guiLabels = guiLabels;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }
    
    public int[][] getValue() {
        return value;
    }
    
    public void setValue(int[][] value) {
        this.value = value;
    }
    
    void readValue() {
        nRow.readValue();
        int nRows = nRow.getValue();
        // if the requested size of matrix has changed, make a new matrix...
        if (nRows != value.length) {
            int[][] newValue = new int[nRows][nCol];
            for (int iR = 0; iR < Math.min(value.length,nRows); iR++) {
                for (int iC = 0; iC < nCol; iC++){
                    newValue[iR][iC] = value[iR][iC];
                }
            }
            for (int iR = Math.min(value.length,nRows); iR < nRows; iR++) {
                for (int iC = 0; iC < nCol; iC++){
                    newValue[iR][iC] = -999;
                }
            }
            value = newValue;
        }
    }
    
    void update(Parameter p) {
        IntegerMatrixParameter iMP = (IntegerMatrixParameter) p;
        setValue(iMP.getValue());
    }

    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        button = new JButton("Edit..."); panel.add(button);
        button.setToolTipText(guiHelp);
        
        // create frame to edit values
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                readValue();
                JFrame parent = (JFrame) JOptionPane.getFrameForComponent(button);
                IntegerMatrixParameterFrame iMPF = new IntegerMatrixParameterFrame(parent,guiText,guiUnit,guiLabels,value);
                iMPF.setVisible(true);
            }
        });
        
        return panel;
    }
}