/*
 * BooleanParameter.java
 *
 * Created on September 9, 2002, 10:11 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class BooleanParameter extends Parameter {

    boolean value;
    String guiHelp;
    transient JCheckBox checkBox;
    
    /** Creates new BooleanParameter */
    public BooleanParameter(ParameterList pL, String guiText, boolean value,
    String guiHelp, boolean visible) {
        this.value = value;
        this.guiText = guiText;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }

    public boolean getValue() {
        return value;
    }
    
    public void setValue(boolean value) {
        this.value = value;
        if (checkBox != null) checkBox.setSelected(value);
    }

    public void readValue() {
        if (checkBox != null) {
            value = checkBox.isSelected();
        }
    }
    
    void update(Parameter p) {
        BooleanParameter bP = (BooleanParameter) p;
        setValue(bP.getValue());
    }

    
    Component getComponent() {
        JPanel panel = new JPanel();
        checkBox = new JCheckBox(guiText,value); panel.add(checkBox);
        checkBox.setToolTipText(guiHelp);
        return panel;
    }
    
}
