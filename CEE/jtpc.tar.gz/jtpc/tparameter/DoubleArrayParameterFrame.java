/*
 * DoubleArrayParameterFrame.java
 *
 * Created on April 4, 2005
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version
 */
class DoubleArrayParameterFrame extends javax.swing.JDialog {
    
    String guiUnit;
    int nValue;
    double[] value;
    JTextField[] field;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton okButton;
    private javax.swing.JButton cancelButton;
    
    /** Creates new IntegerArrayParameterFrame */
    DoubleArrayParameterFrame(JFrame parent, String guiText, String guiUnit, double[] value) {
        super (parent,guiText,true);
        this.value = value;
        this.guiUnit = guiUnit;
        nValue = value.length;
        field = new JTextField[nValue];
        initComponents ();
        pack ();
    }
    
    void initComponents() {
        JPanel dataPanel = new JPanel();
        dataPanel.setLayout(new GridLayout(0,4));
        for (int iV = 0; iV < nValue; iV++) {
            dataPanel.add(getFieldPanel(iV));
        }
        getContentPane().add(dataPanel, java.awt.BorderLayout.CENTER);
        
        buttonPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        
        buttonPanel.setLayout(new java.awt.FlowLayout(2, 5, 5));
        
        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(okButton);
        
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(cancelButton);
        
        getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);
    }
    
    JPanel getFieldPanel(int iV) {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiUnit + "[" + iV + "]"); panel.add(label);
        field[iV] = new JTextField("" + value[iV]); panel.add(field[iV]);
        field[iV].setToolTipText("enter new value for " + guiUnit + "[" + iV + "]");
        Dimension d = new Dimension(60,20);
        field[iV].setMinimumSize(d);
        field[iV].setPreferredSize(d);
        field[iV].setHorizontalAlignment(JTextField.RIGHT);
        return panel;
    }
    
    private void readValue() {
        for (int iV = 0; iV < nValue; iV++) {
            value[iV] = Double.valueOf(field[iV].getText()).doubleValue();
        }
    }
    
    private void okButtonActionPerformed (java.awt.event.ActionEvent evt) {
        readValue();
        doClose ();
    }
    
    private void cancelButtonActionPerformed (java.awt.event.ActionEvent evt) {
        doClose ();
    }
    
    private void doClose () {
        setVisible (false);
        dispose ();
    }
    
}