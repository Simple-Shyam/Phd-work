/*
 * ParameterList.java
 *
 * Created on September 9, 2002, 10:08 PM
 */

package tparameter;

import java.util.Vector;
import java.io.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class ParameterList implements Serializable {

    static final long serialVersionUID = 4523621397714040129L;
    String name;
    String currentCategory;
    Vector parameters,categories;
    
    /** Creates new ParameterList */
    public ParameterList(String name) {
        this.name = name;
        currentCategory = " ";
        parameters = new Vector(5,5);
        categories = new Vector(5,5);
    }

    void add(Parameter parameter) {
        parameters.addElement(parameter);
        categories.addElement(currentCategory);
    }
    
    // update values of parameters with the numbers in pL
    // cannot guarantee that list of parameters is identical:
    // need to update on basis of category name and parameter name
    public void update(ParameterList pL) {
        int nPL = pL.parameters.size();
        int n = parameters.size();
        for (int iPL = 0; iPL < nPL; iPL++) {
            String pLC = (String) pL.categories.elementAt(iPL);
            Parameter pLP = (Parameter) pL.parameters.elementAt(iPL);
            boolean matched = false; int i = -1;
            while (!matched && ++i < n) {
                String c = (String) categories.elementAt(i);
                if (c.equals(pLC)) {
                    Parameter p = (Parameter) parameters.elementAt(i);
                    if(p.toString().equals(pLP.toString())) {
                        p.update(pLP);
                        matched=true;
                    }
                }
            }
        }
    }                

    public void setCategory(String category) {
        currentCategory = category;
    }
    
    public void resetCategory() {
        currentCategory = " ";
    }    
    
    public void show(javax.swing.JFrame parent) {
        javax.swing.JDialog dialog = new ParameterListFrame(parent,this);
    }
    
    public String toString(){return name;}
}
