/*
 * DoublerParameter.java
 *
 * Created on September 9, 2002, 10:10 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version 
 */
public class DoubleParameter extends Parameter {

    double value;
    String guiUnit,guiHelp;
    transient JTextField field;
    
    /** Creates new DoublerParameter */
    public DoubleParameter(ParameterList pL, String guiText, double value, String guiUnit, 
    String guiHelp, boolean visible) {
        this.value = value;
        this.guiText = guiText;
        this.guiUnit = guiUnit;
        this.guiHelp = guiHelp;
        this.visible = visible;
        pL.add(this);
    }
    
    public double getValue() {
        return value;
    }
    
    public void setValue(double value) {
        this.value = value;
        if (field != null) field.setText("" + value);
    }

    public void readValue() {
        if (field != null) {
            value = Double.valueOf(field.getText()).doubleValue();
        }
    }    
    
    void update(Parameter p) {
        DoubleParameter dP = (DoubleParameter) p;
        setValue(dP.getValue());
    }
    
    Component getComponent() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiText); panel.add(label);
        field = new JTextField("" + value); panel.add(field);
        label = new JLabel(guiUnit); panel.add(label);
        field.setToolTipText(guiHelp);
        Dimension d = new Dimension(60,20);
        field.setMinimumSize(d);
        field.setPreferredSize(d);
        field.setHorizontalAlignment(JTextField.RIGHT);
        return panel;
    }
}
