/*
 * IntegerMatrixParameterFrame.java
 *
 * Created on February 7, 2005
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version
 */
class IntegerMatrixParameterFrame extends javax.swing.JDialog {
    
    String guiUnit;
    String[] guiLabels;
    int nRow,nCol;
    int[][] value;
    JTextField[][] field;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton okButton;
    private javax.swing.JButton cancelButton;
    
    /** Creates new IntegerArrayParameterFrame */
    IntegerMatrixParameterFrame(JFrame parent, String guiText, String guiUnit, String[] guiLabels, int[][] value) {
        super(parent,guiText,true);
        this.value = value;
        this.guiUnit = guiUnit;
        this.guiLabels = guiLabels;
        nRow = value.length;
        nCol = value[0].length;
        field = new JTextField[nRow][nCol];
        initComponents();
        pack();
    }
    
    void initComponents() {
        JPanel dataPanel = new JPanel();
        dataPanel.setLayout(new GridLayout(0,1));
        for (int iR = 0; iR < nRow; iR++) {
            dataPanel.add(getFieldPanel(iR));
        }
        getContentPane().add(dataPanel, java.awt.BorderLayout.CENTER);
        
        buttonPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        
        buttonPanel.setLayout(new java.awt.FlowLayout(2, 5, 5));
        
        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(okButton);
        
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(cancelButton);
        
        getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);
    }
    
    JPanel getFieldPanel(int iR) {
        JPanel panel = new JPanel();
        JLabel label = new JLabel(guiUnit + "[" + iR + "] "); panel.add(label);
        for (int iC = 0; iC < nCol; iC++){
            label = new JLabel(guiLabels[iC] + ":"); panel.add(label);
            field[iR][iC] = new JTextField("" + value[iR][iC]); panel.add(field[iR][iC]);
            field[iR][iC].setToolTipText("enter new value for " + guiLabels[iC] + "[" + iR + "]");
            Dimension d = new Dimension(60,20);
            field[iR][iC].setMinimumSize(d);
            field[iR][iC].setPreferredSize(d);
            field[iR][iC].setHorizontalAlignment(JTextField.RIGHT);
        }
        return panel;
    }
    
    private void readValue() {
        for (int iR = 0; iR < nRow; iR++) {
            for (int iC = 0; iC < nCol; iC++) {
                value[iR][iC] = Integer.valueOf(field[iR][iC].getText()).intValue();
            }
        }
    }
    
    private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {
        readValue();
        doClose();
    }
    
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {
        doClose();
    }
    
    private void doClose() {
        setVisible(false);
        dispose();
    }
    
}