/*
 * Parameter.java
 *
 * Created on September 9, 2002, 10:09 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;
import java.io.*;

/**
 *
 * @author  karlen
 * @version
 */
abstract public class Parameter implements Serializable {
    
    static final long serialVersionUID = 7632540677996967211L;
    boolean visible;
    String guiText;
    
    
    boolean isVisible(){return visible;}
    public String toString(){return guiText;}
    
    abstract Component getComponent();
    abstract void readValue();
    abstract void update(Parameter p);
    
}