/*
 * ParameterListFrame.java
 *
 * Created on September 12, 2002, 9:34 PM
 */

package tparameter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version
 */
public class ParameterListFrame extends JDialog {
    
    ParameterList pL;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton okButton;
    private javax.swing.JButton cancelButton;
    
    
    /** Creates new ParameterListFrame */
    public ParameterListFrame(JFrame parent, ParameterList pL) {
        super(parent,pL.toString(),true);
        this.pL = pL;
        initComponents();
        pack();
        setVisible(true);
    }
    
    void initComponents() {
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        
        String previousCategory = "No previous category";
        JPanel categoryPanel = null;
        int npar = pL.parameters.size();
        for (int ipar = 0; ipar < npar; ipar++) {
            String category = (String) pL.categories.elementAt(ipar);
            if (category != previousCategory) {
                previousCategory = category;
                if (categoryPanel != null) mainPanel.add(categoryPanel);
                categoryPanel = new JPanel();
                categoryPanel.setLayout(new BoxLayout(categoryPanel, BoxLayout.Y_AXIS));
                categoryPanel.setBorder(new javax.swing.border.TitledBorder(category));
            }
            Parameter parameter = (Parameter) pL.parameters.elementAt(ipar);
            if (parameter.isVisible())categoryPanel.add(parameter.getComponent());
        }
        if (categoryPanel != null) mainPanel.add(categoryPanel);
        getContentPane().add(scrollPane,BorderLayout.CENTER);
        
        buttonPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        
        buttonPanel.setLayout(new java.awt.FlowLayout(2, 5, 5));
        
        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(okButton);
        
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(cancelButton);
        
        getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);
    }
    
    private void okButtonActionPerformed (java.awt.event.ActionEvent evt) {
        readValue();
        doClose ();
    }
    
    private void cancelButtonActionPerformed (java.awt.event.ActionEvent evt) {
        doClose ();
    }
    
    private void readValue() {
        int npar = pL.parameters.size();
        for (int ipar = 0; ipar < npar; ipar++) {
            Parameter parameter = (Parameter) pL.parameters.elementAt(ipar);
            if (parameter.isVisible())parameter.readValue();
        }
    }
    
    private void doClose () {
        setVisible (false);
        dispose ();
    }
    
}