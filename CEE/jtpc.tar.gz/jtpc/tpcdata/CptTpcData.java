/*
 * CptData.java
 *
 * Created on April 3, 2003, 5:05 AM
 */

package tpcdata;
import java.io.*;

/**
 *
 * @author  karlen
 */
public class CptTpcData extends TpcData {
    
    static final int nChan = 256;
    static final int nBin = 100; // number of time bins
    
    /** Creates a new instance of CptData */
    public CptTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            in = new BufferedInputStream(new FileInputStream(readFile));
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        // hard code this, since Desy files do not have a header with the information
        runNumber=997;
        nTimeBin=nBin;
        nChannel=nChan;
        eventNumber=0;
        return true;
    }
    
    public int readEvent() {
        try {
            eventNumber++;
            byte[] bbuf = new byte[2];
            for (int iBin =0; iBin < nBin; iBin++) {
                for (int iChan = 0; iChan < nChan; iChan++){
                    int nb = in.read(bbuf);
                    if (nb < 2)return -1;
                    int val = (((int) (bbuf[1] & 0xFF) - 33) << 6) 
                    + ((int) (bbuf[0] & 0xFF) - 33);
                    int iPin = 15 - iChan%16;
                    int iAB = (iChan%32)/16;
                    int iCard = 7 - iChan/32;
                    iCard += (iCard+1)%2 - iCard%2;
                    int jChan = iCard*32 + iPin*2 + iAB;
                    data[jChan][iBin] = val;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
        
    }
    
}
