/*
 * TekTpcData.java
 *
 * Created on February 27, 2003, 3:00 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 * @version
 */
public class TekTpcData extends TpcData {
    
    int nByteReadout; // number of bytes used per time bin per channel (1 or 2)
    double horizontalScale;
    double[] verticalScale,offset;
    
    public TekTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            
            verticalScale = new double[4];
            offset = new double[4];
            
            in = new BufferedInputStream(new FileInputStream(readFile));
            byte[] ebuf = new byte[8];
            byte[] bbuf = new byte[4];
            byte[] hbuf = new byte[2];

            int nb = in.read(bbuf);
            int ihw = getWord(bbuf);
            if (ihw != 1213093202) { // "RUNH"
                System.err.println("Data file does not contain header.");
                in.close();
                return false;
            }
            // get the number of bytes in run header
            nb = in.read(hbuf);
            int nByteHeader = getHalfWord(hbuf,0);
            // get the run number:
            nb = in.read(hbuf);
            runNumber = getHalfWord(hbuf,0);
            // horizontal scale:
            nb = in.read(ebuf);
            horizontalScale = Double.valueOf(new String(ebuf)).doubleValue();
            // scales and offsets  (Note; channel 0 == scope channel 1)
            // if vertical scale is negative, ignore that channel
            nChannel =0;
            for (int ichan=0; ichan<4; ichan++) {
                nb = in.read(ebuf);
                verticalScale[ichan] = Double.valueOf(new String(ebuf)).doubleValue();
                if (verticalScale[ichan]>0) nChannel++;
                nb = in.read(ebuf);
                offset[ichan] = Double.valueOf(new String(ebuf)).doubleValue();
            }
            // comment field:
            byte[] cbuf = new byte[100];
            nb = in.read(cbuf);
            String fullComment = new String(cbuf);
            comment = fullComment.substring(0,Math.min(79,fullComment.indexOf(0)));
            
            // number of Time Bins:
            nTimeBin = 499;
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        
        return true;
    }
    
    public double getHorizontalScale() {return horizontalScale;}
    public double[] getVerticalScale() {return verticalScale;}
    public double[] getOffset() {return offset;}
    public int getNByteReadout() {return nByteReadout;}
    
    public int readEvent() {
        try {
            byte[] ebuf = new byte[8];
            byte[] bbuf = new byte[4];
            byte[] hbuf = new byte[2];
            byte[] eod = new byte[1];
            
            int nb = in.read(bbuf);
            int ihw = getWord(bbuf);
            if (ihw != 1213486661) { // "EVTH"
                System.err.println("Data file event header has invalid format");
                in.close();
                return -1; 
            }
            // get number of bytes in Event: 1000 per channel +10 for 2 byte scope readout, 500 per channel + 10 for 1 byte readout
            nb = in.read(hbuf);
            int nByteEvent = getHalfWord(hbuf,0);
            nByteReadout = 1;
            int midSize = 750*nChannel + 10;
            if (nByteEvent > midSize) nByteReadout = 2;
            // get event number
            nb = in.read(bbuf);
            eventNumber = getWord(bbuf);
            // get time of event (seconds after Jan 1, 1970)
            nb = in.read(bbuf);
            eventTime = getWord(bbuf);
            // 4 bytes reserved for future use
            nb = in.read(bbuf);
            
            byte[] databuf = new byte[nTimeBin*nByteReadout];
            // Loop over channels:
            for (int iChan = 0; iChan < nChannel; iChan++) {    
                nb = in.read(databuf);
                // put in data array
                if (nByteReadout == 2) {
                    for (int iBin = 0; iBin < nTimeBin; iBin++) {
                        data[iChan][iBin] = ((databuf[iBin*2+1] & 0xFF) <<8) + (databuf[iBin*2] & 0xFF);
                    }
                } else {
                    for (int iBin = 0; iBin < nTimeBin; iBin++) {
                        data[iChan][iBin] = databuf[iBin] & 0xFF;
                    }
                }
                // readout one more time bin: the 500th is just an end of data marker
                nb = in.read(eod);
                if (nByteReadout == 2) nb = in.read(eod);
                // check that we have got to end of data for this channel:
                nb = in.read(bbuf);
                ihw = getWord(bbuf);
                if (ihw != 1145980227) { // "CEND"
                    System.err.println("Data file corrupted: no channel end seen");
                    System.err.println(" This is value seen:" + ihw);
                    in.close();
                    return -1;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
    }

}
