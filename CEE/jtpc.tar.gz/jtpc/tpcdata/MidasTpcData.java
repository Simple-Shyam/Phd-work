/*
 * MidasTpcData.java
 *
 * Created on June 13, 2002, 11:00 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 * @version
 */
public class MidasTpcData extends TpcData {
    
    public MidasTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            
            in = new BufferedInputStream(new FileInputStream(readFile));
            byte[] bbuf = new byte[4];
            int nb = in.read(bbuf);
            int ihw = getHalfWord(bbuf,0);
            if (ihw != 32768) {
                System.err.println("Data file does not contain header.");
                in.close();
                return false;
            }
            // get the run number:
            nb = in.read(bbuf);
            runNumber = getWord(bbuf);
            // time (seconds since Jan 1, 1970)
            in.skip(4);
            // header size
            nb = in.read(bbuf);
            int iHSize = getWord(bbuf);
            // read rest of header:
            byte[] hbuf = new byte[iHSize];
            nb = in.read(hbuf);
            String odbDump = new String(hbuf);
            // number of time bins:
            int iStart = odbDump.indexOf("number of bin pairs = INT :");
            if (iStart > 0) {
                int iLen = odbDump.substring(iStart+28).indexOf(10);
                if (iLen > 0) {
                    int iBinPair = Integer.parseInt(odbDump.substring(iStart+28,iStart+28+iLen));
                    nTimeBin = iBinPair*2;
                }
            }
            if (nTimeBin < 0) {
                System.err.println("Data file header does not contain bin pair count.");
                in.close();
                return false;
            }
            // comment field:
            iStart = odbDump.indexOf("Comment = STRING : [80]");
            if (iStart > 0) {
                int iLen = odbDump.substring(iStart+24).indexOf(10);
                if (iLen > 0) {
                    comment = odbDump.substring(iStart+24,iStart+24+iLen);
                }
            }
            // number of channels:
            iStart = odbDump.indexOf("number of cards = INT :");
            if (iStart > 0) {
                int iLen = odbDump.substring(iStart+24).indexOf(10);
                if (iLen > 0) {
                    nChannel = 4*Integer.parseInt(odbDump.substring(iStart+24,iStart+24+iLen));
                }
            }
            if (nChannel < 0) {
                System.err.println("Data file header does not contain channel count.");
                in.close();
                return false;
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        
        return true;
    }
    
    public int readEvent() {
        try {
            byte[] bbuf = new byte[4];
            int nb = in.read(bbuf);
            int ihw = getHalfWord(bbuf,0);
            if (ihw == 32767) {
                in.close();
                return 0; // end of run
            }
            if (ihw != 1) {
                System.err.println("Data file event header has invalid format");
                in.close();
                return -1; 
            }
            // get event number
            nb = in.read(bbuf);
            eventNumber = getWord(bbuf);
            // get time of event (seconds after Jan 1, 1970)
            nb = in.read(bbuf);
            eventTime = getWord(bbuf);
            // event size
            in.skip(4);
            // global bank size:
            in.skip(4);
            // another header
            in.skip(4);
            
            byte[] databuf = new byte[nTimeBin];
            // Loop over channels:
            for (int iChan = 0; iChan < nChannel; iChan++) {
                // bank name
                in.skip(4);
                // bank header
                in.skip(4);
                // bank size
                nb = in.read(bbuf);
                int iBankSize = getWord(bbuf);
                if (iBankSize != nTimeBin ) {
                    System.err.println("Data file event has invalid format");
                    in.close();
                    return -1;
                }                
                nb = in.read(databuf);
                // put in data array
                for (int iBin = 0; iBin < nTimeBin; iBin++) {
                    data[iChan][iBin] = databuf[iBin] & 0xFF;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
    }

}
