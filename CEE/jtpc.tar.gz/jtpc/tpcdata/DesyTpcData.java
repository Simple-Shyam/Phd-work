/*
 * DesyData.java
 *
 * Created on April 1, 2003, 8:40 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 */
public class DesyTpcData extends TpcData {
    
    static final int nChan = 64; 
    static final int nBin = 500; // maximum time slice number
    
    /** Creates a new instance of DesyData */
    public DesyTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            in = new BufferedInputStream(new FileInputStream(readFile));
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        // hard code this, since Desy files do not have a header with the information
        runNumber=998;
        nTimeBin=nBin;
        nChannel=nChan;
        eventNumber=0;
        return true;
    }
    
    public int readEvent() {
        try {
            eventNumber++;
            byte[] bbuf = new byte[4];
            int nb = in.read(bbuf);
            int ihw1 = getHalfWordNSW(bbuf,0);
            int ihw2 = getHalfWordNSW(bbuf,1);
            if (ihw1 == 78 && ihw2 == 254) {
                in.close();
                return 0; // end of run
            }
            if (ihw1 != 77 || ihw2 != 251) {
                System.err.println("Data file event header has invalid format: "
                + ihw1 + " " + ihw2);
                in.close();
                return -1;
            }
            // clear out data array
            for (int iChan = 0; iChan < nChan; iChan++) {
                for (int iBin = 0; iBin < nTimeBin; iBin++) {
                    data[iChan][iBin] = 0;
                }
            }
            // get trigger and number of channels
            nb = in.read(bbuf);
            ihw1 = getHalfWordNSW(bbuf,0);
            ihw2 = getHalfWordNSW(bbuf,1);
            int trigger = ihw1 + 65536*(ihw2%256);
            int nch = ihw2/256;
            // get time of event (unknown format)
            nb = in.read(bbuf);
            eventTime = getWordNSW(bbuf);
            // loop over channels
            for (int ich = 0; ich < nch; ich++) {
                nb = in.read(bbuf);
                int chan = getHalfWordNSW(bbuf,0);
                // change some channel numbers:
                if (chan == 59) chan = 31;
                if (chan == 62) chan = 33;
                if (chan == 61) chan = 32;
                int nslice = getHalfWordNSW(bbuf,1);
                for (int islice = 0; islice < nslice; islice++) {
                    nb = in.read(bbuf);
                    int charge = getHalfWordNSW(bbuf,0);
                    int timeBin = getHalfWordNSW(bbuf,1);
                    if (chan < nChan && timeBin < nBin) {
                        data[chan][timeBin] = -charge;
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
                
    }
}
