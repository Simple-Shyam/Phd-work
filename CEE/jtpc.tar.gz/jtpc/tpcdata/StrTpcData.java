/*
 * StrTpcData.java
 *
 * Created on April 24, 2003, 2:00 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 * @version
 */
public class StrTpcData extends TpcData {
    
    int nCard; // number of STAR FEE card slots
    boolean[] cardActive; // indicates which ones are active (ie. which are connected and read out)
    
    public StrTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            
            in = new BufferedInputStream(new FileInputStream(readFile));
            byte[] ebuf = new byte[8];
            byte[] bbuf = new byte[4];
            byte[] hbuf = new byte[2];
            byte[] abuf = new byte[1];
            
            int nb = in.read(bbuf);
            int ihw = getWord(bbuf);
            if (ihw != 1213093202) { // "RUNH"
                System.err.println("Data file does not contain header.");
                in.close();
                return false;
            }
            // get the number of bytes in run header
            nb = in.read(hbuf);
            int nByteHeader = getHalfWord(hbuf,0);
            // get the run number:
            nb = in.read(hbuf);
            runNumber = getHalfWord(hbuf,0);
            // get the number of time bins
            nb = in.read(hbuf);
            nTimeBin = getHalfWord(hbuf,0);
            // get the number of STAR FEE cards
            nb = in.read(hbuf);
            nCard = getHalfWord(hbuf,0);
            nChannel = nCard*32;
            cardActive = new boolean[nCard];
            for (int i=0; i<nCard; i++) {
                // get the location number of each FEE card slot: location 99 indicates unused card
                nb = in.read(abuf);
                cardActive[i] = (abuf[0] != 99);
            }
            // comment field:
            byte[] cbuf = new byte[100];
            nb = in.read(cbuf);
            String fullComment = new String(cbuf);
            comment = fullComment.substring(0,Math.min(79,fullComment.indexOf(0)));
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        
        return true;
    }
    
    public int readEvent() {
        try {
            byte[] ebuf = new byte[8];
            byte[] bbuf = new byte[4];
            byte[] hbuf = new byte[2];
            byte[] eod = new byte[1];
            
            int nb = in.read(bbuf);
            if (nb == 0) {
                System.err.println("End of file found");
                in.close();
                return -1;
            }
            int ihw = getWord(bbuf);
            if (ihw != 1213486661) { // "EVTH"
                System.err.println("Data file event header has invalid format");
                // scan for next event: (in case of corrupted data)
                boolean found = false;
                while (!found && nb > 0) {
                    nb = in.read(eod);
                    if (eod[0] == 69) { // "E"
                        nb = in.read(eod);
                        if (eod[0] == 86) { // "V"
                            nb = in.read(eod);
                            if (eod[0] == 84) { // "T"
                                nb = in.read(eod);
                                if (eod[0] == 72) found = true;
                            }
                        }
                    }
                }
                if (!found) {
                    System.err.println("Beginning of next event not found");
                    in.close();
                    return -1;
                }
            }
            // get number of bytes in Event
            nb = in.read(bbuf);
            int nByteEvent = getWord(bbuf);
            // get event number
            nb = in.read(bbuf);
            eventNumber = getWord(bbuf);
            // get time of event (seconds after Jan 1, 2003)
            nb = in.read(bbuf);
            eventTime = getWord(bbuf);
            
            byte[] databuf = new byte[nTimeBin*2];
            // Loop over channels:
            for (int iCard = 0; iCard < nCard; iCard++) {
                if (cardActive[iCard]) {
                    for (int iPin = 0; iPin < 32; iPin++) {
                        int iChan = iCard*32 + iPin;
                        nb = in.read(databuf);
                        // put in data array
                        for (int iBin = 0; iBin < nTimeBin; iBin++) {
                            data[iChan][iBin] = ((databuf[iBin*2+1] & 0xFF) <<8) + (databuf[iBin*2] & 0xFF);
                        }
                    }
                }
            }
            // check that we have got to end of data for this event:
            nb = in.read(bbuf);
            ihw = getWord(bbuf);
            if (ihw != 1145980229) { // "EEND"
                System.err.println("Data file corrupted: no channel end seen");
                System.err.println(" This is value seen:" + ihw);
                // skip this event, get another one
                return readEvent();
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
    }
    
}
