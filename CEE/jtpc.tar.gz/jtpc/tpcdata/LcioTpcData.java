/*
 * LcioTpcData.java
 *
 * Created on August 11, 2004
 */

package tpcdata;
import java.io.*;
import jas.hist.*;
import hep.lcio.io.*;
import hep.lcio.implementation.io.*;
import hep.lcio.event.*;
import hep.lcio.data.*;

/**
 *
 * @author  karlen
 */
public class LcioTpcData extends TpcData {
    
    LCReader lcReader;
    
    static final int nChan = 24 * 8;
    static final int nBin = 512; // maximum time slice number
    static final int maxChannelNumber = 2200;
    int[] padNumber = new int[maxChannelNumber];
    
    /** Creates a new instance of Desy LcioTpcData */
    public LcioTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
        for (int i = 0; i < maxChannelNumber; i++) padNumber[i] = -1;
        for (int i = 0; i < map.length; i++) {
            padNumber[map[i]] = i;
        }
    }
    
    boolean readHeader(File readFile) {
        try {
            String fname = readFile.getAbsolutePath();
            lcReader = LCFactory.getInstance().createLCReader();
            lcReader.open(fname);
            LCRunHeader runHeader = lcReader.readNextRunHeader();
            runNumber = runHeader.getRunNumber();
            String fullComment = runHeader.getDetectorName() + " : " + runHeader.getDescription();
            comment = fullComment.substring(0,Math.min(79,fullComment.length()));
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        // hard code this, since Desy files do not have a header with the information
        nTimeBin=nBin;
        nChannel=nChan;
        
        return true;
    }
    
    public int readEvent() {
        
        // clear out data array
        for (int iChan = 0; iChan < nChan; iChan++) {
            for (int iBin = 0; iBin < nTimeBin; iBin++) {
                data[iChan][iBin] = 0;
            }
        }
        
        try {

            LCEvent evt = lcReader.readNextEvent();
            if (evt == null) {
                lcReader.close();
                return -1;
            }
            
            eventNumber = evt.getEventNumber();
            eventTime = (int) evt.getTimeStamp();
            
            LCCollection col = evt.getCollection("TPCFADC") ;
            
            int nPad = col.getNumberOfElements() ;
            for (int iPad = 0; iPad < nPad; iPad++) {
                TPCHitData padData = (TPCHitData) col.getElementAt(iPad);
                int channel = padData.getCellID();
                if (channel >=0 && channel < maxChannelNumber) {
                    int pad = padNumber[channel];
                    if (pad >=0 && pad < nChan) {
                        int nSlice = padData.getNRawDataWords();
                        for (int iSlice = 0; iSlice < Math.min(nSlice,nBin); iSlice++) {
                            data[pad][iSlice] = -1*padData.getRawDataWord(iSlice);
                        }
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
        
    }
    
    static final int[] map = {
        1647, 1639, 1663, 1655, 2015, 2007, 2031, 2023, 2047, 2039, 2063, 2055, 1623, 1631, 1607, 1615, 655, 663, 639, 647, 623, 631, 607, 615,
        1646, 1638, 1662, 1654, 2014, 2006, 2030, 2022, 2046, 2038, 2062, 2054, 1622, 1630, 1606, 1614, 654, 662, 638, 646, 622, 630, 606, 614,
        1645, 1637, 1661, 1653, 2013, 2005, 2029, 2021, 2045, 2037, 2061, 2053, 1621, 1629, 1605, 1613, 653, 661, 637, 645, 621, 629, 605, 613,
        1644, 1636, 1660, 1652, 2012, 2004, 2028, 2020, 2044, 2036, 2060, 2052, 1620, 1628, 1604, 1612, 652, 660, 636, 644, 620, 628, 604, 612,
        1643, 1635, 1659, 1651, 2011, 2003, 2027, 2019, 2043, 2035, 2059, 2051, 1619, 1627, 1603, 1611, 651, 659, 635, 643, 619, 627, 603, 611,
        1642, 1634, 1658, 1650, 2010, 2002, 2026, 2018, 2042, 2034, 2058, 2050, 1618, 1626, 1602, 1610, 650, 658, 634, 642, 618, 626, 602, 610,
        1641, 1633, 1657, 1649, 2009, 2001, 2025, 2017, 2041, 2033, 2057, 2049, 1617, 1625, 1601, 1609, 649, 657, 633, 641, 617, 625, 601, 609,
        1640, 1632, 1656, 1648, 2008, 2000, 2024, 2016, 2040, 2032, 2056, 2048, 1616, 1624, 1600, 1608, 648, 656, 632, 640, 616, 624, 600, 608};
}
