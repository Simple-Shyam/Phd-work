/*
 * IrqTpcData.java
 *
 * Created on March 25, 2003, 5:21 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 */
public class IrqTpcData extends TpcData {
    
    static final int nChan = 1152;
    static final int nBin = 130;
    static final int nConnector = 8;
    // Victoria with all cards:
    //static final int locConnector[] = {3,4,12,13,21,22,30,31}; // location numbers for connectors
    // Victoria with missing cards:
    static final int locConnector[] = {3,4,12,13,21,22,30,0}; // turn off #8 because of ghosting
    static final boolean doPinSwap = false;
    // Karlsruhe:
    // static final int locConnector[] = {30,21,29,20,28,19,27,18};
    // static final boolean doPinSwap = true;
    //
    int[][] irqData; 
    String line;
    BufferedReader input;
    
    /** Creates a new instance of IrqTpcData */
    public IrqTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
    }
    
    boolean readHeader(File readFile) {
        try {
            input = new BufferedReader(new FileReader(readFile));
            line = input.readLine();
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        // hard code this, since Irq files do not have a header with the information
        runNumber=999;
        nTimeBin=nBin;
        nChannel=256;
        // prepare intermediate data array
        irqData = new int[nChan][];
        for (int i=0; i<nChan; i++) {
            irqData[i] = new int[nBin];
        }
        
        return true;
    }
    
    
    public int readEvent() {
        eventTime = 999;
        try {
            // find event Number:
            while (line.length() < 10 || !line.substring(0,10).equals(" evNumber ")) {
                line = input.readLine();
            }
            eventNumber = Integer.parseInt(line.substring(12,line.length()),10);
            // skip to start of data:
            while (line.length() < 40 || !line.substring(0,10).equals("0xc0001000")) {
                line = input.readLine();
            }
            int iCh = -1;
            int iBin = 0;
            int nDat = nBin*nChan;
            int start = 2;
            for (int i=0; i<nDat; i++) {
                iCh++;
                if (iCh >= nChan) {
                    iCh = 0;
                    iBin++;
                }
                if (iCh%2 == 0) {
                    start += 13;
                } else {
                    start -= 4;
                }
                if (start > 62) {
                    line = input.readLine();
                    start = 15;
                }
                irqData[iCh][iBin] = Integer.parseInt(line.substring(start,start+4),16);
            }
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        // Copy the irqData into the data array for analysis:
        int iChan = -1;
        for (int iCon=0; iCon<nConnector; iCon++) {
            int iLoc = locConnector[iCon];
            for (int iHalf=1; iHalf>-1; iHalf--) {
                for (int iPin=15; iPin>-1; iPin--) {
                    int irqCh = getIrqChannel(iLoc, iHalf, iPin);
                    iChan++;
                    int jChan = iChan;
                    // for Karlsruhe data:
                    if (doPinSwap)jChan = iChan-iChan%2+(iChan+1)%2;
                    for (int iBin=0; iBin<nBin; iBin++) {
                        data[jChan][iBin] = irqData[irqCh][iBin];
                    }
                }
            }
        }
                
        return 1;
    }
    
    int getIrqChannel(int iLoc, int iHalf, int iPin) {
        // even pins are top row
        int iRow = iPin%2;
        // iHalf=0 => ADC A (first 8 pins)
        int jPin = (iPin-iRow)/2 + 8*iHalf;
        return mapSequence[iRow][iLoc] + jPin*72;
    }
    
    static final int[][] mapSequence = {
        {0,1,2,3,4,5,18,19,20,54,55,56,57,58,59,6,7,8,   // top row
         42,43,44,45,46,47,60,61,62,30,31,32,33,34,35,48,49,50},
         {21,22,23,36,37,38,39,40,41,9,10,11,24,25,26,27,28,29,  // bottom row
          63,64,65,12,13,14,15,16,17,51,52,53,66,67,68,69,70,71}
    };
    
}
