/*
 * LcioTpcDataSaclay.java
 *
 * Created on Oct 4, 2005
 */

package tpcdata;
import java.io.*;
import jas.hist.*;
import hep.lcio.io.*;
import hep.lcio.implementation.io.*;
import hep.lcio.event.*;
import hep.lcio.data.*;

/**
 *
 * @author  karlen
 */
public class LcioTpcDataSaclay extends TpcData {
    
    LCReader lcReader;
    
    static final int nChan = 32 * 12;
    static final int nBin = 128; // maximum time slice number
    static final int maxChannelNumber = 2500;
    int[] padNumber = new int[maxChannelNumber];
    
    /** Creates a new instance of Saclay LcioTpcData */
    public LcioTpcDataSaclay(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
        for (int i = 0; i < maxChannelNumber; i++) padNumber[i] = -1;
        for (int i = 0; i < map.length; i++) {
            padNumber[map[i]] = i;
        }
    }
    
    boolean readHeader(File readFile) {
        try {
            String fname = readFile.getAbsolutePath();
            lcReader = LCFactory.getInstance().createLCReader();
            lcReader.open(fname);
            LCRunHeader runHeader = lcReader.readNextRunHeader();
            runNumber = runHeader.getRunNumber();
            String fullComment = runHeader.getDetectorName() + " : " + runHeader.getDescription();
            comment = fullComment.substring(0,Math.min(79,fullComment.length()));
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        // hard code this, since Desy files do not have a header with the information
        nTimeBin=nBin;
        nChannel=nChan;
        
        return true;
    }
    
    public int readEvent() {
        
        // clear out data array
        for (int iChan = 0; iChan < nChan; iChan++) {
            for (int iBin = 0; iBin < nTimeBin; iBin++) {
                data[iChan][iBin] = 0;
            }
        }
        
        try {

            LCEvent evt = lcReader.readNextEvent();
            if (evt == null) {
                lcReader.close();
                return -1;
            }
            
            eventNumber = evt.getEventNumber();
            eventTime = (int) evt.getTimeStamp();
            
            LCCollection col = evt.getCollection("TPCFADC") ;
            
            int nPad = col.getNumberOfElements() ;
            for (int iPad = 0; iPad < nPad; iPad++) {
                TPCHitData padData = (TPCHitData) col.getElementAt(iPad);
                int channel = padData.getCellID();
                if (channel >=0 && channel < maxChannelNumber) {
                    int pad = padNumber[channel];
                    if (pad >=0 && pad < nChan) {
                        int nSlice = padData.getNRawDataWords();
                        for (int iSlice = 0; iSlice < Math.min(nSlice,nBin); iSlice++) {
                            data[pad][iSlice] = -1*padData.getRawDataWord(iSlice);
                        }
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
        
    }
    
    static final int[] map = {
 615, 614, 613, 612, 611, 610, 609, 608, 607, 606, 605, 604, 603, 602, 601, 600,
 631, 630, 629, 628, 627, 626, 625, 624, 623, 622, 621, 620, 619, 618, 617, 616,
 647, 646, 645, 644, 643, 642, 641, 640, 639, 638, 637, 636, 635, 634, 633, 632,
 663, 662, 661, 660, 659, 658, 657, 656, 655, 654, 653, 652, 651, 650, 649, 648,
 915, 914, 913, 912, 911, 910, 909, 908, 907, 906, 905, 904, 903, 902, 901, 900,
 931, 930, 929, 928, 927, 926, 925, 924, 923, 922, 921, 920, 919, 918, 917, 916,
 947, 946, 945, 944, 943, 942, 941, 940, 939, 938, 937, 936, 935, 934, 933, 932,
 963, 962, 961, 960, 959, 958, 957, 956, 955, 954, 953, 952, 951, 950, 949, 948,
1215,1214,1213,1212,1211,1210,1209,1208,1207,1206,1205,1204,1203,1202,1201,1200,
1231,1230,1229,1228,1227,1226,1225,1224,1223,1222,1221,1220,1219,1218,1217,1216,
1247,1246,1245,1244,1243,1242,1241,1240,1239,1238,1237,1236,1235,1234,1233,1232,
1263,1262,1261,1260,1259,1258,1257,1256,1255,1254,1253,1252,1251,1250,1249,1248,
1815,1814,1813,1812,1811,1810,1809,1808,1807,1806,1805,1804,1803,1802,1801,1800,
1831,1830,1829,1828,1827,1826,1825,1824,1823,1822,1821,1820,1819,1818,1817,1816,
1847,1846,1845,1844,1843,1842,1841,1840,1839,1838,1837,1836,1835,1834,1833,1832,
1863,1862,1861,1860,1859,1858,1857,1856,1855,1854,1853,1852,1851,1850,1849,1848,
2115,2114,2113,2112,2111,2110,2109,2108,2107,2106,2105,2104,2103,2102,2101,2100,
2131,2130,2129,2128,2127,2126,2125,2124,2123,2122,2121,2120,2119,2118,2117,2116,
2147,2146,2145,2144,2143,2142,2141,2140,2139,2138,2137,2136,2135,2134,2133,2132,
2163,2162,2161,2160,2159,2158,2157,2156,2155,2154,2153,2152,2151,2150,2149,2148,
2415,2414,2413,2412,2411,2410,2409,2408,2407,2406,2405,2404,2403,2402,2401,2400,
2431,2430,2429,2428,2427,2426,2425,2424,2423,2422,2421,2420,2419,2418,2417,2416,
2447,2446,2445,2444,2443,2442,2441,2440,2439,2438,2437,2436,2435,2434,2433,2432,
2463,2462,2461,2460,2459,2458,2457,2456,2455,2454,2453,2452,2451,2450,2449,2448};
}
