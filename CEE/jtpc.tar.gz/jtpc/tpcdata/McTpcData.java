/*
 * McTpcData.java
 *
 * Created on April 6, 2003, 9:52 AM
 */

package tpcdata;
import java.io.*;

/**
 *
 * @author  karlen
 */
public class McTpcData extends TpcData {
    
    DataInputStream id;
    int fadcBits;
    int version;
    
    /** Creates a new instance of McTpcData */
    public McTpcData(File readFile, boolean readFirstEvent) {
        super(readFile,readFirstEvent);
        truthExists = true;
    }
    
    boolean readHeader(File readFile) {
        try {
            in = new BufferedInputStream(new FileInputStream(readFile));
            id = new DataInputStream(in);
            id.skipBytes(32);
            version = id.readInt();
            comment = "TPC MC";
            comment += ",v" + version;
            int headerSize = id.readInt();
            runNumber = id.readInt();
            comment += ",nevt = " + id.readInt();
            long seed = id.readLong();
            nChannel = id.readInt();
            int firstPad = id.readInt();
            fadcBits = id.readInt();
            nTimeBin = id.readInt();
            comment += ", gain = " + id.readInt()/1000.;
            int fadcDT = id.readInt();
            eventTime = 0;
            
            if (headerSize > 40) id.skipBytes(headerSize - 40);
            
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return false;
        }
        return true;
    }
    
    public int readEvent() {
        try {
            int headerSize = id.readInt();
            eventNumber = id.readInt();
            eventTime++;
            truth[0] = id.readInt()/1000.; // x0
            truth[1] = id.readInt()/1000.; // z0
            truth[2] = id.readInt()/1000000.; // phi
            truth[3] = id.readInt()/1000000.; // psi (or tanl depending on MC type)
            if (version == 2) {
                if (headerSize > 20) id.skipBytes(headerSize - 20);
            } else {
                truth[4] = id.readInt()/1000000.; // kinetic energy
                truth[5] = id.readInt(); // particle code
                if (headerSize > 28) id.skipBytes(headerSize - 28);
            }
            
            // need to zero out data for version 3, otherwise previous data remains:
            if (version>2) {
                for (int ich = 0; ich < nChannel; ich++) {
                    for (int iBin = 0; iBin < nTimeBin; iBin++) {
                        data[ich][iBin] = 0;
                    }
                }
            }
            
            int nB = 1 + (fadcBits-1)/8;
            int iChan = id.readInt();
            for (int ich = 0; (ich < nChannel)&&iChan!=-999; ich++) {
                for (int iBin = 0; iBin < nTimeBin; iBin++) {
                    int val = 0;
                    for (int iB = 0; iB < nB; iB++) {
                        val += (int) ( (id.readByte() & 0xFF) << (8*iB));
                    }
                    data[iChan][iBin] = val;
                }
                iChan = id.readInt();
            }
        } catch (Exception e) {
            System.err.println("Exception " +e+ " while reading file.");
            return -1;
        }
        
        return 1;
        
    }
    
}
