/*
 * TPCData.java
 *
 * Created on February 27, 2003, 3:00 PM
 */

package tpcdata;
import java.io.*;
import jas.hist.*;

/**
 *
 * @author  karlen
 * @version
 */
abstract public class TpcData implements Rebinnable1DHistogramData, HasStyle {
    int[][] data;
    int runNumber = -1;
    int nTimeBin = -1;
    String comment = ""; 
    int nChannel = -1;
    int eventNumber = -1;
    int eventTime = -1;
    boolean goodData = false;
    int channel = 0;
    int nBins = 500;
    int delay = 0;
    BufferedInputStream in;
    JASHistStyle jASHistStyle;
    boolean truthExists;
    double[] truth; // MC truth information
    
    /** Creates new StarData */
    public TpcData(File readFile, boolean readFirstEvent) {

        goodData = readHeader(readFile);
        truthExists = false;
        truth = new double[6];
        if (goodData) {
            data = new int[nChannel][];
            for (int i = 0; i < nChannel; i++) {
               data[i] = new int[nTimeBin];
            }
            if (readFirstEvent) goodData = readEvent() == 1;
        }
        
        jASHistStyle = new JASHist1DHistogramStyle();
        //jASHistStyle.set
    }
    
    public boolean hasTruth() { return truthExists; }
    public double[] getTruth() { return truth; }
    
    int getHalfWord(byte[] bbuf,int iHalf) {
        if (iHalf == 0) {
            return (int) ((bbuf[1] & 0xFF) << 8) + (int) (bbuf[0] & 0xFF);
        } else {
            return (int) ((bbuf[3] & 0xFF) << 8) + (int) (bbuf[2] & 0xFF);
        }
    }
    
    int getHalfWordNSW(byte[] bbuf,int iHalf) {
        if (iHalf == 0) {
            return (int) ((bbuf[0] & 0xFF) << 8) + (int) (bbuf[1] & 0xFF);
        } else {
            return (int) ((bbuf[2] & 0xFF) << 8) + (int) (bbuf[3] & 0xFF);
        }
    }
    
    int getWord(byte[] bbuf) {
        return (getHalfWord(bbuf,1) << 16) + getHalfWord(bbuf,0);
    }
    
    int getWordNSW(byte[] bbuf) {
        return (getHalfWordNSW(bbuf,1) << 16) + getHalfWordNSW(bbuf,0);
    }
    
    int getByte(byte[] bbuf, int index) {
        return (int) (bbuf[index] & 0xFF);
    }
    
    public int getEventNumber() { return eventNumber;}
    public String getComment() { return comment;}
    public int getNChannel() { return nChannel;}
    public int getNTimeBin() { return nTimeBin;}
    public int getRunNumber() { return runNumber;}
    public void setRunNumber(int num) { runNumber = num;}
    public int getEventTime() { return eventTime;}
    public int[][] getData() { return data;}
    
    // METHODS to be provided:
    
    abstract boolean readHeader(File readFile);    
    abstract public int readEvent(); 
 
    public boolean isGood() {
        return goodData;
    }
    
    public void setChannel(int channel) {
        this.channel = channel;
    }
    
    public void setPlotBins(int nBins) {
        this.nBins = nBins;
    }
    
    public double[][] rebin(int rBins,double rMin,double rMax,
    boolean wantErrors,boolean hurry) {
        double del = (rMax - rMin)/rBins;
        double start = rMin; double end;
        int iStart,iEnd;
        double[][] result = new double[3][rBins];
        for (int i=0; i<rBins; i++) {
            end = start+del;
            iStart = Math.max(0,(int) start);
            iEnd = Math.min(nTimeBin,(int) end);
            result[0][i] = 0;
            if (iStart < nTimeBin && iEnd >= 0 && iEnd > iStart) {
                for (int j=iStart; j<iEnd; j++) {
                    result[0][i] += (double) data[channel][j];
                }
                result[0][i] /= (iEnd-iStart);
            }
            start = end;
        }
        // Force histogram to show 0 and 255:
        result[0][0]=0;
        result[0][1]=255;
        return result;
    }
    
    public int getBins() {
        return nBins;
    }
    
    public int getDelay() {
        return delay;
    }
    
    public boolean isRebinnable() {
        return false;
    }
    
    public int getAxisType() {
        return DOUBLE;
    }
    
    public java.lang.String[] getAxisLabels() {
        return null;
    }
    
    public double getMax() {
        return (double) nTimeBin;
    }
    
    public double getMin() {
        return 0.;
    }
    
    public boolean isPadInUse(int iPad){
        if (iPad < nChannel) return true;
        return false;
    }
    
    public java.lang.String getTitle() {
        return "Channel " + channel;
    }
    
    public jas.hist.JASHistStyle getStyle() {
        return jASHistStyle;
    }
    
}
