/*
 * RunMenu.java
 *
 * Created on March 27, 2002, 10:19 AM
 */

package tpcsimulator;
import tpctracker.*;
import javax.swing.*;
import java.io.*;
import java.util.Vector;
/**
 *
 * @author  karlen
 * @version
 */
class RunMenu extends javax.swing.JDialog {
    
    TpcGui tpcGui;
    String newline = "\n";
    RunParam runParam;
    Vector xyFitterPanelVector = new Vector(5,5);
    
    /** Creates new form RunMenu */
    public RunMenu(java.awt.Frame parent) {
        super (parent, "Run Monte Carlo", true);
        tpcGui = (TpcGui) parent;
        initComponents ();
        setRunParam(new RunParam());
        removeXYFitterButton.setEnabled(false);
        pack ();
    }
    
    void setRunParam(RunParam rp) {        
        geantCheckBox.setSelected(rp.geantEvents);
        geantFileField.setText("" + rp.geantFile);
        geantXOffsetField.setText("" + rp.geantXOffset);
        geantYOffsetField.setText("" + rp.geantYOffset);
        geantZOffsetField.setText("" + rp.geantZOffset);
        geantCodeField.setText("" + rp.geantCode);
        geantWiField.setText("" + rp.geantWi);        
        
        minXField.setText("" + (rp.minX));
        maxXField.setText("" + rp.maxX);
        minZField.setText("" + rp.minZ);
        maxZField.setText("" + rp.maxZ);
        minPhiField.setText("" + rp.minPhi);
        maxPhiField.setText("" + rp.maxPhi);
        minPsiField.setText("" + rp.minPsi);
        maxPsiField.setText("" + rp.maxPsi);
        
        trk2XField.setText("" + (rp.trk2X));
        trk2ZField.setText("" + rp.trk2Z);
        trk2PhiField.setText("" + rp.trk2Phi);
        trk2PsiField.setText("" + rp.trk2Psi);
        trk2CheckBox.setSelected(rp.makeTrk2);
        
        lowXField.setText("" + rp.lowX);
        highXField.setText("" + rp.highX);
        lowYField.setText("" + rp.lowY);
        highYField.setText("" + rp.highY);
        lowZField.setText("" + rp.lowZ);
        highZField.setText("" + rp.highZ);
        timeField.setText("" + rp.time);
        sxyzField.setText("" + rp.sxyz);
        cdField.setText("" + rp.cd);
        preAmpGainField.setText("" + rp.preAmpGain);
        // backward compatibility for gain std. dev... (new parameter)
        preAmpGainStdDevField.setText("" + rp.preAmpGainStdDev);
        preAmpRiseTimeField.setText("" + rp.preAmpRiseTime);
        preAmpFallTimeField.setText("" + rp.preAmpFallTime);
        if (rp.preAmpType == 0) preAmpGenericRadioButton.setSelected(true);
        else if (rp.preAmpType == 1) preAmpStarRadioButton.setSelected(true);
        fadcGainField.setText("" + rp.fadcGain);
        fadcBitsField.setText("" + rp.fadcBits);
        fadcDTField.setText("" + rp.fadcDT);
        fadcBinsField.setText("" + rp.fadcBins);
        runField.setText("" + rp.run);
        numberField.setText("" + rp.number);
        seedField.setText("" + rp.seed);
        writeRawDataCheckBox.setSelected(rp.writeRawData);
        writeTupleCheckBox.setSelected(rp.writeTuple);
        filenameField.setText("" + rp.filename);
        tFilenameField.setText("" + rp.tFilename);
        // remove any existing Fitters from Panel and rewrite them
        for (int i=0; i < xyFitterPanelVector.size(); i++) {
            xyFittersPanel.remove((XYFitterPanel) xyFitterPanelVector.elementAt(i));
        }
        xyFitterPanelVector.removeAllElements();
        for (int i=0; i < rp.xyFitterParamVector.size(); i++) {
            XYFitterPanel xyfPanel = 
                new XYFitterPanel(tpcGui,(XYFitterParam) rp.xyFitterParamVector.elementAt(i));
            xyFittersPanel.add(xyfPanel);
            xyFitterPanelVector.addElement(xyfPanel);
        }
        if (rp.xyFitterParamVector.size() > 0)
           removeXYFitterButton.setEnabled(true);
        runParam = rp;
    }
    
    RunParam getRunParam() {
        RunParam rp = new RunParam();
        rp.geantEvents = geantCheckBox.isSelected();
        rp.geantFile = geantFileField.getText();
        rp.geantXOffset = Double.valueOf(geantXOffsetField.getText()).doubleValue();
        rp.geantYOffset = Double.valueOf(geantYOffsetField.getText()).doubleValue();
        rp.geantZOffset = Double.valueOf(geantZOffsetField.getText()).doubleValue();
        rp.geantCode = Integer.valueOf(geantCodeField.getText()).intValue();
        rp.geantWi = Double.valueOf(geantWiField.getText()).doubleValue();
        
        rp.minX = Double.valueOf(minXField.getText()).doubleValue();
        rp.maxX = Double.valueOf(maxXField.getText()).doubleValue();
        rp.minZ = Double.valueOf(minZField.getText()).doubleValue();
        rp.maxZ = Double.valueOf(maxZField.getText()).doubleValue();
        rp.minPhi = Double.valueOf(minPhiField.getText()).doubleValue();
        rp.maxPhi = Double.valueOf(maxPhiField.getText()).doubleValue();
        rp.minPsi = Double.valueOf(minPsiField.getText()).doubleValue();
        rp.maxPsi = Double.valueOf(maxPsiField.getText()).doubleValue();
        rp.trk2X = Double.valueOf(trk2XField.getText()).doubleValue();
        rp.trk2Z = Double.valueOf(trk2ZField.getText()).doubleValue();
        rp.trk2Phi = Double.valueOf(trk2PhiField.getText()).doubleValue();
        rp.trk2Psi = Double.valueOf(trk2PsiField.getText()).doubleValue();
        rp.makeTrk2 = trk2CheckBox.isSelected();
        rp.lowX = Double.valueOf(lowXField.getText()).doubleValue();
        rp.highX = Double.valueOf(highXField.getText()).doubleValue();
        rp.lowY = Double.valueOf(lowYField.getText()).doubleValue();
        rp.highY = Double.valueOf(highYField.getText()).doubleValue();
        rp.lowZ = Double.valueOf(lowZField.getText()).doubleValue();
        rp.highZ = Double.valueOf(highZField.getText()).doubleValue();
        rp.time = Double.valueOf(timeField.getText()).doubleValue();
        rp.sxyz = Double.valueOf(sxyzField.getText()).doubleValue();
        rp.cd = Double.valueOf(cdField.getText()).doubleValue();
        rp.preAmpGain = Double.valueOf(preAmpGainField.getText()).doubleValue();
        rp.preAmpGainStdDev = Double.valueOf(preAmpGainStdDevField.getText()).doubleValue();
        rp.preAmpRiseTime = Integer.valueOf(preAmpRiseTimeField.getText()).intValue();
        rp.preAmpFallTime = Integer.valueOf(preAmpFallTimeField.getText()).intValue();
        if (preAmpGenericRadioButton.isSelected()) rp.preAmpType = 0;
        else if(preAmpStarRadioButton.isSelected()) rp.preAmpType = 1;
        rp.fadcGain = Double.valueOf(fadcGainField.getText()).doubleValue();
        rp.fadcBits = Integer.valueOf(fadcBitsField.getText()).intValue();
        rp.fadcDT = Double.valueOf(fadcDTField.getText()).doubleValue();
        rp.fadcBins = Integer.valueOf(fadcBinsField.getText()).intValue();
        rp.run = Integer.valueOf(runField.getText()).intValue();
        rp.number = Integer.valueOf(numberField.getText()).intValue();
        rp.seed = Long.valueOf(seedField.getText()).longValue();
        rp.writeRawData = writeRawDataCheckBox.isSelected();
        rp.filename = filenameField.getText();
        rp.writeTuple = writeTupleCheckBox.isSelected();
        rp.tFilename = tFilenameField.getText();
        // read the fitter panels:
        for (int i=0; i < xyFitterPanelVector.size(); i++) {
            ((XYFitterPanel) xyFitterPanelVector.elementAt(i)).readPanel();
        }
        rp.xyFitterParamVector = runParam.xyFitterParamVector;
        return rp;
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        preAmpTypeButtonGroup = new javax.swing.ButtonGroup();
        buttonPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        optionsScrollPane = new javax.swing.JScrollPane();
        optionsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        optionsPanel = new javax.swing.JPanel();
        eventsPanel = new javax.swing.JPanel();
        eventsSubPanel1 = new javax.swing.JPanel();
        eventsSubPanel1Labels = new javax.swing.JPanel();
        runLabel = new javax.swing.JLabel();
        numberLabel = new javax.swing.JLabel();
        eventsSubPanel1Fields = new javax.swing.JPanel();
        runField = new javax.swing.JTextField();
        numberField = new javax.swing.JTextField();
        eventsSubPanel2 = new javax.swing.JPanel();
        eventsSubPanel2Labels = new javax.swing.JPanel();
        seedLabel = new javax.swing.JLabel();
        eventsSubPanel2Fields = new javax.swing.JPanel();
        seedField = new javax.swing.JTextField();
        trackParameterPanel = new javax.swing.JPanel();
        trackParameterSubPanel1 = new javax.swing.JPanel();
        trackParameterSubPanel1Labels = new javax.swing.JPanel();
        minXLabel = new javax.swing.JLabel();
        minZLabel = new javax.swing.JLabel();
        minPhiLabel = new javax.swing.JLabel();
        minPsiLabel = new javax.swing.JLabel();
        timeLabel = new javax.swing.JLabel();
        sxyzLabel = new javax.swing.JLabel();
        trackParameterSubPanel1Fields = new javax.swing.JPanel();
        minXField = new javax.swing.JTextField();
        minZField = new javax.swing.JTextField();
        minPhiField = new javax.swing.JTextField();
        minPsiField = new javax.swing.JTextField();
        timeField = new javax.swing.JTextField();
        sxyzField = new javax.swing.JTextField();
        trackParameterSubPanel2 = new javax.swing.JPanel();
        trackParameterSubPanel2Labels = new javax.swing.JPanel();
        maxXLabel = new javax.swing.JLabel();
        maxZLabel = new javax.swing.JLabel();
        maxPhiLabel = new javax.swing.JLabel();
        maxPsiLabel = new javax.swing.JLabel();
        cdLabel = new javax.swing.JLabel();
        blankLabel = new javax.swing.JLabel();
        trackParameterSubPanel2Fields = new javax.swing.JPanel();
        maxXField = new javax.swing.JTextField();
        maxZField = new javax.swing.JTextField();
        maxPhiField = new javax.swing.JTextField();
        maxPsiField = new javax.swing.JTextField();
        cdField = new javax.swing.JTextField();
        blankLabel1 = new javax.swing.JLabel();
        trackParameterSubPanel3 = new javax.swing.JPanel();
        trackParameterSubPanel3Labels = new javax.swing.JPanel();
        trk2XLabel = new javax.swing.JLabel();
        trk2ZLabel = new javax.swing.JLabel();
        trk2PhiLabel = new javax.swing.JLabel();
        trk2PsiLabel = new javax.swing.JLabel();
        trk2Label = new javax.swing.JLabel();
        blankLabel2 = new javax.swing.JLabel();
        trackParameterSubPanel3Fields = new javax.swing.JPanel();
        trk2XField = new javax.swing.JTextField();
        trk2ZField = new javax.swing.JTextField();
        trk2PhiField = new javax.swing.JTextField();
        trk2PsiField = new javax.swing.JTextField();
        trk2CheckBox = new javax.swing.JCheckBox();
        blankLabel3 = new javax.swing.JLabel();
        geantPanel = new javax.swing.JPanel();
        geantparPanel = new javax.swing.JPanel();
        geantpar1Panel = new javax.swing.JPanel();
        geantCheckBox = new javax.swing.JCheckBox();
        geantFileLabel = new javax.swing.JLabel();
        geantFileField = new javax.swing.JTextField();
        geantpar2Panel = new javax.swing.JPanel();
        boxSubPanel3 = new javax.swing.JPanel();
        boxSubPanel1Labels1 = new javax.swing.JPanel();
        lowXLabel1 = new javax.swing.JLabel();
        lowYLabel1 = new javax.swing.JLabel();
        lowZLabel1 = new javax.swing.JLabel();
        boxSubPanel1Fields1 = new javax.swing.JPanel();
        geantXOffsetField = new javax.swing.JTextField();
        geantYOffsetField = new javax.swing.JTextField();
        geantZOffsetField = new javax.swing.JTextField();
        boxSubPanel4 = new javax.swing.JPanel();
        boxSubPanel1Labels2 = new javax.swing.JPanel();
        lowXLabel2 = new javax.swing.JLabel();
        lowYLabel2 = new javax.swing.JLabel();
        lowZLabel2 = new javax.swing.JLabel();
        boxSubPanel1Fields2 = new javax.swing.JPanel();
        geantCodeField = new javax.swing.JTextField();
        geantWiField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        boxPanel = new javax.swing.JPanel();
        boxSubPanel1 = new javax.swing.JPanel();
        boxSubPanel1Labels = new javax.swing.JPanel();
        lowXLabel = new javax.swing.JLabel();
        lowYLabel = new javax.swing.JLabel();
        lowZLabel = new javax.swing.JLabel();
        boxSubPanel1Fields = new javax.swing.JPanel();
        lowXField = new javax.swing.JTextField();
        lowYField = new javax.swing.JTextField();
        lowZField = new javax.swing.JTextField();
        boxSubPanel2 = new javax.swing.JPanel();
        boxSubPanel2Labels = new javax.swing.JPanel();
        highXLabel = new javax.swing.JLabel();
        highYLabel = new javax.swing.JLabel();
        highZLabel = new javax.swing.JLabel();
        boxSubPanel2Fields = new javax.swing.JPanel();
        highXField = new javax.swing.JTextField();
        highYField = new javax.swing.JTextField();
        highZField = new javax.swing.JTextField();
        preAmpPanel = new javax.swing.JPanel();
        preAmpTypePanel = new javax.swing.JPanel();
        preAmpTypeButtonsPanel = new javax.swing.JPanel();
        preAmpGenericRadioButton = new javax.swing.JRadioButton();
        preAmpStarRadioButton = new javax.swing.JRadioButton();
        preAmpSubPanel1 = new javax.swing.JPanel();
        preAmpSubPanel1Labels = new javax.swing.JPanel();
        preAmpGainLabel = new javax.swing.JLabel();
        preAmpRiseTimeLabel = new javax.swing.JLabel();
        preAmpSubPanel1Fields = new javax.swing.JPanel();
        preAmpGainField = new javax.swing.JTextField();
        preAmpRiseTimeField = new javax.swing.JTextField();
        preAmpSubPanel2 = new javax.swing.JPanel();
        preAmpSubPanel2Labels = new javax.swing.JPanel();
        preAmpGainStdDevLabel = new javax.swing.JLabel();
        preAmpFallTimeLabel = new javax.swing.JLabel();
        preAmpSubPanel2Fields = new javax.swing.JPanel();
        preAmpGainStdDevField = new javax.swing.JTextField();
        preAmpFallTimeField = new javax.swing.JTextField();
        fadcPanel = new javax.swing.JPanel();
        fadcSubPanel1 = new javax.swing.JPanel();
        fadcSubPanel1Labels = new javax.swing.JPanel();
        fadcGainLabel = new javax.swing.JLabel();
        fadcDTLabel = new javax.swing.JLabel();
        fadcSubPanel1Fields = new javax.swing.JPanel();
        fadcGainField = new javax.swing.JTextField();
        fadcDTField = new javax.swing.JTextField();
        fadcSubPanel2 = new javax.swing.JPanel();
        fadcSubPanel2Labels = new javax.swing.JPanel();
        fadcBitsLabel = new javax.swing.JLabel();
        fadcBinsLabel = new javax.swing.JLabel();
        fadcSubPanel2Fields = new javax.swing.JPanel();
        fadcBitsField = new javax.swing.JTextField();
        fadcBinsField = new javax.swing.JTextField();
        rawDataOutputPanel = new javax.swing.JPanel();
        writeRawDataPanel = new javax.swing.JPanel();
        writeRawDataCheckBox = new javax.swing.JCheckBox();
        writeRawDataLabel = new javax.swing.JLabel();
        filenamePanel = new javax.swing.JPanel();
        filenameLabel = new javax.swing.JLabel();
        filenameField = new javax.swing.JTextField();
        fitterPanel = new javax.swing.JPanel();
        addFitterPanel = new javax.swing.JPanel();
        addXYFitterButton = new javax.swing.JButton();
        removeXYFitterButton = new javax.swing.JButton();
        xyFittersPanel = new javax.swing.JPanel();
        tupleOutputPanel = new javax.swing.JPanel();
        writeTuplePanel = new javax.swing.JPanel();
        writeTupleCheckBox = new javax.swing.JCheckBox();
        writeTupleLabel = new javax.swing.JLabel();
        tFilenamePanel = new javax.swing.JPanel();
        tFilenameLabel = new javax.swing.JLabel();
        tFilenameField = new javax.swing.JTextField();
        loadSavePanel = new javax.swing.JPanel();
        loadButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();

        setTitle("Run Monte Carlo");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        buttonPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        okButton.setText("RUN");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });

        buttonPanel.add(okButton);

        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        buttonPanel.add(cancelButton);

        getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);

        optionsScrollPane.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        optionsScrollPane.setPreferredSize(new java.awt.Dimension(560, 600));
        optionsScrollPane.setAutoscrolls(true);
        optionsPanel.setLayout(new javax.swing.BoxLayout(optionsPanel, javax.swing.BoxLayout.Y_AXIS));

        optionsPanel.setMinimumSize(new java.awt.Dimension(520, 1000));
        optionsPanel.setPreferredSize(new java.awt.Dimension(520, 1000));
        eventsPanel.setBorder(new javax.swing.border.TitledBorder("Run parameters"));
        eventsSubPanel1.setLayout(new java.awt.BorderLayout());

        eventsSubPanel1Labels.setLayout(new java.awt.GridLayout(0, 1));

        runLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        runLabel.setText("run #");
        runLabel.setToolTipText("Run number");
        runLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        runLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        runLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        eventsSubPanel1Labels.add(runLabel);

        numberLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        numberLabel.setText("# events");
        numberLabel.setToolTipText("Number of MC events to generate");
        numberLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        numberLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        numberLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        eventsSubPanel1Labels.add(numberLabel);

        eventsSubPanel1.add(eventsSubPanel1Labels, java.awt.BorderLayout.WEST);

        eventsSubPanel1Fields.setLayout(new java.awt.GridLayout(0, 1));

        runField.setText("5001");
        runField.setToolTipText("Run number");
        runField.setMinimumSize(new java.awt.Dimension(50, 20));
        runField.setPreferredSize(new java.awt.Dimension(50, 20));
        eventsSubPanel1Fields.add(runField);

        numberField.setText("100");
        numberField.setToolTipText("Number of MC events to generate");
        numberField.setMinimumSize(new java.awt.Dimension(50, 20));
        numberField.setPreferredSize(new java.awt.Dimension(50, 20));
        eventsSubPanel1Fields.add(numberField);

        eventsSubPanel1.add(eventsSubPanel1Fields, java.awt.BorderLayout.CENTER);

        eventsPanel.add(eventsSubPanel1);

        eventsSubPanel2.setLayout(new java.awt.BorderLayout());

        eventsSubPanel2Labels.setLayout(new java.awt.GridLayout(0, 1));

        seedLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        seedLabel.setText("seed");
        seedLabel.setToolTipText("Starting seed for MC generation");
        seedLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        seedLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        seedLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        eventsSubPanel2Labels.add(seedLabel);

        eventsSubPanel2.add(eventsSubPanel2Labels, java.awt.BorderLayout.WEST);

        eventsSubPanel2Fields.setLayout(new java.awt.GridLayout(0, 1));

        seedField.setText("-1");
        seedField.setToolTipText("If -1, then use system time for seed");
        seedField.setMinimumSize(new java.awt.Dimension(50, 20));
        seedField.setPreferredSize(new java.awt.Dimension(50, 20));
        eventsSubPanel2Fields.add(seedField);

        eventsSubPanel2.add(eventsSubPanel2Fields, java.awt.BorderLayout.CENTER);

        eventsPanel.add(eventsSubPanel2);

        optionsPanel.add(eventsPanel);

        trackParameterPanel.setBorder(new javax.swing.border.TitledBorder("Track parameters"));
        trackParameterSubPanel1.setLayout(new java.awt.BorderLayout());

        trackParameterSubPanel1Labels.setLayout(new java.awt.GridLayout(0, 1));

        minXLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        minXLabel.setText("min x0 (mm)");
        minXLabel.setToolTipText("range of track parameters to generate");
        minXLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        minXLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        minXLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(minXLabel);

        minZLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        minZLabel.setText("min z0 (mm)");
        minZLabel.setToolTipText("range of track parameters to generate");
        minZLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        minZLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        minZLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(minZLabel);

        minPhiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        minPhiLabel.setText("min phi (rad)");
        minPhiLabel.setToolTipText("range of track parameters to generate");
        minPhiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        minPhiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        minPhiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(minPhiLabel);

        minPsiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        minPsiLabel.setText("min psi (rad)");
        minPsiLabel.setToolTipText("range of track parameters to generate");
        minPsiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        minPsiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        minPsiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(minPsiLabel);

        timeLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        timeLabel.setText("time (ns)");
        timeLabel.setToolTipText("t0 of track");
        timeLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        timeLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        timeLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(timeLabel);

        sxyzLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        sxyzLabel.setText("sigma xyz (mm)");
        sxyzLabel.setToolTipText("t0 of track");
        sxyzLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        sxyzLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        sxyzLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel1Labels.add(sxyzLabel);

        trackParameterSubPanel1.add(trackParameterSubPanel1Labels, java.awt.BorderLayout.WEST);

        trackParameterSubPanel1Fields.setLayout(new java.awt.GridLayout(0, 1));

        minXField.setText("-1.");
        minXField.setToolTipText("range of track parameters to generate");
        minXField.setMinimumSize(new java.awt.Dimension(50, 20));
        minXField.setPreferredSize(new java.awt.Dimension(50, 20));
        trackParameterSubPanel1Fields.add(minXField);

        minZField.setText("80.");
        minZField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel1Fields.add(minZField);

        minPhiField.setText("-0.1");
        minPhiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel1Fields.add(minPhiField);

        minPsiField.setText("-0.1");
        minPsiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel1Fields.add(minPsiField);

        timeField.setText("0");
        timeField.setToolTipText("t0 of track");
        trackParameterSubPanel1Fields.add(timeField);

        sxyzField.setText("0.1");
        sxyzField.setToolTipText("initial spread of electron clouds");
        trackParameterSubPanel1Fields.add(sxyzField);

        trackParameterSubPanel1.add(trackParameterSubPanel1Fields, java.awt.BorderLayout.CENTER);

        trackParameterPanel.add(trackParameterSubPanel1);

        trackParameterSubPanel2.setLayout(new java.awt.BorderLayout());

        trackParameterSubPanel2Labels.setLayout(new java.awt.GridLayout(0, 1));

        maxXLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        maxXLabel.setText("max x0 (mm)");
        maxXLabel.setToolTipText("range of track parameters to generate");
        maxXLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        maxXLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        maxXLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(maxXLabel);

        maxZLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        maxZLabel.setText("max z0 (mm)");
        maxZLabel.setToolTipText("range of track parameters to generate");
        maxZLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        maxZLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        maxZLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(maxZLabel);

        maxPhiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        maxPhiLabel.setText("max phi (rad)");
        maxPhiLabel.setToolTipText("range of track parameters to generate");
        maxPhiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        maxPhiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        maxPhiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(maxPhiLabel);

        maxPsiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        maxPsiLabel.setText("max psi (rad)");
        maxPsiLabel.setToolTipText("range of track parameters to generate");
        maxPsiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        maxPsiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        maxPsiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(maxPsiLabel);

        cdLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        cdLabel.setText("cd (/mm)");
        cdLabel.setToolTipText("cluster density (average number of clusters per mm)");
        cdLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        cdLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        cdLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(cdLabel);

        blankLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        blankLabel.setText("  ");
        blankLabel.setToolTipText("");
        blankLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        blankLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        blankLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel2Labels.add(blankLabel);

        trackParameterSubPanel2.add(trackParameterSubPanel2Labels, java.awt.BorderLayout.WEST);

        trackParameterSubPanel2Fields.setLayout(new java.awt.GridLayout(0, 1));

        maxXField.setText("1.");
        maxXField.setToolTipText("range of track parameters to generate");
        maxXField.setMinimumSize(new java.awt.Dimension(50, 20));
        maxXField.setPreferredSize(new java.awt.Dimension(50, 20));
        trackParameterSubPanel2Fields.add(maxXField);

        maxZField.setText("80.");
        maxZField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel2Fields.add(maxZField);

        maxPhiField.setText("0.1");
        maxPhiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel2Fields.add(maxPhiField);

        maxPsiField.setText("0.1");
        maxPsiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel2Fields.add(maxPsiField);

        cdField.setText("3.0");
        cdField.setToolTipText("cluster density (average number of clusters per mm)");
        trackParameterSubPanel2Fields.add(cdField);

        blankLabel1.setFont(new java.awt.Font("Dialog", 0, 10));
        blankLabel1.setText("  ");
        blankLabel1.setToolTipText("");
        blankLabel1.setMaximumSize(new java.awt.Dimension(20, 20));
        blankLabel1.setMinimumSize(new java.awt.Dimension(20, 20));
        blankLabel1.setPreferredSize(new java.awt.Dimension(20, 20));
        trackParameterSubPanel2Fields.add(blankLabel1);

        trackParameterSubPanel2.add(trackParameterSubPanel2Fields, java.awt.BorderLayout.CENTER);

        trackParameterPanel.add(trackParameterSubPanel2);

        trackParameterSubPanel3.setLayout(new java.awt.BorderLayout());

        trackParameterSubPanel3Labels.setLayout(new java.awt.GridLayout(0, 1));

        trk2XLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        trk2XLabel.setText("trk 2 x0 (mm)");
        trk2XLabel.setToolTipText("x0 value for track #2");
        trk2XLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        trk2XLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        trk2XLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel3Labels.add(trk2XLabel);

        trk2ZLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        trk2ZLabel.setText("trk2 z0 (mm)");
        trk2ZLabel.setToolTipText("z0 value for track #2");
        trk2ZLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        trk2ZLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        trk2ZLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel3Labels.add(trk2ZLabel);

        trk2PhiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        trk2PhiLabel.setText("trk2 phi (rad)");
        trk2PhiLabel.setToolTipText("phi value for track #2");
        trk2PhiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        trk2PhiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        trk2PhiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel3Labels.add(trk2PhiLabel);

        trk2PsiLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        trk2PsiLabel.setText("trk2 psi (rad)");
        trk2PsiLabel.setToolTipText("psi value for track #2");
        trk2PsiLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        trk2PsiLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        trk2PsiLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel3Labels.add(trk2PsiLabel);

        trk2Label.setFont(new java.awt.Font("Dialog", 0, 10));
        trk2Label.setText("do 2 tracks");
        trk2Label.setToolTipText("select this to generate 2 track events");
        trk2Label.setMaximumSize(new java.awt.Dimension(100, 20));
        trk2Label.setMinimumSize(new java.awt.Dimension(70, 20));
        trk2Label.setPreferredSize(new java.awt.Dimension(80, 20));
        trackParameterSubPanel3Labels.add(trk2Label);

        blankLabel2.setFont(new java.awt.Font("Dialog", 0, 10));
        blankLabel2.setText("  ");
        blankLabel2.setToolTipText("");
        blankLabel2.setMaximumSize(new java.awt.Dimension(20, 20));
        blankLabel2.setMinimumSize(new java.awt.Dimension(20, 20));
        blankLabel2.setPreferredSize(new java.awt.Dimension(20, 20));
        trackParameterSubPanel3Labels.add(blankLabel2);

        trackParameterSubPanel3.add(trackParameterSubPanel3Labels, java.awt.BorderLayout.WEST);

        trackParameterSubPanel3Fields.setLayout(new java.awt.GridLayout(0, 1));

        trk2XField.setText("1.");
        trk2XField.setToolTipText("range of track parameters to generate");
        trk2XField.setMinimumSize(new java.awt.Dimension(50, 20));
        trk2XField.setPreferredSize(new java.awt.Dimension(50, 20));
        trackParameterSubPanel3Fields.add(trk2XField);

        trk2ZField.setText("80.");
        trk2ZField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel3Fields.add(trk2ZField);

        trk2PhiField.setText("0.1");
        trk2PhiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel3Fields.add(trk2PhiField);

        trk2PsiField.setText("0.1");
        trk2PsiField.setToolTipText("range of track parameters to generate");
        trackParameterSubPanel3Fields.add(trk2PsiField);

        trk2CheckBox.setToolTipText("select this to generate 2 track events");
        trackParameterSubPanel3Fields.add(trk2CheckBox);

        blankLabel3.setFont(new java.awt.Font("Dialog", 0, 10));
        blankLabel3.setText("  ");
        blankLabel3.setToolTipText("");
        blankLabel3.setMaximumSize(new java.awt.Dimension(20, 20));
        blankLabel3.setMinimumSize(new java.awt.Dimension(20, 20));
        blankLabel3.setPreferredSize(new java.awt.Dimension(20, 20));
        trackParameterSubPanel3Fields.add(blankLabel3);

        trackParameterSubPanel3.add(trackParameterSubPanel3Fields, java.awt.BorderLayout.CENTER);

        trackParameterPanel.add(trackParameterSubPanel3);

        optionsPanel.add(trackParameterPanel);

        geantPanel.setBorder(new javax.swing.border.TitledBorder("Geant parameters"));
        geantparPanel.setLayout(new javax.swing.BoxLayout(geantparPanel, javax.swing.BoxLayout.Y_AXIS));

        geantCheckBox.setText("use geant file");
        geantpar1Panel.add(geantCheckBox);

        geantFileLabel.setText("Geant File Name:");
        geantpar1Panel.add(geantFileLabel);

        geantFileField.setText("filename");
        geantFileField.setMinimumSize(new java.awt.Dimension(150, 21));
        geantFileField.setPreferredSize(new java.awt.Dimension(150, 21));
        geantpar1Panel.add(geantFileField);

        geantparPanel.add(geantpar1Panel);

        boxSubPanel1Labels1.setLayout(new javax.swing.BoxLayout(boxSubPanel1Labels1, javax.swing.BoxLayout.Y_AXIS));

        lowXLabel1.setFont(new java.awt.Font("Dialog", 0, 10));
        lowXLabel1.setText("x offset (mm)");
        lowXLabel1.setToolTipText("");
        lowXLabel1.setMaximumSize(new java.awt.Dimension(100, 20));
        lowXLabel1.setMinimumSize(new java.awt.Dimension(70, 20));
        lowXLabel1.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels1.add(lowXLabel1);

        lowYLabel1.setFont(new java.awt.Font("Dialog", 0, 10));
        lowYLabel1.setText("y offset (mm)");
        lowYLabel1.setToolTipText("");
        lowYLabel1.setMaximumSize(new java.awt.Dimension(100, 20));
        lowYLabel1.setMinimumSize(new java.awt.Dimension(70, 20));
        lowYLabel1.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels1.add(lowYLabel1);

        lowZLabel1.setFont(new java.awt.Font("Dialog", 0, 10));
        lowZLabel1.setText("z offset (mm)");
        lowZLabel1.setToolTipText("specify fiducial volume");
        lowZLabel1.setMaximumSize(new java.awt.Dimension(100, 20));
        lowZLabel1.setMinimumSize(new java.awt.Dimension(70, 20));
        lowZLabel1.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels1.add(lowZLabel1);

        boxSubPanel3.add(boxSubPanel1Labels1);

        boxSubPanel1Fields1.setLayout(new javax.swing.BoxLayout(boxSubPanel1Fields1, javax.swing.BoxLayout.Y_AXIS));

        geantXOffsetField.setText("0.");
        geantXOffsetField.setToolTipText("offset of origins");
        geantXOffsetField.setMinimumSize(new java.awt.Dimension(50, 20));
        geantXOffsetField.setPreferredSize(new java.awt.Dimension(50, 20));
        boxSubPanel1Fields1.add(geantXOffsetField);

        geantYOffsetField.setText("0.");
        geantYOffsetField.setToolTipText("offset of origins");
        boxSubPanel1Fields1.add(geantYOffsetField);

        geantZOffsetField.setText("0.");
        geantZOffsetField.setToolTipText("offset of origins");
        boxSubPanel1Fields1.add(geantZOffsetField);

        boxSubPanel3.add(boxSubPanel1Fields1);

        geantpar2Panel.add(boxSubPanel3);

        boxSubPanel4.setLayout(new java.awt.BorderLayout());

        boxSubPanel1Labels2.setLayout(new javax.swing.BoxLayout(boxSubPanel1Labels2, javax.swing.BoxLayout.Y_AXIS));

        lowXLabel2.setFont(new java.awt.Font("Dialog", 0, 10));
        lowXLabel2.setText("particle code");
        lowXLabel2.setToolTipText("");
        lowXLabel2.setMaximumSize(new java.awt.Dimension(100, 20));
        lowXLabel2.setMinimumSize(new java.awt.Dimension(70, 20));
        lowXLabel2.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels2.add(lowXLabel2);

        lowYLabel2.setFont(new java.awt.Font("Dialog", 0, 10));
        lowYLabel2.setText("Wi (eV)");
        lowYLabel2.setToolTipText("specify fiducial volume");
        lowYLabel2.setMaximumSize(new java.awt.Dimension(100, 20));
        lowYLabel2.setMinimumSize(new java.awt.Dimension(70, 20));
        lowYLabel2.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels2.add(lowYLabel2);

        lowZLabel2.setFont(new java.awt.Font("Dialog", 0, 10));
        lowZLabel2.setToolTipText("");
        lowZLabel2.setMaximumSize(new java.awt.Dimension(100, 20));
        lowZLabel2.setMinimumSize(new java.awt.Dimension(70, 20));
        lowZLabel2.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels2.add(lowZLabel2);

        boxSubPanel4.add(boxSubPanel1Labels2, java.awt.BorderLayout.WEST);

        boxSubPanel1Fields2.setLayout(new javax.swing.BoxLayout(boxSubPanel1Fields2, javax.swing.BoxLayout.Y_AXIS));

        geantCodeField.setText("0");
        geantCodeField.setToolTipText("specify Geant code to accept (0=all, if negative also accept 3 (electrons))");
        geantCodeField.setMinimumSize(new java.awt.Dimension(50, 20));
        geantCodeField.setPreferredSize(new java.awt.Dimension(50, 20));
        boxSubPanel1Fields2.add(geantCodeField);

        geantWiField.setText("26.");
        geantWiField.setToolTipText("mean energy to produce electron-ion pair");
        boxSubPanel1Fields2.add(geantWiField);

        jLabel1.setText(" ");
        boxSubPanel1Fields2.add(jLabel1);

        boxSubPanel4.add(boxSubPanel1Fields2, java.awt.BorderLayout.CENTER);

        geantpar2Panel.add(boxSubPanel4);

        geantparPanel.add(geantpar2Panel);

        geantPanel.add(geantparPanel);

        optionsPanel.add(geantPanel);

        boxPanel.setBorder(new javax.swing.border.TitledBorder("Fiducial volume"));
        boxSubPanel1.setLayout(new java.awt.BorderLayout());

        boxSubPanel1Labels.setLayout(new java.awt.GridLayout(0, 1));

        lowXLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        lowXLabel.setText("low x (mm)");
        lowXLabel.setToolTipText("specify fiducial volume");
        lowXLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        lowXLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        lowXLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels.add(lowXLabel);

        lowYLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        lowYLabel.setText("low y (mm)");
        lowYLabel.setToolTipText("specify fiducial volume");
        lowYLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        lowYLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        lowYLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels.add(lowYLabel);

        lowZLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        lowZLabel.setText("low z (mm)");
        lowZLabel.setToolTipText("specify fiducial volume");
        lowZLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        lowZLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        lowZLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel1Labels.add(lowZLabel);

        boxSubPanel1.add(boxSubPanel1Labels, java.awt.BorderLayout.WEST);

        boxSubPanel1Fields.setLayout(new java.awt.GridLayout(0, 1));

        lowXField.setText("-10.");
        lowXField.setToolTipText("specify fiducial volume");
        lowXField.setMinimumSize(new java.awt.Dimension(50, 20));
        lowXField.setPreferredSize(new java.awt.Dimension(50, 20));
        boxSubPanel1Fields.add(lowXField);

        lowYField.setText("-15.");
        lowYField.setToolTipText("specify fiducial volume");
        boxSubPanel1Fields.add(lowYField);

        lowZField.setText("0.");
        lowZField.setToolTipText("specify fiducial volume");
        boxSubPanel1Fields.add(lowZField);

        boxSubPanel1.add(boxSubPanel1Fields, java.awt.BorderLayout.CENTER);

        boxPanel.add(boxSubPanel1);

        boxSubPanel2.setLayout(new java.awt.BorderLayout());

        boxSubPanel2Labels.setLayout(new java.awt.GridLayout(0, 1));

        highXLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        highXLabel.setText("high x (mm)");
        highXLabel.setToolTipText("specify fiducial volume");
        highXLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        highXLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        highXLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel2Labels.add(highXLabel);

        highYLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        highYLabel.setText("high y (mm)");
        highYLabel.setToolTipText("specify fiducial volume");
        highYLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        highYLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        highYLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel2Labels.add(highYLabel);

        highZLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        highZLabel.setText("high z (mm)");
        highZLabel.setToolTipText("specify fiducial volume");
        highZLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        highZLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        highZLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        boxSubPanel2Labels.add(highZLabel);

        boxSubPanel2.add(boxSubPanel2Labels, java.awt.BorderLayout.WEST);

        boxSubPanel2Fields.setLayout(new java.awt.GridLayout(0, 1));

        highXField.setText("10");
        highXField.setToolTipText("specify fiducial volume");
        highXField.setMinimumSize(new java.awt.Dimension(50, 20));
        highXField.setPreferredSize(new java.awt.Dimension(50, 20));
        boxSubPanel2Fields.add(highXField);

        highYField.setText("15");
        highYField.setToolTipText("specify fiducial volume");
        boxSubPanel2Fields.add(highYField);

        highZField.setText("150");
        highZField.setToolTipText("specify fiducial volume");
        boxSubPanel2Fields.add(highZField);

        boxSubPanel2.add(boxSubPanel2Fields, java.awt.BorderLayout.CENTER);

        boxPanel.add(boxSubPanel2);

        optionsPanel.add(boxPanel);

        preAmpPanel.setBorder(new javax.swing.border.TitledBorder("Pre-Amp parameters"));
        preAmpTypePanel.setLayout(new java.awt.BorderLayout());

        preAmpTypeButtonsPanel.setLayout(new java.awt.GridLayout(0, 1));

        preAmpGenericRadioButton.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpGenericRadioButton.setSelected(true);
        preAmpGenericRadioButton.setText("generic type");
        preAmpGenericRadioButton.setToolTipText("choose this for generic preamp shaping");
        preAmpTypeButtonGroup.add(preAmpGenericRadioButton);
        preAmpTypeButtonsPanel.add(preAmpGenericRadioButton);

        preAmpStarRadioButton.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpStarRadioButton.setText("STAR");
        preAmpStarRadioButton.setToolTipText("choose this for STAR shaping");
        preAmpTypeButtonGroup.add(preAmpStarRadioButton);
        preAmpTypeButtonsPanel.add(preAmpStarRadioButton);

        preAmpTypePanel.add(preAmpTypeButtonsPanel, java.awt.BorderLayout.CENTER);

        preAmpPanel.add(preAmpTypePanel);

        preAmpSubPanel1.setLayout(new java.awt.BorderLayout());

        preAmpSubPanel1Labels.setLayout(new java.awt.GridLayout(0, 1));

        preAmpGainLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpGainLabel.setText("gain (mV/fC)");
        preAmpGainLabel.setToolTipText("PreAmp Gain (mV/fC)");
        preAmpGainLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        preAmpGainLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        preAmpGainLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        preAmpSubPanel1Labels.add(preAmpGainLabel);

        preAmpRiseTimeLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpRiseTimeLabel.setText("rise time (ns)");
        preAmpRiseTimeLabel.setToolTipText("Pre-Amp rise time (ns)");
        preAmpRiseTimeLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        preAmpRiseTimeLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        preAmpRiseTimeLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        preAmpSubPanel1Labels.add(preAmpRiseTimeLabel);

        preAmpSubPanel1.add(preAmpSubPanel1Labels, java.awt.BorderLayout.WEST);

        preAmpSubPanel1Fields.setLayout(new java.awt.GridLayout(0, 1));

        preAmpGainField.setText("3.3");
        preAmpGainField.setToolTipText("PreAmp Gain (mV/fC)");
        preAmpGainField.setMinimumSize(new java.awt.Dimension(50, 20));
        preAmpGainField.setPreferredSize(new java.awt.Dimension(50, 20));
        preAmpSubPanel1Fields.add(preAmpGainField);

        preAmpRiseTimeField.setText("30");
        preAmpRiseTimeField.setToolTipText("Pre-Amp rise time (ns)");
        preAmpRiseTimeField.setMinimumSize(new java.awt.Dimension(50, 20));
        preAmpRiseTimeField.setPreferredSize(new java.awt.Dimension(50, 20));
        preAmpSubPanel1Fields.add(preAmpRiseTimeField);

        preAmpSubPanel1.add(preAmpSubPanel1Fields, java.awt.BorderLayout.CENTER);

        preAmpPanel.add(preAmpSubPanel1);

        preAmpSubPanel2.setLayout(new java.awt.BorderLayout());

        preAmpSubPanel2Labels.setLayout(new java.awt.GridLayout(0, 1));

        preAmpGainStdDevLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpGainStdDevLabel.setText("gain s.d. (rel)");
        preAmpGainStdDevLabel.setToolTipText("standard deviation of preamp gains (eg. 0.1 corresponds to 10%)");
        preAmpGainStdDevLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        preAmpGainStdDevLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        preAmpGainStdDevLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        preAmpSubPanel2Labels.add(preAmpGainStdDevLabel);

        preAmpFallTimeLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        preAmpFallTimeLabel.setText("fall time (ns)");
        preAmpFallTimeLabel.setToolTipText("Pre-Amp fall time (ns)");
        preAmpFallTimeLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        preAmpFallTimeLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        preAmpFallTimeLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        preAmpSubPanel2Labels.add(preAmpFallTimeLabel);

        preAmpSubPanel2.add(preAmpSubPanel2Labels, java.awt.BorderLayout.WEST);

        preAmpSubPanel2Fields.setLayout(new java.awt.GridLayout(0, 1));

        preAmpGainStdDevField.setText("0.");
        preAmpGainStdDevField.setToolTipText("standard deviation of preamp gains (eg. 0.1 corresponds to 10%)");
        preAmpGainStdDevField.setMinimumSize(new java.awt.Dimension(50, 20));
        preAmpGainStdDevField.setPreferredSize(new java.awt.Dimension(50, 20));
        preAmpSubPanel2Fields.add(preAmpGainStdDevField);

        preAmpFallTimeField.setText("2000");
        preAmpFallTimeField.setToolTipText("Pre-Amp fall time (ns)");
        preAmpFallTimeField.setMinimumSize(new java.awt.Dimension(50, 20));
        preAmpFallTimeField.setPreferredSize(new java.awt.Dimension(50, 20));
        preAmpSubPanel2Fields.add(preAmpFallTimeField);

        preAmpSubPanel2.add(preAmpSubPanel2Fields, java.awt.BorderLayout.CENTER);

        preAmpPanel.add(preAmpSubPanel2);

        optionsPanel.add(preAmpPanel);

        fadcPanel.setBorder(new javax.swing.border.TitledBorder("FADC parameters"));
        fadcSubPanel1.setLayout(new java.awt.BorderLayout());

        fadcSubPanel1Labels.setLayout(new java.awt.GridLayout(0, 1));

        fadcGainLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        fadcGainLabel.setText("gain (ch/mV)");
        fadcGainLabel.setToolTipText("FADC channels per mV");
        fadcGainLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        fadcGainLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        fadcGainLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        fadcSubPanel1Labels.add(fadcGainLabel);

        fadcDTLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        fadcDTLabel.setText("delta t (ns)");
        fadcDTLabel.setToolTipText("FADC time bin width in ns");
        fadcDTLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        fadcDTLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        fadcDTLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        fadcSubPanel1Labels.add(fadcDTLabel);

        fadcSubPanel1.add(fadcSubPanel1Labels, java.awt.BorderLayout.WEST);

        fadcSubPanel1Fields.setLayout(new java.awt.GridLayout(0, 1));

        fadcGainField.setText("1.0");
        fadcGainField.setToolTipText("FADC channels per mV");
        fadcGainField.setMinimumSize(new java.awt.Dimension(50, 20));
        fadcGainField.setPreferredSize(new java.awt.Dimension(50, 20));
        fadcSubPanel1Fields.add(fadcGainField);

        fadcDTField.setText("5.0");
        fadcDTField.setToolTipText("FADC time bin width in ns");
        fadcDTField.setMinimumSize(new java.awt.Dimension(50, 20));
        fadcDTField.setPreferredSize(new java.awt.Dimension(50, 20));
        fadcSubPanel1Fields.add(fadcDTField);

        fadcSubPanel1.add(fadcSubPanel1Fields, java.awt.BorderLayout.CENTER);

        fadcPanel.add(fadcSubPanel1);

        fadcSubPanel2.setLayout(new java.awt.BorderLayout());

        fadcSubPanel2Labels.setLayout(new java.awt.GridLayout(0, 1));

        fadcBitsLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        fadcBitsLabel.setText("# bits");
        fadcBitsLabel.setToolTipText("FADC number of bits");
        fadcBitsLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        fadcBitsLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        fadcBitsLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        fadcSubPanel2Labels.add(fadcBitsLabel);

        fadcBinsLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        fadcBinsLabel.setText("# bins");
        fadcBinsLabel.setToolTipText("FADC number of time bins to record");
        fadcBinsLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        fadcBinsLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        fadcBinsLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        fadcSubPanel2Labels.add(fadcBinsLabel);

        fadcSubPanel2.add(fadcSubPanel2Labels, java.awt.BorderLayout.WEST);

        fadcSubPanel2Fields.setLayout(new java.awt.GridLayout(0, 1));

        fadcBitsField.setText("8");
        fadcBitsField.setToolTipText("FADC number of bits");
        fadcBitsField.setMinimumSize(new java.awt.Dimension(50, 20));
        fadcBitsField.setPreferredSize(new java.awt.Dimension(50, 20));
        fadcSubPanel2Fields.add(fadcBitsField);

        fadcBinsField.setText("4000");
        fadcBinsField.setToolTipText("FADC number of time bins to record");
        fadcBinsField.setMinimumSize(new java.awt.Dimension(50, 20));
        fadcBinsField.setPreferredSize(new java.awt.Dimension(50, 20));
        fadcSubPanel2Fields.add(fadcBinsField);

        fadcSubPanel2.add(fadcSubPanel2Fields, java.awt.BorderLayout.CENTER);

        fadcPanel.add(fadcSubPanel2);

        optionsPanel.add(fadcPanel);

        rawDataOutputPanel.setLayout(new javax.swing.BoxLayout(rawDataOutputPanel, javax.swing.BoxLayout.Y_AXIS));

        rawDataOutputPanel.setBorder(new javax.swing.border.TitledBorder("Raw Data Output"));
        writeRawDataPanel.add(writeRawDataCheckBox);

        writeRawDataLabel.setText("write raw data to output file");
        writeRawDataPanel.add(writeRawDataLabel);

        rawDataOutputPanel.add(writeRawDataPanel);

        filenameLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        filenameLabel.setText("Filename");
        filenameLabel.setToolTipText("File to store MC events");
        filenameLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        filenameLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        filenameLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        filenamePanel.add(filenameLabel);

        filenameField.setText("filename.mc");
        filenameField.setToolTipText("File to store MC events");
        filenameField.setMinimumSize(new java.awt.Dimension(180, 20));
        filenameField.setPreferredSize(new java.awt.Dimension(180, 20));
        filenamePanel.add(filenameField);

        rawDataOutputPanel.add(filenamePanel);

        optionsPanel.add(rawDataOutputPanel);

        fitterPanel.setLayout(new javax.swing.BoxLayout(fitterPanel, javax.swing.BoxLayout.Y_AXIS));

        fitterPanel.setBorder(new javax.swing.border.TitledBorder("Track Fitters"));
        addXYFitterButton.setForeground(new java.awt.Color(102, 102, 153));
        addXYFitterButton.setText("Add XY Fitter");
        addXYFitterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addXYFitterButtonActionPerformed(evt);
            }
        });

        addFitterPanel.add(addXYFitterButton);

        removeXYFitterButton.setForeground(new java.awt.Color(102, 102, 153));
        removeXYFitterButton.setText("Remove XY Fitter");
        removeXYFitterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeXYFitterButtonActionPerformed(evt);
            }
        });

        addFitterPanel.add(removeXYFitterButton);

        fitterPanel.add(addFitterPanel);

        xyFittersPanel.setLayout(new javax.swing.BoxLayout(xyFittersPanel, javax.swing.BoxLayout.Y_AXIS));

        fitterPanel.add(xyFittersPanel);

        optionsPanel.add(fitterPanel);

        tupleOutputPanel.setLayout(new javax.swing.BoxLayout(tupleOutputPanel, javax.swing.BoxLayout.Y_AXIS));

        tupleOutputPanel.setBorder(new javax.swing.border.TitledBorder(new javax.swing.border.EtchedBorder(), "Tuple Output"));
        writeTuplePanel.add(writeTupleCheckBox);

        writeTupleLabel.setText("write tuple to output file");
        writeTuplePanel.add(writeTupleLabel);

        tupleOutputPanel.add(writeTuplePanel);

        tFilenameLabel.setFont(new java.awt.Font("Dialog", 0, 10));
        tFilenameLabel.setText("Filename");
        tFilenameLabel.setToolTipText("File to store tuples (.aida)");
        tFilenameLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        tFilenameLabel.setMinimumSize(new java.awt.Dimension(70, 20));
        tFilenameLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        tFilenamePanel.add(tFilenameLabel);

        tFilenameField.setToolTipText("File to store MC events");
        tFilenameField.setMinimumSize(new java.awt.Dimension(180, 20));
        tFilenameField.setPreferredSize(new java.awt.Dimension(180, 20));
        tFilenamePanel.add(tFilenameField);

        tupleOutputPanel.add(tFilenamePanel);

        optionsPanel.add(tupleOutputPanel);

        loadSavePanel.setBorder(new javax.swing.border.TitledBorder("MC parameter files"));
        loadButton.setText("Load ...");
        loadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadButtonActionPerformed(evt);
            }
        });

        loadSavePanel.add(loadButton);

        saveButton.setText("Save ...");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        loadSavePanel.add(saveButton);

        optionsPanel.add(loadSavePanel);

        optionsPanel.add(jSeparator5);

        optionsScrollPane.setViewportView(optionsPanel);

        getContentPane().add(optionsScrollPane, java.awt.BorderLayout.EAST);

    }//GEN-END:initComponents

  private void removeXYFitterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeXYFitterButtonActionPerformed
    int nFitter = runParam.xyFitterParamVector.size();
    if (nFitter > 0) {
        xyFittersPanel.remove((JPanel) xyFitterPanelVector.elementAt(nFitter-1));
        runParam.xyFitterParamVector.removeElementAt(nFitter-1);
        xyFitterPanelVector.removeElementAt(nFitter-1);        
        if (nFitter == 1) removeXYFitterButton.setEnabled(false);
        pack();
    }
    
  }//GEN-LAST:event_removeXYFitterButtonActionPerformed

  private void addXYFitterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addXYFitterButtonActionPerformed
    int nFitter = runParam.xyFitterParamVector.size();
    XYFitterParam xyfParam = new XYFitterParam();
    xyfParam.setNumber(nFitter+1);
    runParam.xyFitterParamVector.addElement(xyfParam);

    XYFitterPanel xyfPanel = new XYFitterPanel(tpcGui,xyfParam);
    xyFittersPanel.add(xyfPanel);
    xyFitterPanelVector.addElement(xyfPanel);
    removeXYFitterButton.setEnabled(true);
    pack();

  }//GEN-LAST:event_addXYFitterButtonActionPerformed
    
  private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
      // Add your handling code here:
      RunParam rp = getRunParam();
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("tmc");
      filter.setDescription("TPC MC parameter files");
      chooser.setFileFilter(filter);
      if (tpcGui.dir != null) chooser.setCurrentDirectory(tpcGui.dir);
      String fileName = "";
      //**********
      int returnVal = chooser.showSaveDialog(RunMenu.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          fileName = chooser.getSelectedFile().getAbsolutePath();
          tpcGui.dir = chooser.getSelectedFile().getParentFile();
          if (!fileName.endsWith(".tmc"))
              fileName= fileName+".tmc";
          try {
              if (fileName.length() > 0) {
                  FileOutputStream in = new FileOutputStream(fileName);
                  ObjectOutputStream iobject = new ObjectOutputStream(in);
                  iobject.writeObject(rp);
                  iobject.flush();
                  iobject.close();
                  tpcGui.output.append("Saved MC parameter file to " + fileName + newline);
                  
                /*This saves the file to the forte directory no matter what
                 directory you choose. */
              }
              else
                  tpcGui.output.append("didn't work"+ newline);
          }
          catch (IOException except) {
              except.printStackTrace();
              tpcGui.output.append(except.getMessage() + newline);
              tpcGui.output.append("Could not write file" + newline);
          }
      }
  
  }//GEN-LAST:event_saveButtonActionPerformed
  
  private void loadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadButtonActionPerformed
      // Add your handling code here:
      RunParam rp;
      JFileChooser chooser = new JFileChooser();
      ExampleFileFilter filter = new ExampleFileFilter();
      filter.addExtension("tmc");
      filter.setDescription("TPC MC parameter files");
      chooser.setFileFilter(filter);
      if (tpcGui.dir != null) chooser.setCurrentDirectory(tpcGui.dir);
      File afile;
      //**********
      int returnVal = chooser.showOpenDialog(RunMenu.this);
      if (returnVal == JFileChooser.APPROVE_OPTION) {
          afile= chooser.getSelectedFile();
          tpcGui.dir = afile.getParentFile();
          try {
              if (afile.getName().length() > 0) {
                  FileInputStream in = new FileInputStream(afile);
                  ObjectInputStream object = new ObjectInputStream(in);
                  rp = (RunParam)object.readObject();
                  object.close();
                  tpcGui.output.append("Opened MC parameter file " + afile.getAbsolutePath()+newline);
                  setRunParam(rp);
                  pack();
              }
          }
          catch (IOException except) {
              tpcGui.output.append("Could not read file" + newline);
              except.printStackTrace();
          }
          catch (ClassNotFoundException except2) {
              tpcGui.output.append("Improper data" + newline);
          }
      }
  
  }//GEN-LAST:event_loadButtonActionPerformed
  
  private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
      // Add your handling code here:
      setVisible (false);
  }//GEN-LAST:event_cancelButtonActionPerformed
  
  private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
      // Add your handling code here:
      Run run = new Run(getRunParam());
      run.start(tpcGui.tpc);
      
      setVisible (false);
  }//GEN-LAST:event_okButtonActionPerformed
  
    /** Closes the dialog */
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        setVisible (false);
    }//GEN-LAST:event_closeDialog
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel addFitterPanel;
    private javax.swing.JButton addXYFitterButton;
    private javax.swing.JLabel blankLabel;
    private javax.swing.JLabel blankLabel1;
    private javax.swing.JLabel blankLabel2;
    private javax.swing.JLabel blankLabel3;
    private javax.swing.JPanel boxPanel;
    private javax.swing.JPanel boxSubPanel1;
    private javax.swing.JPanel boxSubPanel1Fields;
    private javax.swing.JPanel boxSubPanel1Fields1;
    private javax.swing.JPanel boxSubPanel1Fields2;
    private javax.swing.JPanel boxSubPanel1Labels;
    private javax.swing.JPanel boxSubPanel1Labels1;
    private javax.swing.JPanel boxSubPanel1Labels2;
    private javax.swing.JPanel boxSubPanel2;
    private javax.swing.JPanel boxSubPanel2Fields;
    private javax.swing.JPanel boxSubPanel2Labels;
    private javax.swing.JPanel boxSubPanel3;
    private javax.swing.JPanel boxSubPanel4;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JTextField cdField;
    private javax.swing.JLabel cdLabel;
    private javax.swing.JPanel eventsPanel;
    private javax.swing.JPanel eventsSubPanel1;
    private javax.swing.JPanel eventsSubPanel1Fields;
    private javax.swing.JPanel eventsSubPanel1Labels;
    private javax.swing.JPanel eventsSubPanel2;
    private javax.swing.JPanel eventsSubPanel2Fields;
    private javax.swing.JPanel eventsSubPanel2Labels;
    private javax.swing.JTextField fadcBinsField;
    private javax.swing.JLabel fadcBinsLabel;
    private javax.swing.JTextField fadcBitsField;
    private javax.swing.JLabel fadcBitsLabel;
    private javax.swing.JTextField fadcDTField;
    private javax.swing.JLabel fadcDTLabel;
    private javax.swing.JTextField fadcGainField;
    private javax.swing.JLabel fadcGainLabel;
    private javax.swing.JPanel fadcPanel;
    private javax.swing.JPanel fadcSubPanel1;
    private javax.swing.JPanel fadcSubPanel1Fields;
    private javax.swing.JPanel fadcSubPanel1Labels;
    private javax.swing.JPanel fadcSubPanel2;
    private javax.swing.JPanel fadcSubPanel2Fields;
    private javax.swing.JPanel fadcSubPanel2Labels;
    private javax.swing.JTextField filenameField;
    private javax.swing.JLabel filenameLabel;
    private javax.swing.JPanel filenamePanel;
    private javax.swing.JPanel fitterPanel;
    private javax.swing.JCheckBox geantCheckBox;
    private javax.swing.JTextField geantCodeField;
    private javax.swing.JTextField geantFileField;
    private javax.swing.JLabel geantFileLabel;
    private javax.swing.JPanel geantPanel;
    private javax.swing.JTextField geantWiField;
    private javax.swing.JTextField geantXOffsetField;
    private javax.swing.JTextField geantYOffsetField;
    private javax.swing.JTextField geantZOffsetField;
    private javax.swing.JPanel geantpar1Panel;
    private javax.swing.JPanel geantpar2Panel;
    private javax.swing.JPanel geantparPanel;
    private javax.swing.JTextField highXField;
    private javax.swing.JLabel highXLabel;
    private javax.swing.JTextField highYField;
    private javax.swing.JLabel highYLabel;
    private javax.swing.JTextField highZField;
    private javax.swing.JLabel highZLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JButton loadButton;
    private javax.swing.JPanel loadSavePanel;
    private javax.swing.JTextField lowXField;
    private javax.swing.JLabel lowXLabel;
    private javax.swing.JLabel lowXLabel1;
    private javax.swing.JLabel lowXLabel2;
    private javax.swing.JTextField lowYField;
    private javax.swing.JLabel lowYLabel;
    private javax.swing.JLabel lowYLabel1;
    private javax.swing.JLabel lowYLabel2;
    private javax.swing.JTextField lowZField;
    private javax.swing.JLabel lowZLabel;
    private javax.swing.JLabel lowZLabel1;
    private javax.swing.JLabel lowZLabel2;
    private javax.swing.JTextField maxPhiField;
    private javax.swing.JLabel maxPhiLabel;
    private javax.swing.JTextField maxPsiField;
    private javax.swing.JLabel maxPsiLabel;
    private javax.swing.JTextField maxXField;
    private javax.swing.JLabel maxXLabel;
    private javax.swing.JTextField maxZField;
    private javax.swing.JLabel maxZLabel;
    private javax.swing.JTextField minPhiField;
    private javax.swing.JLabel minPhiLabel;
    private javax.swing.JTextField minPsiField;
    private javax.swing.JLabel minPsiLabel;
    private javax.swing.JTextField minXField;
    private javax.swing.JLabel minXLabel;
    private javax.swing.JTextField minZField;
    private javax.swing.JLabel minZLabel;
    private javax.swing.JTextField numberField;
    private javax.swing.JLabel numberLabel;
    private javax.swing.JButton okButton;
    private javax.swing.JPanel optionsPanel;
    private javax.swing.JScrollPane optionsScrollPane;
    private javax.swing.JTextField preAmpFallTimeField;
    private javax.swing.JLabel preAmpFallTimeLabel;
    private javax.swing.JTextField preAmpGainField;
    private javax.swing.JLabel preAmpGainLabel;
    private javax.swing.JTextField preAmpGainStdDevField;
    private javax.swing.JLabel preAmpGainStdDevLabel;
    private javax.swing.JRadioButton preAmpGenericRadioButton;
    private javax.swing.JPanel preAmpPanel;
    private javax.swing.JTextField preAmpRiseTimeField;
    private javax.swing.JLabel preAmpRiseTimeLabel;
    private javax.swing.JRadioButton preAmpStarRadioButton;
    private javax.swing.JPanel preAmpSubPanel1;
    private javax.swing.JPanel preAmpSubPanel1Fields;
    private javax.swing.JPanel preAmpSubPanel1Labels;
    private javax.swing.JPanel preAmpSubPanel2;
    private javax.swing.JPanel preAmpSubPanel2Fields;
    private javax.swing.JPanel preAmpSubPanel2Labels;
    private javax.swing.ButtonGroup preAmpTypeButtonGroup;
    private javax.swing.JPanel preAmpTypeButtonsPanel;
    private javax.swing.JPanel preAmpTypePanel;
    private javax.swing.JPanel rawDataOutputPanel;
    private javax.swing.JButton removeXYFitterButton;
    private javax.swing.JTextField runField;
    private javax.swing.JLabel runLabel;
    private javax.swing.JButton saveButton;
    private javax.swing.JTextField seedField;
    private javax.swing.JLabel seedLabel;
    private javax.swing.JTextField sxyzField;
    private javax.swing.JLabel sxyzLabel;
    private javax.swing.JTextField tFilenameField;
    private javax.swing.JLabel tFilenameLabel;
    private javax.swing.JPanel tFilenamePanel;
    private javax.swing.JTextField timeField;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JPanel trackParameterPanel;
    private javax.swing.JPanel trackParameterSubPanel1;
    private javax.swing.JPanel trackParameterSubPanel1Fields;
    private javax.swing.JPanel trackParameterSubPanel1Labels;
    private javax.swing.JPanel trackParameterSubPanel2;
    private javax.swing.JPanel trackParameterSubPanel2Fields;
    private javax.swing.JPanel trackParameterSubPanel2Labels;
    private javax.swing.JPanel trackParameterSubPanel3;
    private javax.swing.JPanel trackParameterSubPanel3Fields;
    private javax.swing.JPanel trackParameterSubPanel3Labels;
    private javax.swing.JCheckBox trk2CheckBox;
    private javax.swing.JLabel trk2Label;
    private javax.swing.JTextField trk2PhiField;
    private javax.swing.JLabel trk2PhiLabel;
    private javax.swing.JTextField trk2PsiField;
    private javax.swing.JLabel trk2PsiLabel;
    private javax.swing.JTextField trk2XField;
    private javax.swing.JLabel trk2XLabel;
    private javax.swing.JTextField trk2ZField;
    private javax.swing.JLabel trk2ZLabel;
    private javax.swing.JPanel tupleOutputPanel;
    private javax.swing.JCheckBox writeRawDataCheckBox;
    private javax.swing.JLabel writeRawDataLabel;
    private javax.swing.JPanel writeRawDataPanel;
    private javax.swing.JCheckBox writeTupleCheckBox;
    private javax.swing.JLabel writeTupleLabel;
    private javax.swing.JPanel writeTuplePanel;
    private javax.swing.JPanel xyFittersPanel;
    // End of variables declaration//GEN-END:variables
    
}
