package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import tpctracker.FitterControlFrame;
import tpctracker.FitterControlFrame2;

class PadRowLayoutPanel extends PadArrayPanel {
    TpcDesign tpcDesign;
    JButton designButton,batchButton;
    PadRowLayoutEventFrame eventDisplay;
    PadRowLayoutPanel prlpThis;
    FitterControlFrame fitterControl;
    FitterControlFrame2 fitterControl2;
    RowLayoutPanel rowLayoutPanel;
    /** Creates new PadArrayPanel */
    PadRowLayoutPanel(PadRowLayout padRowLayout,TpcDesign iTpcDesign) {
        padArray = padRowLayout;
        tpcDesign = iTpcDesign;
        prlpThis = this;
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Pad Row Layout: " + padArray.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Layout of the Row Layout:
        rowLayoutPanel = new RowLayoutPanel(padArray);
        add(rowLayoutPanel, BorderLayout.CENTER);
        // button for design pads for pad row layout
        JPanel designPanel = new JPanel();
        designPanel.setLayout(new FlowLayout(1,5,5));
        designButton = new JButton("Design Pad Row Layout");
        designPanel.add(designButton);
        designPanel.add(designButton);
        batchButton = new JButton("Batch Pad Row Layout");
        designPanel.add(batchButton);
        add(designPanel,BorderLayout.NORTH);
        addActionListeners();
        
        createAssociatedWindows();
        eventDisplay = new PadRowLayoutEventFrame(padArray);
        eventDisplay.setVisible(false);
        
        fitterControl = new FitterControlFrame(padRowLayout);
        fitterControl.setVisible(false);
        
        fitterControl2 = new FitterControlFrame2(padRowLayout);
        fitterControl2.setVisible(false);
        
    }
    
    int nWindow(){return 5;}
    JFrame window(int i) {
        if(i==1){
            return readOut;
        } else if (i==2){
            return statsWindow;
        } else if (i==3) {
            return eventDisplay;
        } else if (i==4) {
            return fitterControl;
        } else 
            return fitterControl2;
    }
    
    public void addActionListeners() {
        designButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rowLayoutPanel.readPanel();
                PadRowLayoutDesignFrame padRowLayoutDesignFrame =
                new PadRowLayoutDesignFrame(tpcDesign, padArray, prlpThis);
                padRowLayoutDesignFrame.setVisible(true);
                resetPadRowLayoutEventFrame();
            }
        });
        batchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rowLayoutPanel.readPanel();
                PadRowLayoutBatchFrame padRowLayoutBatchFrame =
                new PadRowLayoutBatchFrame(tpcDesign, padArray, prlpThis);
                padRowLayoutBatchFrame.setVisible(true);
                resetPadRowLayoutEventFrame();
            }
        });
    }
    
    void resetPadRowLayoutEventFrame() {
        eventDisplay.setVisible(false);
        eventDisplay = new PadRowLayoutEventFrame(padArray);
        eventDisplay.setVisible(false);
    }
}