/*
 * SymLayout.java
 *
 * Created on March 12, 2005, 5:33 AM
 */

package tpcsimulator;

/** Describe a Layout with rotational symmetry (squares or equilateral triangles)
 * the shapes are defined by the symmetry not the shape identifier.
 *
 * @author  karlen
 */
public class SymLayout extends TwoDimenLayout {
    
    //freeze version at some point:
    static final long serialVersionUID = -3940686246306267318L;
   
    double base; // width of the base of pad (ie. extent in x)
    double xMin,xMax,yMin,yMax; // area of plane to pave
    int symmetry; // number of symmetries (either 2=square or 3=triangle);
    double pixelSize;
    
    /** Creates a new instance of SymLayout */
    public SymLayout() {
        // define a default layout
        base = 4.0;
        xMin = -20.; xMax = 20.; yMin = -30.; yMax = 30.;
        symmetry = 2;
        pixelSize = 0.5;
    }
    
    public void getCentre(int index, Location loc) {
        int nPadHoriRow = getNX();
        int ix=(index)%nPadHoriRow;
        int iy=(index)/nPadHoriRow;
        loc.x=getX0()+ix*getDX();
        loc.y=getY0()+iy*getDY();
    }
    
    public boolean isUp(int index) {
        // determine if triangular pad is pointing up
        if (symmetry == 2)return true;
        int nPadHoriRow = getNX();
        int ix=(index)%nPadHoriRow;
        int iy=(index)/nPadHoriRow;
        return (ix+iy)%2 == 1;
    }
    
    public double getDX() {
        if (symmetry == 2) return base;
        else return base/2.; // up and down triangles alternating gives one row
    }
    
    public double getDY() {
        if (symmetry == 2) return base;
        else return Math.sqrt(3.)*base/2.;
    }
    
    public int getNX() {
        int nbase = (int) ((xMax-xMin)/base);
        if (symmetry == 2) return nbase;
        else return nbase*2-1; // forces an odd number
    }
    
    public int getNY() {
        int nbase = (int) ((yMax-yMin)/getDY());
        if (symmetry == 3 && nbase%2 == 1) nbase--; // forces an even number
        return nbase;
    }
    
    public int[] getNearbyIndicies(double x, double y, double distance) {
        System.out.println("SymLayout.getNearbyIndicies not implemented!");
        return null;
    }
    
    public void getNearestCentre(double x, double y, Location loc) {
        int index=getNearestIndex(x,y);
        getCentre(index,loc);
    }
    
    public void getNearestEdge(double x, double y, Location loc) {
        System.out.println("SymLayout.getNearestEdge not implemented!");
    }
    
    public int getNearestIndex(double x, double y) {
        double dx = getDX();
        double dy = getDY();
        int ix= (int) ((x-getX0())/dx+0.5);
        int iy= (int) ((y-getY0())/dy+0.5);
        ix=Math.max(0,Math.min(getNX()-1,ix));
        iy=Math.max(0,Math.min(getNY()-1,iy));
        int index=getNX()*iy+ix;
        if (symmetry == 2) return index;
        // check if correction to ix is necessary (for triangles):
        Location loc = new Location();
        getCentre(index,loc);
        if(isUp(index)){
            if(y>=loc.y+dy/2.-(x-loc.x)*dy/dx)ix++;
            else if(y>=loc.y+dy/2.+(x-loc.x)*dy/dx)ix--;
        } else {
            if(y<loc.y-dy/2.+(x-loc.x)*dy/dx)ix++;
            else if (y<loc.y-dy/2.-(x-loc.x)*dy/dx)ix--;
        }
        ix=Math.max(0,Math.min(getNX()-1,ix));
        index=getNX()*iy+ix;
        return index;
    }
    
    public int getNumElement() {
        return getNX()*getNY();
    }
    
    public int getNRow() {
        if (symmetry == 2) return getNX() + getNY();
        else return getNX() + 2*getNY() - 1;
    }
    
    public double getRowAngle(int iRow) {
        // return angle of row with respect to x axis
        if (symmetry ==2){
            if (iRow < getNY())return 0.;
            else return Math.PI/2.;
        } else {
            if (iRow < getNY())return 0.;
            else if (iRow < getNY()+(getNY()+getNX()-1)/2)return Math.PI/3.;
            else return -Math.PI/3.;
        }
    }
    
    public int[][] getPadGroupInRow() {
        int nX = getNX();
        int nY = getNY();
        if (symmetry == 2){
            int[][] pGIR = new int[nX+nY][];
            // horizontal rows
            for (int i=0; i < nY; i++){
                pGIR[i] = new int[nX];
                for (int j=0; j < nX; j++){
                    pGIR[i][j] = i*nX + j;
                }
            }
            // vertical rows
            for (int j=0; j < nX; j++){
                pGIR[nY+j] = new int[nY];
                for (int i=0; i < nY; i++){
                    pGIR[nY+j][i] = i*nX + j;
                }
            }
            return pGIR;
        } else {
            int[][] pGIR = new int[2*nY+nX-1][];
            // horizontal rows
            for (int i=0; i < nY; i++){
                pGIR[i] = new int[nX];
                for (int j=0; j < nX; j++){
                    pGIR[i][j] = i*nX + j;
                }
            }
            // right going rows - starting on bottom row
            int iR = nY - 1;
            for (int i=2; i < nX; i+=2){
                iR++;
                int n = Math.min(2*nY,(nX-i)*2+1);
                pGIR[iR] = new int[n];
                int iP = 0;
                pGIR[iR][iP++] = i-1;
                for (int k=0; k < Math.min(nY-1,nX-i); k++){
                    pGIR[iR][iP++] = i + k + k*nX;
                    pGIR[iR][iP++] = i + k + (k+1)*nX;
                }
                if (nY-1 < nX-i)pGIR[iR][iP++] = i + nY-1 + (nY-1)*nX;
            }
            // right going rows - rows that intersect left edge
            for (int i=0; i < nY; i+=2){
                iR++;
                int n = nY*2-1-2*i;
                pGIR[iR] = new int[n];
                int iP = 0;
                for (int k=0; k < nY-i-1; k++){
                    pGIR[iR][iP++] = i*nX + k + k*nX;
                    pGIR[iR][iP++] = i*nX + k + (k+1)*nX;
                }
                pGIR[iR][iP++] = i*nX + (nY-i-1) + (nY-i-1)*nX;
            }
            // left going rows - starting on bottom row
            for (int i=0; i < nX-2; i+=2){
                iR++;
                int n = Math.min(2*nY,(i+1)*2+1);
                pGIR[iR] = new int[n];
                int iP = 0;
                pGIR[iR][iP++] = i+1;
                for (int k=0; k < Math.min(nY-1,i+1); k++){
                    pGIR[iR][iP++] = i - k + k*nX;
                    pGIR[iR][iP++] = i - k + (k+1)*nX;
                }
                if (nY-1 < i+1)pGIR[iR][iP++] = i - (nY-2) - 1 + (nY-1)*nX;
            }
            // left going rows - rows that intersect right edge
            for (int i=0; i < nY; i+=2){
                iR++;
                int n = nY*2-1-2*i;
                pGIR[iR] = new int[n];
                int iP = 0;
                for (int k=0; k < nY-i-1; k++){
                    pGIR[iR][iP++] = (i+1)*nX - 1 - k + k*nX;
                    pGIR[iR][iP++] = (i+1)*nX - 1 - k + (k+1)*nX;
                }
                pGIR[iR][iP++] = (i+1)*nX - 1 - (nY-i-1) + (nY-i-1)*nX;
            }
            return pGIR;
        }
    }
    
    public Shape getShape() {
        return null;
    }
    
    public double getX0() {
        return xMin + base/2.;
    }
    
    public double getXMax() {
        return xMax;
    }
    
    public double getXMin() {
        return xMin;
    }
    
    public double getY0() {
        return yMin + getDY()/2.;
    }
    
    public double getYMax() {
        return yMax;
    }
    
    public double getYMin() {
        return yMin;
    }
    
    public boolean insideElement(double x, double y) {
        double xRight = xMin + getNX()*getDX();
        double yTop = yMin + getNY()*getDY();
        if (symmetry == 2) return (x>=xMin && x<xRight && y>=yMin && y<yTop);
        // for triangles - do simple checks before looking at zig-zag boundary
        if(x<xMin || x>=xRight+getDX() || y<yMin || y>=yTop)return false;
        if(x>=xMin+getDX() && x<xRight && y>=yMin && y<yTop)return true;
        int index = getNearestIndex(x,y);
        return insideElement(x,y,index);
    }
    
    public boolean insideElement(double x, double y, int index) {
        int nPadHoriRow = getNX();
        int ix=(index)%nPadHoriRow;
        int iy=(index)/nPadHoriRow;
        double dx = getDX();
        double dy = getDY();
        double xPad = getX0()+ix*dx;
        double yPad = getY0()+iy*dy;
        if (symmetry == 2){
            return (x>=xPad-dx/2.&& x<xPad+dx/2. && y>=yPad-dy/2. && y<yPad+dy/2.);
        }
        if (isUp(index)){
            return (y>=yPad-dy/2. && y<yPad+dy/2.-(x-xPad)*dy/dx && y<yPad+dy/2.+(x-xPad)*dy/dx);
        } else {
            return (y<yPad+dy/2. && y>=yPad-dy/2.+(x-xPad)*dy/dx && y>=yPad-dy/2.-(x-xPad)*dy/dx);
        }
    }
    
    void setShape(Shape shape) {
        System.out.println("SymLayout.setShape() not implemented");
    }
    
}
