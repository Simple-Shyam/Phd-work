package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import jas.hist.*;
import java.util.Observable;
import java.io.Serializable;

/** Provide functionality of an oscilliscope
 * @author Dean Karlen
 * @version 1.0
 */
class Scope extends JPanel {
    
    int nChan;
    JButton triggerButton;
    ScopeChan[] scopeChan;
    PadArray padArray;
    ArraySignalSource[] arraySignalSource;
    TwoDData twoDData;
    JASHist scopePlot,twoDPlot;
    JASHistData[] jASHistData;
    HistogramUpdate hu;
    ReadOut readOut;
    
    Scope(ReadOut iReadOut, PadArray iPadArray){
        this.readOut = iReadOut;
        padArray=iPadArray;
        
        scopePlot = new JASHist();
        twoDPlot = new JASHist();
        int flag = HistogramUpdate.DATA_UPDATE | HistogramUpdate.RANGE_UPDATE |HistogramUpdate.TITLE_UPDATE;
        hu = new HistogramUpdate(flag,true);
        
        // layout the Panel in the Read Out window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Scope"),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        
        JPanel jPanel = new JPanel(new BorderLayout());
        
        // provide a trigger button: draws the data in the event buffer
        triggerButton = new JButton("Trigger");
        triggerButton.setToolTipText("Click here to trigger the scope");
        triggerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                twoDData.updateData();
                twoDData.notifyObservers(hu);
                for (int i=0; i<nChan; i++){
                    scopeChan[i].padIndex = (int)scopeChan[i].pField.getValue();
                    arraySignalSource[i].updateData(scopeChan[i].padIndex);
                    jASHistData[i].setLegendText(arraySignalSource[i].getTitle());
                    jASHistData[i].setStyle(scopeChan[i].jASHist1DHistogramStyle);
                    arraySignalSource[i].notifyObservers(hu);
                    scopeChan[i].nField.setValue(padArray.getNElectron(scopeChan[i].padIndex));
                }
            }
        });
        
        // setup default channels for the scope
        
        JPanel channelPanel = new JPanel();
        channelPanel.add(triggerButton);
        
        int index = padArray.getPadIndex(0.,0.); // find a pad in the centre
        
        nChan=6;
        scopeChan = new ScopeChan[nChan];
        for (int i=0; i<nChan; i++){
            scopeChan[i] = new ScopeChan(i+1,index-3+i);
            channelPanel.add(scopeChan[i]);
        }
        scopeChan[0].setColor(Color.red);
        scopeChan[1].setColor(Color.green);
        scopeChan[2].setColor(Color.blue);
        scopeChan[3].setColor(Color.magenta);
        scopeChan[4].setColor(Color.orange);
        scopeChan[5].setColor(Color.gray);
        
        arraySignalSource = new ArraySignalSource[nChan];
        // define jASHistData just to see if legend update could be forced (not)
        jASHistData = new JASHistData[nChan];
        for (int i=0; i<nChan; i++){
            arraySignalSource[i] = new ArraySignalSource(readOut,padArray,scopeChan[i].padIndex,
            scopeChan[i].jASHist1DHistogramStyle);
            jASHistData[i] = scopePlot.addData(arraySignalSource[i]);
            jASHistData[i].show(true);
        }
        
        twoDData = new TwoDData(padArray,"TPC Simulation");
        twoDPlot.addData(twoDData).show(true);
        
        jPanel.add(channelPanel,BorderLayout.NORTH);
        jPanel.add(scopePlot,BorderLayout.CENTER);
        jPanel.add(twoDPlot,BorderLayout.SOUTH);
        add(jPanel);
    }
}
