package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide a panel to adjust rectangle options
 * @author Dean Karlen
 * @version 1.0
 */
class SquarePanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField lxField;
    JLabel lxUnitLabel;
    SquarePanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the lx:
        lxField = new DecimalField(0, 5, numberFormat);
        lxField.setValue(lGP.square.lx);
        lxField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.square.setLength(lxField.getValue());
            }
        });
        JLabel lxLabel = new JLabel("size: ");
        lxUnitLabel = new JLabel("mm");
        add(lxLabel);
        add(lxField);
        add(lxUnitLabel);
    }
    void readPanel(){
        lGP.square.setLength(lxField.getValue());
    }
    void setModifiable(boolean enabled) {
        lxField.setEditable(enabled);
        lxField.setVisible(enabled);
        if (!enabled) {
            lxUnitLabel.setToolTipText("set to pitch size");
            lxUnitLabel.setText("set to pitch size");
        } else {
            lxUnitLabel.setToolTipText(" ");
            lxUnitLabel.setText("mm");
        }
    }
}
