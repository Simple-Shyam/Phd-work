package tpcsimulator;
import java.util.Vector;

/** A PadMesh is a special type of PadArray. The layout is required to be
 *  of a grid type, with equal pitch in x and y. The shapes are required to
 *  be squares whose sizes are equal to the pitch. It is for this geometry
 *  that induced signals can be simulated.
 *  The pads in a PadMesh can be connected to one another in arbitrary
 *  patterns for the readout (see padGroup).
 */
public class PadMesh extends PadArray {
    
    // version frozen on Sept 10, 2002:
    static final long serialVersionUID = -4636790447337899396L;
    
    private int nPadGroup;
    private int padGroup[][];
    
    private int nx,ny; // mesh specification
    private double xp0,yp0,dpx,dpy; // mesh specification
    private double lg[][]; // value of linear gaussian function at corners of mesh elements
    public int nRow; // number of rows of pad groups
    public int padGroupInRow[][]; // list of lists of pad groups in each row
    transient boolean[] padGroupEnabled; // specifies whether signal information from this pad group is to be used
    private double yRow[]; // the average y location of each row
    double z0,dzdy,sigmaSlope; // for variable sigma along the track length
    transient int nRowUsed; // number of rows used in fit
    
    static double sqrt2pi = Math.sqrt(2.*Math.PI);
    
    PadMesh(PadDesc desc, Tpc tpc){
        super(desc, tpc);
        fittable = true;
        
        layout = meshLayout;
        square.setLength(meshLayout.getMeshPitch());
        layout.setShape(square);
        reset();
        
        setPadGroup(0,null);
        setVarSigma(0.,0.,0.);
    }
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new PadMeshPanel(this, tpcDesign);
    }
    
    public PadMeshEventFrame getEventFrame() {
        return new PadMeshEventFrame(this);
    }
    
    public int getNumElement() {
        return nPadGroup;
    }
    
    public int getNumRowUsed() {
        return nRowUsed;
    }
    
    public boolean[] selectRow(int[] dumRow) {
        nRowUsed = nRow;
        boolean[] includeRow = new boolean[nRow];
        for (int i=0; i<nRow; i++) includeRow[i] = true;
        return includeRow;
    }
    
    public int[][] getPadGroup() {
        return padGroup;
    }
    
    public int[][] getPadGroupInRow() {
        return padGroupInRow;
    }
    
    public void setPadGroup(int nPadGroup, int[][] padGroup) {
        this.nPadGroup = nPadGroup;
        this.padGroup = padGroup;
        // recalculate quantities that depend on pad mesh design
        recalc();
    }

    public void setVarSigma(double z0, double dzdy, double sigmaSlope){
        this.z0 = z0;
        this.dzdy = dzdy;
        this.sigmaSlope = sigmaSlope;
    }
    
    public double[] getVarSigma(){
        double[] val = new double[3];
        val[0] = z0;
        val[1] = dzdy;
        val[2] = sigmaSlope;
        return val;
    }
    
    // only record those electrons that are on top of pads for a pad mesh
    // this is particularly important for pad row layouts
    // this is not applied for grids of circles for example
    boolean recordElectron(double x, double y, int hitPad) {
        return layout.insideElement(x,y,hitPad);
    }
    
    public int getNRow() { return nRow; }
    
    public int getNY() { return nRow; }
    
    public double[] getYRow() {return yRow;}
    
    void recalc() {
        // when the pad mesh design changes, a number of quantities for fitting
        // need to be recalculated...
        nx = layout.getNX();
        ny = layout.getNY();
        lg = new double[nx+1][];
        for (int i=0; i<=nx; i++) {
            lg[i] = new double[ny+1];
        }
        xp0 = layout.getX0();
        yp0 = layout.getY0();
        dpx = layout.getDX();
        dpy = layout.getDY();
        
        // assign the pad groups into rows. Use temporary vectors to keep track
        Vector yLow = new Vector(10,10);
        Vector yHigh = new Vector(10,10);
        Vector vPadGroupInRow = new Vector(10,10);
        
        padGroupEnabled = new boolean[nPadGroup];
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) padGroupEnabled[iPadGroup] = true;
        
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            int minY = ny+10;
            int maxY = -10;
            for (int i = 0; i < nPadInGroup; i++) {
                int iPad = padGroup[iPadGroup][i];
                int iy=iPad/nx;
                minY = Math.min(minY,iy);
                maxY = Math.max(maxY,iy);
            }
            int aveY = (minY+maxY)/2;
            // place this pad Group in an existing row or make a new row
            int iRow = -1; boolean finished = false;
            while ((iRow < vPadGroupInRow.size() - 1) && !finished) {
                iRow++;
                int lowY = ((Integer) yLow.elementAt(iRow)).intValue();
                int highY = ((Integer) yHigh.elementAt(iRow)).intValue();
                if (aveY < lowY) {
                    // insert a new row here
                    yLow.insertElementAt(new Integer(minY),iRow);
                    yHigh.insertElementAt(new Integer(maxY),iRow);
                    Vector list = new Vector(10,5);
                    list.addElement(new Integer(iPadGroup));
                    vPadGroupInRow.insertElementAt(list,iRow);
                    finished = true;
                } else if (aveY < highY) {
                    // add this padGroup to the existing row
                    if (minY < lowY) yLow.setElementAt(new Integer(minY),iRow);
                    if (maxY > highY) yHigh.setElementAt(new Integer(maxY),iRow);
                    Vector list = (Vector) vPadGroupInRow.elementAt(iRow);
                    list.addElement(new Integer(iPadGroup));
                    vPadGroupInRow.setElementAt(list,iRow);
                    finished = true;
                }
            }
            if (!finished) {
                // make a new row at the end of the row list
                yLow.addElement(new Integer(minY));
                yHigh.addElement(new Integer(maxY));
                Vector list = new Vector(10,5);
                list.addElement(new Integer(iPadGroup));
                vPadGroupInRow.addElement(list);
            }
        }
        // now put the pad-group-in-row information into an array for easier access
        nRow = vPadGroupInRow.size();
        if (nRow > 0) {
            padGroupInRow = new int[nRow][];
            yRow = new double[nRow];
            for (int iRow = 0; iRow < nRow; iRow++) {
                int lowY = ((Integer) yLow.elementAt(iRow)).intValue();
                int highY = ((Integer) yHigh.elementAt(iRow)).intValue();
                yRow[iRow] = 0.5*(lowY + highY)*dpy;
                Vector list = (Vector) vPadGroupInRow.elementAt(iRow);
                int nPadGroupInRow = list.size();
                padGroupInRow[iRow] = new int[nPadGroupInRow];
                for (int iPGIR = 0; iPGIR < nPadGroupInRow; iPGIR++) {
                    padGroupInRow[iRow][iPGIR] = ((Integer) list.elementAt(iPGIR)).intValue();
                }
            }
        }
    }
    
    public boolean padGroupIsEnabled(int iPadGroup) { 
        // for backward compatibility of existing tpc objects: return true if padGroupEnabled doesn't exist
        return padGroupEnabled == null || padGroupEnabled[iPadGroup]; 
    }
    public void padGroupSetEnabled(int iPadGroup, boolean enabled) { padGroupEnabled[iPadGroup] = enabled; }
    public void padGroupSetEnabled(boolean enabled) { 
        // for backward compatibility of existing tpc objects: create this array if it doesn't already exist
        if (padGroupEnabled == null) padGroupEnabled = new boolean[nPadGroup];
        for (int iPG = 0; iPG < nPadGroup; iPG++) padGroupEnabled[iPG] = enabled; 
    }
    
    /** calculate the values of the linear Gaussian pdf at the corners of the mesh */
    void calcLinearGaussian(double[] param) {
        for (int i=0; i <= nx; i++) {
            double xp = xp0 - dpx/2. + i*dpx;
            for (int j=0; j <= ny; j++){
                double yp = yp0 - dpy/2. + j*dpy;
                lg[i][j] = linearGaussian(xp,yp,param);
            }
        }
    }
    
    double linearGaussian(double x, double y, double[] param) {
        double sigma = param[2];
        if (sigmaSlope != 0.){
            double sig2 = param[2]*param[2]+sigmaSlope*dzdy*y;
            if (sig2 > 0.) sigma = Math.sqrt(sig2);
            else sigma = -1.;
        }
        
        if (sigma <= 0.) return 1.E-80;
        double arg = ((x-param[0])*Math.cos(param[1]) + y*Math.sin(param[1]))/sigma;
        if (Math.abs(arg) < 20.) {
            return Math.exp(-0.5*arg*arg)/sqrt2pi/sigma;
        } else {
            return Math.exp(-0.5*20.*20.)/sqrt2pi/sigma;
        }
    }
    
    public double calcLogLikelihood(double[] param, double totGain, double pNoise) {
        int fR[] = new int[nRow];
        for (int iRow = 0; iRow < nRow; iRow++) {
            fR[iRow] = iRow;
        }
        return calcLogLikelihood(param,totGain,pNoise,fR);
    }
    
    public double calcLogLikelihood(double[] param, double totGain, double pNoise, int[] fitRows) {
        
        // calculate the log likelihood of the observed fractions
        
        double lnlike =0.;
        nRowUsed = fitRows.length;
        
        // for each row, calculate the relative charge fractions in each pad
        // and compare to observed signals
        calcLinearGaussian(param);
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            
            // Calculate the charge fractions in the row
            double calcCharge[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] = 0.;
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                // for backward compatibility, do not assume that padGroupEnabled exists
                if (padGroupEnabled == null || padGroupEnabled[iPadGroup]) {
                    int nPadInGroup = padGroup[iPadGroup].length;
                    for (int i = 0; i < nPadInGroup; i++) {
                        int iPad = padGroup[iPadGroup][i];
                        int ix=iPad%nx;
                        int iy=iPad/nx;
                        calcCharge[iPadGroupInRow] += ( lg[ix][iy] + lg[ix+1][iy]
                        + lg[ix][iy+1] + lg[ix+1][iy+1] );
                    }
                }
            }
            double totCharge = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                totCharge += calcCharge[iPadGroupInRow];
            }
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] /= totCharge;
            }
            
            // get the estimated number of primary electrons sampled by each pad
            double rElectron[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                int nElectron = getNElectron(iPadGroup);
                rElectron[iPadGroupInRow] = nElectron / totGain;
            }
            
            // work out the contribution to the log likelihood
            double lnl = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                lnl += rElectron[iPadGroupInRow]
                * Math.log((calcCharge[iPadGroupInRow] + pNoise) /
                (1.+nPadGroupInRow*pNoise));
            }
            
            lnlike += lnl;
            
        }
        return lnlike;
    }
    
    public double calcLogLikelihood2(double[] param, double totGain, double pNoise, int[] fitRows) {
        // dummy for now
        return 0.;
    }

    public double[] getExpectedElectronInPadGroup(double[] param, int[] fitRows) {
        
        // for systematic studies, work out the expected charge for each PadGroup:
        // copied code from calcLogLikelihood
        
        double[] expectedElectronInPadGroup = new double[nPadGroup];
        for (int i = 0; i < nPadGroup; i++) expectedElectronInPadGroup[i]=0;
        
        // for each row, calculate the relative charge fractions in each pad
        // and compare to observed signals
        calcLinearGaussian(param);
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            
            // Calculate the charge fractions in the row
            double calcCharge[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] = 0.;
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                // for backward compatibility, do not assume that padGroupEnabled exists
                if (padGroupEnabled == null || padGroupEnabled[iPadGroup]) {
                    int nPadInGroup = padGroup[iPadGroup].length;
                    for (int i = 0; i < nPadInGroup; i++) {
                        int iPad = padGroup[iPadGroup][i];
                        int ix=iPad%nx;
                        int iy=iPad/nx;
                        calcCharge[iPadGroupInRow] += ( lg[ix][iy] + lg[ix+1][iy]
                        + lg[ix][iy+1] + lg[ix+1][iy+1] );
                    }
                }
            }
            double totCharge = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                totCharge += calcCharge[iPadGroupInRow];
            }
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] /= totCharge;
            }
            
            // sum up all electrons in a row:
            int nElectronInRow = 0;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                nElectronInRow += getNElectron(iPadGroup);
            }
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                expectedElectronInPadGroup[iPadGroup] = nElectronInRow*calcCharge[iPadGroupInRow];
            }
            
        }
        return expectedElectronInPadGroup;
    }
    
    public double[][] getYZData() {
        // return an array of yz points for all rows
        
        double[][] yzPoints = new double[nRow][2];
        
        for (int iRow = 0; iRow < nRow; iRow++) {
            int nPadGroupInRow = padGroupInRow[iRow].length;
            double time = -1.;
            int iPG = 0;
            while (time < 0. && iPG < nPadGroupInRow) {
                int iPadG = padGroupInRow[iRow][iPG];
                if (getNElectron(iPadG) > 0) {
                    time = getTime(iPadG);
                }
                iPG++;
            }
            yzPoints[iRow][0] = yRow[iRow];
            yzPoints[iRow][1] = time;
        }
        return yzPoints;
    }

    
    public int getFirstElement() {
        return 0;
    }
    
    public int getNElectron(int iPadGroup) {
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return 0;
        int nPadInGroup = padGroup[iPadGroup].length;
        int sum = 0;
        for (int i = 0; i < nPadInGroup; i++) {
            int iPad = padGroup[iPadGroup][i];
            sum += pad[iPad].getNElectron();
        }
        return sum;
    }
    
    public double getTime(int iPadGroup) {
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return -1.;
        int nPadInGroup = padGroup[iPadGroup].length;
        double weightedSum = 0.;
        double sum = 0.;
        for (int i = 0; i < nPadInGroup; i++) {
            int iPad = padGroup[iPadGroup][i];
            sum += pad[iPad].getNElectron();
            weightedSum += pad[iPad].getNElectron()*pad[iPad].getTime();
        }
        if (sum <= 0.) return -1.;
        return weightedSum/sum;
    }
    
    public void addNElectron(int iPadGroup, int nElectron) {
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return;
        int nPadInGroup = padGroup[iPadGroup].length;
        if (nPadInGroup > 0) {
            int iPad = padGroup[iPadGroup][0];
            pad[iPad].addNElectron(nElectron);
        }
    }
    
    public void addNElectron(int iPadGroup, int nElectron, double time) {
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return;
        int nPadInGroup = padGroup[iPadGroup].length;
        if (nPadInGroup > 0) {
            int iPad = padGroup[iPadGroup][0];
            pad[iPad].addNElectron(nElectron,time);
        }
    }
    
    public void setData(int iPadGroup, double[] data) {
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return;
        int nPadInGroup = padGroup[iPadGroup].length;
        for (int iPadInGroup = 0; iPadInGroup < nPadInGroup; iPadInGroup++) {
            int iPad = padGroup[iPadGroup][iPadInGroup];
            pad[iPad].setData(data);
        }
    }
    
    public int getPadIndex(double x, double y) {
        // find padGroup that contains the pad
        int iPad=layout.getNearestIndex(x,y);
        int iPadGroup = -1;
        boolean found = false;
        while (iPadGroup < nPadGroup-1 && !found) {
            iPadGroup++;
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int i = 0; i < nPadInGroup; i++) {
                int jPad = padGroup[iPadGroup][i];
                found = found || (jPad == iPad);
            }
        }
        if (found) return iPadGroup;
        return iPad;
    }
    
    public boolean getPadSignal(int iPadGroup, Signal signal) {
        // calculate the signal on a padGroup
        // the signal is formed from a combination of direct charge pulses and
        // induced pulses. Filtering (low and high pass) are applied
        // The amplitude units are scaled to values in mV.
        // Variations in preamp gain are applied
        
        signal.clear();
        if (iPadGroup < 0 || iPadGroup >= nPadGroup) return false;
        
        // assume the induced pulses are significant only for pads horizontally
        // as far away as the transfer gap. This assumes the induction gap is
        // directly above this padMesh!
        double inducedExtent = 0.1;
        double driftTime = 1.;
        if (partAbove !=null) {
            inducedExtent = partAbove.thickness;
            driftTime = Math.max(1.,partAbove.thickness/partAbove.vDrift*1000.);
        }
        double padArea = square.lx*square.lx;
        
        int nPadInGroup = padGroup[iPadGroup].length;
        for (int i = 0; i < nPadInGroup; i++) {
            int iPad = padGroup[iPadGroup][i];
            // direct pulses:
            Cluster cluster = pad[iPad].firstCluster;
            while (cluster != null){
                signal.addDirect(cluster, driftTime);
                cluster = cluster.nextCluster;
            }
            // induced pulses:
            if (signal.preAmp.induction) {
                Location loc = new Location();
                layout.getCentre(iPad,loc);
                int[] nearbyPads = layout.getNearbyIndicies(loc.x,loc.y,inducedExtent);
                int nPadsNearby = nearbyPads.length;
                for (int j = 0; j < nPadsNearby; j++) {
                    int jPad = nearbyPads[j];
                    cluster = pad[jPad].firstCluster;
                    while (cluster != null){
                        signal.addInduced(cluster, driftTime, padArea, inducedExtent, loc);
                        cluster = cluster.nextCluster;
                    }
                }
            }
        }
        signal.filter();
        signal.applyGain(iPadGroup);
        return true;
    }
    
    public double getBValue(double[] param, int iRow) {
        // not enabled: works only in padrowlayout
        return -9999.;
    }
    
    public double getTransverseTrackLength(double[] param, int iRow) {
        // not enabled: works only in padrowlayout
        return -9999.;
    }
    
}
