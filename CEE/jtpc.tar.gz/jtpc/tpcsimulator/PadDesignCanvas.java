package tpcsimulator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.text.DecimalFormat;
import javax.swing.*;

class PadDesignCanvas extends JPanel implements Scrollable, MouseListener, MouseMotionListener{
    
    static final Color Colors[] = {Color.red,
    Color.yellow, Color.green, Color.cyan, Color.blue, Color.pink, Color.magenta,
    Color.lightGray, Color.gray, Color.darkGray};
    
    Image offImage;
    Graphics offGraphics;
    
    PadMesh padMesh;
    PadDesignFrame padDesignFrame;
    int nx,ny;
    int width,height;
    int[] groupForPad;
    int largestPadGroupNumber;
    int startSelectionPadGroup,endSelectionPadGroup;
    int pixelSize;

    Location loc;
    DecimalFormat stdFormat;
    
    PadDesignCanvas(PadMesh padMesh, PadDesignFrame padDesignFrame){
        this.padMesh = padMesh;        
        this.padDesignFrame = padDesignFrame;

        loc = new Location();
        stdFormat = new DecimalFormat("##0.0####");
        setBackground(Color.black);
        nx = padMesh.meshLayout.nx;
        ny = padMesh.meshLayout.ny;
        pixelSize = Math.min(20,Math.max(5,500/ny));
        width = nx*pixelSize + 1;
        height = ny*pixelSize + 1;
        setBounds(0,0,width,height);
        
        addMouseMotionListener(this);
        addMouseListener(this);
        
        // copy the contents of PadGroup into groupForPad
        groupForPad = new int[padMesh.nPad];
        for (int i = 0; i < padMesh.nPad; i++) {
            groupForPad[i] = -888;
        }
        int nPadGroup = padMesh.getNumElement();
        int[][] padGroup = padMesh.getPadGroup();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int iPad = 0; iPad < nPadInGroup; iPad++) {
                int padNumber = padGroup[iPadGroup][iPad];
                groupForPad[padNumber] = iPadGroup;
            }
        }
        largestPadGroupNumber = nPadGroup - 1;
        startSelectionPadGroup = -1;
        endSelectionPadGroup = -1;
    }
    
    PadDesignCanvas() {
    }

    public void setPreferredSize(Dimension dummy) {
        super.setPreferredSize(new Dimension(width,height));
    }
    
    void saveGroups() {
        // copy the contents of groupForPad into padGroup
        
        // count the number of pads in each group
        int[] count = new int[largestPadGroupNumber+1];
        int[] point = new int[largestPadGroupNumber+1];
        for (int i = 0; i <= largestPadGroupNumber; i++) count[i]=0;
        for (int i = 0; i < padMesh.nPad; i++) {
            if(groupForPad[i] >=0) count[groupForPad[i]]++;
        }
        int nPG = 0;
        for (int i=0; i <= largestPadGroupNumber; i++) {
            if (count[i] > 0) nPG++;
        }
        
        // setup the padGroup array
        int[][] pG = new int[nPG][];
        int j = -1;
        for (int i=0; i <= largestPadGroupNumber; i++ ) {
            if (count[i] > 0) {
                j++;
                point[i] = j;
                pG[j] = new int[count[i]];
            }
        }
        
        // fill the padGroup array
        for (int i = 0; i <= largestPadGroupNumber; i++) count[i]=0;
        for (int i = 0; i < padMesh.nPad; i++) {
            int group = groupForPad[i];
            if(group >=0) {
                pG[point[group]][count[group]] = i;
                count[group]++;
            }
        }
        padMesh.setPadGroup(nPG,pG);
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        update(g);
    }
    
    public void update(Graphics g){
        
        if (offGraphics == null) {
            offImage = createImage(width,height);
            offGraphics = offImage.getGraphics();
        }
        
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0,0,width,height);
        
        // draw in the arranged padMesh
        int nColors = Colors.length;
        for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
            int iGroup = groupForPad[iPad];
            if (iGroup < 0) {
                offGraphics.setColor(Color.white);
            } else {
                offGraphics.setColor(Colors[iGroup%nColors]);
            }
            int ix = getX(iPad);
            int iy = getY(iPad);
            offGraphics.fillRect(ix,iy,pixelSize-1,pixelSize-1);
        }
        
        // Draws the buffered image to the screen.
        g.drawImage(offImage, 0, 0, this);
    }
    
    void select(MouseEvent e, boolean reset) {
        int iGroup = padDesignFrame.getAssignGroup();
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < padMesh.nPad) {
            if (groupForPad[iPad] == iGroup && reset) {
                groupForPad[iPad] = -999;
            } else {
                groupForPad[iPad] = iGroup;
                largestPadGroupNumber = Math.max(largestPadGroupNumber,iGroup);
            }
        }
        updateLocationLabel(iPad, groupForPad[iPad]);
        repaint();
    }    
    
    public void mouseClicked(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            select(e,true);
        } else if ((e.getModifiers() & InputEvent.BUTTON2_MASK)
        == InputEvent.BUTTON2_MASK) {
            int iPadGroup = getPadGroup(e);
            if (iPadGroup >= 0) {
                padDesignFrame.setGroupNumber(iPadGroup);
            }
        } else if ((e.getModifiers() & InputEvent.BUTTON3_MASK)
        == InputEvent.BUTTON3_MASK) {
            int iPadGroup = getPadGroup(e);
            if (iPadGroup >= 0) {
                padDesignFrame.setDuplicateGroupNumber(iPadGroup);
            }
        }
        updateSelectionLabel(-1,-1);
    }
    
    public void mousePressed(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            startSelectionPadGroup = getPadGroup(e);
            endSelectionPadGroup = -1;
            updateSelectionLabel(-1,-1);
        } else {
            select(e,false);
        }
    }
    
    public void mouseDragged(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            int iPad = getPadGroup(e);
            updateSelectionLabel(startSelectionPadGroup,iPad);
        } else {
            select(e,false);
        }
    }
    
    public void mouseReleased(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            endSelectionPadGroup = getPadGroup(e);
            updateSelectionLabel(startSelectionPadGroup,endSelectionPadGroup);
        } else {
            select(e,false);
        }
    }
    
    public void mouseExited(MouseEvent e) {
        updateLocationLabel(-1,-1);
    }
    
    public void mouseEntered(MouseEvent e) {
    }
    
    public void mouseMoved(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < padMesh.nPad) {
            updateLocationLabel(iPad, groupForPad[iPad]);
        }
    }
    
    void updateLocationLabel(int iPad, int iGroup) {
        if (iPad >= 0 && iPad < padMesh.nPad) {
            padMesh.layout.getCentre(iPad,loc);
            if (iGroup < 0) {
                padDesignFrame.setDataLabel("Pad # " + iPad 
                + " centred at (" + stdFormat.format(loc.x) + "," + stdFormat.format(loc.y) + ")"
                + " is unassigned");
            } else {
                padDesignFrame.setDataLabel("Pad # " + iPad 
                + " centred at (" + stdFormat.format(loc.x) + "," + stdFormat.format(loc.y) + ")"
                + " is in group # " + iGroup);
            }
        } else {
            padDesignFrame.setDataLabel(" ");
        }
    }
    
    void updateSelectionLabel(int padGroup1, int padGroup2) {
        if (padGroup1 >= 0 && padGroup2 >=0) {
            padDesignFrame.setSelectionLabel("Pad groups selection: "
            + padGroup1 + " through " + padGroup2);
            padDesignFrame.setSelectionDuplicationEnabled(true);
        } else {
            padDesignFrame.setSelectionLabel(" ");
            padDesignFrame.setSelectionDuplicationEnabled(false);
        }
    }
    
    int getPadGroup(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < padMesh.nPad) {
            return groupForPad[iPad];
        }
        return -1;
    }
    
    int getIPad(MouseEvent e) {
        return getIPad(e.getX(),e.getY());
    }
    
    int getIPad(int ix, int iy) {
        return (ny-1)*nx - iy/pixelSize*nx + (ix-1)/pixelSize;
    }
    
    int getX(int iPad) {
        return 1 + (iPad%nx)*pixelSize;
    }
    
    int getY(int iPad) {
        return 1 + (ny - 1 - iPad/nx)*pixelSize;
    }
    
    boolean duplicateGroup(int dupGroup, int dx, int dy) {
        boolean allOK = false;
        if (dupGroup >= 0) {
            allOK = true;
            int maxPadInGroup = 10000;
            int nPadInGroup = 0;
            int[] padList = new int[maxPadInGroup];
            for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
                if (groupForPad[iPad] == dupGroup) {
                    nPadInGroup = Math.min(maxPadInGroup,nPadInGroup+1);
                    int ix = getX(iPad);
                    int iy = getY(iPad);
                    if (ix + dx*pixelSize < 1 || ix + dx*pixelSize > (nx-1)*pixelSize + 1 ||
                    iy - dy*pixelSize > (ny-1)*pixelSize + 1 || iy - dy*pixelSize < 1) allOK = false;
                    padList[nPadInGroup-1] = iPad;
                }
            }
            if (allOK && nPadInGroup > 0) {
                largestPadGroupNumber++;
                for (int i = 0; i < nPadInGroup; i++) {
                    int iPad = padList[i];
                    int ix = getX(iPad);
                    int iy = getY(iPad);
                    int jPad = getIPad(ix+dx*pixelSize,iy-dy*pixelSize);
                    groupForPad[jPad] = largestPadGroupNumber;
                }
                repaint();
            }
        }
        return allOK;
    }
    
    void duplicateSelectionGroup(int dx, int dy) {
        if (startSelectionPadGroup >= 0 && endSelectionPadGroup >= 0) {
            int nextStartSelectionPadGroup = largestPadGroupNumber+1;
            for (int iPG = startSelectionPadGroup; iPG <= endSelectionPadGroup; iPG++) {
                duplicateGroup(iPG,dx,dy);
            }
            startSelectionPadGroup = nextStartSelectionPadGroup;
            endSelectionPadGroup = largestPadGroupNumber;
            updateSelectionLabel(startSelectionPadGroup,endSelectionPadGroup);
        }
    }
    
    void clearAll() {
        for (int i = 0; i < padMesh.nPad; i++) {
            groupForPad[i] = -888;
        }
        largestPadGroupNumber = 0;
        repaint();
    }
    
    public boolean getScrollableTracksViewportHeight() {
        return (height < 500);
    }
    
    public int getScrollableUnitIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return pixelSize;
    }
    
    public int getScrollableBlockIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return pixelSize*10;
    }
    
    public java.awt.Dimension getPreferredScrollableViewportSize() {
        return new Dimension(Math.min(500,width),Math.min(500,height));
    }
    
    public boolean getScrollableTracksViewportWidth() {
        return (width < 500);
    }
    
}