package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import jas.hist.*;
import java.util.Observable;

/** Hold data for 2D scatter plots
 * @author Dean Karlen
 * @version 1.0
 */
class TwoDData extends Observable implements Rebinnable2DHistogramData
{
    private String name;
    private PadArray padArray;
    
    TwoDData(PadArray padArray)
    {
        this.padArray = padArray;
        this.name = padArray.name;
    }
    TwoDData(PadArray padArray, String name)
    {
        this.padArray = padArray;
        this.name = name;
    }
    public double[][][] rebin(int xBins,double xMin,double xMax,
    int yBins,double yMin,double yMax,
    boolean wantErrors,boolean hurry,
    boolean overFlow)
    {
        double[][][] result = new double[3][xBins][yBins];
        for (int i=0; i<3 ; i++){
            for (int j=0; j<xBins; j++){
                for (int k=0; k<yBins; k++){
                    result[i][j][k] = 0.;
                }
            }
        }
        
        for (int i=1; i<=padArray.nPad; i++){
            Cluster cluster = padArray.pad[i].firstCluster;
            while (cluster != null){
                double x = cluster.getX();
                double y = cluster.getY();
                int xBin = (int)((x-xMin)*xBins/(xMax-xMin));
                xBin = Math.max(0,Math.min(xBins-1,xBin));
                int yBin = (int)((y-yMin)*yBins/(yMax-yMin));
                yBin = Math.max(0,Math.min(yBins-1,yBin));
                result[0][xBin][yBin] += cluster.n;
                cluster = cluster.nextCluster;
            }
        }
        
        return result;
    }
    void updateData()
    {
        setChanged(); // notifyObservers needs this
    }
    
    public String[] getXAxisLabels()   { return null; }
    public String[] getYAxisLabels()   { return null; }
    public int getXAxisType() { return DOUBLE; }
    public int getYAxisType() { return DOUBLE; }
    public int getXBins() { return padArray.layout.getNX(); }
    public int getYBins() { return padArray.layout.getNY(); }
    public double getXMin() { return padArray.layout.getXMin(); }
    public double getYMin() { return padArray.layout.getYMin(); }
    public double getXMax() { return padArray.layout.getXMax(); }
    public double getYMax() { return padArray.layout.getYMax(); }
    public boolean isRebinnable() {   return true; }
    public String getTitle() { return name;   }
    
}
