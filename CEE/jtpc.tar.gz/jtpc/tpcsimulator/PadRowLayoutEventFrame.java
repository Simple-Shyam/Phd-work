/*
 * PadRowLayoutEventFrame.java
 *
 * Created on July 7, 2002, 8:45 PM
 */

package tpcsimulator;

import tpctracker.*;
import tpcanalyzer.*;

/**
 *
 * @author  karlen
 * @version
 */
public class PadRowLayoutEventFrame extends PadMeshEventFrame {
    
    PadRowLayout padRowLayout;
    PadRowLayoutDataFrame padRowLayoutDataFrame;
    PadArray padArray;
    
    /** Creates new form PadMeshEventFrame */
    public PadRowLayoutEventFrame(PadArray padArray) {
        padRowLayout = (PadRowLayout) padArray;
        name = "Event Display for " + padArray.name;
        setTitle(name);
        initComponents();
        rightSidePanel.add(javax.swing.Box.createVerticalGlue());
        rightSidePanel.add(javax.swing.Box.createVerticalGlue());
        rightSidePanel.add(javax.swing.Box.createVerticalGlue());
        rightSidePanel.add(javax.swing.Box.createVerticalGlue());
        rightSidePanel.add(javax.swing.Box.createVerticalGlue());
        pack();
        this.padArray = padArray;
        newDataFrame();
    }
    
    public void newDataFrame() {
        boolean resize = false;
        java.awt.Dimension size = null;
        if (padRowLayoutDataFrame != null) {
            resize = true;
            size = padRowLayoutDataFrame.getJasPanel().getSize();
        }
            
        padRowLayoutDataFrame = new PadRowLayoutDataFrame(this,padArray);
        padRowLayoutDataFrame.setVisible(showPulseData());
        
        if (resize) padRowLayoutDataFrame.setJasPanelSize(size);
    }
    
    public void setDataLabel(String string) {
        dataLabel.setText(string);
    }
    
    public void setSelectionLabel(String string) {
        selectionLabel.setText(string);
    }
    
    void setLegend(int maxElectron) {
        highValueLabel.setText("" + maxElectron);
        if (logScale()) {
            int half = (int) Math.sqrt(maxElectron*5000.);
            midValueLabel.setText("" + half);
            lowValueLabel.setText("5000");
        } else {
            int half = maxElectron/2;
            midValueLabel.setText("" + half);
            lowValueLabel.setText("0");
        }
        if (greyScale()) {
            legendPanel.setBorder(new javax.swing.border.TitledBorder("Grey scale"));
        } else {
            legendPanel.setBorder(new javax.swing.border.TitledBorder("Color scale"));
        }
    }
    
    void setLegend(double minT, double maxT) {
        highValueLabel.setText(myFormat(maxT));
        if (logScale()) {
            double half = minT + Math.sqrt(Math.abs(maxT-minT));
            midValueLabel.setText(myFormat(half));
            lowValueLabel.setText(myFormat(minT));
        } else {
            double half = (minT + maxT)/2.;
            midValueLabel.setText(myFormat(half));
            lowValueLabel.setText(myFormat(minT));
        }
        if (greyScale()) {
            legendPanel.setBorder(new javax.swing.border.TitledBorder("Grey scale"));
        } else {
            legendPanel.setBorder(new javax.swing.border.TitledBorder("Color scale"));
        }
    }
    
    String myFormat(double x) {
        int ix = (int) (x*10.);
        double sx = ix/10.;
        return "" + sx;
    }
    
    boolean showDemultiplexed() {
        return showDemultiplexedCheckBox.isSelected();
    }
    
    public void setDemuxEnabled(boolean enabled) {
        showDemultiplexedCheckBox.setEnabled(enabled);
    }
    
    boolean showPulseData() {
        return showPulseDataCheckBox.isSelected();
    }
    
    void showPulseData(boolean checked) {
        showPulseDataCheckBox.setSelected(checked);
    }   
    
    public void setPulseDataEnabled(boolean enabled) {
        showPulseDataCheckBox.setEnabled(enabled);
    }
    
    // the following methods have to be repeated here: Forte IDE does not
    // handle extended GUI classes very well... The checkboxes that are part of
    // this class need to be accessed.
    
    boolean logScale() {
        return showLogScaleCheckBox.isSelected();
    }
    
    boolean greyScale() {
        return showGreyScaleCheckBox.isSelected();
    }
    
    boolean showTrackFit() {
        return showTrackFitCheckBox.isSelected();
    }
    
    boolean showTimeData() {
        return showTimeDataCheckBox.isSelected();
    }
    
    public void setFitterControlFrame(FitterControlFrame fitterControlFrame){
        this.fitterControlFrame = fitterControlFrame;
        showTrackFitCheckBox.setEnabled(true);
    }
    
    boolean showSeedTrack() {
        return showSeedTrackCheckBox.isSelected();
    }
    
    public void setSeedTrackEnabled(boolean enabled) {
        showSeedTrackCheckBox.setEnabled(enabled);
    }
    
    public void setTpcAnalyzer(TpcAnalyzer tpcAnalyzer){
        this.tpcAnalyzer = tpcAnalyzer;
    }
    
    public void drawEvent(){
        padRowLayoutEventCanvas.repaint();
        legendCanvas.repaint();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        padRowLayoutEventScrollPane = new javax.swing.JScrollPane();
        padRowLayoutEventCanvas = new PadRowLayoutEventCanvas(padRowLayout,this);
        rightSidePanel = new javax.swing.JPanel();
        commandPanel = new javax.swing.JPanel();
        drawButton = new javax.swing.JButton();
        showDemultiplexedCheckBox = new javax.swing.JCheckBox();
        showLogScaleCheckBox = new javax.swing.JCheckBox();
        showSeedTrackCheckBox = new javax.swing.JCheckBox();
        showTrackFitCheckBox = new javax.swing.JCheckBox();
        showPulseDataCheckBox = new javax.swing.JCheckBox();
        showTimeDataCheckBox = new javax.swing.JCheckBox();
        showGreyScaleCheckBox = new javax.swing.JCheckBox();
        legendPanel = new javax.swing.JPanel();
        legendCanvas = new LegendCanvas((PadMesh) padRowLayout, (PadMeshEventFrame) this, (PadMeshEventCanvas) padRowLayoutEventCanvas);
        legendValuePanel = new javax.swing.JPanel();
        highValueLabel = new javax.swing.JLabel();
        midValueLabel = new javax.swing.JLabel();
        lowValueLabel = new javax.swing.JLabel();
        dataPanel = new javax.swing.JPanel();
        dataLabel = new javax.swing.JLabel();
        selectionLabel = new javax.swing.JLabel();

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        padRowLayoutEventCanvas.setPreferredSize(new java.awt.Dimension(600, 600));
        padRowLayoutEventScrollPane.setViewportView(padRowLayoutEventCanvas);

        getContentPane().add(padRowLayoutEventScrollPane, java.awt.BorderLayout.CENTER);

        rightSidePanel.setLayout(new javax.swing.BoxLayout(rightSidePanel, javax.swing.BoxLayout.Y_AXIS));

        rightSidePanel.setMaximumSize(new java.awt.Dimension(118, 358));
        commandPanel.setLayout(new java.awt.GridLayout(0, 1, 10, 10));

        commandPanel.setBorder(new javax.swing.border.TitledBorder("Options"));
        drawButton.setText("Draw Event");
        drawButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drawButtonActionPerformed(evt);
            }
        });

        commandPanel.add(drawButton);

        showDemultiplexedCheckBox.setText("demultiplex data");
        showDemultiplexedCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showDemultiplexedCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showDemultiplexedCheckBox);

        showLogScaleCheckBox.setText("use log scale");
        showLogScaleCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showLogScaleCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showLogScaleCheckBox);

        showSeedTrackCheckBox.setText("show seed track");
        showSeedTrackCheckBox.setEnabled(false);
        showSeedTrackCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showSeedTrackCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showSeedTrackCheckBox);

        showTrackFitCheckBox.setText("show Track Fit");
        showTrackFitCheckBox.setEnabled(false);
        showTrackFitCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showTrackFitCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showTrackFitCheckBox);

        showPulseDataCheckBox.setText("show pulse data");
        showPulseDataCheckBox.setEnabled(false);
        showPulseDataCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPulseDataCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showPulseDataCheckBox);

        showTimeDataCheckBox.setText("show time data");
        showTimeDataCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showTimeDataCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showTimeDataCheckBox);

        showGreyScaleCheckBox.setText("use grey scale");
        showGreyScaleCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showGreyScaleCheckBoxActionPerformed(evt);
            }
        });

        commandPanel.add(showGreyScaleCheckBox);

        rightSidePanel.add(commandPanel);

        legendPanel.setLayout(new java.awt.GridLayout(1, 2));

        legendPanel.setBorder(new javax.swing.border.TitledBorder("Color scale"));
        legendPanel.setMaximumSize(new java.awt.Dimension(110, 230));
        legendPanel.setMinimumSize(new java.awt.Dimension(110, 230));
        legendPanel.setPreferredSize(new java.awt.Dimension(110, 230));
        legendPanel.add(legendCanvas);

        legendValuePanel.setLayout(new java.awt.BorderLayout());

        legendValuePanel.setMaximumSize(new java.awt.Dimension(50, 200));
        legendValuePanel.setMinimumSize(new java.awt.Dimension(50, 200));
        legendValuePanel.setPreferredSize(new java.awt.Dimension(50, 200));
        highValueLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        highValueLabel.setText("0");
        highValueLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        legendValuePanel.add(highValueLabel, java.awt.BorderLayout.NORTH);

        midValueLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        midValueLabel.setText("0");
        legendValuePanel.add(midValueLabel, java.awt.BorderLayout.CENTER);

        lowValueLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lowValueLabel.setText("0");
        legendValuePanel.add(lowValueLabel, java.awt.BorderLayout.SOUTH);

        legendPanel.add(legendValuePanel);

        rightSidePanel.add(legendPanel);

        getContentPane().add(rightSidePanel, java.awt.BorderLayout.EAST);

        dataLabel.setText(" ");
        dataPanel.add(dataLabel);

        selectionLabel.setText(" ");
        dataPanel.add(selectionLabel);

        getContentPane().add(dataPanel, java.awt.BorderLayout.NORTH);

    }//GEN-END:initComponents

    private void showGreyScaleCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showGreyScaleCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showGreyScaleCheckBoxActionPerformed

    private void showTimeDataCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showTimeDataCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showTimeDataCheckBoxActionPerformed

    private void showTrackFitCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showTrackFitCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showTrackFitCheckBoxActionPerformed

    private void showSeedTrackCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showSeedTrackCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showSeedTrackCheckBoxActionPerformed

    private void showLogScaleCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showLogScaleCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showLogScaleCheckBoxActionPerformed

    private void showDemultiplexedCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showDemultiplexedCheckBoxActionPerformed
        drawButtonActionPerformed(evt);
    }//GEN-LAST:event_showDemultiplexedCheckBoxActionPerformed
    
    private void showPulseDataCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPulseDataCheckBoxActionPerformed
        padRowLayoutDataFrame.setVisible(showPulseData());
    }//GEN-LAST:event_showPulseDataCheckBoxActionPerformed
    
  private void drawButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drawButtonActionPerformed
      drawEvent();
  }//GEN-LAST:event_drawButtonActionPerformed
  
  /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        setVisible(false);
    }//GEN-LAST:event_exitForm
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel commandPanel;
    private javax.swing.JLabel dataLabel;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JButton drawButton;
    private javax.swing.JLabel highValueLabel;
    private java.awt.Canvas legendCanvas;
    private javax.swing.JPanel legendPanel;
    private javax.swing.JPanel legendValuePanel;
    private javax.swing.JLabel lowValueLabel;
    private javax.swing.JLabel midValueLabel;
    private javax.swing.JPanel padRowLayoutEventCanvas;
    private javax.swing.JScrollPane padRowLayoutEventScrollPane;
    private javax.swing.JPanel rightSidePanel;
    private javax.swing.JLabel selectionLabel;
    private javax.swing.JCheckBox showDemultiplexedCheckBox;
    private javax.swing.JCheckBox showGreyScaleCheckBox;
    private javax.swing.JCheckBox showLogScaleCheckBox;
    private javax.swing.JCheckBox showPulseDataCheckBox;
    private javax.swing.JCheckBox showSeedTrackCheckBox;
    private javax.swing.JCheckBox showTimeDataCheckBox;
    private javax.swing.JCheckBox showTrackFitCheckBox;
    // End of variables declaration//GEN-END:variables
    
}
