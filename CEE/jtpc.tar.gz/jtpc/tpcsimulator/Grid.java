package tpcsimulator;
/** Layout of elements in a grid (holes or pads)<br>
 * <PRE>
 * The elements are numbered as follows:
 *
 *                    ^
 * 9 10 11 12         |
 * 5  6  7  8         y
 * 1  2  3  4           x ->
 *
 * </PRE>
 * @author Dean Karlen
 * @version 1.1
 */
import java.awt.Graphics;
import java.awt.Color;
import java.lang.Integer;
import java.util.Hashtable;

public class Grid extends TwoDimenLayout{
    double dx,dy; // spacing between centres
    double x0,y0; // location of centre of first element (lower left)
    int nx,ny;    // number of rows and columns
    Shape shape; // shape of elements that make up grid
/** Constructor
 */
    Grid()
    { // set a default layout
        this.dx=0.1;
        this.dy=0.1;
        this.x0=-1.0;
        this.y0=-1.0;
        this.nx=21;
        this.ny=21;
        this.shape=null;
    }
/** Set shape of objects in grid
 * @param shape Shape of objects
 */
    void setShape(Shape shape) {this.shape=shape;}
/** Return shape of objects
 * @return shape of objects
 */
    public Shape getShape() {return shape;}
/** return number of divisions in x direction (columns)
 * @return number of x divisions
 */
    public int getNX() {return nx;}
/** return number of divisions in y (rows)
 * @return number of y divisions
 */
    public int getNY() {return ny;}
/** Return x coordinate of left edge of leftmost element
 * @return left edge of leftmost element (mm)
 */
    public double getXMin() {return x0-dx/2.;}
/** Return y coordinate of lower edge of lowest element
 * @return low edge of lowest element (mm)
 */
    public double getYMin() {return y0-dy/2.;}
/** Return x coordinate of right edge of rightmost element
 * @return right edge of rightmost element (mm)
 */
    public double getXMax() {return x0+(nx-0.5)*dx;}
/** Return y coordinate of top edge of top element
 * @return top edge of top element (mm)
 */
    public double getYMax() {return y0+(ny-0.5)*dy;}
/** Return x coordinate of centre of first element
 * @return x coordinate of centre of first element (mm)
 */
    public double getX0() {return x0;}
/** Return y coordinate of centre of first element
 * @return y coordinate of centre of element (mm)
 */
    public double getY0() {return y0;}
/** Return pitch of elements in x direction
 * @return pitch of elements in x direction (mm)
 */
    public double getDX() {return dx;}
/** Return pitch of elements in y direction
 * @return pitch of elements in y direction (mm)
 */
    public double getDY() {return dy;}
/** Return x coordinate of right edge of rightmost element
 * @return right edge of rightmost element (mm)
 */
/** Set the spacing between element centres
 * @param dx spacing in x between element centres
 * @param dy spacing in y between element centres
 */
    void setPitch(double dx, double dy) {
        this.dx=dx;
        this.dy=dy;
    }
/** Return spacing between element centres
 * @return spacing between element centres (x and y) in mm
 */
    public Location getPitch() {
        Location loc = new Location();
        loc.x=dx;
        loc.y=dy;
        return loc;
    }
/** Set the centre of the first element (lower left corner of grid)
 * @param x0 x coordinate of first element (mm)
 * @param y0 y coordinate of first element (mm)
 */
    public void setOrigin(double x0, double y0)
    {
        this.x0=x0;
        this.y0=y0;
    }
/** Set number of divisions of elements in x and y (columns and rows)
 * @param nx Number of columns
 * @param ny Number of rows
 */
    void setNumber(int nx, int ny)
    {
        this.nx=nx;
        this.ny=ny;
    }
/** Return the number of elements in grid
 * @return number of elements
 */
    public int getNumElement() {return nx*ny;}
/** Return index of element that is closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return index of element closest to point
 */
    public int getNearestIndex(double x, double y)
    {
        int ix= (int) ((x-x0)/dx+1.5);
        int iy= (int) ((y-y0)/dy+1.5);
        ix=Math.max(1,Math.min(nx,ix));
        iy=Math.max(1,Math.min(ny,iy));
        int index=nx*(iy-1)+ix;
        return index;
    }
/** Return indicies of elements that are (approx) within distance to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param distance distance
 * @return indicies of elements within distance of point
 */
    public int[] getNearbyIndicies(double x, double y, double distance) {
        /* maximum number of indicies */
        int row = (getNearestIndex(x0,y)-1)/nx + 1;
        int col = getNearestIndex(x,y0);
        int rowMin = (int) Math.max(1,row-distance/dy);
        int rowMax = (int) Math.min(ny,row+distance/dy);
        int colMin = (int) Math.max(1,col-distance/dx);
        int colMax = (int) Math.min(nx,col+distance/dx);
        int num = (rowMax-rowMin+1)*(colMax-colMin+1);
        int[] buffer = new int[num];
        int i=-1;
        for (int iCol = colMin; iCol <= colMax; iCol++) {
            for (int iRow = rowMin; iRow <= rowMax; iRow++) {
                i++;
                buffer[i]=nx*(iRow-1)+iCol;
            }
        }
        return buffer;
    }
    
/** Return centre of element corresponding to specified index
 * @param index element index
 * @param loc location of centre of element (returned)
 */
    public void getCentre(int index, Location loc)
    {
        int ix=(index-1)%nx+1;
        int iy=(index-1)/nx+1;
        loc.x=x0+(ix-1)*dx;
        loc.y=y0+(iy-1)*dy;
    }
/** Return centre of element that is closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param loc location of centre of nearest element (x,y) in mm (returned)
 */
    public void getNearestCentre(double x, double y, Location loc)
    {
        int index=getNearestIndex(x,y);
        getCentre(index,loc);
    }
/** Return location of edge of element closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param loc location of nearest edge of element (x,y) in mm (returned)
 */
    public void getNearestEdge(double x, double y, Location loc)
    {
        Location centre = new Location();
        getNearestCentre(x,y,centre);
        shape.getNearestEdge(centre.x,centre.y,x,y,loc);
    }
/** Check if point is within any of the elements
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return True if within an element
 */
    public boolean insideElement(double x, double y)
    {
        Location centre = new Location();
        getNearestCentre(x,y,centre);
        return shape.insideElement(centre.x,centre.y,x,y);
    }

    public boolean insideElement(double x, double y, int index)
    {
        Location centre = new Location();
        getCentre(index,centre);
        return shape.insideElement(centre.x,centre.y,x,y);
    }
}