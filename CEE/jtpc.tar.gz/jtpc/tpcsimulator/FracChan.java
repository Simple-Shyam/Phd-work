package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.io.Serializable;

/** Panel displays the fractional charge seen by each channel
 * @author Dean Karlen
 * @version 1.0
 */
class FracChan extends JPanel {
    JButton cButton;
    int padNum,channel;
    DecimalField fField,fRMSField;
    PadArrayPanel padArrayPanel;
    
/** Constructor
 * @param padArray Pad array
 * @param channel Channel number
 * @param cumul True: cumulative information
 */
    FracChan(PadArrayPanel padArrayPanel, int channel, boolean cumul){
        this.padArrayPanel = padArrayPanel;
        this.channel = channel;
        
        // make the GUI here
        
        setLayout(new GridLayout(0,1));
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(4);
        // fraction of charge field
        fField = new DecimalField(0, 4, numberFormat);
        fField.setEditable(false);
        // rms of fraction of charge field
        if(cumul){
            fRMSField = new DecimalField(0, 4, numberFormat);
            fRMSField.setEditable(false);
        }
        
        cButton = new JButton(String.valueOf(channel));
        cButton.setBackground(padArrayPanel.readOut.scope.scopeChan[channel-1].color);
        cButton.setForeground(Color.white);
        
        add(cButton);
        add(fField);
        if(cumul)add(fRMSField);
    }
/** Update channel color
 */
    void updateColor(){
        cButton.setBackground(padArrayPanel.readOut.scope.scopeChan[channel-1].color);
    }
}
