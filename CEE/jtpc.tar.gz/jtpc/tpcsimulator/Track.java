/*
 * Track.java
 *
 * Created on April 3, 2002, 8:44 AM
 */

package tpcsimulator;

/**
 *
 * @author  karlen
 * @version
 */
public class Track {
    
    double cd,xStart,yStart,zStart,xEnd,yEnd,zEnd,t,sxyz;
    int id;
    
    /** Creates new default Track */
    public Track() {
        cd = 3.0;  // cluster density (clusters per mm)
        xStart = 0.;
        yStart = -10.;
        zStart =  15.;
        xEnd = 0.;
        yEnd = 10.;
        zEnd = 15.;
        t = 0.; // t0 of track
        id = 0; // id of first cluster
        sxyz = 0.1; // transverse and longitudinal standard deviation (mm)
    }
    
    /** Creates new Track from specified segment*/
    public Track(double cd, double xStart, double yStart, double zStart,
    double xEnd, double yEnd, double zEnd, double t, int id, double sxyz) {
        this.cd = cd;
        this.xStart = xStart;
        this.yStart = yStart;
        this.zStart =  zStart;
        this.xEnd = xEnd;
        this.yEnd = yEnd;
        this.zEnd = zEnd;
        this.t = t;
        this.id = id;
        this.sxyz = sxyz;
    }

    /** Creates new Track from specified track parameters and fiducial volume */
    public Track(double x0, double z0, double phi, double psi, double lowX,
    double highX, double lowY, double highY, double lowZ, double highZ, double t,
    double cd, int id, double sxyz) {
        
        double tanPhi = Math.tan(phi);
        double tanPsi = Math.tan(psi);
        if (phi == 0.) tanPhi = 1.E-20;
        if (psi == 0.) tanPsi = 1.E-20;
        
        // find the two planes where the track intersects the rectangular block:
        
        double[] x = new double[2];
        double[] y = new double[2];
        double[] z = new double[2];
        
        double xTest;
        double yTest;
        double zTest;
        
        int nIntersect = 0;
        // x planes:
        for (int iPlane = 0; iPlane < 2; iPlane++) {
            xTest = lowX + (highX-lowX)*iPlane;
            yTest = (x0 - xTest)/tanPhi;
            zTest = z0 + yTest*tanPsi;
            if (yTest > lowY && yTest < highY && zTest > lowZ && zTest < highZ) {
                nIntersect++;
                if (nIntersect <= 2) {
                    int i = nIntersect - 1;
                    x[i] = xTest;
                    y[i] = yTest;
                    z[i] = zTest;
                }
            }
        }
        // y planes:
        for (int iPlane = 0; iPlane < 2; iPlane++) {
            yTest = lowY + (highY-lowY)*iPlane;
            xTest = x0 - yTest*tanPhi;
            zTest = z0 + yTest*tanPsi;
            if (xTest > lowX && xTest < highX && zTest > lowZ && zTest < highZ) {
                nIntersect++;
                if (nIntersect <= 2) {
                    int i = nIntersect - 1;
                    x[i] = xTest;
                    y[i] = yTest;
                    z[i] = zTest;
                }
            }
        }
        // z planes:
        for (int iPlane = 0; iPlane < 2; iPlane++) {
            zTest = lowZ + (highZ-lowZ)*iPlane;
            yTest = (zTest - z0)/tanPsi;
            xTest = x0 - yTest*tanPhi;
            if (yTest > lowY && yTest < highY && xTest > lowX && xTest < highX) {
                nIntersect++;
                if (nIntersect <= 2) {
                    int i = nIntersect - 1;
                    x[i] = xTest;
                    y[i] = yTest;
                    z[i] = zTest;
                }
            }
        }
        // if there are only intersections then we have a unique solution
        if (nIntersect == 2) {
            
            xStart = x[0];
            xEnd = x[1];
            yStart = y[0];
            yEnd = y[1];
            zStart = z[0];
            zEnd = z[1];
            
        } else {
            // track appears to have missed the box! Return zero length track
            xStart = 0.;
            xEnd = 0.;
            yStart = 0.;
            yEnd = 0.;
            zStart = 0.;
            zEnd = 0.;
            
        }
        
        this.cd = cd;
        this.t = t;
        this.id = id;
        this.sxyz = sxyz;
    }     
    
/** Put this track into a TPC
 */
    public void putInto(Tpc tpc) {
        double length = Math.sqrt((xEnd-xStart)*(xEnd-xStart) 
        + (yEnd-yStart)*(yEnd-yStart) + (zEnd-zStart)*(zEnd-zStart));
        if (length <= 0. || cd == 0.) return;
        double xhat = (xEnd-xStart)/length;
        double yhat = (yEnd-yStart)/length;
        double zhat = (zEnd-zStart)/length;
        double distance = 0.;
        int idCluster = id - 1;
        double xLoc = xStart;
        double yLoc = yStart;
        double zLoc = zStart;
        while (distance < length) {
            // generate a random delta
            double delta = -1. * Math.log(tpc.random.nextDouble())/Math.abs(cd);
            distance += delta;
            if (distance < length) {
                // generate a random number of electrons in cloud
                int nE = 0;
                if (cd > 0) nE = getPrimaryIonizations(tpc);
                else nE = getPoissonIonizations(tpc);
                if (nE > 0) {
                    idCluster++;
                    xLoc += delta * xhat;
                    yLoc += delta * yhat;
                    zLoc += delta * zhat;
                    ElectronCloud electronCloud =
                    new ElectronCloud(nE,xLoc,yLoc,zLoc,sxyz,sxyz,t,id);
                    tpc.addElectronCloud(electronCloud);
                }
            }
        }
    }

    public int getPoissonIonizations(Tpc tpc) {
        // generate a Poisson random number of mean 3
        double val = Math.exp(-3.);
        int k=0;
        double A=1.;
        while (A > val) {
            A *= tpc.random.nextDouble();
            k++;
        }
        return k-1;
    }
    
    public int getPrimaryIonizations(Tpc tpc) {
        
        int nCumul = 20;
        int nCheck = 4;
        int nTestMax = 100;
        final double coeff = 0.216; // for large n this is coeff of 1/n^2
        final double[] cumul = new double[] {
            0.65600,0.80600,0.87000,0.90500,0.92750,0.94300,0.95350,0.96160,0.96770,0.97260,
            0.97650,0.97950,0.98200,0.98400,0.98560,0.98680,0.98775,0.98850,0.98913,0.98967
        };
             
        double r = tpc.random.nextDouble();
        int index = 0;
        while (r > cumul[index] && index < nCheck) {
            index++;
        }
        if (r < cumul[index]) {
            return index+1;
        } else if (r < cumul[nCumul-1]) {
            while (r > cumul[index] && index < nCumul) {
                index++;
            }
            return index+1;
        } else {
            int i;
            double cSum = cumul[nCumul-1];
            for (i = nCumul+1; i < nTestMax; i++) {
                cSum += coeff/i/i;
                if (r < cSum) break;
            }
            return i;
        }
    } 
    
}
