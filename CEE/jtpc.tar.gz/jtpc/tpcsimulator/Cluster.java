package tpcsimulator;

/** Information for the cluster of electrons produced from a single primary
 * electron that hit a particular readout pad
 * @author Dean Karlen
 * @version 1.0
 */

public class Cluster {
    private double sumX,sumX2,sumY,sumY2,sumZ,sumZ2,sumT,sumT2;
    
/** number of electrons in cluster
 */
    public int n;
/** identifier of primary electron
 */
    public int idPrimary;
/** next cluster in linked list
 */
    public Cluster nextCluster;
    
/** Constructor
 * @param idPrimary identifier of primary electron
 * @param nextCluster next cluster in linked list
 */
    public Cluster(int idPrimary, Cluster nextCluster)
    {
        sumX=0.;
        sumX2=0.;
        sumY=0.;
        sumY2=0.;
        sumZ=0.;
        sumZ2=0.;
        sumT=0.;
        sumT2=0.;
        n=0;
        this.idPrimary = idPrimary;
        this.nextCluster = nextCluster;
    }
/** Add an electron to this cluster
 * @param electron electron
 */
    public void addElectron(Electron electron)
    {
        n++;
        sumX += electron.x;
        sumX2 += electron.x*electron.x;
        sumY += electron.y;
        sumY2 += electron.y*electron.y;
        sumZ += electron.z;
        sumZ2 += electron.z*electron.z;
        sumT += electron.t;
        sumT2 += electron.t*electron.t;
    }
    
    public void addNElectron(int nElectron) {
        n += nElectron;
    }
    
    public void addNElectron(int nElectron, double time) {
        n += nElectron;
        sumT += nElectron*time;
    }
    
/** Return mean x coordinate of electrons in this cluster
 * @return mean x coordinate of electrons in this cluster (mm)
 */
    public double getX()
    {
        double x=-9999.;
        if (n>0) x = sumX/n;
        return x;
    }
/** Return standard deviation of x coordinates of electrons in cluster
 * @return standard deviation of x coordinates of electrons in cluster (mm)
 */
    public double getSx()
    {
        double sx=0.00001;
        if (n>1) sx = Math.sqrt((sumX2-sumX*sumX/n)/(n-1));
        return sx;
    }
  /** Return mean y coordinate of electrons in this cluster
   * @return mean y coordinate of electrons in this cluster (mm)
   */
    public double getY()
    {
        double y=-9999.;
        if (n>0) y = sumY/n;
        return y;
    }
/** Return standard deviation of y coordinates of electrons in cluster
 * @return standard deviation of y coordinates of electrons in cluster (mm)
 */
    public double getSy()
    {
        double sy=0.00001;
        if (n>1) sy = Math.sqrt((sumY2-sumY*sumY/n)/(n-1));
        return sy;
    }
  /** Return mean z coordinate of electrons in this cluster
   * @return mean z coordinate of electrons in this cluster (mm)
   */
    public double getZ()
    {
        double z=-9999.;
        if (n>0) z = sumZ/n;
        return z;
    }
/** Return standard deviation of z coordinates of electrons in cluster
 * @return standard deviation of z coordinates of electrons in cluster (mm)
 */
    public double getSz()
    {
        double sz=0.00001;
        if (n>1) sz = Math.sqrt((sumZ2-sumZ*sumZ/n)/(n-1));
        return sz;
    }
  /** Return mean time coordinate of electrons in this cluster
   * @return mean time coordinate of electrons in this cluster (ns)
   */
    public double getT()
    {
        double t=-9999.;
        if (n>0) t = sumT/n;
        return t;
    }
/** Return standard deviation of time coordinates of electrons in cluster
 * @return standard deviation of time coordinates of electrons in cluster (ns)
 */
    public double getSt()
    {
        double st=0.00001;
        if (n>1) st = Math.sqrt((sumT2-sumT*sumT/n)/(n-1));
        return st;
    }
}

