/*
 * TpcSimulatorBatch.java
 *
 * Created on April 2, 2002, 9:43 AM
 */

package tpcsimulator;
import java.io.*;

/**
 *
 * @author  karlen
 * @version
 */
public class Batch {
    
    Tpc tpc;
    RunParam rp;
    String newline = "\n";
    
    /** Creates new TpcSimulatorBatch */
    public Batch(String[] args) {
        
        if (args.length !=2) {
            System.err.print("TpcSimulator Batch error: program requires 2 arguments" 
            + newline
            + "Usage: tpcsimulator/Batch tpcObject.tpc mcParam.tmc" 
            + newline);
        } else {
            File tpcFile = new File(args[0]);
            File mcParamFile = new File(args[1]);
            
            try {
                // Create the tpc from the saved tpc object
                FileInputStream in = new FileInputStream(tpcFile);
                ObjectInputStream object = new ObjectInputStream(in);
                tpc = (Tpc)object.readObject();
                object.close();
                System.out.print("Opened TPC file " + tpcFile.getAbsolutePath()+newline);
                
                // Read in the MC parameter object
                in = new FileInputStream(mcParamFile);
                object = new ObjectInputStream(in);
                rp = (RunParam)object.readObject();
                object.close();
                System.out.print("Opened MC parameter file " + mcParamFile.getAbsolutePath()+newline);

                // Generate events.
                Run run = new Run(rp);
                run.start(tpc);
                
            }
            catch (IOException except) {
                System.err.print("TpcSimulator Batch error: Could not read file" + newline);
                except.printStackTrace();
            }
            catch (ClassNotFoundException except2) {
                System.err.print("TpcSimulator Batch error: Improper data" + newline);
            }
        }
        
   }
    
    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
        new Batch(args);
    }
    
}
