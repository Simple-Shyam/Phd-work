package tpcsimulator;
import javax.swing.*;

/**
 *
 * @author  karlen
 * @version
 */
abstract class TpcPartPanel extends javax.swing.JPanel {
    
    /** Creates new TpcPartPanel */
    TpcPartPanel() {
    }
    
/** Number of windows associated with this
 * @return 0
 */
    int nWindow(){return 0;}
    
/* get windows associated with this */
    JFrame window(int i){return null;}
    
    // action to read in all values from the Panel(in case changed)
    abstract void readPanel();
    
    /** Actions to be taken after electrons propogated
     * @param runSum true if run summary
     */
    void doCalc(boolean runSum){}
    
    /** Actions to be taken when clear button pushed
     */
    void clear(boolean runSum){}
    
    /** Actions to be taken when part is deleted
     */
    void delete(){}
}
