package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

/** Frame for designing the TPC
 * @author Dean Karlen
 * @version 1.0
 */
class TpcDesign extends JFrame {
    Tpc tpc;
    JPanel mainPane;
    JPanel buttonPane;
    JPanel allPane;
    JScrollPane scrollPane;
    JButton okButton;
    Vector tpcPartPanelVector;
    
/** Constructor
 * @param iTpc Gas Electron Multiplier
 */
    TpcDesign(Tpc iTpc){
        tpc = iTpc;
        allPane = new JPanel();
        allPane.setLayout(new BoxLayout(allPane, BoxLayout.Y_AXIS));
        
        mainPane = new JPanel();
        mainPane.setLayout(new BoxLayout(mainPane, BoxLayout.Y_AXIS));
        
        scrollPane = new JScrollPane(mainPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        buttonPane = new JPanel();
        okButton = new JButton("OK");
        buttonPane.add(okButton);
        
        allPane.add(buttonPane);
        allPane.add(scrollPane);
        
        setContentPane(allPane);
        addActionListeners();
        
        tpcPartPanelVector = new Vector(5,5);
    }
    
/** Put TPC parts onto Frame
 */
    void drawTpc(){
        mainPane.removeAll();
        
        TpcPart nextPart = tpc.topPart;
        tpcPartPanelVector.removeAllElements();
        while (nextPart != null) {
            mainPane.add(Box.createRigidArea(new Dimension(0,5)));
            TpcPartPanel gpp = nextPart.newPanel(this);
            mainPane.add(gpp);
            tpcPartPanelVector.add(gpp);
            nextPart = (nextPart).partBelow;
        }
        
        pack();
    }
    
    public String toString(){return "TPC design window";}
    public void addActionListeners() {
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                readPanel();
                setVisible(false);
            }
        });
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                readPanel();
                setVisible(false);
            }
        });
        
    }
    
    void readPanel() {
        int nPart = tpcPartPanelVector.size();
        for (int iPart = 0; iPart < nPart; iPart++) {
            TpcPartPanel gpp = (TpcPartPanel) tpcPartPanelVector.elementAt(iPart);
            gpp.readPanel();
        }
        doCalc(false);
    }
    
    void clear(boolean runSum) {
        int nPart = tpcPartPanelVector.size();
        for (int iPart = 0; iPart < nPart;  iPart++) {
            TpcPartPanel gpp = (TpcPartPanel) tpcPartPanelVector.elementAt(iPart);
            gpp.clear(runSum);
        }
        doCalc(false);
    }
    
    void doCalc(boolean runSum) {
        int nPart = tpcPartPanelVector.size();
        for (int iPart = 0; iPart < nPart; iPart++) {
            TpcPartPanel gpp = (TpcPartPanel) tpcPartPanelVector.elementAt(iPart);
            gpp.doCalc(runSum);
        }
    }
}
