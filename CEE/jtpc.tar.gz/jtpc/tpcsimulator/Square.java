package tpcsimulator;

public class Square extends Rectangle {

    /** Creates new Square */
    Square(double len) {
        setLength(len);
    }

    void setLength(double len) {
        lx = len;
        ly = len;
    }
}