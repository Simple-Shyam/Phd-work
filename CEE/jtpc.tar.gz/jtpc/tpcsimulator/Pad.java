package tpcsimulator;

/** A pad sensitive to electrons
 * @author Dean Karlen
 * @version 1.0
 */

import java.io.*;
public class Pad implements Serializable{
    
    static final long serialVersionUID = 8518671156146911334L;
    
    /** First cluster in a linked list of clusters of electrons that hit this pad
     */

    public transient Cluster firstCluster;

    /** pulse shape data that may be associated with this pad (real data, not simulation)
     */

    public transient double[] data;

    Pad() {
        firstCluster = null;
        data = null;
    }

    void addElectron(Electron electron) {
        int idPrimary = electron.idPrimary;
        boolean found = false;
        Cluster cluster = firstCluster;
        while (cluster != null && !found){
            if (idPrimary==cluster.idPrimary){
                found=true;
                cluster.addElectron(electron);
            }
            else {
                cluster = cluster.nextCluster;
            }
        }
        // a new cluster needs to be formed. Put it first, so that search is fastest
        if(!found){
            firstCluster = new Cluster(idPrimary,firstCluster);
            firstCluster.addElectron(electron);
        }
    }

    /** Return the number of electrons that are collected by this pad
     * @return number of electrons hitting pad
     */
    public int getNElectron() {
        Cluster cluster = firstCluster;
        int nElectron=0;
        while (cluster != null){
            nElectron += cluster.n;
            cluster = cluster.nextCluster;
        }
        return nElectron;
    }
    
    public double getTime() {
        Cluster cluster = firstCluster;
        int nElectron=0;
        double timeSum=0.;
        while (cluster != null){
            nElectron += cluster.n;
            timeSum += cluster.getT()*cluster.n;
            cluster = cluster.nextCluster;
        }
        if (nElectron>0) return timeSum/nElectron;
        return -999.;
    }
    
    public void addNElectron(int nElectronToAdd) {
        Cluster cluster = new Cluster(-1,firstCluster);
        cluster.addNElectron(nElectronToAdd);
        firstCluster = cluster;
    }

    public void addNElectron(int nElectronToAdd, double time) {
        Cluster cluster = new Cluster(-1,firstCluster);
        cluster.addNElectron(nElectronToAdd,time);
        firstCluster = cluster;
    }
    
    /** return signal observed by pad
     * @param signal Signal observed by pad (returned)
     */
    public void getSignal(Signal signal, double driftTime) {
        signal.clear();
        Cluster cluster = firstCluster;
        while (cluster != null){
            signal.addDirect(cluster, driftTime);
            cluster = cluster.nextCluster;
        }
        signal.filter();
        signal.applyGain();
    }

    /** return signal observed by pad (accounting for preamp variations)
     * @param signal Signal observed by pad (returned)
     */
    public void getSignal(Signal signal, double driftTime, int iChan) {
        signal.clear();
        Cluster cluster = firstCluster;
        while (cluster != null){
            signal.addDirect(cluster, driftTime);
            cluster = cluster.nextCluster;
        }
        signal.filter();
        signal.applyGain(iChan);
    }
    
    /** clear charge collected by this pad
     */
    public void clear(){ firstCluster = null;}
    
    public void setData(double[] data) { this.data = data; }

    public double[] getData() { return data; }

}

