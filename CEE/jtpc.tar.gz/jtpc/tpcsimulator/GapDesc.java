package tpcsimulator;

/** Descriptor for gas gaps

 * @author Dean Karlen
 * @version 1.0
 */

class GapDesc extends TpcPartDesc{

/** Drift velocity (microns/ns)
 */

    double vDrift;

/** transverse diffusion  (micron/sqrt(cm))
 */

    double transverseDiffusion;

/** longitudinal diffusion  (micron/sqrt(cm))
 */

    double longitudinalDiffusion;

/** inverse lifetime (attachment) (1/ms)
 */
    
    double invLifetime;  

/** Constructor
 * @param name Name for gas gap
 */

    GapDesc(String name){

        this.name = name;
        // define default gas gap
        
        thickness=5.0;
        vDrift = 50.; // microns per ns
        transverseDiffusion = 90.; // micron/sqrt(cm)
        longitudinalDiffusion = 250.;
        invLifetime = 0; // no attachment
    }

}
