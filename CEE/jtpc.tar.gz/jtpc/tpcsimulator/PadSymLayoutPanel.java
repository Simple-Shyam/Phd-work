package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import tpctracker.FitterControlFrame;
import tpctracker.FitterControlFrame2;

class PadSymLayoutPanel extends PadArrayPanel {
    TpcDesign tpcDesign;
    PadSymLayoutEventFrame eventDisplay;
    PadSymLayoutPanel pslpThis;
    FitterControlFrame fitterControl;
    SymLayoutPanel symLayoutPanel;
    /** Creates new PadArrayPanel */
    PadSymLayoutPanel(PadSymLayout padSymLayout, TpcDesign iTpcDesign) {
        padArray = padSymLayout;
        tpcDesign = iTpcDesign;
        pslpThis = this;
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Pad Sym Layout: " + padArray.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Layout of the Row Layout:
        symLayoutPanel = new SymLayoutPanel(padSymLayout,this);
        add(symLayoutPanel, BorderLayout.CENTER);
        
        createAssociatedWindows();
        eventDisplay = new PadSymLayoutEventFrame(padSymLayout);
        eventDisplay.setVisible(false);
        
        fitterControl = new FitterControlFrame(padSymLayout);
        fitterControl.setVisible(false);
        
    }
    
    void readPanel(){
        if (symLayoutPanel != null)symLayoutPanel.readPanel();
    }
    
    int nWindow(){return 4;}
    JFrame window(int i) {
        if(i==1){
            return readOut;
        } else if (i==2){
            return statsWindow;
        } else if (i==3) {
            return eventDisplay;
        } else
            return fitterControl;
    }
    
    void resetPadSymLayoutEventFrame() {
        eventDisplay.setVisible(false);
        eventDisplay = new PadSymLayoutEventFrame(padArray);
        eventDisplay.setVisible(false);
    }
    
}