package tpcsimulator;

/** An array of pads used for signal readout
 * @author Dean Karlen
 * @version 1.0
 */

public class PadArray extends LayoutTpcPart {

    static final long serialVersionUID = -4443301608790770679L;  
    int nPad,nElectron;
    Pad pad[];
    
    PadArray(PadDesc desc, Tpc tpc){
        super(desc);
        this.tpc = tpc;

        // create array of pads
        reset();
    }
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new PadArrayPanel(this, tpcDesign);
    }
    
    void reset() {
        nElectron=0;
        nPad=layout.getNumElement();
        pad = new Pad[nPad+1];
        for (int i=0; i<=nPad; i++){
            pad[i]= new Pad();
        }
    }
    
    boolean overAPad(double x, double y) {
        return layout.insideElement(x,y);
    }
    
    void shift(double x, double y, Location loc) {
        // return the location of the nearest edge of a pad
        // (the electron will shift to that position)
        layout.getNearestEdge(x,y,loc);
    }
    
/** add electron clouds to pads
 */
    void propagateElectronCloud(ElectronCloud electronCloud) {
        /* pull electrons out of the cloud and assign to pads */
        for (int i =0; i < electronCloud.n; i++) {
            double x = electronCloud.x + electronCloud.sxy*tpc.random.nextGaussian();
            double y = electronCloud.y + electronCloud.sxy*tpc.random.nextGaussian();
            double z = zBottom;
            double t = electronCloud.t;
            if (partAbove !=null) 
                t += electronCloud.sz*tpc.random.nextGaussian()/partAbove.vDrift*1000.;
            // find pad to assign electron to
            int hitPad=layout.getNearestIndex(x,y);
            // make the electron if it is within pad element
            if (recordElectron(x,y,hitPad)) {
                Electron electron = new Electron(x,y,z,t,electronCloud.idPrimary);
                pad[hitPad].addElectron(electron);
                nElectron++;
            }
        }
    }
    
    // decide if electron should be recorded: For Meshes and Row Layouts, only
    // record if the electron is inside the pad element... it is assumed that the
    // non-pad areas are grounded.
    
    boolean recordElectron(double x, double y, int hitPad) {
        return true;
    }
    
    public boolean getPadSignal(int padIndex, Signal signal) {
        if (padIndex < 1 || padIndex > nPad) return false;
        // This assumes the induction gap is
        // directly above this padArray:
        double driftTime = 1.;
        if (partAbove !=null) {
            driftTime = Math.max(1.,partAbove.thickness/partAbove.vDrift*1000.);
        }
        pad[padIndex].getSignal(signal,driftTime,padIndex);
        return true;
    }
    
    public int getNElectron(int padIndex) {
        if (padIndex < 1 || padIndex > nPad) return 0;
        return pad[padIndex].getNElectron();
    }
    
    public int getPadIndex(double x, double y) {
        return layout.getNearestIndex(x,y);
    }
    
    public void getPadLoc(double x, double y, Location loc) {
        layout.getNearestCentre(x,y,loc);
    }
  
    public int getNumElement() {
        return nPad;
    } 
   
    public int getFirstElement() {
        return 1;
    }
    
    public void clear() {
        nElectron=0;
        for (int i=0; i<=nPad; i++){
            pad[i].clear();
        }
    }
    
}