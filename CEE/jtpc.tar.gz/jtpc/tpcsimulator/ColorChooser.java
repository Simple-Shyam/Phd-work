package tpcsimulator;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.colorchooser.*;

/** Choose color for a oscilliscope channel
 */
class ColorChooser extends JFrame {
    ScopeChan scopeChan;
/** Constructor
 * @param iScopeChan Oscilliscope Channel identifier
 */
    ColorChooser(ScopeChan iScopeChan) {
        super("Choose Color");
        scopeChan = iScopeChan;
        
        //Set up the banner at the top of the window
        final JLabel banner = new JLabel("Scope Channel Color",
        JLabel.CENTER);
        banner.setForeground(Color.white);
        banner.setBackground(scopeChan.color);
        banner.setOpaque(true);
        banner.setFont(new Font("SansSerif", Font.BOLD, 24));
        banner.setPreferredSize(new Dimension(100, 65));
        
        JPanel bannerPanel = new JPanel(new BorderLayout());
        bannerPanel.add(banner, BorderLayout.CENTER);
        bannerPanel.setBorder(BorderFactory.createTitledBorder("Example"));
        
        //Set up color chooser for setting text color
        final JColorChooser tcc = new JColorChooser(banner.getForeground());
        tcc.getSelectionModel().
        addChangeListener(
        new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                Color newColor = tcc.getColor();
                banner.setBackground(newColor);
                scopeChan.setColor(newColor);
            }
        }
        );
        tcc.setBorder(BorderFactory.
        createTitledBorder(
        "Choose Scope Channel Color"));
        
        //Add the components to the demo frame
        Container contentPane = getContentPane();
        contentPane.add(bannerPanel, BorderLayout.CENTER);
        contentPane.add(tcc, BorderLayout.SOUTH);
    }
}



