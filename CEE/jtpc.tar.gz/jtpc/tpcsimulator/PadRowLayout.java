package tpcsimulator;
import java.util.Vector;

/** A Pad Row Layout is a special type of PadMesh. The layout is required to be
 *  in rows. The shapes are required to be rectangles.
 *  It is for this geometry
 *  that the tracking algorithm can be applied.
 *  The pads in a Pad Row Layout can be connected to one another in arbitrary
 *  patterns for multiplexed readout.
 */
public class PadRowLayout extends PadMesh {
    
    // version # frozen on Sept 10, 2002:
    static final long serialVersionUID = -3613438524102028974L;
    
    private double[] lgPadGroup; // sum of the integrals of the linear Gaussian for all Pads in a group
    
    PadRowLayout(PadDesc desc,Tpc tpc){
        super(desc, tpc);
        fittable = true;
        
        layout = rowLayout;
        reset();
        setPadGroup(0,null);
    }
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new PadRowLayoutPanel(this, tpcDesign);
    }
    
    public PadMeshEventFrame getEventFrame() {
        return new PadRowLayoutEventFrame(this);
    }
    
    void recalc() {
        // to be called whenever layout is changed...
        nRow = rowLayout.nRow;
        int nPadGroup = getNumElement();
        if (nPadGroup == 0) return;
        
        lgPadGroup = new double[nPadGroup];
        padGroupEnabled = new boolean[nPadGroup];
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) padGroupEnabled[iPadGroup] = true;
        
        int[][] padGroup = getPadGroup();
        // use a temporary array to collect data
        boolean[][] pGIR = new boolean [nRow][nPadGroup];
        int[] nPGIR = new int[nRow];
        for (int iRow = 0; iRow < nRow; iRow++) {
            nPGIR[iRow] = 0;
            for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
                pGIR[iRow][iPadGroup] = false;
            }
        }
        // loop over all Pad Groups: fill pGIR with true for rows they are present in
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int iPadInGroup = 0; iPadInGroup < nPadInGroup; iPadInGroup++) {
                int iPad = padGroup[iPadGroup][iPadInGroup];
                int iRow = rowLayout.rowForPad[iPad];
                if (!pGIR[iRow][iPadGroup]) {
                    pGIR[iRow][iPadGroup] = true;
                    nPGIR[iRow]++;
                }
            }
        }
        // fill in the padGroupInRow from the data in the temporary array
        padGroupInRow = new int[nRow][];
        for (int iRow = 0; iRow < nRow; iRow++) {
            int nPadGroupInRow = nPGIR[iRow];
            padGroupInRow[iRow] = new int[nPadGroupInRow];
            int iPadGroupInRow = -1;
            for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
                if (pGIR[iRow][iPadGroup]) {
                    iPadGroupInRow++;
                    padGroupInRow[iRow][iPadGroupInRow] = iPadGroup;
                }
            }
        }
    }
    
    final static double sqrt2 = Math.sqrt(2.);
    final static double s2p = Math.sqrt(2.*Math.PI);
    
    double eta(double u, double s) {
        return (u/2.)*Gaussian.erf(u/sqrt2/s) +
        (s/s2p)*Math.exp(Math.max(-100.,-u*u/2./s/s));
    }
    
    void calcLinearGaussian(double[] param, boolean[] includeRow) {
        // calculate the integral of the linear Gaussian over rectangular pads
        
        // dk: May 14, 2003: include new parameter (param[3]), the signed inverse radius of curvature
        // the definition of phi is now the local angle at y=0 (ie. phi_0)
        
        // dk: Jan 22, 2006: include the variable sigma along the length of the track
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        double cosp0 = Math.cos(param[1]);
        
        double sigma = param[2];
        
        int nPadGroup = getNumElement();
        int[][] padGroup = getPadGroup();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            lgPadGroup[iPadGroup] = 0.;
            // for backward compatibility: do not assume padGroupEnabled exists
            if (padGroupEnabled == null || padGroupEnabled[iPadGroup]) {
                int nPadInGroup = padGroup[iPadGroup].length;
                for (int iPadInGroup = 0; iPadInGroup < nPadInGroup; iPadInGroup++) {
                    int iPad = padGroup[iPadGroup][iPadInGroup];
                    int iRow = rowLayout.rowForPad[iPad];
                    if (includeRow[iRow]){
                        double dx = rowLayout.padWidth[iPad];
                        double dy = rowLayout.rowHeight[iRow];
                        double xp = rowLayout.padX[iPad] + dx/2.;
                        double yp = rowLayout.rowY[iRow] + dy/2.;
                        
                        if (sigmaSlope != 0.){
                            double sig2 = param[2]*param[2]+sigmaSlope*dzdy*yp;
                            if (sig2 > 0.) sigma = Math.sqrt(sig2);
                            else sigma = 0.001;
                        }
                        
                        // Calculate the integral of a line charge with global track parameters
                        // BG,PHI, and transverse width SIGMA through a rectangular pad of width
                        // DX and height DY centred at XP,YP
                        
                        // check if necessary to do expandsion in 1/r:
                        double b = 0;
                        if(Math.abs(yp*param[3])<0.001){
                            double coeff1 = yp*yp/2./cosp0/cosp0/cosp0;
                            double coeff2 = coeff1*yp*sinp0/cosp0/cosp0;
                            b = param[0] - xp - yp*sinp0/cosp0 + coeff1*param[3] - coeff2*param[3]*param[3];
                        } else {
                            double alpha = (2.*sinp0-yp*param[3])*yp*param[3]/cosp0/cosp0;
                            b = param[0] - xp + cosp0/param[3]*(1.-Math.sqrt(1.+alpha));
                        }
                        
                        double sinp = sinp0 - yp*param[3];
                        sinp = Math.min(0.999,Math.max(-0.999,sinp));
                        double cosp = Math.sqrt(1.-sinp*sinp);
                        double a1 = b * cosp;
                        double a2 = (dx / 2.) * cosp;
                        double a3 = (dy / 2.) * sinp;
                        
                        double tpcchr = eta(a1+a2+a3,sigma) - eta(a1+a2-a3,sigma)
                        + eta(a1-a2-a3,sigma) - eta(a1-a2+a3,sigma);
                        tpcchr /= sinp*cosp;
                        
                        lgPadGroup[iPadGroup] += Math.abs(tpcchr);
                    }
                }
            }
        }
    }
    
    public boolean[] selectRow(int[] fitRows){
        nRowUsed = 0;
        
        // get charge in each row first - so we can skip rows without any charge, or not in fit (speed it up)
        // also ignore rows in which the pad with the largest signal in the row is next to a bad pad or is on
        // the border
        boolean[] includeRow = new boolean[nRow]; for (int i=0; i<nRow; i++) includeRow[i]=false;
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            // get the estimated number of primary electrons sampled by each pad
            int maxE = 0; int maxIndex = 0;
            for (int iPadGroupInRow = 0; (iPadGroupInRow < nPadGroupInRow)&&!includeRow[iRow]; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                int nElectron = getNElectron(iPadGroup);
                if (nElectron > maxE) {
                    maxE = nElectron;
                    maxIndex = iPadGroupInRow;
                }
            }
            if (maxE>0){
                if(maxIndex>0 && maxIndex<nPadGroupInRow-1){
                    int left = padGroupInRow[iRow][maxIndex-1];
                    int right = padGroupInRow[iRow][maxIndex+1];
                    includeRow[iRow] = padGroupIsEnabled(left) && padGroupIsEnabled(right);
                    nRowUsed++;
                }
            }
        }
        return includeRow;
    }
    
    public double calcLogLikelihood(double[] param, double totGain, double pNoise, int[] fitRows) {
        
        // calculate the log likelihood of the observed fractions
        
        double lnlike =0.;
        
        // select the rows to be used in the likelihood fit
        boolean[] includeRow = selectRow(fitRows);
        
        // calculate the integral of the linear Gaussian for all pad groups
        calcLinearGaussian(param,includeRow);
        
        // for each row, calculate the relative charge fractions in each pad group
        // and compare to observed signals
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            if(includeRow[iRow]){
                int nPadGroupInRow = padGroupInRow[iRow].length;
                
                // Calculate the charge fractions in the row
                double calcCharge[] = new double[nPadGroupInRow];
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge[iPadGroupInRow] = 0.;
                    int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                    calcCharge[iPadGroupInRow] = lgPadGroup[iPadGroup];
                }
                double totCharge = 0.;
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    totCharge += calcCharge[iPadGroupInRow];
                }
                if (totCharge > 0.){
                    for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                        calcCharge[iPadGroupInRow] /= totCharge;
                    }
                }
                
                // get the estimated number of primary electrons sampled by each pad
                double rElectron[] = new double[nPadGroupInRow];
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                    int nElectron = getNElectron(iPadGroup);
                    rElectron[iPadGroupInRow] = nElectron / totGain;
                }
                
                // work out the contribution to the log likelihood
                double lnl = 0.;
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    lnl += rElectron[iPadGroupInRow]
                    * Math.log((calcCharge[iPadGroupInRow] + pNoise + 1.E-8) /
                    (1.+nPadGroupInRow*pNoise));
                }
                
                lnlike += lnl;
            }
            
        }
        return lnlike;
    }
    
    public double calcLogLikelihood2(double[] param, double totGain, double pNoise, int[] fitRows) {
        
        // calculate the log likelihood of the observed fractions for the two straight track case
        // this is complicated because of the arbitrary relative normalization of the
        // contributions from the two tracks - should not assume them to be equal
        // find the value that maximises the liklihood (finding where the derivative is zero)
        
        double lnlike =0.;
        
        // get charge in each row first - so we can skip rows without any charge, or not in fit (speed it up)
        boolean[] includeRow = new boolean[nRow]; for (int i=0; i<nRow; i++) includeRow[i]=false;
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            // get the estimated number of primary electrons sampled by each pad
            for (int iPadGroupInRow = 0; (iPadGroupInRow < nPadGroupInRow)&&!includeRow[iRow]; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                int nElectron = getNElectron(iPadGroup);
                includeRow[iRow] |= (nElectron>0);
            }
        }
        
        // calculate the integral of the linear Gaussian for all pad groups for track 1
        double param1[] = new double[4];
        param1[0] = param[0];
        param1[1] = param[1];
        param1[2] = param[2];
        param1[3] = 0.;
        
        calcLinearGaussian(param1,includeRow);
        
        // for each row, calculate the relative charge fractions in each pad group for track 1
        
        double calcCharge1[][] = new double[fitRows.length][];
        double rElectron[][] = new double[fitRows.length][];
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            if(includeRow[iRow]){
                int nPadGroupInRow = padGroupInRow[iRow].length;
                
                // Calculate the charge fractions in the row
                calcCharge1[iR] = new double[nPadGroupInRow];
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge1[iR][iPadGroupInRow] = 0.;
                    int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                    calcCharge1[iR][iPadGroupInRow] = lgPadGroup[iPadGroup];
                }
                double totCharge = 0.;
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    totCharge += calcCharge1[iR][iPadGroupInRow];
                }
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge1[iR][iPadGroupInRow] /= totCharge;
                }
                
                // get the estimated number of primary electrons sampled by each pad
                rElectron[iR] = new double[nPadGroupInRow];
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                    int nElectron = getNElectron(iPadGroup);
                    rElectron[iR][iPadGroupInRow] = nElectron / totGain;
                }
            }
        }
        
        // calculate the integral of the linear Gaussian for all pad groups for track 2
        double param2[] = new double[4];
        param2[0] = param[3];
        param2[1] = param[4];
        param2[2] = param[5];
        param2[3] = 0.;
        
        calcLinearGaussian(param2,includeRow);
        
        // for each row, calculate the relative charge fractions in each pad group for track 1
        
        double calcCharge2[][] = new double[fitRows.length][];
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            if (includeRow[iRow]){
                int nPadGroupInRow = padGroupInRow[iRow].length;
                
                // Calculate the charge fractions in the row
                calcCharge2[iR] = new double[nPadGroupInRow];
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge2[iR][iPadGroupInRow] = 0.;
                    int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                    calcCharge2[iR][iPadGroupInRow] = lgPadGroup[iPadGroup];
                }
                double totCharge = 0.;
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    totCharge += calcCharge2[iR][iPadGroupInRow];
                }
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge2[iR][iPadGroupInRow] /= totCharge;
                }
            }
        }
        
        // work out the contributions to the log likelihood
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            if (includeRow[iRow]){
                int nPadGroupInRow = padGroupInRow[iRow].length;
                
                // Now find where the derivative of the likelihood w.r.t. the
                // relative amplitude of the pulses for each row is zero
                
                likelihoodDerivative lD = new likelihoodDerivative(rElectron[iR],
                calcCharge1[iR],calcCharge2[iR], pNoise);
                double xlow[] = new double[1]; xlow[0] = 0.01;
                double xhigh[] = new double[1]; xhigh[0] = 0.99;
                double a = 0.5;
                if (numal.Analytic_problems.zeroin(xlow,xhigh,lD))a = xlow[0];
                
                // work out the contribution to the log likelihood
                double lnl = 0.;
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    lnl += rElectron[iR][iPadGroupInRow]
                    * Math.log((a*calcCharge1[iR][iPadGroupInRow] +
                    (1.-a)*calcCharge2[iR][iPadGroupInRow] + pNoise + 1.E-8) /
                    (1.+nPadGroupInRow*pNoise));
                }
                
                lnlike += lnl;
            }
            
        }
        return lnlike;
    }
    
    class likelihoodDerivative implements numal.AP_zeroin_methods {
        
        double[] n,p1,p2;
        double noise;
        double[] denom;
        
        likelihoodDerivative(double[] n, double[] p1, double[] p2, double noise) {
            this.n = n;
            this.p1 = p1;
            this.p2 = p2;
            this.noise = noise;
            denom = new double[n.length];
            for (int i = 0; i < n.length; i++) {
                if (n[i] > 0. && p1[i] != p2[i]) {
                    denom[i] = (p2[i] + noise)/(p1[i] - p2[i]);
                }
            }
        }
        
        public double fx(double[] values) {
            double a = values[0];
            double sum = 0.;
            for (int i = 0; i < n.length; i++) {
                if (n[i] > 0. && p1[i] != p2[i]) {
                    sum += n[i]/(a + denom[i]);
                }
            }
            return sum;
        }
        
        public double tolx(double[] values) {
            return 0.001;
        }
        
    }
    
    public double getBValue(double[] param, int iRow) {
        // work out the b value (local x coordinate in pad over which track passes)
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        double cosp0 = Math.cos(param[1]);
        
        double dy = rowLayout.rowHeight[iRow];
        double yp = rowLayout.rowY[iRow] + dy/2.;
        
        double coeff1 = yp*yp/2./cosp0/cosp0/cosp0;
        double coeff2 = coeff1*yp*sinp0/cosp0/cosp0;
        double x = param[0] - yp*sinp0/cosp0 + coeff1*param[3] - coeff2*param[3]*param[3];
        
        Location loc = new Location();
        rowLayout.getNearestCentre(x,yp,loc);
        
        return x-loc.x;
    }
    
    public double getTransverseTrackLength(double[] param, int iRow) {
        // work out the transverse track length in the row
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        
        double dy = rowLayout.rowHeight[iRow];
        double yp = rowLayout.rowY[iRow] + dy/2.;
        
        double sinp = sinp0 - yp*param[3];
        sinp = Math.min(0.999,Math.max(-0.999,sinp));
        double cosp = Math.sqrt(1.-sinp*sinp);
        
        return dy/cosp;
    }
    
    public double[] getExpectedElectronInPadGroup(double[] param, int[] fitRows) {
        
        // for systematic studies, work out the expected charge for each PadGroup:
        int nPadGroup = getNumElement();
        double[] expectedElectronInPadGroup = new double[nPadGroup];
        for (int i = 0; i < nPadGroup; i++) expectedElectronInPadGroup[i]=0;
        
        // calculate the integral of the linear Gaussian for all pad groups
        boolean[] includeRow = new boolean[nRow]; for (int i=0; i<nRow; i++) includeRow[i]=true;
        calcLinearGaussian(param,includeRow);
        
        // for each row, calculate the relative charge fractions in each pad group
        // and compare to observed signals
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            
            // Calculate the charge fractions in the row
            double calcCharge[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] = 0.;
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                calcCharge[iPadGroupInRow] = lgPadGroup[iPadGroup];
            }
            double totCharge = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                totCharge += calcCharge[iPadGroupInRow];
            }
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] /= totCharge;
            }
            
            // find total number of electrons in the row:
            int nElectronInRow = 0;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                nElectronInRow += getNElectron(iPadGroup);
            }
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                expectedElectronInPadGroup[iPadGroup] = nElectronInRow*calcCharge[iPadGroupInRow];
            }
            
        }
        return expectedElectronInPadGroup;
    }
    
    public double[][] getYZData() {
        // return an array of yz points for all rows
        
        double[][] yzPoints = new double[nRow][2];
        
        for (int iRow = 0; iRow < nRow; iRow++) {
            int nPadGroupInRow = padGroupInRow[iRow].length;
            double time = -1.;
            int iPG = 0;
            while (time < 0. && iPG < nPadGroupInRow) {
                int iPadG = padGroupInRow[iRow][iPG];
                if (getNElectron(iPadG) > 0) {
                    time = getTime(iPadG);
                }
                iPG++;
            }
            yzPoints[iRow][0] = rowLayout.rowY[iRow] + rowLayout.rowHeight[iRow]/2.;
            yzPoints[iRow][1] = time;
        }
        return yzPoints;
    }
    
    public boolean getPadSignal(int iPadGroup, Signal signal) {
        // calculate the signal on a padGroup
        // the signal is only made from the direct charge pulse
        // induced pulse are not included. Filtering (low and high pass) are applied
        // The amplitude units are scaled to values in mV.
        // Variations in preamp gain is included
        
        signal.clear();
        if (iPadGroup < 0 || iPadGroup >= getNumElement()) return false;
        
        // assume the induced pulses are significant only for pads horizontally
        // as far away as the transfer gap. This assumes the induction gap is
        // directly above this padMesh!
        
        double driftTime = 1.;
        if (partAbove !=null) {
            driftTime = Math.max(1.,partAbove.thickness/partAbove.vDrift*1000.);
        }
        
        int[][] padGroup = getPadGroup();
        int nPadInGroup = padGroup[iPadGroup].length;
        for (int i = 0; i < nPadInGroup; i++) {
            int iPad = padGroup[iPadGroup][i];
            // direct pulses:
            Cluster cluster = pad[iPad].firstCluster;
            while (cluster != null){
                signal.addDirect(cluster, driftTime);
                cluster = cluster.nextCluster;
            }
        }
        signal.filter();
        signal.applyGain(iPadGroup);
        return true;
    }
    
}