package tpcsimulator;

/** Holds information about signals on pads
 * @author Dean Karlen
 * @version 1.0
 */

public class Signal {
    
    static final double sqrtPi = Math.sqrt(Math.PI);
    static final double sqrt2 = Math.sqrt(2.);
    
/** Number of time bins for signal
 */
    public int nBin;
/** Low edge of first bin of signal (ns)
 */
    public double low;
/** High edge of last bin of signal (ns)
 */
    public double high;
/** Bin width (ns)
 */
    public double delta;
/** Signal data
 */
    public double data[];
    
    PreAmp preAmp;

/** Constructor
 * @param nBin Number of bins
 * @param low Low edge (ns)
 * @param high High edge (ns)
 */
    public Signal(int nBin, double low, double high, PreAmp preAmp) {
        this.nBin = nBin;
        this.low = low;
        this.high = high;
        this.preAmp = preAmp;
        delta = (high-low)/nBin;
        data = new double[nBin];
        clear();
    }
/** reset signal to zero
 */
    public void clear() {
        for (int i=0; i<nBin; i++){
            data[i]=0.;
        }
    }
    
    void filter() {
        if (!preAmp.isGeneric()) return; // only do filtering for generic preamp
        double tRise = (double) preAmp.riseTime;
        double tFall = (double) preAmp.fallTime;
        double alpha = tRise / (tRise + delta);
        double beta = tFall / (tFall + delta);
        // low pass filter (tRise):
        for (int i = 1; i < nBin; i++) {
            data[i] = alpha*data[i-1] + (1.-alpha)*data[i];
        }
        // high pass filter (tFall):
        double prev = data[0];
        for (int i = 1; i < nBin; i++) {
            double save = data[i];
            data[i] = beta*data[i-1] + beta*(data[i]-prev);
            prev = save;
        }
    }
    
    void applyGain() {
        double scale = preAmp.gain*1.6E-4; //  conversion: mV / electron
        for (int i = 1; i < nBin; i++) {
            data[i] = scale*data[i];
        }
    }
    
    void applyGain(int iChan) {
        double scale = preAmp.getGain(iChan)*1.6E-4; //  conversion: mV / electron
        for (int i = 1; i < nBin; i++) {
            data[i] = scale*data[i];
        }
    }
    
    void addCluster(Cluster cluster)
    {
        double denom = Math.sqrt(2.)*cluster.getSt();
        double t = cluster.getT();
        for (int iBin=0; iBin<nBin; iBin++){
            double tLow = low + iBin*delta;
            double tHigh = tLow + delta;
            double dist = Math.min(Math.abs(t-tLow),Math.abs(t-tHigh));
            if(dist<3.*denom || (t>tLow && t<tHigh)){
                data[iBin] += (cluster.n/2.)*Gaussian.erf((tHigh-t)/denom);
                data[iBin] -= (cluster.n/2.)*Gaussian.erf((tLow-t)/denom);
            }
        }
    }
    
    void addDirect(Cluster cluster, double driftTime) {
        double amplitude = (double) cluster.n;
        double arrivalTime = cluster.getT();
        double sigmaTime = cluster.getSt();
        double t = low - delta - arrivalTime + driftTime;
        for (int iBin = 0; iBin < nBin; iBin++) {
            t += delta;
            data[iBin] += amplitude*preAmp.directPulse(t, driftTime, sigmaTime);
        }
    }
    
    void addInduced(Cluster cluster, double driftTime, double padArea, double thickness, Location loc) {
        double r2 = Math.pow(loc.x - cluster.getX(),2.) + Math.pow(loc.y - cluster.getY(),2.);
        double amplitude = cluster.n*inducedScale(padArea, thickness, r2);
        double arrivalTime = cluster.getT();
        double sigmaTime = cluster.getSt();
        double t = low - delta - arrivalTime + driftTime;
        for (int iBin = 0; iBin < nBin; iBin++) {
            t += delta;
            data[iBin] += amplitude*inducedPulse(t, driftTime, sigmaTime);
        }
    }
    
    double inducedScale(double padArea, double thickness, double r2) {
        // work out relation for scale of induced pulse
        // strength = factor * f(r2 + th2/4) * area
        // the form is pretty much guesswork, inspired by data!
        double dist2 = r2 + thickness*thickness/4.;
        double strength = 0.15 * padArea / dist2;
        return strength;
    }
    
    double inducedPulse(double time, double driftTime, double sigmaT) {
        // shape of pulse due to induced pulse
        if(time < -5.*sigmaT || time > driftTime + 5.*sigmaT) return 0.;
        double t = time;
        double d = driftTime;
        double s = sigmaT;
        double term1,term2,term3;
        
        double arg = (d-t)/s/sqrt2;
        term1 = Math.exp(-1.*arg*arg) + Math.exp(-1.*t*t/s/s/2.);
        term3 = (d-t)*sqrtPi*Gaussian.erf(arg);
        term3 += t*sqrtPi*Gaussian.erf(t/s/sqrt2);
        arg = (d-2.*t)/s/2./sqrt2;
        term1 -= 2.*Math.exp(-1.*arg*arg);
        term1 *= sqrt2*s;
        term2 = (2.*t-d)*sqrtPi*Gaussian.erf(arg);
        double result = -1.*(term1+term2+term3)/d/sqrtPi;
        return result;
    }

}