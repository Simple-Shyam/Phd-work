package tpcsimulator;
import javax.swing.*;
import javax.swing.text.*;

import java.awt.Toolkit;
import java.text.*;
import java.io.Serializable;

class DecimalField extends JTextField {
    private NumberFormat format;
    
    DecimalField(double value, int columns, NumberFormat f) {
        super(columns);
        setDocument(new FormattedDocument(f));
        format = f;
        setValue(value);
        setHorizontalAlignment(JTextField.RIGHT);
    }
    
    double getValue() {
        double retVal = 0.0;
        
        try {
            retVal = format.parse(getText()).doubleValue();
        } catch (ParseException e) {
            // This should never happen because insertString allows
            // only properly formatted data to get in the field.
            Toolkit.getDefaultToolkit().beep();
            System.err.println("getValue: could not parse: " + getText());
        }
        return retVal;
    }
    
    void setValue(double value) {
        setText(format.format(value));
    }
}
