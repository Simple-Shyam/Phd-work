package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide panel to control Mesh layout options (pitch, number etc)
 * @author Dean Karlen
 * @version 1.0
 */

class MeshPanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField xpField,xnField,ynField,x0Field,y0Field;
    
    MeshPanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the pitch:
        xpField = new DecimalField(0, 5, numberFormat);
        xpField.setValue(lGP.meshLayout.getMeshPitch());
        xpField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.meshLayout.setPitch(xpField.getValue());
                lGP.square.setLength(xpField.getValue());
            }
        });
        JLabel xpLabel = new JLabel("pitch:");
        JLabel xpUnitLabel = new JLabel("mm");
        // code for the number:
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((lGP.meshLayout).nx);
        ynField.setValue((lGP.meshLayout).ny);
        xnField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.meshLayout).setNumber((int)xnField.getValue(),(lGP.meshLayout).ny);
                lGP.reset();
            }
        });
        ynField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.meshLayout).setNumber((lGP.meshLayout).nx,(int)ynField.getValue());
                lGP.reset();
            }
        });
        JLabel xnLabel = new JLabel("x number:");
        JLabel ynLabel = new JLabel("y number:");
        // code for the origin:
        x0Field = new DecimalField(0, 5, numberFormat);
        y0Field = new DecimalField(0, 5, numberFormat);
        x0Field.setValue((lGP.meshLayout).x0);
        y0Field.setValue((lGP.meshLayout).y0);
        x0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.meshLayout).setOrigin(x0Field.getValue(),(lGP.meshLayout).y0);
            }
        });
        y0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.meshLayout).setOrigin((lGP.meshLayout).x0,y0Field.getValue());
            }
        });
        JLabel x0Label = new JLabel("x origin:");
        JLabel y0Label = new JLabel("y origin:");
        JLabel x0UnitLabel = new JLabel("mm");
        JLabel y0UnitLabel = new JLabel("mm");
        
        // arrange into a grid
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xpLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xpField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(xpUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(x0Label);
        labelPane.add(y0Label);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(x0Field);
        fieldPane.add(y0Field);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(x0UnitLabel);
        unitPane.add(y0UnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
    void readPanel(){
        lGP.meshLayout.setPitch(xpField.getValue());
        lGP.square.setLength(xpField.getValue());
        lGP.meshLayout.setOrigin(x0Field.getValue(),lGP.meshLayout.y0);
        lGP.meshLayout.setOrigin(lGP.meshLayout.x0,y0Field.getValue());
        
        if((int)xnField.getValue() != lGP.meshLayout.nx ||
        (int)ynField.getValue() != lGP.meshLayout.ny){
            lGP.meshLayout.setNumber((int)xnField.getValue(),lGP.meshLayout.ny);
            lGP.meshLayout.setNumber(lGP.meshLayout.nx,(int)ynField.getValue());
            lGP.reset();
        }
    }
}
