package tpcsimulator;

public class Location {
    public double x,y;
}