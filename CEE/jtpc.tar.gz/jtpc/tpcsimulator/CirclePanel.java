package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Panel that controls circle options
 * @author Dean Karlen
 * @version 1.0
 */
class CirclePanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField rField;
/** Constructor
 * @param iLGP Tpc Part identifier
 */
    CirclePanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the radius:
        rField = new DecimalField(0, 5, numberFormat);
        rField.setValue((lGP.circle).r);
        rField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.circle).r=rField.getValue();
            }
        });
        JLabel rLabel = new JLabel("radius: ");
        JLabel rUnitLabel = new JLabel("mm");
        add(rLabel);
        add(rField);
        add(rUnitLabel);
    }
    void readPanel(){(lGP.circle).r=rField.getValue();}
}
