package tpcsimulator;
/** Foil Descriptor
 * @author Dean Karlen
 * @version 1.0
 */
class FoilDesc extends LayoutTpcPartDesc{
/** Gas gain of foil
 */
    double gain;
/** Collection efficiency of foil (probability of an electron to enter a TPC hole)
 */
    double collectionEfficiency;
/** Extraction efficiency of foil (probability of electrons to exit TPC)
 */
    double extractionEfficiency;
    
/** Constructor
 * @param name Foil name
 */
    FoilDesc(String name){
        this.name=name;
        
        // define a default foil
        // these can be modified after FoilDesc is created
        
        Circle foilHoleCircle = new Circle(0.05);
        Rectangle foilHoleRectangle = new Rectangle(0.1,0.1);
        Square foilHoleSquare = new Square(0.1);
        
        Grid foilHoleGrid = new Grid();
        foilHoleGrid.setPitch(0.15,0.15);
        foilHoleGrid.setOrigin(-15.,-15.);
        foilHoleGrid.setNumber(201,201);
        
        Mesh foilHoleMesh = new Mesh();
        foilHoleMesh.setPitch(0.15);
        foilHoleMesh.setOrigin(-15.,-15.);
        foilHoleMesh.setNumber(201,201);
        
        HexPack foilHoleHexPack = new HexPack();        
        foilHoleHexPack.setPitch(0.140);
        foilHoleHexPack.setOrigin(-15.,-15.);
        foilHoleHexPack.setNumber(215,215);
        
        //**************
        ShiftedGrid foilShiftedGrid = new ShiftedGrid();
        
        thickness=0.1;
        gain=100.;
        collectionEfficiency=1.0;
        extractionEfficiency=0.6;
        
        gridLayout=foilHoleGrid;
        meshLayout=foilHoleMesh;
        hexPackLayout=foilHoleHexPack;
        shiftedGridLayout = foilShiftedGrid;
        
        layout=foilHoleHexPack;
        
        circle=foilHoleCircle;
        rectangle=foilHoleRectangle;
        square=foilHoleSquare;
        
        foilHoleGrid.setShape(circle);
        foilHoleMesh.setShape(circle);
        foilHoleHexPack.setShape(circle);
        foilShiftedGrid.setShape(circle);
    }
}
