package tpcsimulator;

/** Volume of gas
 * @author Dean Karlen
 * @version 1.0
 */

public class GasGap extends TpcPart{
    
    static final long serialVersionUID = -561774458796978L;
    
    double transverseDiffusion,longitudinalDiffusion;
    double invLifetime = 0.;
    
    /** Constructor
     * @param desc Gas gap descriptor
     * @param tpc Gas Electron Multiplier
     */
    
    GasGap(GapDesc desc, Tpc tpc) {
        super(desc);
        this.tpc = tpc;
        vDrift = desc.vDrift;
        transverseDiffusion=desc.transverseDiffusion;
        longitudinalDiffusion=desc.longitudinalDiffusion;
        invLifetime=desc.invLifetime;
    }
    
    
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new GasGapPanel(this, tpcDesign);
    }
    
    /** Drift electron cloud through the gas gap according to the diffusion constants
     * @param electronCloud electron cloud to be transported
     */
    
    void propagateElectronCloud(ElectronCloud electronCloud){
        
        /* move an electron cloud through the Gas Gap, in essentially one large
         time step... one assumes that the drift lines are perpendicular to the
         tpc structure, so there is no need to make small steps */
        
        /* calculate the distance to the bottom of the gas gap */
        
        double driftDistance = electronCloud.z - zBottom;
        
        /* calculate the additional standard deviations due to diffusion */
        
        double addSZ = Math.sqrt(driftDistance*0.1)*longitudinalDiffusion/1000.;
        double addSXY = Math.sqrt(driftDistance*0.1)*transverseDiffusion/1000.;
        
        /* calculate the total standard deviations after diffusion */
        
        double sz = Math.sqrt(electronCloud.sz*electronCloud.sz + addSZ*addSZ);
        double sxy = Math.sqrt(electronCloud.sxy*electronCloud.sxy + addSXY*addSXY);
        
        /* calculate average time for centroid to reach bottom of gas gap */
        
        double tDrift = driftDistance/vDrift*1000.;
        
        /* calculate the number of electrons that survive the drift, and modify accordingly */
        
        if (invLifetime > 0.){
            double coeff = tDrift*invLifetime/1.E6;
            if (coeff<80.){
                double prob = Math.exp(-1.*coeff); // probability for an electron to survive the trip
                if (prob < 0.99){ // avoid waisting time attaching small fraction of electrons between GEMs etc.
                    int ne = electronCloud.n;
                    if (ne > 0){
                        int newne = binomialRandomNumber(ne,prob);
                        electronCloud.n = newne;
                    }
                }
            } else {
                electronCloud.n = 0;
            }
        }
        
        /* now smear this time - not needed!*/
        // double sigmaT = addSZ/vDrift*1000./sqrt(electronCloud.n);
        // tDrift += sigmaT*Gaussian.random();
        /* electron clouds entering the tpc near the bottom of a Gas gap can wind up with a negative tDrift: */
        // tDrift = Math.max(0.,tDrift);
        
        /* update the electron cloud data */
        
        electronCloud.sxy = sxy;
        electronCloud.sz = sz;
        electronCloud.z = zBottom;
        electronCloud.t += tDrift;
    }
    
    
    
    /** Return current drift velocity for electrons in TPC part
     * @return current drift velocity for electrons in TPC part (um/ns)
     */
    
    public double getTransverseDiffusion() {
        return transverseDiffusion;
    }
    
    public double getLongitudinalDiffusion() {
        return longitudinalDiffusion;
    }
    
    public int binomialRandomNumber(int n, double p){
        // follows description in PDG - but correctly!
        
        boolean swap = false;
        if (p>0.5){
            swap = true;
            p = 1. - p;
        }
        
        int r = 0;
        double u = tpc.random.nextDouble();
        double pk = Math.pow(1.-p,1.*n);
        double b = pk;
        while (u>b){
            pk *= p/(1-p)*(n-r)/(r+1);
            b += pk;
            r++;
        }
        
        if(swap) r = n - r;
        return r;
    }
}