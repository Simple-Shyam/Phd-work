package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide panel to control sym layout options: for pads only
 * @author Dean Karlen
 * @version 1.0
 */

class SymLayoutPanel extends JPanel {
    PadSymLayout pSL;
    PadSymLayoutPanel pSLP;
    DecimalField baseField,psField,xnField,ynField,xxField,yxField;
    JComboBox shapeComboBox;
    final static String SQUARES = "squares";
    final static String TRIANGLES = "triangles";
    
    SymLayoutPanel(PadSymLayout iPSL, PadSymLayoutPanel iPSLP){
        pSL = iPSL;
        pSLP = iPSLP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for symmetry number
        String[] list = {SQUARES,TRIANGLES};
        shapeComboBox = new JComboBox(list);
        shapeComboBox.setSelectedIndex(pSL.symLayout.symmetry-2);
        
        JLabel shapeLabel = new JLabel("Shape:");
        // code for the base size:
        baseField = new DecimalField(0, 5, numberFormat);
        baseField.setValue(pSL.symLayout.base);
        
        JLabel baseLabel = new JLabel("Base Size:");
        JLabel baseUnitLabel = new JLabel("mm");
        // code for the pixel size:
        psField = new DecimalField(0, 5, numberFormat);
        psField.setValue(pSL.symLayout.pixelSize);
        
        JLabel psLabel = new JLabel("Pixel Size:");
        JLabel psUnitLabel = new JLabel("mm");
        // code for the lower left corner
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((pSL.symLayout).xMin);
        ynField.setValue((pSL.symLayout).yMin);
        
        JLabel xnLabel = new JLabel("x_min (left):");
        JLabel ynLabel = new JLabel("y_min (bottom):");
        // code for the upper right corner
        xxField = new DecimalField(0, 5, numberFormat);
        yxField = new DecimalField(0, 5, numberFormat);
        xxField.setValue((pSL.symLayout).xMax);
        yxField.setValue((pSL.symLayout).yMax);
        
        JLabel xxLabel = new JLabel("x_max (right):");
        JLabel yxLabel = new JLabel("y_max (top):");
        JLabel xxUnitLabel = new JLabel("mm");
        JLabel yxUnitLabel = new JLabel("mm");
        
        // arrange into a grid
        
        JPanel shapePane = new JPanel();
        shapePane.setLayout(new GridLayout(0,1));
        shapePane.add(shapeLabel);
        shapePane.add(shapeComboBox);
        add(shapePane);
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(baseLabel);
        labelPane.add(psLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(baseField);
        fieldPane.add(psField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(baseUnitLabel);
        unitPane.add(psUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xxLabel);
        labelPane.add(yxLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xxField);
        fieldPane.add(yxField);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(xxUnitLabel);
        unitPane.add(yxUnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
 
    void readPanel(){
        // check for changes that could affect number of pads
        boolean changed = false;
        changed |= pSL.symLayout.symmetry != shapeComboBox.getSelectedIndex()+2;
        changed |= pSL.symLayout.base != baseField.getValue();
        changed |= pSL.symLayout.xMin != xnField.getValue();
        changed |= pSL.symLayout.yMin != ynField.getValue();
        changed |= pSL.symLayout.xMax != xxField.getValue();
        changed |= pSL.symLayout.yMax != yxField.getValue();
        boolean pixelChanged = pSL.symLayout.pixelSize != psField.getValue();
        
        pSL.symLayout.symmetry = shapeComboBox.getSelectedIndex()+2;
        pSL.symLayout.base = baseField.getValue();
        pSL.symLayout.pixelSize = psField.getValue();
        pSL.symLayout.xMin = xnField.getValue();
        pSL.symLayout.yMin = ynField.getValue();
        pSL.symLayout.xMax = xxField.getValue();
        pSL.symLayout.yMax = yxField.getValue();
        
        if(changed){
            pSL.symReset();
        }
        if(changed || pixelChanged) {
            pSLP.resetPadSymLayoutEventFrame();
        }
    }
}