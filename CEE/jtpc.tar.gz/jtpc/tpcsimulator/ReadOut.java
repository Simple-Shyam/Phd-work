package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;

/** Frame for readout contains preamps and oscilliscope
 * @author Dean Karlen
 * @version 1.0
 */
class ReadOut extends JFrame {
    PadArray padArray;
    PreAmpPanel preAmpPanel;
    PreAmp preAmp;
    JPanel mainPane;
    JScrollPane scrollPane;
    Scope scope;
    
    ReadOut(PadArray padArray){
        this.padArray=padArray;
        mainPane = new JPanel();
        mainPane.setLayout(new BoxLayout(mainPane, BoxLayout.Y_AXIS));
        
        scrollPane = new JScrollPane(mainPane);
        setContentPane(scrollPane);
        
        // setup default parameters for the PreAmp
        preAmp = new PreAmp(30,800,5.,false);
        // riseTime = 30; // ns
        // fallTime = 800; // ns
        // gain = 5; // mV/fC
        // induction = false; // by default do not include induced pulses
        
        preAmpPanel = new PreAmpPanel(preAmp);
        scope = new Scope(this,padArray);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
    }
    
    void drawReadOut(){
        mainPane.removeAll();
        mainPane.add(preAmpPanel);
        mainPane.add(scope);
        
        pack();
    }
    
    public String toString(){return getTitle();}
    
}