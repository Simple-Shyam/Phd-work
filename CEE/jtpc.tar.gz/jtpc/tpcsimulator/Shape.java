package tpcsimulator;
/** Abstract class for generic shapes (circle, rectangle)
 * @author Dean Karlen
 * @version 1.1
 */
import java.io.*;
import java.awt.*;
abstract public class Shape implements Serializable{

    // the following methods must be implemented when extending this class
    abstract void getNearestEdge(double x0, double y0, double x, double y, Location loc);
    // returns location of edge of shape centred at x0,y0 nearest to x,y
    abstract boolean insideElement(double x0, double y0, double x, double y);
    // true if (x,y) is inside shape centred at (x0,y0)
    abstract double getSize();
    // returns the characteristic size of the object (like radius)
    
}