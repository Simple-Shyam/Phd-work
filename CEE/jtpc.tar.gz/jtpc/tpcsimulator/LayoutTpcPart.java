package tpcsimulator;

/** generic class of TpcParts that are layed out in a pattern (foil holes and pads)

 * @author Dean Karlen

 * @version 1.0

 */



public abstract class LayoutTpcPart extends TpcPart {
    
    static final long serialVersionUID = -8346813764093086930L;

    TwoDimenLayout layout;

    Grid gridLayout;

    Mesh meshLayout;

    HexPack hexPackLayout;

    ShiftedGrid shiftedGridLayout;

    RowLayout rowLayout;
    
    SymLayout symLayout;

    

    Circle circle;

    Rectangle rectangle;

    Square square;

    

    LayoutTpcPart(LayoutTpcPartDesc lTPD){

        super(lTPD);

        layout = lTPD.layout;

        gridLayout = lTPD.gridLayout;

        meshLayout = lTPD.meshLayout;

        hexPackLayout = lTPD.hexPackLayout;

        shiftedGridLayout = lTPD.shiftedGridLayout;

        rowLayout = lTPD.rowLayout;

        symLayout = lTPD.symLayout;
        
        circle = lTPD.circle;

        rectangle = lTPD.rectangle;

        square = lTPD.square;

    }

    abstract void reset(); // called when number of elements change in layout

    

    public TwoDimenLayout getLayout() {return layout;}

}

