package tpcsimulator;
import java.util.Vector;

/** A Pad Sym Layout is a special type of PadMesh. This layout has a rotational symmetry.
 *  - two shapes are implemented: squares and equilateral triangles
 */
public class PadSymLayout extends PadMesh {
    
    //freeze version at some point:
    static final long serialVersionUID = -3613438524102028974L;
    
    private double[] lgPadGroup; // sum of the integrals of the linear Gaussian for all Pads in a group
    
    PadSymLayout(PadDesc desc, Tpc tpc){
        super(desc, tpc);
        fittable = true;
        
        layout = symLayout;
        
        symReset();
    }
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new PadSymLayoutPanel(this, tpcDesign);
    }
    
    public PadMeshEventFrame getEventFrame() {
        return new PadSymLayoutEventFrame(this);
    }
    
    public int getNY(){return layout.getNY();}
    
    void symReset() {
        reset();
        int nPadGroup = layout.getNumElement();
        int[][] padGroup = new int[nPadGroup][1];
        for (int i=0; i< nPadGroup; i++) padGroup[i][0]=i;
        setPadGroup(nPadGroup,padGroup);
    }
    
    void recalc() {
        // to be called whenever layout is changed...
        nRow = symLayout.getNRow();
        int nPadGroup = layout.getNumElement();
        if (nPadGroup == 0) return;
        
        lgPadGroup = new double[nPadGroup];
        padGroupEnabled = new boolean[nPadGroup];
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) padGroupEnabled[iPadGroup] = true;
        
        padGroupInRow = symLayout.getPadGroupInRow();
        
    }
    
    final static double sqrt2 = Math.sqrt(2.);
    final static double sqrt3 = Math.sqrt(3.);
    final static double s2p = Math.sqrt(2.*Math.PI);
    
    double eta(double u, double s) {
        return (u/2.)*Gaussian.erf(u/sqrt2/s) +
        (s/s2p)*Math.exp(Math.max(-100.,-u*u/2./s/s));
    }
    
    void calcLinearGaussianSquare(double[] param) {
        // calculate the integral of the linear Gaussian over the square pads
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        double cosp0 = Math.cos(param[1]);
        
        double sigma = param[2];
        
        int nPadGroup = layout.getNumElement();
        int[][] padGroup = getPadGroup();
        double dx = symLayout.getDX();
        double dy = symLayout.getDY();
        Location loc = new Location();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            lgPadGroup[iPadGroup] = 0.;
            // for backward compatibility: do not assume padGroupEnabled exists
            if (padGroupEnabled == null || padGroupEnabled[iPadGroup]) {
                int nPadInGroup = padGroup[iPadGroup].length;
                for (int iPadInGroup = 0; iPadInGroup < nPadInGroup; iPadInGroup++) {
                    int iPad = padGroup[iPadGroup][iPadInGroup];
                    
                    symLayout.getCentre(iPad,loc);
                    double xp = loc.x;
                    double yp = loc.y;
                    
                    if (sigmaSlope != 0.){
                        double sig2 = param[2]*param[2]+sigmaSlope*dzdy*yp;
                        if (sig2 > 0.) sigma = Math.sqrt(sig2);
                        else sigma = 0.001;
                    }
                    
                    // Calculate the integral of a line charge with global track parameters
                    // BG,PHI, and transverse width SIGMA through a rectangular pad of width
                    // DX and height DY centred at XP,YP
                    
                    // check if necessary to do expandsion in 1/r:
                    double b = 0;
                    if(Math.abs(yp*param[3])<0.001){
                        double coeff1 = yp*yp/2./cosp0/cosp0/cosp0;
                        double coeff2 = coeff1*yp*sinp0/cosp0/cosp0;
                        b = param[0] - xp - yp*sinp0/cosp0 + coeff1*param[3] - coeff2*param[3]*param[3];
                    } else {
                        double alpha = (2.*sinp0-yp*param[3])*yp*param[3]/cosp0/cosp0;
                        b = param[0] - xp + cosp0/param[3]*(1.-Math.sqrt(1.+alpha));
                    }
                    
                    double sinp = sinp0 - yp*param[3];
                    sinp = Math.min(0.999,Math.max(-0.999,sinp));
                    double cosp = Math.sqrt(1.-sinp*sinp);
                    double a1 = b * cosp;
                    double a2 = (dx / 2.) * cosp;
                    double a3 = (dy / 2.) * sinp;
                    
                    double tpcchr = eta(a1+a2+a3,sigma) - eta(a1+a2-a3,sigma)
                    + eta(a1-a2-a3,sigma) - eta(a1-a2+a3,sigma);
                    tpcchr /= sinp*cosp;
                    
                    lgPadGroup[iPadGroup] += Math.abs(tpcchr);
                    
                }
            }
        }
    }
    
    void calcLinearGaussianTriangle(double[] param) {
        // calculate the integral of the linear Gaussian over the triangular pads
        double w = symLayout.base;
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        double cosp0 = Math.cos(param[1]);
        
        double sigma = param[2];
        
        int nPadGroup = layout.getNumElement();
        int[][] padGroup = getPadGroup();
        Location loc = new Location();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            lgPadGroup[iPadGroup] = 0.;
            // for backward compatibility: do not assume padGroupEnabled exists
            if (padGroupEnabled == null || padGroupEnabled[iPadGroup]) {
                int nPadInGroup = padGroup[iPadGroup].length;
                for (int iPadInGroup = 0; iPadInGroup < nPadInGroup; iPadInGroup++) {
                    int iPad = padGroup[iPadGroup][iPadInGroup];
                    
                    symLayout.getCentre(iPad,loc);
                    double xp = loc.x;
                    double yp = loc.y;
                    boolean up = symLayout.isUp(iPad);
                    
                    if (sigmaSlope != 0.){
                        double sig2 = param[2]*param[2]+sigmaSlope*dzdy*yp;
                        if (sig2 > 0.) sigma = Math.sqrt(sig2);
                        else sigma = 0.001;
                    }
                    
                    // Calculate the integral of a line charge with global track parameters
                    // BG,PHI, and transverse width SIGMA through an equilateral pad of base w
                    // centred at XP,YP (pointing up or down).
                    
                    // check if necessary to do expandsion in 1/r:
                    double b = 0;
                    if(Math.abs(yp*param[3])<0.001){
                        double coeff1 = yp*yp/2./cosp0/cosp0/cosp0;
                        double coeff2 = coeff1*yp*sinp0/cosp0/cosp0;
                        b = param[0] - xp - yp*sinp0/cosp0 + coeff1*param[3] - coeff2*param[3]*param[3];
                    } else {
                        double alpha = (2.*sinp0-yp*param[3])*yp*param[3]/cosp0/cosp0;
                        b = param[0] - xp + cosp0/param[3]*(1.-Math.sqrt(1.+alpha));
                    }
                    
                    double sinp = sinp0 - yp*param[3];
                    sinp = Math.min(0.999,Math.max(-0.999,sinp));
                    double cosp = Math.sqrt(1.-sinp*sinp); // we assume -pi < phi < pi
                    if(!symLayout.isUp(iPad))sinp*=-1.; // downward pointing triangle: phi -> -phi
                    
                    double sinpp6 = (sqrt3*sinp + cosp)/2.; // sin(phi+pi/6)
                    double sinpm6 = (sqrt3*sinp - cosp)/2.; // sin(phi-pi/6)
                    
                    double tpcchr = eta((b+w/4.)*cosp+w/2.*sinpp6,sigma)*sinpm6
                    - eta((b-w/4.)*cosp+w/2.*sinpm6,sigma)*sinpp6
                    + eta(-b*cosp+sqrt3/4.*w*sinp,sigma)*cosp;
                    
                    tpcchr /= 2./sqrt3*cosp*(sqrt3/2.-cosp)*(sqrt3/2.+cosp);
                    
                    lgPadGroup[iPadGroup] += Math.abs(tpcchr);
                    
                }
            }
        }
    }
    
    public double calcLogLikelihood(double[] param, double totGain, double pNoise, int[] fitRows) {
        
        // calculate the log likelihood of the observed fractions
        
        double lnlike =0.;
        
        // calculate the integral of the linear Gaussian for all pad groups
        if (symLayout.symmetry == 2){
            calcLinearGaussianSquare(param);
        } else {
            calcLinearGaussianTriangle(param);
        }
        
        // for each row, calculate the relative charge fractions in each pad group
        // and compare to observed signals
        
        for (int iR = 0; iR < fitRows.length; iR++) {
            int iRow = fitRows[iR];
            int nPadGroupInRow = padGroupInRow[iRow].length;
            
            // Calculate the charge fractions in the row
            double calcCharge[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                calcCharge[iPadGroupInRow] = 0.;
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                calcCharge[iPadGroupInRow] = lgPadGroup[iPadGroup];
            }
            double totCharge = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                totCharge += calcCharge[iPadGroupInRow];
            }
            if (totCharge > 0.){
                for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                    calcCharge[iPadGroupInRow] /= totCharge;
                }
            }
            
            // get the estimated number of primary electrons sampled by each pad
            double rElectron[] = new double[nPadGroupInRow];
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                int iPadGroup = padGroupInRow[iRow][iPadGroupInRow];
                int nElectron = getNElectron(iPadGroup);
                rElectron[iPadGroupInRow] = nElectron / totGain;
            }
            
            // work out the contribution to the log likelihood
            double lnl = 0.;
            for (int iPadGroupInRow = 0; iPadGroupInRow < nPadGroupInRow; iPadGroupInRow++) {
                if (rElectron[iPadGroupInRow]>0) lnl += rElectron[iPadGroupInRow]
                * Math.log((calcCharge[iPadGroupInRow] + pNoise + 1.E-8) /
                (1.+nPadGroupInRow*pNoise));
            }
            
            lnlike += lnl;
            
        }
        return lnlike;
    }
    
    public double getBValue(double[] param, int iRow) {
        // work out the b value (local x coordinate in pad over which track passes)
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        double cosp0 = Math.cos(param[1]);
        
        double dy = symLayout.getDY();
        double yp = symLayout.getY0() + dy*iRow;
        
        double coeff1 = yp*yp/2./cosp0/cosp0/cosp0;
        double coeff2 = coeff1*yp*sinp0/cosp0/cosp0;
        double x = param[0] - yp*sinp0/cosp0 + coeff1*param[3] - coeff2*param[3]*param[3];
        
        Location loc = new Location();
        symLayout.getNearestCentre(x,yp,loc);
        
        return x-loc.x;
    }
    
    public double getTransverseTrackLength(double[] param, int iRow) {
        // work out the transverse track length in the row
        
        // Prevent divide by zero:
        double sinp0 = Math.sin(param[1]);
        if (Math.abs(sinp0) < 1.E-8) sinp0 = 1.E-8;
        
        double dy = symLayout.getDY();
        double yp = symLayout.getY0() + dy*iRow;
        
        double sinp = sinp0 - yp*param[3];
        sinp = Math.min(0.999,Math.max(-0.999,sinp));
        double phi = Math.asin(sinp);
        
        // get the orientation of the row with respect to horizontal:
        double rowAngle = symLayout.getRowAngle(iRow);
        
        return dy/Math.abs(Math.cos(sinp-rowAngle));
    }
    
    public double[][] getYZData() {
        // return an array of yz points for all rows
        
        int nYRow = symLayout.getNY();
        double[][] yzPoints = new double[nYRow][2];
        
        for (int iRow = 0; iRow < nYRow; iRow++) {
            int nPadGroupInRow = padGroupInRow[iRow].length;
            double time = -1.;
            int iPG = 0;
            while (time < 0. && iPG < nPadGroupInRow) {
                int iPadG = padGroupInRow[iRow][iPG];
                if (getNElectron(iPadG) > 0) {
                    time = getTime(iPadG);
                }
                iPG++;
            }
            yzPoints[iRow][0] = symLayout.getY0() + symLayout.getDY()*iRow;
            yzPoints[iRow][1] = time;
        }
        return yzPoints;
    }
    
    public boolean getPadSignal(int iPadGroup, Signal signal) {
        // calculate the signal on a padGroup
        // the signal is only made from the direct charge pulse
        // induced pulse are not included. Filtering (low and high pass) are applied
        // The amplitude units are scaled to values in mV.
        // Variations in preamp gain is included
        
        signal.clear();
        if (iPadGroup < 0 || iPadGroup >= getNumElement()) return false;
        
        // assume the induced pulses are significant only for pads horizontally
        // as far away as the transfer gap. This assumes the induction gap is
        // directly above this padMesh!
        
        double driftTime = 1.;
        if (partAbove !=null) {
            driftTime = Math.max(1.,partAbove.thickness/partAbove.vDrift*1000.);
        }
        
        int[][] padGroup = getPadGroup();
        int nPadInGroup = padGroup[iPadGroup].length;
        for (int i = 0; i < nPadInGroup; i++) {
            int iPad = padGroup[iPadGroup][i];
            // direct pulses:
            Cluster cluster = pad[iPad].firstCluster;
            while (cluster != null){
                signal.addDirect(cluster, driftTime);
                cluster = cluster.nextCluster;
            }
        }
        signal.filter();
        signal.applyGain(iPadGroup);
        return true;
    }
    
}