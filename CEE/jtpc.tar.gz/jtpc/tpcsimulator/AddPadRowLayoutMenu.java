package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Provides menu to allow a Pad Row Layout to be added to the TPC. Note that
 * the pads can be added at any location in order to readout the electron
 * signals. Electrons pass through these "virtual" pads.
 * @author Dean Karlen
 * @version 1.0
 */
class AddPadRowLayoutMenu extends JFrame{
    
    TpcGui tpcGui;
    JTextField nameField;
    JComboBox comboBox;
    AboveBelowComboBox abBox;
/** Constructor
 * @param iTpc Gas Electron Multiplier
 */
    AddPadRowLayoutMenu(TpcGui iTpcGui){
        super("Add a Pad Row-Layout");
        tpcGui = iTpcGui;
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(new JLabel("Name:"));
        labelPane.add(new JLabel(" "));
        labelPane.add(new JLabel(" "));
        
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        nameField = new JTextField(20);

        abBox = new AboveBelowComboBox();
        comboBox = new JComboBox();
        
        TpcPart tpcPart = tpcGui.tpc.topPart;
        while (tpcPart != null){
            comboBox.addItem(tpcPart);
            tpcPart = tpcPart.partBelow;
        }        
        
        fieldPane.add(nameField);
        fieldPane.add(abBox);
        fieldPane.add(comboBox);
        
        getContentPane().add(labelPane, BorderLayout.WEST);
        getContentPane().add(fieldPane, BorderLayout.CENTER);
        
        JButton cancelButton = new JButton("Cancel");
        JButton okButton = new JButton("Ok");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cancelButton);
        buttonPanel.add(okButton);
        
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                TpcPart tpcPart = (TpcPart) comboBox.getSelectedItem();
                PadDesc padDesc = new PadDesc(name);
                PadRowLayout padRowLayout = new PadRowLayout(padDesc,tpcGui.tpc);
                tpcGui.tpc.insertPart(padRowLayout,tpcPart,abBox.isAbove());
                tpcGui.tpcDesign.drawTpc();
                setVisible(false);
            }
        });
    }
}
