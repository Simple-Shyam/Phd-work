package tpcsimulator;
/** TPC Simulation Package
 * @author Dean Karlen
 * @version 1.0
 */

public class Interactive {
/** Constructor
 */
    public Interactive(){
        
        // construct the GUI (Command menu)
        TpcGui tpcGui = new TpcGui();
        tpcGui.createDefaultTpc();
        tpcGui.setTitle("TPC Simulation Package");
        tpcGui.setSize(450,260);
        tpcGui.show();
        
    }
    
/** Main program
 * @param args Arguments
 */
    public static void main(String[] args){
        new Interactive();
    }
}
