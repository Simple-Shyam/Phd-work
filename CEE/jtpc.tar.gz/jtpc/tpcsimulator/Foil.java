package tpcsimulator;

/** A thin sheet perforated with holes that provides the gas multiplication
 *
 * @author Dean Karlen
 * @version 1.0
 */

public class Foil extends LayoutTpcPart{
    
    static final long serialVersionUID = -8620615658230950693L;
    double gain,collectionEfficiency,extractionEfficiency;
    
    /** Constructor
     * @param desc Description of foil
     * @param tpc Time Projection Chamber
     */
    Foil(FoilDesc desc, Tpc tpc) {
        super(desc);
        this.tpc = tpc;
        gain = desc.gain;
        collectionEfficiency = desc.collectionEfficiency;
        extractionEfficiency = desc.extractionEfficiency;
    }
    
    TpcPartPanel newPanel(TpcDesign tpcDesign) {
        return new FoilPanel(this, tpcDesign);
    }
    
    /** no operation
     */
    void reset(){}
    
    /** propogate an electron cloud through the foil
     */
    void propagateElectronCloud(ElectronCloud electronCloud){
        double effectiveGain = Math.abs(gain)*extractionEfficiency;
        if (collectionEfficiency*extractionEfficiency*Math.abs(gain) > 0.) {
            /* turn cloud into individual electrons */
            for (int i = 0; i < electronCloud.n; i++) {
                /* only consider electrons that get into the GEM hole */
                if(collectionEfficiency >= 1. ||
                tpc.random.nextDouble() > collectionEfficiency) {
                    int n = 0;
                    if (gain < 0.) {
                        /* work out the number of electrons in the new cloud (Poisson) */
                        // Poisson is probably not a good approximation...
                        if (effectiveGain > 6) {
                            n = (int) (effectiveGain + Math.sqrt(effectiveGain)*tpc.random.nextGaussian() + 0.5);
                        } else {
                            int k = 0;
                            double A = 1.;
                            double con = Math.exp(-1.*effectiveGain);
                            while (A > con) {
                                k++;
                                A*=tpc.random.nextDouble();
                            }
                            n = k - 1;
                        }
                    } else {
                        /* Exponential gain: */
                        //
                        n = (int) (-1.*effectiveGain*Math.log(tpc.random.nextDouble()));
                        //
                    }
                    if (n > 0) {
                        /* work out coordinates of new electron Cloud */
                        double x = electronCloud.x +
                        electronCloud.sxy*tpc.random.nextGaussian();
                        double y = electronCloud.y +
                        electronCloud.sxy*tpc.random.nextGaussian();
                        Location loc = new Location();
                        layout.getNearestCentre(x,y,loc);
                        ElectronCloud newCloud = new ElectronCloud();
                        newCloud.n = n;
                        newCloud.x = loc.x;
                        newCloud.y = loc.y;
                        newCloud.z = zBottom;
                        newCloud.sxy = layout.getShape().getSize();
                        newCloud.sz = thickness;
                        newCloud.t = electronCloud.t;
                        // modification: June 21, 2005 by DK:
                        // add variation in times for electrons given longitudinal diffusion
                        if (partAbove !=null)
                            newCloud.t += electronCloud.sz*tpc.random.nextGaussian()/partAbove.vDrift*1000.;
                        // end of modification: June 21, 2005 by DK
                        newCloud.idPrimary = electronCloud.idPrimary;
                        tpc.addElectronCloud(newCloud,partBelow);
                    }
                }
            }
        }
        /* disband the original cloud that entered the foil */
        electronCloud.n = 0;
    }
}
