package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class PadArrayPanel extends TpcPartPanel {
    
    LayoutPanel layoutPanel;
    ShapePanel shapePanel;
    ReadOut readOut;
    StatsWindow statsWindow;
    PadArray padArray;
    
    /* need this for some reason */
    PadArrayPanel() {}
    
    /** Creates new PadArrayPanel */
    PadArrayPanel(PadArray padArray, TpcDesign tpcDesign) {
        this.padArray = padArray;
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Pad Array: " + padArray.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Layout of the Pad Array:
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new BoxLayout(selectionPanel, BoxLayout.Y_AXIS));
        JPanel cbp = new JPanel();
        layoutPanel = new LayoutPanel(padArray,cbp);
        JLabel cbpLabel = new JLabel("Pad Array layout:");
        cbpLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        selectionPanel.add(cbpLabel);
        selectionPanel.add(cbp);
        add(selectionPanel, BorderLayout.WEST);
        add(layoutPanel,BorderLayout.CENTER);
        // Shape of the Pads:
        JPanel selectShapePanel = new JPanel();
        JPanel cbpShape = new JPanel();
        shapePanel = new ShapePanel(padArray,cbpShape);
        JLabel cbpShapeLabel = new JLabel("Pad shape:");
        selectShapePanel.add(cbpShapeLabel);
        selectShapePanel.add(cbpShape);
        selectShapePanel.add(shapePanel);
        add(selectShapePanel,BorderLayout.SOUTH);
        
        createAssociatedWindows();
    }
    
    void createAssociatedWindows() {
        // connect a ReadOut system to these pads
        readOut = new ReadOut(padArray);
        readOut.setTitle("Electronics for " + padArray.name);
        readOut.drawReadOut();
        readOut.setVisible(false);
        
        // create a statistics window
        statsWindow = new StatsWindow(this);
        statsWindow.setTitle("Statistics for " + padArray.name);
        statsWindow.drawStatsWindow();
        statsWindow.setVisible(false);
        
    }
    
    void readPanel(){
        if (layoutPanel != null)layoutPanel.readPanel();
        if (shapePanel != null)shapePanel.readPanel();
    }
    
    int nWindow(){return 2;}
    JFrame window(int i) {
        if(i==1){
            return readOut;
        } else {
            return statsWindow;
        }
    }
    
    void clear(boolean runSum) {
        padArray.clear();
        if(runSum) {
            statsWindow.clear();
            statsWindow.pack();
        }
    }
    
    void delete() {
        readOut.setVisible(false);
        statsWindow.setVisible(false);
        readOut=null;
        statsWindow=null;
    }
    
    void doCalc(boolean runSum) {
        statsWindow.doCalc(runSum);
    }
    
}
