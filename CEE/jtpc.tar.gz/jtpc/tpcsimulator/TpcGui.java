package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/** Frame for main command menus
 * @author Dean Karlen
 * @version 1.0
 */

public class TpcGui extends JFrame{
    JTextArea output;
    JScrollPane scrollPane;
    String newline = "\n";
    Tpc tpc;
    TpcDesign tpcDesign = null;
    AddCloudMenu addCloudMenu;
    AddCloudsMenu addCloudsMenu;
    AddTrackMenu addTrackMenu;
    RunMenu runMenu;
    File dir = null;
    AboutFrame aboutFrame;
    
/** Constructor
 * @param iTpc Gas Electron Multiplier
 */
    TpcGui(){
        JMenuBar menuBar;
        JMenu menu, submenu;
        JMenuItem menuItem;
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
        //Add regular components to the window, using the default BorderLayout.
        Container contentPane = getContentPane();
        output = new JTextArea(5, 30);
        output.setEditable(false);
        scrollPane = new JScrollPane(output);
        contentPane.add(scrollPane, BorderLayout.CENTER);
        
        //Create the menu bar.
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        //Build the first menu
        menu = new JMenu("File");
        menuBar.add(menu);
        
        menuItem = new JMenuItem("Exit");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        menu.add(menuItem);
        
        //Build the second menu
        menu = new JMenu("TPC");
        menuBar.add(menu);
        
        // Build the New submenu
        submenu = new JMenu("New");
        
        // a new blank TPC
        menuItem = new JMenuItem("Blank TPC");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tpc = new Tpc();
                createDesignWindow();
                output.append("Blank TPC created" + newline);
            }
        });
        submenu.add(menuItem);
        
        // the default TPC
        menuItem = new JMenuItem("Default TPC");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createDefaultTpc();
            }
        });
        submenu.add(menuItem);
        
        menu.add(submenu);
        
        //NEW CODE AS OF MAY 15
        menuItem = new JMenuItem("Open...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //implementing object serialization
                //initialization of open dialog
                JFileChooser chooser = new JFileChooser();
                ExampleFileFilter filter = new ExampleFileFilter();
                filter.addExtension("tpc");
                filter.setDescription("TPC files");
                chooser.setFileFilter(filter);
                if (dir != null) chooser.setCurrentDirectory(dir);
                File afile;
                //**********
                int returnVal = chooser.showOpenDialog(TpcGui.this);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    afile= chooser.getSelectedFile();
                    dir = afile.getParentFile();
                    try {
                        if (afile.getName().length() > 0) {
                            FileInputStream in = new FileInputStream(afile);
                            ObjectInputStream object = new ObjectInputStream(in);
                            tpc = (Tpc)object.readObject();
                            object.close();
                            output.append("Opened file " + afile.getAbsolutePath()+newline);
                            createDesignWindow();
                            tpcDesign.doCalc(false);
                        }
                    }
                    catch (IOException except) {
                        output.append("Could not read file" + newline);
                        except.printStackTrace();
                    }
                    catch (ClassNotFoundException except2) {
                        output.append("Improper data" + newline);
                    }
                }
            }
        });
        menu.add(menuItem);
        
        menuItem = new JMenuItem("Save as...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //implementing object serialization
                //initialization of save dialog
                JFileChooser chooser = new JFileChooser();
                ExampleFileFilter filter = new ExampleFileFilter();
                filter.addExtension("tpc");
                filter.setDescription("TPC files");
                chooser.setFileFilter(filter);
                if (dir != null) chooser.setCurrentDirectory(dir);
                String fileName = "";
                //**********
                int returnVal = chooser.showSaveDialog(TpcGui.this);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    fileName = chooser.getSelectedFile().getAbsolutePath();
                    dir = chooser.getSelectedFile().getParentFile();
                    if (!fileName.endsWith(".tpc"))
                        fileName= fileName+".tpc";
                    try {
                        if (fileName.length() > 0) {
                            FileOutputStream in = new FileOutputStream(fileName);
                            ObjectOutputStream iobject = new ObjectOutputStream(in);
                            iobject.writeObject(tpc);
                            iobject.flush();
                            iobject.close();
                            output.append("Saved file to " + fileName + newline);
                            
                /*This saves the file to the forte directory no matter what
                 directory you choose. */
                        }
                        else
                            output.append("didn't work"+ newline);
                    }
                    catch (IOException except) {
                        except.printStackTrace();
                        output.append(except.getMessage() + newline);
                        output.append("Could not write file" + newline);
                    }
                }
            }
        });
        menu.add(menuItem);
        //**************************
        
        //Build the add submenu
        submenu = new JMenu("Add Part");
        
        menuItem = new JMenuItem("GEM Foil...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddFoilMenu addFoilMenu = new AddFoilMenu(TpcGui.this);
                addFoilMenu.pack();
                addFoilMenu.setVisible(true);
            }
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Gas Gap...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddGasGapMenu addGasGapMenu = new AddGasGapMenu(TpcGui.this);
                addGasGapMenu.pack();
                addGasGapMenu.setVisible(true);
            }
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Pad Array...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddPadMenu addPadMenu = new AddPadMenu(TpcGui.this);
                addPadMenu.pack();
                addPadMenu.setVisible(true);
            }
        });       
        submenu.add(menuItem);

        menuItem = new JMenuItem("Pad Mesh...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddPadMeshMenu addPadMeshMenu = new AddPadMeshMenu(TpcGui.this);
                addPadMeshMenu.pack();
                addPadMeshMenu.setVisible(true);
            }
        });
        submenu.add(menuItem);

        menuItem = new JMenuItem("Pad Row-Layout...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddPadRowLayoutMenu addPadRowLayoutMenu = new AddPadRowLayoutMenu(TpcGui.this);
                addPadRowLayoutMenu.pack();
                addPadRowLayoutMenu.setVisible(true);
            }
        });
        submenu.add(menuItem);
        
        menuItem = new JMenuItem("Pad Sym-Layout...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddPadSymLayoutMenu addPadSymLayoutMenu = new AddPadSymLayoutMenu(TpcGui.this);
                addPadSymLayoutMenu.pack();
                addPadSymLayoutMenu.setVisible(true);
            }
        });
        submenu.add(menuItem);

        menu.add(submenu);
        
        //Build the delete item
        menuItem = new JMenuItem("Delete Part...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteTpcPartMenu deleteTpcPartMenu = new DeleteTpcPartMenu(TpcGui.this);
                deleteTpcPartMenu.pack();
                deleteTpcPartMenu.setVisible(true);
            }
        });
        menu.add(menuItem);
        
        menuItem = new JMenuItem("Design TPC");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tpcDesign.setVisible(true);
                tpcDesign.setState(JFrame.NORMAL);
            }
        });
        menu.add(menuItem);
        
        //Build the third menu
        menu = new JMenu("Action");
        menuBar.add(menu);
        
        menuItem = new JMenuItem("Clear");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tpcDesign.clear(true);
            }
        });
        menu.add(menuItem);
        
        //the addCloud menu awaits to be displayed (rather than a new one each time)
        addCloudMenu = new AddCloudMenu(this);
         
        menuItem = new JMenuItem("Add Electron Cloud...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addCloudMenu.setVisible(true);
            }
        });
        menu.add(menuItem);     
                
        //the addClouds menu awaits to be displayed (rather than a new one each time)
        addCloudsMenu = new AddCloudsMenu(this);
         
        menuItem = new JMenuItem("Add Electron Clouds...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addCloudsMenu.setVisible(true);
            }
        });
        menu.add(menuItem);    
        
        //the addTrack menu awaits to be displayed (rather than a new one each time)
        addTrackMenu = new AddTrackMenu(this);      
        menuItem = new JMenuItem("Add Track...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addTrackMenu.setVisible(true);
            }
        });
        menu.add(menuItem);
        
        //the Run menu awaits to be displayed (rather than a new one each time)
        runMenu = new RunMenu(this);
         
        menuItem = new JMenuItem("Run...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                runMenu.setVisible(true);
            }
        });
        menu.add(menuItem);
        
        //Build the fourth menu
        menu = new JMenu("Window");
        menuBar.add(menu);
        
        //Build the view window
        menuItem = new JMenuItem("View window...");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ViewWindowMenu viewWindowMenu = new ViewWindowMenu(TpcGui.this);
                viewWindowMenu.pack();
                viewWindowMenu.setVisible(true);
            }
        });
        menu.add(menuItem);
        
        
        

        //Build the help menu
        menu = new JMenu("Help");
        menuBar.add(menu);
        
 
        
        
        
        
        aboutFrame = new AboutFrame();
        menuItem = new JMenuItem("About");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                aboutFrame.setVisible(true);
                aboutFrame.setState(JFrame.NORMAL);
            }
        });
        menu.add(menuItem);
    
    }
    
    void createDefaultTpc() {
        tpc = new Tpc();
        tpc.createDefault();
        createDesignWindow();
        output.append("Default TPC created" + newline);
    }
        
    void createDesignWindow() {
        //construct the TpcDesign Frame
        // if this is replacing an existing tpc, then remove all associated windows
        if (tpcDesign != null) {
            tpcDesign.setVisible(false);
            int nPart = tpcDesign.tpcPartPanelVector.size();
            for (int iPart = 0; iPart < nPart; iPart++) {
                TpcPartPanel gpp = (TpcPartPanel) tpcDesign.tpcPartPanelVector.elementAt(iPart);
                for (int i=1; i<=gpp.nWindow(); i++){
                    JFrame frame = gpp.window(i);
                    frame.setVisible(false);
                }
            }
        }
        tpcDesign = new TpcDesign(tpc);
        tpcDesign.setTitle("TPC Design");
        tpcDesign.setSize(450,260);
        tpcDesign.setVisible(false);
        tpcDesign.drawTpc();
    }
    
    public Tpc getTpc(){
        return tpc;
    }
    
}
