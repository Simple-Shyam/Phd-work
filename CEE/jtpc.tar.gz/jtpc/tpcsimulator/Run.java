/*
 * Run.java
 *
 * Created on April 3, 2002, 9:26 AM
 */

package tpcsimulator;
import tpctracker.*;
import java.io.*;
import java.util.Vector;
import hep.aida.*;

/**
 *
 * @author  karlen
 * @version
 */
public class Run {
    
    int version = 3; // MC file output format: version 2 is verbose, version 3 minimizes output (zero suppression etc)
    
    RunParam rp;
    /** Creates new default Run */
    public Run() {
        rp = new RunParam();
    }
    
    /** Creates a Run according to specified parameters */
    public Run(RunParam rp) {
        this.rp = rp;
    }
    
    /** Start the run to generate events and write data from bottomPart of TPC to file */
    public void start(Tpc tpc) {
        
        int nPad = ((PadArray) tpc.bottomPart).getNumElement();
        int firstPad = ((PadArray) tpc.bottomPart).getFirstElement();
        
        // random numbers:
        if (rp.seed == -1) rp.seed = System.currentTimeMillis();
        tpc.setSeed(rp.seed);
        
        // pre amplifiers:
        PreAmp preAmp = new PreAmp(rp.preAmpType, rp.preAmpRiseTime, rp.preAmpFallTime, rp.preAmpGain, rp.preAmpGainStdDev, nPad, tpc.random, false);
        
        // flash ADC:
        FlashADC fadc = new FlashADC(rp.fadcGain,rp.fadcBits);
        
        // signal
        Signal signal = new Signal(rp.fadcBins, 0., rp.fadcBins*rp.fadcDT, preAmp);
        
        // fitters
        Vector tpcFittables = new Vector(5,5);
        TpcPart tpcPart = tpc.getTopPart();
        while (tpcPart != null){
            if( tpcPart.isFittable())
                tpcFittables.addElement(tpcPart);
            tpcPart = tpcPart.getPartBelow();
        }
        Vector xyFitters = new Vector(5,5);
        Vector xyFitterParams = new Vector(5,5);
        for (int i=0; i < rp.xyFitterParamVector.size(); i++) {
            XYFitterParam  xyFitterParam = (XYFitterParam) rp.xyFitterParamVector.elementAt(i);
            if (xyFitterParam.getMeshIndex() < tpcFittables.size()) {
                PadMesh padMesh = (PadMesh) tpcFittables.elementAt(xyFitterParam.getMeshIndex());
                xyFitters.addElement(new XYFitter(padMesh,xyFitterParam));
                xyFitterParams.addElement(xyFitterParam);
            }
        }
        int nXYFitters = xyFitters.size();
        
        // tuple definition:
        boolean writeTuple = nXYFitters > 0 && rp.writeTuple;
        String columnString = "";
        IAnalysisFactory af = null;
        ITree tree = null;
        ITupleFactory tf = null;
        ITuple tuple = null;
        if (writeTuple) {
            af = hep.aida.ref.AnalysisFactory.create();
            try {
                tree = af.createTreeFactory().create(rp.tFilename,"type=xml;compress=yes");
                tf = af.createTupleFactory(tree);
                
                columnString = "int run=0; int event=0";
                columnString += "; double x0=0.; double z0=0.; double phi=0.; double psi=0.";
                
                for (int i=0; i < nXYFitters; i++) {
                    int j = i+1;
                    columnString += "; double x0" + j + "=0.";
                    columnString += "; double dx" + j + "=0.";
                    columnString += "; double phi" + j + "=0.";
                    columnString += "; double sig" + j + "=0.";
                    columnString += "; double ex0" + j + "=0.";
                    columnString += "; double ephi" + j + "=0.";
                    columnString += "; double esig" + j + "=0.";
                }
                tuple = tf.create( "tuple", "TPC sim tuple", columnString, "");
            } catch (IOException e) {
                System.err.println(
                "Caught IOException:" + e.getMessage());
                writeTuple = false;
            }
        }
        
        try {
            DataOutputStream out=null;
            if (rp.writeRawData) {
                out = new DataOutputStream( new FileOutputStream(rp.filename));
                out.writeChars("TPC Simulator MC");
                out.writeInt(version); // version number
                // run header
                int nByteHeader = 40;
                if (version == 2) nByteHeader += 4*nPad;
                out.writeInt(nByteHeader); // number of bytes in run header to follow
                out.writeInt(rp.run);
                out.writeInt(rp.number);
                out.writeLong(rp.seed);
                out.writeInt(nPad);
                out.writeInt(firstPad);
                out.writeInt(rp.fadcBits);
                out.writeInt(rp.fadcBins);
                out.writeInt((int)(rp.fadcGain*1000.));
                out.writeInt((int)(rp.fadcDT*1000.));
                // gains for each channel
                if (version == 2){
                    for (int iPad=0; iPad < nPad; iPad++) {
                        out.writeInt((int)((preAmp.getGain(iPad)-preAmp.getGain())/preAmp.getGain()*1000.));
                    }
                }
            }
            BufferedReader geantReader=null;
            if (rp.geantEvents) {
                File geantFile = new File(rp.geantFile);
                FileInputStream fis = new FileInputStream(geantFile);
                geantReader = new BufferedReader(new InputStreamReader(fis));
                geantReader.readLine(); // read first -99
            }
            
            int ievt=0;
            boolean eof = false; // End of File for geant events
            while (ievt<rp.number && !eof) {
                ievt++;
                // clear out tpc to prepare for a new track
                tpc.clear();
                
                // Random track event generation:
                int itup = 0;
                double x0=0.,z0=0.,phi=0.,psi=0.,kineticEnergy=0.; int particleCode = 0;
                if (!rp.geantEvents){
                    // create track parameters:
                    x0 = rp.minX + (rp.maxX-rp.minX)*tpc.random.nextDouble();
                    z0 = rp.minZ + (rp.maxZ-rp.minZ)*tpc.random.nextDouble();
                    phi = rp.minPhi + (rp.maxPhi-rp.minPhi)*tpc.random.nextDouble();
                    psi = rp.minPsi + (rp.maxPsi-rp.minPsi)*tpc.random.nextDouble();
                    
                    // fill tuple
                    if (writeTuple) {
                        tuple.fill(itup,rp.run); itup++;
                        tuple.fill(itup,ievt); itup++;
                        tuple.fill(itup,x0); itup++;
                        tuple.fill(itup,z0); itup++;
                        tuple.fill(itup,phi); itup++;
                        tuple.fill(itup,psi); itup++;
                    }
                    
                    // create the corresponding track segment
                    Track track = new Track(x0,z0,phi,psi,rp.lowX,rp.highX,
                    rp.lowY,rp.highY,rp.lowZ,rp.highZ,rp.time,rp.cd,0,rp.sxyz);
                    
                    // put track into TPC
                    track.putInto(tpc);
                    
                    // add the second track if requested: DK changed id from 0 to 1 (May 29,2005)
                    if (rp.makeTrk2) {
                        track = new Track(rp.trk2X,rp.trk2Z,rp.trk2Phi,rp.trk2Psi,rp.lowX,rp.highX,
                        rp.lowY,rp.highY,rp.lowZ,rp.highZ,rp.time,rp.cd,1,rp.sxyz);
                        track.putInto(tpc);
                    }
                } else {
                    double t = 0;
                    double sxy =0.;
                    double sz = 0.;
                    int id=0;
                    // Geant event generation - read until -99 read
                    String[] geant = geantReader.readLine().split("\\s");
                    int i=0;
                    int code = 0; int lastcode = 0;
                    while (geant[i].length() == 0) i++; code = Integer.valueOf(geant[i++]).intValue();
                    int istep=0; double x1=0,x2=1,y1=0,y2=1,z1=0,z2=1;
                    double lastX=-999.,lastY=-999.,lastZ=-999.; boolean trackpardone = false;
                    double xOffset = -Math.abs(rp.geantXOffset); 
                    // double yOffset = -Math.abs(rp.geantYOffset);
                    phi = -999.; // indicate if no track found cross y=0
                    double yOffset = rp.geantYOffset;
                    while (code !=-99 && geant.length >= 5){
                        if (rp.geantCode==0 || Math.abs(rp.geantCode)==code || (rp.geantCode<0 && code==3)){
                            while (geant[i].length() == 0) i++; double kE = Double.valueOf(geant[i++]).doubleValue();
                            while (geant[i].length() == 0) i++; double z = Double.valueOf(geant[i++]).doubleValue()*10. + rp.geantZOffset;
                            while (geant[i].length() == 0) i++; double x = Double.valueOf(geant[i++]).doubleValue()*10.*(-1.) + xOffset;
                            while (geant[i].length() == 0) i++; double y = Double.valueOf(geant[i++]).doubleValue()*10. + yOffset;
                            while (geant[i].length() == 0) i++; double dE = Double.valueOf(geant[i++]).doubleValue();
                            int n = (int) (dE*1.E9/rp.geantWi);
                            if (istep > 2 && n>0 && x<rp.highX && x>rp.lowX && y<rp.highY && y>rp.lowY && z<rp.highZ && z>rp.lowZ) {
                                if (code != lastcode) { // DK added on May 29, 2005 - treat ionization from separte tracks separately
                                    id++;
                                    lastcode = code;
                                }
                                ElectronCloud electronCloud = new ElectronCloud(n,x,y,z,sxy,sz,t,id);
                                tpc.addElectronCloud(electronCloud);
                            }
                            if (rp.geantCode==0 || Math.abs(rp.geantCode)==code)istep++;
                            if (istep==1){
                                x1 = x; y1=y; z1=z;
                                kineticEnergy = kE;
                                particleCode = code;
                            } else if (istep==2){
                                x2 = x; y2=y; z2=z;
                            } else if (istep==3){
                                // shift track so that the greatest number of pads are hit
                                if (x2 < x1) xOffset = Math.abs(rp.geantXOffset);
                                // if (y2 < y1) yOffset = Math.abs(rp.geantYOffset);
                                lastcode = code;
                            }
                            // estimate truth information: when track crosses y=0
                            if (!trackpardone && istep > 3 && y*lastY < 0){
                                double y0 = 0.;
                                x0 = x + (y0 - y)/(lastY - y) * (lastX - x);
                                z0 = z + (y0 - y)/(lastY - y) * (lastZ - z);
                                phi = -Math.atan2(x-lastX,y-lastY);
                                trackpardone = true;
                            }
                            lastX = x;
                            lastY = y;
                            lastZ = z;
                        }
                        String nextLine = geantReader.readLine();
                        if (nextLine == null){
                            // end of file reached
                            eof = true;
                            code = -99;
                        } else {
                            geant = nextLine.split("\\s");
                            i=0;
                            while (geant[i].length() == 0) i++; code = Integer.valueOf(geant[i++]).intValue();
                        }
                    }
                    
                    double tanl = Math.sqrt((z2-z1)*(z2-z1)/((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)));
                    psi = tanl; // so that it will be written out to MC file
                    
                    // fill tuple
                    if (writeTuple) {
                        tuple.fill(itup,rp.run); itup++;
                        tuple.fill(itup,ievt); itup++;
                        tuple.fill(itup,x0); itup++;
                        tuple.fill(itup,z0); itup++;
                        tuple.fill(itup,phi); itup++;
                        tuple.fill(itup,tanl); itup++;
                    }
                }
                
                // do fits if any
                for (int ifit = 0; ifit < nXYFitters; ifit++) {
                    XYFitter xyFitter = (XYFitter) xyFitters.elementAt(ifit);
                    xyFitter.setParam((XYFitterParam) xyFitterParams.elementAt(ifit));
                    xyFitter.doFit();
                    // fill tuple
                    if (writeTuple) {
                        tuple.fill(itup,xyFitter.getParam(0)); itup++;
                        tuple.fill(itup,xyFitter.getParam(0)-x0); itup++;
                        tuple.fill(itup,xyFitter.getParam(1)); itup++;
                        tuple.fill(itup,xyFitter.getParam(2)); itup++;
                        tuple.fill(itup,xyFitter.getError(0)); itup++;
                        tuple.fill(itup,xyFitter.getError(1)); itup++;
                        tuple.fill(itup,xyFitter.getError(2)); itup++;
                    }
                }
                
                // finish tuple row:
                if (writeTuple) tuple.addRow();
                
                if (rp.writeRawData) {
                    // event header
                    int nByteHeader = 28 + 16;
                    if (version == 2)nByteHeader += 4*nPad;
                    out.writeInt(nByteHeader); // number of bytes of header to follow
                    out.writeInt(ievt);
                    out.writeInt((int) (x0*1000.));
                    out.writeInt((int) (z0*1000.));
                    out.writeInt((int) (phi*1000000.));
                    out.writeInt((int) (psi*1000000.));
                    out.writeInt((int) (kineticEnergy*1000000.));
                    out.writeInt(particleCode);
                    if(version == 2){
                        for (int iPad=0; iPad<nPad; iPad++) {
                            out.writeInt(((PadArray) tpc.bottomPart).getNElectron(iPad));
                        }
                    }
                    out.writeInt((int) (rp.trk2X*1000.));
                    out.writeInt((int) (rp.trk2Z*1000.));
                    out.writeInt((int) (rp.trk2Phi*1000000.));
                    out.writeInt((int) (rp.trk2Psi*1000000.));
                    
                    if (version == 2){
                        for (int iPad=firstPad; iPad < nPad+firstPad; iPad++) {
                            
                            out.writeInt(iPad);
                            
                            // get signal from Bottom Tpc Part
                            ((PadArray) tpc.bottomPart).getPadSignal(iPad,signal);
                            
                            // convert to FADC channels
                            byte[] data = fadc.convert(signal);
                            out.write(data,0,data.length);
                        }
                        
                    } else {
                        for (int iPad=firstPad; iPad < nPad+firstPad; iPad++) {
                            // only write out pads with electrons associated:
                            if (((PadArray) tpc.bottomPart).getNElectron(iPad)>0) {
                                out.writeInt(iPad);
                                
                                // get signal from Bottom Tpc Part
                                ((PadArray) tpc.bottomPart).getPadSignal(iPad,signal);
                                
                                // convert to FADC channels
                                byte[] data = fadc.convert(signal);
                                out.write(data,0,data.length);
                            }
                        }
                        out.writeInt(-999); // indicates end of data for this event (remaining pads have no data)
                    }
                }
            }
            // event loop finished
            if (rp.writeRawData) out.close();
            if (writeTuple) tree.commit();
            if (rp.geantEvents) System.out.println("Done: " + ievt + " GEANT events processed");
            
        } catch (IOException e) {
            System.err.println(
            "Caught IOException:" + e.getMessage());
        }
        
    }
    
}