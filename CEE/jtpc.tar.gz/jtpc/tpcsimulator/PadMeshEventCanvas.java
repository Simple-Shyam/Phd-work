package tpcsimulator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import tpctracker.XYFitter;
import tpcanalyzer.*;

class PadMeshEventCanvas extends JPanel implements Scrollable,MouseListener, MouseMotionListener{
    
    Image offImage;
    Graphics offGraphics;
    
    PadMesh padMesh;
    PadMeshEventFrame padMeshEventFrame;
    int nx,ny,width,height;
    int[] groupForPad;
    int largestPadGroupNumber;
    int startSelectionPadGroup,endSelectionPadGroup;
    int pixelSize;
    int[] nElectronInPadGroup;
    int maxElectron;
    double[] timeForPadGroup;
    double minTime,maxTime;
    boolean colorScaleLog,colorScaleGrey;
    
    PadMeshEventCanvas(PadMesh padMesh, PadMeshEventFrame padMeshEventFrame){
        this.padMesh = padMesh;
        this.padMeshEventFrame = padMeshEventFrame;
        setBackground(Color.black);
        nx = padMesh.meshLayout.nx;
        ny = padMesh.meshLayout.ny;
        pixelSize = Math.min(20,Math.max(5,500/ny));
        width = nx*pixelSize + 1;
        height = ny*pixelSize + 1;
        setBounds(0,0,width,height);
        
        addMouseMotionListener(this);
        addMouseListener(this);
        
        // copy the contents of PadGroup into groupForPad
        groupForPad = new int[padMesh.nPad];
        for (int i = 0; i < padMesh.nPad; i++) {
            groupForPad[i] = -888;
        }
        int nPadGroup = padMesh.getNumElement();
        int[][] padGroup = padMesh.getPadGroup();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int iPad = 0; iPad < nPadInGroup; iPad++) {
                int padNumber = padGroup[iPadGroup][iPad];
                groupForPad[padNumber] = iPadGroup;
            }
        }
        largestPadGroupNumber = nPadGroup - 1;
        startSelectionPadGroup = -1;
        endSelectionPadGroup = -1;
        
        nElectronInPadGroup = new int[nPadGroup];
        timeForPadGroup = new double[nPadGroup];
    }
    
    PadMeshEventCanvas() {
        padMesh = null;
    }
    
    public void setPreferredSize(Dimension dummy) {
        super.setPreferredSize(new Dimension(width,height));
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        update(g);
    }
    
    public void update(Graphics g){
        
        if (offGraphics == null) {
            offImage = createImage(width,height);
            offGraphics = offImage.getGraphics();
        }
        
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0,0,width,height);
        
        setColorScaleLog(padMeshEventFrame.logScale());
        setColorScaleGrey(padMeshEventFrame.greyScale());
        
        int nPadGroup = padMesh.getNumElement();
        for (int i=0; i < nPadGroup; i++) {
            nElectronInPadGroup[i] = 0;
            timeForPadGroup[i] = -999.;
        }
        
        for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
            int iGroup = groupForPad[iPad];
            if (iGroup >= 0) {
                nElectronInPadGroup[iGroup] += padMesh.pad[iPad].getNElectron();
                timeForPadGroup[iGroup] = padMesh.pad[iPad].getTime()*padMesh.pad[iPad].getNElectron();
            }
        }
        
        for (int i=0; i<nPadGroup; i++) {
            if (nElectronInPadGroup[i] > 0) {
                timeForPadGroup[i] /= nElectronInPadGroup[i];
            }
        }
        
        if (padMeshEventFrame.showMesh()) {
            maxElectron = 1;
            minTime = 9999.;
            maxTime = -9999.;
            for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
                if (groupForPad[iPad] >= 0){
                    maxElectron = Math.max(maxElectron,padMesh.pad[iPad].getNElectron());
                    if (padMesh.pad[iPad].getNElectron()>0) {
                        minTime = Math.min(minTime,padMesh.pad[iPad].getTime());
                        maxTime = Math.max(maxTime,padMesh.pad[iPad].getTime());
                    }
                }
            }
            for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
                if (groupForPad[iPad] < 0) {
                    offGraphics.setColor(Color.white);
                } else if (!padMesh.padGroupIsEnabled(groupForPad[iPad])) {
                        offGraphics.setColor(Color.gray);
                } else {
                    if (padMeshEventFrame.showTimeData()) {
                        offGraphics.setColor(colorScale(padMesh.pad[iPad].getTime(),minTime,maxTime));
                    } else {
                        offGraphics.setColor(colorScale(padMesh.pad[iPad].getNElectron(),maxElectron));
                    }
                }
                int ix = getX(iPad);
                int iy = getY(iPad);
                offGraphics.fillRect(ix,iy,pixelSize-1,pixelSize-1);
            }
        } else {
            // draw the number of electrons collected by each pad group
            
            maxElectron = 1;
            for (int iGroup = 0; iGroup < nPadGroup; iGroup++) {
                maxElectron = Math.max(maxElectron,nElectronInPadGroup[iGroup]);
                if (nElectronInPadGroup[iGroup] > 0) {
                    minTime = Math.min(minTime,timeForPadGroup[iGroup]);
                    maxTime = Math.max(maxTime,timeForPadGroup[iGroup]);
                }
            }
            
            for (int iPad = 0; iPad < padMesh.nPad; iPad++) {
                int iGroup = groupForPad[iPad];
                if (iGroup < 0) {
                    offGraphics.setColor(Color.white);
                } else if (!padMesh.padGroupIsEnabled(groupForPad[iPad])) {
                        offGraphics.setColor(Color.gray);
                } else {
                    if (padMeshEventFrame.showTimeData()) {
                        offGraphics.setColor(colorScale(timeForPadGroup[iGroup],minTime,maxTime));
                    } else {
                        offGraphics.setColor(colorScale(nElectronInPadGroup[iGroup],maxElectron));
                    }
                }
                int ix = getX(iPad);
                int iy = getY(iPad);
                offGraphics.fillRect(ix,iy,pixelSize-1,pixelSize-1);
            }
        }
        
        // Draw the seed track if requested:
        if (padMeshEventFrame.showSeedTrack()) {
            TpcAnalyzer tpcAnalyzer = padMeshEventFrame.tpcAnalyzer;
            if (tpcAnalyzer != null) {
                double[] param = tpcAnalyzer.getSeedParam();
                double x0 = param[0];
                double phi = param[1];
                double sigma = param[2];
                double dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                addLine(x0,phi,Color.green);
                addLine(x0+dxs,phi,Color.yellow);
                addLine(x0-dxs,phi,Color.yellow);
            }
        }
        
        // Draw the track fit if requested:
        if (padMeshEventFrame.showTrackFit()) {
            XYFitter xyFitter = padMeshEventFrame.fitterControlFrame.getXYFitter();
            if (xyFitter != null) {
                double[] param=xyFitter.getParam();
                double x0 = param[0];
                double phi = param[1];
                double sigma = param[2];
                double dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                addLine(x0,phi,Color.white);
                addLine(x0+dxs,phi,Color.lightGray);
                addLine(x0-dxs,phi,Color.lightGray);
            }
        }
        
        // Draws the buffered image to the screen.
        g.drawImage(offImage, 0, 0, this);
        
        // update legend
        if(padMeshEventFrame.showTimeData()) {
            padMeshEventFrame.setLegend(minTime,maxTime);
        } else {
            padMeshEventFrame.setLegend(maxElectron);
        }
    }
    
    void addLine(double x0, double phi, Color color){
        
        double xMin = padMesh.layout.getXMin();
        double xMax = padMesh.layout.getXMax();
        double yMin = padMesh.layout.getYMin();
        double yMax = padMesh.layout.getYMax();
        double scale = pixelSize/padMesh.layout.getDX();
        
        double xTop = x0 - yMax*Math.tan(phi);
        double xBot = x0 - yMin*Math.tan(phi);
        
        int ixTop = (int) ((xTop-xMin)*scale + 0.5);
        int ixBot = (int) ((xBot-xMin)*scale + 0.5);
        offGraphics.setColor(color);
        offGraphics.drawLine(ixTop,0,ixBot,height);
    }
    
    void setColorScaleLog(boolean setLog) {
        colorScaleLog = setLog;
    }
    void setColorScaleGrey(boolean setGrey) {
        colorScaleGrey = setGrey;
    }
    
    Color colorScale(int n, int nMax) {
        if (n <= 0) return Color.darkGray;
        if (nMax < 1) return Color.cyan;
        float frac;
        if (colorScaleLog) {
            if (n <= 5000) return Color.darkGray;
            double dfrac = Math.log((double) n/5000.) / Math.log((double) nMax/5000.);
            frac = (float) dfrac;
        } else {
            frac = ((float) n)/nMax;
        }
        if (colorScaleGrey) {
            frac = (float) (0.4 + 0.6*frac);
            return new Color(frac,frac,frac);
        }
        frac *= (float) 0.85; // removes the red near 1
        return new Color(Color.HSBtoRGB(frac, (float) 0.9, (float) 0.7));
    }
    
    Color colorScale(double t, double tMin, double tMax) {
        if (t <= 0.) return Color.darkGray;
        float frac;
        if (colorScaleLog) {
            double dfrac = Math.log((t-tMin+0.001)) / Math.log(tMax-tMin+0.001);
            frac = (float) dfrac;
        } else {
            frac = (float) ((t - tMin)/(tMax-tMin));
        }
        if (colorScaleGrey) {
            frac = (float) (0.4 + 0.6*frac);
            return new Color(frac,frac,frac);
        }
        frac *= (float) 0.85; // removes the red near 1
        return new Color(Color.HSBtoRGB(frac, (float) 0.9, (float) 0.7));
    }
    
    public void mouseClicked(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            
        } else if ((e.getModifiers() & InputEvent.BUTTON2_MASK)
        == InputEvent.BUTTON2_MASK) {
            
        } else if ((e.getModifiers() & InputEvent.BUTTON3_MASK)
        == InputEvent.BUTTON3_MASK) {
            
        }
        
    }
    
    public void mousePressed(MouseEvent e) {
        
    }
    
    public void mouseDragged(MouseEvent e) {
        
    }
    
    public void mouseReleased(MouseEvent e) {
        
    }
    
    public void mouseExited(MouseEvent e) {
        updateLocationLabel(-1,-1);
    }
    
    public void mouseEntered(MouseEvent e) {
    }
    
    public void mouseMoved(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < padMesh.nPad) {
            updateLocationLabel(iPad, groupForPad[iPad]);
        }
    }
    
    void updateLocationLabel(int iPad, int iGroup) {
        if (iPad >= 0 && iPad < padMesh.nPad) {
            if (iGroup < 0) {
                if (padMesh.pad[iPad].getNElectron() > 0){
                    padMeshEventFrame.setDataLabel("Pad # " + iPad +
                    " (" + padMesh.pad[iPad].getNElectron() + " electrons" +
                    " @ time " + myFormat(padMesh.pad[iPad].getTime()) + ")" +
                    " is unassigned");
                } else {
                    padMeshEventFrame.setDataLabel("Pad # " + iPad);
                }
            } else {
                if (padMesh.pad[iPad].getNElectron() > 0) {
                    padMeshEventFrame.setDataLabel("Pad # " + iPad +
                    " (" + padMesh.pad[iPad].getNElectron() + " electrons" +
                    " time " + myFormat(padMesh.pad[iPad].getTime()) + ")" +
                    " in group # " + iGroup + " (" + nElectronInPadGroup[iGroup]
                    + " electrons @ time " + myFormat(timeForPadGroup[iGroup]) + ")");
                } else {
                    padMeshEventFrame.setDataLabel("Pad # " + iPad);
                }
            }
        } else {
            padMeshEventFrame.setDataLabel(" ");
        }
    }
    
    String myFormat(double x) {
        int ix = (int) (x*10.);
        double sx = ix/10.;
        return "" + sx;
    }
    
    int getPadGroup(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < padMesh.nPad) {
            return groupForPad[iPad];
        }
        return -1;
    }
    
    int getIPad(MouseEvent e) {
        return getIPad(e.getX(),e.getY());
    }
    
    int getIPad(int ix, int iy) {
        return (ny-1)*nx - iy/pixelSize*nx + (ix-1)/pixelSize;
    }
    
    int getX(int iPad) {
        return 1 + (iPad%nx)*pixelSize;
    }
    
    int getY(int iPad) {
        return 1 + (ny - 1 - iPad/nx)*pixelSize;
    }
    
    public boolean getScrollableTracksViewportHeight() {
        return (height < 500);
    }
    
    public int getScrollableUnitIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return pixelSize;
    }
    
    public int getScrollableBlockIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return pixelSize*10;
    }
    
    public java.awt.Dimension getPreferredScrollableViewportSize() {
        return new Dimension(Math.min(500,width),Math.min(500,height));
    }
    
    public boolean getScrollableTracksViewportWidth() {
        return (width < 500);
    }
}