package tpcsimulator;

import java.util.Random;

/**
 *
 * @author  karlen
 * @version
 */
public class PreAmp {
    
    int riseTime,fallTime,nChan;
    double gain,gainStdDev;
    double[] gainChan;
    boolean induction;
    private int type; // to identify type of preamp: 0=generic, 1=star ...
    double[] tau,starCon;
    
    static final double sqrtPi = Math.sqrt(Math.PI);
    static final double sqrt2 = Math.sqrt(2.);
    
    /** Creates new PreAmp */
    public PreAmp(int riseTime, int fallTime, double gain, boolean induction) {
        this.riseTime = riseTime;
        this.fallTime = fallTime;
        this.gain = gain;
        this.induction = induction;
        this.gainStdDev = 0.;
        this.nChan = 1;
        type = 0;
    }
    
    /** Creates new generic PreAmps, with different gains in each channel*/
    public PreAmp(int riseTime, int fallTime, double gain, double gainStdDev, int nChan, Random random, boolean induction) {
        this.riseTime = riseTime;
        this.fallTime = fallTime;
        this.gain = gain;
        this.induction = induction;
        this.gainStdDev = gainStdDev;
        this.nChan = nChan;
        type = 0;
        
        gainChan = new double[nChan];
        for (int iChan=0; iChan<nChan; iChan++) {
            double del = gainStdDev*random.nextGaussian();
            double newGain = gain *(1.+del);
            newGain = Math.max(newGain, 0.);
            gainChan[iChan] = newGain;
        }
    }
    
    /** Creates new non-generic PreAmps, with different gains in each channel*/
    public PreAmp(int type, int riseTime, int fallTime, double gain, double gainStdDev, int nChan, Random random, boolean induction) {
        this.riseTime = riseTime;
        this.fallTime = fallTime;
        this.gain = gain;
        this.induction = induction;
        this.gainStdDev = gainStdDev;
        this.nChan = nChan;
        this.type = type;
        
        gainChan = new double[nChan];
        for (int iChan=0; iChan<nChan; iChan++) {
            double del = gainStdDev*random.nextGaussian();
            double newGain = gain *(1.+del);
            newGain = Math.max(newGain, 0.);
            gainChan[iChan] = newGain;
        }
        
        if(type == 1) {
            // STAR preamps - pulse shape described by formula by Paul Poffenberger
            tau = new double[6];
            tau[1] = 729.878;  // time constants (in ns)
            tau[2] = 89.0123;
            tau[3] = 88.9504;
            tau[4] = riseTime; // current rise
            tau[5] = fallTime; // current fall
            double k1 = 0.32851;
            starCon = new double[4];
            starCon[0] = 58.*4.; // absolute amplitude of pulse at peak, fudge factor of 4 to account for shaping loss
            starCon[1] = tau[1]*tau[3]*tau[1]*tau[1]*k1/(tau[1]-tau[2])/(tau[1]-tau[3]);
            starCon[2] = tau[1]*tau[3]*tau[2]*tau[2]/(tau[2]-tau[1])/(tau[2]-tau[3]);
            starCon[3] = tau[1]*tau[3]*tau[3]*tau[3]/(tau[3]-tau[1])/(tau[3]-tau[2]);
        }
    }
    
    double directPulse(double time, double driftTime, double sigmaT) {
        if (type == 0) {
            // shape of pulse due to direct charge (from MathCad calculation) - not yet filtered
            if(time < -5.*sigmaT) return 0.;
            if(time > driftTime + 5.*sigmaT) return -1.;
            double t = time;
            double d = driftTime;
            double s = sigmaT;
            double term1,term2,term3;
            
            double arg = (d-t)/s/sqrt2;
            term1 = s/sqrt2*Math.exp(-1.*arg*arg) - 0.5*t*sqrtPi*Gaussian.erf(arg);
            term3 = 0.5*Gaussian.erf(arg);
            arg = t/s/sqrt2;
            term2 = -1.*s/sqrt2*Math.exp(-1.*arg*arg) -0.5*t*sqrtPi*Gaussian.erf(arg);
            double result = (term1+term2)/d/sqrtPi + term3 - 0.5;
            return result;
        } else if (type == 1) {
            // STAR pulse - already with shaping filter
            double t = time;
            if (t<0) {
                return 0.;
            } else if (t<tau[4]) {
                double sum = 0.;
                for (int i=1; i<=3; i++) {
                    sum += starCon[i]*(Math.exp(-t/tau[i]) + t/tau[i] - 1.)/tau[4];
                }
                return sum/starCon[0];
            } else if (t<tau[4]+tau[5]){
                double sum = 0.;
                for (int i=1; i<=3; i++) {
                    sum += starCon[i]*((tau[i]+tau[4]+tau[5]-t)/tau[i]/tau[5] + Math.exp(-t/tau[i])/tau[4]
                            - (1./tau[4] + 1./tau[5])*Math.exp((tau[4]-t)/tau[i]));
                }
                return sum/starCon[0];
            } else {
                double sum = 0.;
                for (int i=1; i<=3; i++) {
                    sum += starCon[i]*Math.exp(-t/tau[i])*(1./tau[4]+Math.exp((tau[4]+tau[5])/tau[i])/tau[5] 
                            - Math.exp(tau[4]/tau[i])*(1./tau[4]+1./tau[5]));
                }
                return sum/starCon[0];
            }
            
        } else return 0.;
    }
    
    public boolean isGeneric() {return type==0;}
    
    public double getGain() { return gain; }
    public double getGain(int iChan) {
        if (iChan >=0 && iChan < nChan) return gainChan[iChan];
        else return gain;
    }
    
}
