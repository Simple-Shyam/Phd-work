package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author  karlen
 * @version
 */
class FoilPanel extends TpcPartPanel {
    
    LayoutPanel layoutPanel;
    FoilPropertiesPanel foilPropertiesPanel;
    ShapePanel shapePanel;
    Foil foil;
    
    /** Creates new FoilPanel */
    FoilPanel(Foil foil, TpcDesign tpcDesign) {
        this.foil = foil;
        
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("GEM Foil: " + foil.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Generic properties of the Foil:
        foilPropertiesPanel = new FoilPropertiesPanel(foil);
        add(foilPropertiesPanel,BorderLayout.NORTH);
        
        // Layout of the Foil:
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new BoxLayout(selectionPanel, BoxLayout.Y_AXIS));
        JPanel cbp = new JPanel();
        layoutPanel = new LayoutPanel(foil,cbp);
        JLabel cbpLabel = new JLabel("Foil hole layout:");
        cbpLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        selectionPanel.add(cbpLabel);
        selectionPanel.add(cbp);
        add(selectionPanel, BorderLayout.WEST);
        add(layoutPanel,BorderLayout.CENTER);
        
        // Shape of the Foil Holes:
        JPanel selectShapePanel = new JPanel();
        JPanel cbpShape = new JPanel();
        shapePanel = new ShapePanel(foil,cbpShape);
        JLabel cbpShapeLabel = new JLabel("Foil hole shape:");
        selectShapePanel.add(cbpShapeLabel);
        selectShapePanel.add(cbpShape);
        selectShapePanel.add(shapePanel);
        add(selectShapePanel,BorderLayout.SOUTH);
    }
    
/** read parameters from panel
 */
    void readPanel(){
        foilPropertiesPanel.readPanel();
        layoutPanel.readPanel();
        shapePanel.readPanel();
    }
    
}
