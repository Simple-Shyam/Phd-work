package tpcsimulator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

class LegendCanvas extends Canvas {
        
    Image offImage;
    Graphics offGraphics;
    
    PadMesh padMesh;
    PadMeshEventFrame padMeshEventFrame;
    PadMeshEventCanvas padMeshEventCanvas;
    int width = 20;
    int height = 200;
    
    LegendCanvas(PadMesh padMesh, PadMeshEventFrame padMeshEventFrame, JPanel padMeshEventCanvas){
        this.padMesh = padMesh;
        this.padMeshEventFrame = padMeshEventFrame;
        this.padMeshEventCanvas = (PadMeshEventCanvas) padMeshEventCanvas;
        setBounds(0,0,width,height);
    }
    
    public void paint(Graphics g){
        update(g);
    }
    
    public void update(Graphics g){
        
        if (offGraphics == null) {
            offImage = createImage(width,height);
            offGraphics = offImage.getGraphics();
        }
        
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0,0,width,height);
        
        // draw a scale for the number of electrons in each group
        padMeshEventCanvas.setColorScaleLog(false);
        int nPixel = 2;
        int nDiv = height/nPixel;
        int iy = height;
        for (int i=0; i < nDiv; i++) {
            Color color = padMeshEventCanvas.colorScale(i,nDiv);
            offGraphics.setColor(color);
            iy -= nPixel;
            offGraphics.fillRect(0,iy,width,nPixel);
        }
        
        // Draws the buffered image to the screen.
        g.drawImage(offImage, 0, 0, this);
    }
        
}