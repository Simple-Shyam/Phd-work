package tpcsimulator;
import java.io.*;
import java.util.Random;

/** An object consisting of TpcParts, each lying on top of each other:
 * GEM foils, gas gaps, an arrangement of readout pads, and readout electronics
 * @author Dean Karlen
 * @version 1.0
 */

public class Tpc implements Serializable{
    TpcPart topPart,bottomPart;
    Random random;
    
/** Constructor
 */
    public Tpc() {
        // this is the Tpc constructor (a blank Tpc):
        topPart = null;
        bottomPart = null;
        random = new Random();
    }

    public TpcPart getTopPart() {return topPart;}
    public TpcPart getBottomPart() {return bottomPart;}
    public TpcPart getPart(String partName) {
        TpcPart tpcPart = bottomPart;
        boolean found = false;
        while (tpcPart != null){
            if (tpcPart.name == partName) return tpcPart; 
            tpcPart = tpcPart.partAbove;
        }   
        return null;
    }
    
/** sets the Seed for random number generator used for simulation */
    public void setSeed(long seed) {
        random.setSeed(seed);
    }        
    
/* a default Tpc */
    
    void createDefault() {
        // design a foil: a grid of circular holes
        FoilDesc foil1Desc = new FoilDesc("Foil 1");
        // make changes to default here
        foil1Desc.gain=80.;
        foil1Desc.collectionEfficiency=1.0;
        foil1Desc.extractionEfficiency=0.7;
        Foil foil1 = new Foil(foil1Desc,this);
        
        // design the second foil: a grid of circular holes
        
        FoilDesc foil2Desc = new FoilDesc("Foil 2");
        // make changes to default here
        foil2Desc.gain=80.;
        foil2Desc.collectionEfficiency=1.0;
        foil2Desc.extractionEfficiency=0.7;
        foil2Desc.hexPackLayout.setOrigin(-15.07,-15.07);
        Foil foil2 = new Foil(foil2Desc,this);
        
        // design a pad layout: a grid of rectangular pads
        
        PadDesc padDesc = new PadDesc("Readout Pads");
        padDesc.gridLayout.setPitch(2.0,4.0);
        padDesc.gridLayout.setOrigin(-20.,-20.);
        padDesc.gridLayout.setNumber(21,11);
        padDesc.rectangle.lx=2.0;
        padDesc.rectangle.ly=4.0;
        PadArray padArray = new PadArray(padDesc,this);
        
        // design the gas gap between the foil and the readout pads
        
        GapDesc inductionGapDesc = new GapDesc("Induction Gap");
        inductionGapDesc.vDrift = 50.; // microns per nanosecond //
        inductionGapDesc.thickness=5.7;
        inductionGapDesc.transverseDiffusion = 400.; // micron/sqrt(cm)
        inductionGapDesc.longitudinalDiffusion = 250.;
        GasGap inductionGap = new GasGap(inductionGapDesc,this);
        
        // design the gap between the two foils
        
        GapDesc transferGapDesc = new GapDesc("Transfer Gap");
        transferGapDesc.vDrift = 50.; // microns per nanosecond //
        transferGapDesc.thickness=2.0;
        transferGapDesc.transverseDiffusion = 400.; // micron/sqrt(cm)
        transferGapDesc.longitudinalDiffusion = 250.;
        GasGap transferGap = new GasGap(transferGapDesc,this);
        
        // design the drift gap
        
        GapDesc driftGapDesc = new GapDesc("Drift Gap");
        driftGapDesc.vDrift = 9.; // microns per nanosecond //
        driftGapDesc.thickness=150.;
        driftGapDesc.transverseDiffusion = 190.; // micron/sqrt(cm)
        driftGapDesc.longitudinalDiffusion = 200.;
        GasGap driftGap = new GasGap(driftGapDesc,this);
        
        // build the tpc from the bottom up
        insertPart(padArray,null,true);
        insertPart(inductionGap,padArray,true);
        insertPart(foil1,inductionGap,true);
        insertPart(transferGap,foil1,true);
        insertPart(foil2,transferGap,true);
        insertPart(driftGap,foil2,true);
        
    }
    
/** Inserts a tpc part above/below tpcPartLoc
 * @param tpcPart TPC part
 * @param tpcPartLoc TPC part above/below which new part is placed
 * @param above set true if part is to be above (false if to be below)
 * @return True if successful
 */
    boolean insertPart(TpcPart tpcPart, TpcPart tpcPartLoc, boolean above){
        if (tpcPartLoc == null) {
            if (topPart != null) {
                return false;
            } else { // this is the first part added
                topPart = tpcPart;
                bottomPart = tpcPart;
                tpcPart.partAbove = null;
                tpcPart.partBelow = null;
            }
        } else {
            if (above) {  // put the new part above the specified location
                tpcPart.partAbove = tpcPartLoc.partAbove;
                if (tpcPart.partAbove != null) {
                    (tpcPart.partAbove).partBelow = tpcPart;
                } else {
                    topPart = tpcPart;
                }
                tpcPart.partBelow = tpcPartLoc;
                tpcPartLoc.partAbove = tpcPart;
            } else { // put the new part below the specified location
                tpcPart.partBelow = tpcPartLoc.partBelow;
                if (tpcPart.partBelow != null) {
                    (tpcPart.partBelow).partAbove = tpcPart;
                } else {
                    bottomPart = tpcPart;
                }
                tpcPart.partAbove = tpcPartLoc;
                tpcPartLoc.partBelow = tpcPart;
            }
        }
        // with the new part added, need to recalculate z coordinates of the Tpc parts
        calculateTpcPartZCoordinates();
        return true;
    }
    
/** Remove a TPC part from tpc
 * @param tpcPartOld TPC part to be removed
 * @return True if successful
 */
    boolean deletePart(TpcPart tpcPartOld){
        if (tpcPartOld == null) return false;
        if (tpcPartOld.partAbove != null) (tpcPartOld.partAbove).partBelow = tpcPartOld.partBelow;
        if (tpcPartOld == topPart) topPart = tpcPartOld.partBelow;
        if (tpcPartOld == bottomPart) bottomPart = tpcPartOld.partAbove;
        
        if (tpcPartOld.partBelow != null) (tpcPartOld.partBelow).partAbove = tpcPartOld.partAbove;
        tpcPartOld = null;
        
        calculateTpcPartZCoordinates();
        return true;
    }
    
/** Calculate z coordinates of all TPC parts
 */
    void calculateTpcPartZCoordinates(){
        TpcPart tpcPart = bottomPart;
        double zCoordinate = 0.;
        while (tpcPart != null){
            tpcPart.zBottom = zCoordinate;
            zCoordinate += tpcPart.getThickness();
            tpcPart.zTop = zCoordinate;
            tpcPart = tpcPart.partAbove;
        }
        
        return;
    }
    
/** Add an electron cloud into the TPC
 * @param electronCloud electron cloud to be added
 */
    public void addElectronCloud(ElectronCloud electronCloud) {
        TpcPart tpcPart = topPart;
        while (tpcPart != null) {
            if (electronCloud.z >= tpcPart.zBottom) {
                addElectronCloud(electronCloud,tpcPart);
                tpcPart = null;
            } else {
                tpcPart = tpcPart.partBelow;
            }
        }
    }
    
/** Add an electron cloud into the TPC at the tpc Part given by the
 * second argument (assumed that z coordinate is correct)
 * Gas gain is incorporated by calling this method recursively
 * @param electronCloud electron cloud to be added
 * @param tpcPart top tpcPart to start electron propogation
 */
    void addElectronCloud(ElectronCloud electronCloud, TpcPart tpcPart) {
        while (tpcPart != null && electronCloud.n > 0){
            tpcPart.propagateElectronCloud(electronCloud);
            tpcPart = tpcPart.partBelow;
        }
    }

 /** Clear out the charge from the TPC parts
 */
    void clear(){
        TpcPart tpcPart = bottomPart;
        while (tpcPart != null){
            tpcPart.clear();
            tpcPart = tpcPart.partAbove;
        }
    }
    
}
