package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide panel to control Grid layout options (pitch, number etc)
 * @author Dean Karlen
 * @version 1.0
 */

class GridPanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField xpField,ypField,xnField,ynField,x0Field,y0Field;
    
    GridPanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the pitch:
        xpField = new DecimalField(0, 5, numberFormat);
        ypField = new DecimalField(0, 5, numberFormat);
        xpField.setValue(((lGP.gridLayout).getPitch()).x);
        ypField.setValue(((lGP.gridLayout).getPitch()).y);
        xpField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Location loc = (lGP.gridLayout).getPitch();
                (lGP.gridLayout).setPitch(xpField.getValue(),loc.y);
            }
        });
        ypField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Location loc = (lGP.gridLayout).getPitch();
                (lGP.gridLayout).setPitch(loc.x,ypField.getValue());
            }
        });
        JLabel xpLabel = new JLabel("x pitch:");
        JLabel ypLabel = new JLabel("y pitch:");
        JLabel xpUnitLabel = new JLabel("mm");
        JLabel ypUnitLabel = new JLabel("mm");
        // code for the number:
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((lGP.gridLayout).nx);
        ynField.setValue((lGP.gridLayout).ny);
        xnField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.gridLayout).setNumber((int)xnField.getValue(),(lGP.gridLayout).ny);
                lGP.reset();
            }
        });
        ynField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.gridLayout).setNumber((lGP.gridLayout).nx,(int)ynField.getValue());
                lGP.reset();
            }
        });
        JLabel xnLabel = new JLabel("x number:");
        JLabel ynLabel = new JLabel("y number:");
        // code for the origin:
        x0Field = new DecimalField(0, 5, numberFormat);
        y0Field = new DecimalField(0, 5, numberFormat);
        x0Field.setValue((lGP.gridLayout).x0);
        y0Field.setValue((lGP.gridLayout).y0);
        x0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.gridLayout).setOrigin(x0Field.getValue(),(lGP.gridLayout).y0);
            }
        });
        y0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.gridLayout).setOrigin((lGP.gridLayout).x0,y0Field.getValue());
            }
        });
        JLabel x0Label = new JLabel("x origin:");
        JLabel y0Label = new JLabel("y origin:");
        JLabel x0UnitLabel = new JLabel("mm");
        JLabel y0UnitLabel = new JLabel("mm");
        
        // arrange into a grid
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xpLabel);
        labelPane.add(ypLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xpField);
        fieldPane.add(ypField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(xpUnitLabel);
        unitPane.add(ypUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(x0Label);
        labelPane.add(y0Label);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(x0Field);
        fieldPane.add(y0Field);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(x0UnitLabel);
        unitPane.add(y0UnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
    void readPanel(){
        (lGP.gridLayout).setPitch(xpField.getValue(),ypField.getValue());
        (lGP.gridLayout).setOrigin(x0Field.getValue(),(lGP.gridLayout).y0);
        (lGP.gridLayout).setOrigin((lGP.gridLayout).x0,y0Field.getValue());
        
        if((int)xnField.getValue() != (lGP.gridLayout).nx ||
        (int)ynField.getValue() != (lGP.gridLayout).ny){
            (lGP.gridLayout).setNumber((int)xnField.getValue(),(lGP.gridLayout).ny);
            (lGP.gridLayout).setNumber((lGP.gridLayout).nx,(int)ynField.getValue());
            lGP.reset();
        }
    }
}
