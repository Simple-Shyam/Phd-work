package tpcsimulator;
/** Class to define circular objects (holes and pads)
 * @author Dean Karlen
 * @version 1.0
 */
import java.awt.Graphics;
import java.awt.Color;

public class Circle extends Shape{
    double r;
/** Constructor
 * @param r Radius of circle (mm)
 */
    public Circle(double r)
    {
        this.r=r;
    }
/** Find the nearest edge of the circle centred at (x0,y0) to the point (x,y).
 * Method finds the intersection between line connecting (x0,y0) to (x,y) and
 * the circle, by shrinking the line to the radius of the circle.
 * @param x0 x centre of circle (mm)
 * @param y0 y centre of circle (mm)
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param loc nearest edge (returned)
 */
    public void getNearestEdge(double x0, double y0, double x, double y, Location loc)
    {
        double dx=(x-x0);
        double dy=(y-y0);
        double R=Math.sqrt(dx*dx+dy*dy);
        loc.x=x0+dx*r/R;
        loc.y=y0+dy*r/R;
    }
/** Returns true if a point is inside the circle
 * @param x0 x centre of circle (mm)
 * @param y0 y centre of circle (mm)
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return True if point is inside circle, otherwise false
 */
    public boolean insideElement(double x0, double y0, double x, double y)
    {
        double dx=(x-x0);
        double dy=(y-y0);
        double R=Math.sqrt(dx*dx+dy*dy);
        return R < r;
    }
/** Returns size of circle
 * @return radius of circle (mm)
 */
    public double getSize(){
        return r;
    }
    
}