package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Menu to control which windows to display
 * @author Dean Karlen
 * @version 1.0
 */
class ViewWindowMenu extends JFrame{
    
    TpcGui tpcGui;
    JList list;
    
    ViewWindowMenu(TpcGui iTpcGui){
        super("View a window");
        tpcGui = iTpcGui;
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(new JLabel("Choose Window to view:"));
        
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        
        DefaultListModel listModel = new DefaultListModel();
        if(tpcGui.tpcDesign != null) {
            
            // listModel.addElement(tpcGui.tpcDesign);
            
            int nPart = tpcGui.tpcDesign.tpcPartPanelVector.size();
            for (int iPart = 0; iPart < nPart; iPart++) {
                TpcPartPanel gpp = (TpcPartPanel) tpcGui.tpcDesign.tpcPartPanelVector.elementAt(iPart);
                for (int i=1; i<=gpp.nWindow(); i++){
                    listModel.addElement(gpp.window(i));
                }
            }
        }
        
        list = new JList(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fieldPane.add(list);
        
        getContentPane().add(labelPane, BorderLayout.NORTH);
        getContentPane().add(fieldPane, BorderLayout.CENTER);
        
        JButton cancelButton = new JButton("Cancel");
        JButton okButton = new JButton("Ok");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cancelButton);
        buttonPanel.add(okButton);
        
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!list.isSelectionEmpty()) {
                    JFrame jFrame = (JFrame) list.getSelectedValue();
                    jFrame.setVisible(true);
                    jFrame.setState(JFrame.NORMAL);
                    setVisible(false);
                }
            }
        });
    }
}
