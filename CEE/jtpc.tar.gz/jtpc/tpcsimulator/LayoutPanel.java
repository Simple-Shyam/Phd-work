package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/** Provide panel for layout options (foil holes and pads)
 * @author Dean Karlen
 * @version 1.0
 */
class LayoutPanel extends JPanel implements ItemListener {
    final static String GRIDLAYOUT = "Grid";
    final static String MESHLAYOUT = "Mesh";
    final static String HEXLAYOUT = "Hex Pack";
    final static String SHIFTEDGRIDLAYOUT = "Shifted Grid";
    
    LayoutTpcPart lGP;
    GridPanel gridPanel;
    MeshPanel meshPanel;
    HexPackPanel hexPackPanel;
    ShiftedGridPanel shiftedGridPanel;
    JComboBox comboBox;
    
    LayoutPanel(LayoutTpcPart lGP, JPanel cbp) {
        // combo Box to decide what kind of layout
        this.lGP = lGP;
        String comboBoxItems[] = {GRIDLAYOUT, MESHLAYOUT, HEXLAYOUT, SHIFTEDGRIDLAYOUT};
        comboBox = new JComboBox(comboBoxItems);
        comboBox.setEditable(false);
        comboBox.addItemListener(this);
        cbp.add(comboBox);
        // panel with the options
        setLayout(new CardLayout());
        // Grid options
        gridPanel = new GridPanel(lGP);
        add(gridPanel,GRIDLAYOUT);
        // Mesh options
        meshPanel = new MeshPanel(lGP);
        add(meshPanel,MESHLAYOUT);
        // Hex options
        hexPackPanel = new HexPackPanel(lGP);
        add(hexPackPanel,HEXLAYOUT);
        //Shifted Grid options
        shiftedGridPanel = new ShiftedGridPanel(lGP);
        add(shiftedGridPanel, SHIFTEDGRIDLAYOUT);
        
        // decide which to show to start off with
        if (lGP.layout == lGP.gridLayout) {
            comboBox.setSelectedItem(GRIDLAYOUT);
        } else if (lGP.layout == lGP.meshLayout) {
            comboBox.setSelectedItem(MESHLAYOUT);
        } else if (lGP.layout == lGP.hexPackLayout) {
            comboBox.setSelectedItem(HEXLAYOUT);
        } else if (lGP.layout == lGP.shiftedGridLayout)
        { comboBox.setSelectedItem(SHIFTEDGRIDLAYOUT);}
    }
    
    public void itemStateChanged(ItemEvent evt) {
        CardLayout cl = (CardLayout)(this.getLayout());
        cl.show(this, (String)evt.getItem());
        if((String)evt.getItem() == GRIDLAYOUT) {
            lGP.layout = lGP.gridLayout;
        } else if((String)evt.getItem() == MESHLAYOUT) {
            lGP.layout = lGP.meshLayout;
        } else if((String)evt.getItem() == HEXLAYOUT){
            lGP.layout = lGP.hexPackLayout;
        } else if ((String)evt.getItem() == SHIFTEDGRIDLAYOUT) {
            lGP.layout = lGP.shiftedGridLayout;
            
        }
        //**** ensures no array out of bounds exceptions occur.
        lGP.reset();
    }
    void readPanel(){
        gridPanel.readPanel();
        meshPanel.readPanel();
        hexPackPanel.readPanel();
        shiftedGridPanel.readPanel();
    }
    
    void setModifiable(boolean enabled) {
        comboBox.setEnabled(enabled);
    }
}
