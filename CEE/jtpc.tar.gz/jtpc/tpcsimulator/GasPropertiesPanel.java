package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Panel that allows users to change gas properties
 * @author Dean Karlen
 * @version 1.0
 */

class GasPropertiesPanel extends JPanel {
    GasGap gasGap;
    DecimalField tField,vDField,tDField,lDField,iLField;
    
/** Constructor
 * @param iGasGap Gas gap
 */
    GasPropertiesPanel(GasGap iGasGap){
        gasGap = iGasGap;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);

        // code for the thickness
        tField = new DecimalField(0, 5, numberFormat);
        tField.setValue(gasGap.getThickness());
        tField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gasGap.setThickness(tField.getValue());
            }
        });

        JLabel tLabel = new JLabel("Thickness ");
        JLabel tUnitLabel = new JLabel("mm");

        // code for the drift velocity
        vDField = new DecimalField(0, 5, numberFormat);
        vDField.setValue(gasGap.vDrift);
        vDField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gasGap.vDrift=vDField.getValue();
            }
        });

        JLabel vDLabel = new JLabel("Drift velocity ");
        JLabel vDUnitLabel = new JLabel("um/ns");
        
        // code for the inverse Lifetime
        iLField = new DecimalField(0, 5, numberFormat);
        iLField.setValue(gasGap.invLifetime);
        iLField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gasGap.invLifetime=iLField.getValue();
            }
        });

        JLabel iLLabel = new JLabel("inv. e lifetime ");
        JLabel iLUnitLabel = new JLabel("1/ms");

        // code for the transverse diffusion

        tDField = new DecimalField(0, 5, numberFormat);
        tDField.setValue(gasGap.transverseDiffusion);
        tDField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gasGap.transverseDiffusion=tDField.getValue();
            }
        });

        JLabel tDLabel = new JLabel("Trans. diff. ");
        JLabel tDUnitLabel = new JLabel("um/sqrt(cm)");

        // code for the longitudinal diffusion

        lDField = new DecimalField(0, 5, numberFormat);
        lDField.setValue(gasGap.longitudinalDiffusion);
        lDField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                gasGap.longitudinalDiffusion=lDField.getValue();
            }

        });

        JLabel lDLabel = new JLabel("Long. diff. ");
        JLabel lDUnitLabel = new JLabel("um/sqrt(cm)");

        // arrange into subpanels:
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(tLabel);
        labelPane.add(vDLabel);
        labelPane.add(iLLabel);
        
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(tField);
        fieldPane.add(vDField);
        fieldPane.add(iLField);

        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(tUnitLabel);
        unitPane.add(vDUnitLabel);
        unitPane.add(iLUnitLabel);
        
        JPanel col1 = new JPanel();
        col1.add(labelPane);
        col1.add(fieldPane);
        col1.add(unitPane);

        add(col1);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(tDLabel);
        labelPane.add(lDLabel);

        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(tDField);
        fieldPane.add(lDField);

        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(tDUnitLabel);
        unitPane.add(lDUnitLabel);
        
        JPanel col2 = new JPanel();
        col2.add(labelPane);
        col2.add(fieldPane);
        col2.add(unitPane);
        add(col2);
        
    }

    void readPanel(){

        gasGap.setThickness(tField.getValue());
        gasGap.vDrift=vDField.getValue();
        gasGap.transverseDiffusion=tDField.getValue();
        gasGap.longitudinalDiffusion=lDField.getValue();
        gasGap.invLifetime = iLField.getValue();
    }

}
