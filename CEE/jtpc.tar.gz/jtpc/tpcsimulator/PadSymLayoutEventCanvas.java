package tpcsimulator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import tpctracker.*;
import tpcanalyzer.*;

class PadSymLayoutEventCanvas extends PadMeshEventCanvas implements MouseListener, MouseMotionListener{
    
    SymLayout symLayout;
    PadSymLayout padSymLayout;
    PadSymLayoutEventFrame padSymLayoutEventFrame;
    
    double xmin,xmax,ymin,ymax;
    double pixelSize;
    int lastPadUpdate;
    
    PadSymLayoutEventCanvas(PadSymLayout padSymLayout, PadSymLayoutEventFrame padSymLayoutEventFrame){
        this.padSymLayout = padSymLayout;
        symLayout = padSymLayout.symLayout;
        this.padSymLayoutEventFrame = padSymLayoutEventFrame;
        setBackground(Color.black);
        
        xmin = symLayout.xMin;
        xmax = symLayout.xMax;
        ymin = symLayout.yMin;
        ymax = symLayout.yMax;
        pixelSize = symLayout.pixelSize;
        
        width = (int) ((xmax-xmin)/pixelSize + 0.5);
        height =(int) ((ymax-ymin)/pixelSize + 0.5);
        setBounds(0,0,width,height);
        
        addMouseMotionListener(this);
        addMouseListener(this);
        
        // copy the contents of PadGroup into groupForPad
        // NOTE: No multiplexing for this layout
        int nPadGroup = padSymLayout.getNumElement();
        
        groupForPad = new int[nPadGroup];
        for (int i = 0; i < nPadGroup; i++) {
            groupForPad[i] = -888;
        }
        
        int[][] padGroup = padSymLayout.getPadGroup();
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int iPad = 0; iPad < nPadInGroup; iPad++) {
                int padNumber = padGroup[iPadGroup][iPad];
                groupForPad[padNumber] = iPadGroup;
            }
        }
        largestPadGroupNumber = nPadGroup - 1;
        startSelectionPadGroup = -1;
        endSelectionPadGroup = -1;
        lastPadUpdate = -999;
        
        nElectronInPadGroup = new int[nPadGroup];
        timeForPadGroup = new double[nPadGroup];
    }
    
    public void update(Graphics g){
        
        if (offGraphics == null) {
            offImage = createImage(width,height);
            offGraphics = offImage.getGraphics();
        }
        
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0,0,width,height);
        
        setColorScaleLog(padSymLayoutEventFrame.logScale());
        
        int nPadGroup = padSymLayout.getNumElement();
        for (int i=0; i < nPadGroup; i++) {
            nElectronInPadGroup[i] = 0;
            timeForPadGroup[i] = -999.;
        }
        
        for (int iPad = 0; iPad < padSymLayout.nPad; iPad++) {
            int iGroup = groupForPad[iPad];
            if (iGroup >= 0) {
                nElectronInPadGroup[iGroup] += padSymLayout.pad[iPad].getNElectron();
                timeForPadGroup[iGroup] = padSymLayout.pad[iPad].getTime()*padSymLayout.pad[iPad].getNElectron();
            }
        }
        
        for (int i=0; i<nPadGroup; i++) {
            if (nElectronInPadGroup[i] > 0) {
                timeForPadGroup[i] /= nElectronInPadGroup[i];
            }
        }
        
        // draw the number of electrons collected by each pad group
        
        maxElectron = 1;
        minTime = 9999.;
        maxTime = -9999.;
        for (int iGroup = 0; iGroup < nPadGroup; iGroup++) {
            maxElectron = Math.max(maxElectron,nElectronInPadGroup[iGroup]);
            if (nElectronInPadGroup[iGroup] > 0) {
                minTime = Math.min(minTime,timeForPadGroup[iGroup]);
                maxTime = Math.max(maxTime,timeForPadGroup[iGroup]);
            }
        }
        for (int iPad=0; iPad < nPadGroup; iPad++){
            
            int iGroup = groupForPad[iPad];
            if (iGroup < 0) {
                offGraphics.setColor(Color.white);
            } else if (!padSymLayout.padGroupIsEnabled(groupForPad[iPad])) {
                offGraphics.setColor(Color.gray);
            } else {
                if (padSymLayoutEventFrame.showTimeData()) {
                    offGraphics.setColor(colorScale(timeForPadGroup[iGroup],minTime,maxTime));
                } else {
                    offGraphics.setColor(colorScale(nElectronInPadGroup[iGroup],maxElectron));
                }
            }
            
            // draw pad: leave a pixel around it to show shapes
            
            Location loc = new Location();
            symLayout.getCentre(iPad,loc);
            double base = symLayout.base;
            if (symLayout.symmetry == 2){
                int ix = (int) ((loc.x-base/2.-xmin)/pixelSize + 0.5) + 1;
                int iy = (int) ((loc.y-base/2.-ymin)/pixelSize + 0.5) + 1;
                int dx = (int) (base/pixelSize + 0.5) - 2;
                int dy = (int) (base/pixelSize + 0.5) - 2;
                offGraphics.fillRect(ix,height-iy-dy,dx,dy);
            } else {
                int[] ix = new int[3];
                int[] iy = new int[3];
                double vert = base * Math.sqrt(3.)/2.;
                if(symLayout.isUp(iPad)){
                    // pointing up
                    ix[0] = (int) ((loc.x-base/2.-xmin)/pixelSize + 0.5) + 1;
                    iy[0] = height - ((int) ((loc.y-vert/2.-ymin)/pixelSize + 0.5) + 1);
                    ix[1] = (int) ((loc.x-xmin)/pixelSize + 0.5);
                    iy[1] = height - ((int) ((loc.y+vert/2.-ymin)/pixelSize + 0.5) - 1);
                    ix[2] = (int) ((loc.x+base/2.-xmin)/pixelSize + 0.5) - 1;
                    iy[2] = height - ((int) ((loc.y-vert/2.-ymin)/pixelSize + 0.5) + 1);
                } else {
                    // pointing down
                    ix[0] = (int) ((loc.x-base/2.-xmin)/pixelSize + 0.5) + 1;
                    iy[0] = height - ((int) ((loc.y+vert/2.-ymin)/pixelSize + 0.5) - 1);
                    ix[1] = (int) ((loc.x-xmin)/pixelSize + 0.5);
                    iy[1] = height - ((int) ((loc.y-vert/2.-ymin)/pixelSize + 0.5) + 1);
                    ix[2] = (int) ((loc.x+base/2.-xmin)/pixelSize + 0.5) - 1;
                    iy[2] = height - ((int) ((loc.y+vert/2.-ymin)/pixelSize + 0.5) - 1);
                }
                offGraphics.fillPolygon(ix, iy, 3);
            }
        }
        
        // Draw the seed track if requested:
        if (padSymLayoutEventFrame.showSeedTrack()) {
            TpcAnalyzer tpcAnalyzer = padSymLayoutEventFrame.tpcAnalyzer;
            if (tpcAnalyzer != null && tpcAnalyzer.getFitterMultiplicity() > 0) {
                double[] seedParam = tpcAnalyzer.getSeedParam();
                if (tpcAnalyzer.getFitterMultiplicity() == 1) {
                    double x0 = seedParam[0];
                    double phi = seedParam[1];
                    double sigma = seedParam[2];
                    double iR = seedParam[5];
                    double dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                    addCurve(x0, phi, iR, 0., Color.green);
                    addCurve(x0, phi, iR, sigma, Color.yellow);
                    addCurve(x0, phi, iR, -sigma, Color.yellow);
                } else {
                    double x0 = seedParam[0];
                    double phi = seedParam[1];
                    double sigma = seedParam[2];
                    double dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                    addLine(x0,phi,Color.green);
                    addLine(x0+dxs,phi,Color.yellow);
                    addLine(x0-dxs,phi,Color.yellow);
                    x0 = seedParam[3];
                    phi = seedParam[4];
                    sigma = seedParam[5];
                    dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                    addLine(x0,phi,Color.cyan);
                    addLine(x0+dxs,phi,Color.pink);
                    addLine(x0-dxs,phi,Color.pink);
                }
            }
        }
        
        // Draw the track fit if requested:
        if (padSymLayoutEventFrame.showTrackFit()) {
            XYFitter xyFitter = padSymLayoutEventFrame.fitterControlFrame.getXYFitter();
            if (xyFitter != null) {
                double[] param=xyFitter.getParam();
                if(xyFitter.getFitterMultiplicity() == 1) {
                    double x0 = param[0];
                    double phi0 = param[1];
                    double sigma = param[2];
                    double iR = param[3];
                    addCurve(x0, phi0, iR, 0., Color.white);
                    addCurve(x0, phi0, iR, sigma, Color.lightGray);
                    addCurve(x0, phi0, iR, -sigma, Color.lightGray);
                } else {
                    double x0 = param[0];
                    double phi = param[1];
                    double sigma = param[2];
                    double dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                    addLine(x0,phi,Color.white);
                    addLine(x0+dxs,phi,Color.lightGray);
                    addLine(x0-dxs,phi,Color.lightGray);
                    x0 = param[3];
                    phi = param[4];
                    sigma = param[5];
                    dxs = sigma/Math.cos(phi); // hori offset of +/- 1 sigma lines
                    addLine(x0,phi,Color.blue);
                    addLine(x0+dxs,phi,Color.orange);
                    addLine(x0-dxs,phi,Color.orange);
                }
            }
        }
        
        // Draws the buffered image to the screen.
        g.drawImage(offImage, 0, 0, this);
        
        // update legend
        if(padSymLayoutEventFrame.showTimeData()) {
            padSymLayoutEventFrame.setLegend(minTime,maxTime);
        } else {
            padSymLayoutEventFrame.setLegend(maxElectron);
        }
    }
    
    void addLine(double x0, double phi, Color color){
        
        double xTop = x0 - ymax*Math.tan(phi);
        double xBot = x0 - ymin*Math.tan(phi);
        
        int ixTop = (int) ((xTop-xmin)/pixelSize + 0.5);
        int ixBot = (int) ((xBot-xmin)/pixelSize + 0.5);
        offGraphics.setColor(color);
        offGraphics.drawLine(ixTop,0,ixBot,height);
    }
    
    void addCurve(double x0, double phi0, double invRadius, double offset, Color color){
        
        int nSeg = 50;
        double dy = (ymax - ymin)/nSeg;
        double y = ymin - dy/2.;
        for (int i=0; i < nSeg; i++) {
            y += dy;
            double sinp0 = Math.sin(phi0);
            double cosp0 = Math.cos(phi0);
            if (cosp0<0.){sinp0 *= -1.; cosp0 *= -1.;}
            
            // check if necessary to do expandsion in 1/r:
            double x = 0;
            if(Math.abs((ymax-ymin)*invRadius)<0.001){
                double coeff1 = y*y/2./cosp0/cosp0/cosp0;
                double coeff2 = coeff1*y*sinp0/cosp0/cosp0;
                x = x0 - y*sinp0/cosp0 + coeff1*invRadius - coeff2*invRadius*invRadius;
            } else {
                double alpha = (2.*sinp0-y*invRadius)*y*invRadius/cosp0/cosp0;
                x = x0 + cosp0/invRadius*(1.-Math.sqrt(1.+alpha));
            }
            double sinp = sinp0 - y*invRadius;
            double cosp = Math.sqrt(1. - sinp*sinp);
            
            double yTop = y + dy/2.;
            double xTop = x - dy/2.*sinp/cosp + offset/cosp;
            double yBot = y - dy/2.;
            double xBot = x + dy/2.*sinp/cosp + offset/cosp;
            
            int ixTop = (int) ((xTop-xmin)/pixelSize + 0.5);
            int iyTop = height - (int) ((yTop-ymin)/pixelSize + 0.5);
            int ixBot = (int) ((xBot-xmin)/pixelSize + 0.5);
            int iyBot = height - (int) ((yBot-ymin)/pixelSize + 0.5);
            
            offGraphics.setColor(color);
            offGraphics.drawLine(ixTop,iyTop,ixBot,iyBot);
        }
        
    }
    
    public void mouseMoved(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad != lastPadUpdate) {
            updateLocationLabel(iPad,0);
            lastPadUpdate = iPad;
        } 
    }
    
    public void mouseClicked(MouseEvent e) {
        if (padSymLayoutEventFrame.showPulseData() && e.getButton() > 1)
            padSymLayoutEventFrame.newDataFrame();
    }
    
    void updateLocationLabel(int iPad, int dummy) {
        if (iPad >= 0 && iPad < padSymLayout.nPad) {
            int iGroup = groupForPad[iPad];
            if (iGroup < 0) {
                if (padSymLayout.pad[iPad].getNElectron() > 0) {
                    padSymLayoutEventFrame.setDataLabel("Pad # " + iPad +
                    " (" + padSymLayout.pad[iPad].getNElectron() + " electrons" +
                    " @ time " + myFormat(padSymLayout.pad[iPad].getTime()) + ")" +
                    " is unassigned");
                } else {
                    padSymLayoutEventFrame.setDataLabel("Pad # " + iPad);
                }
            } else {
                if (padSymLayout.pad[iPad].getNElectron() > 0) {
                    padSymLayoutEventFrame.setDataLabel("Pad # " + iPad +
                    " (" + padSymLayout.pad[iPad].getNElectron() + " electrons" +
                    " @ time " + myFormat(padSymLayout.pad[iPad].getTime()) + ")" +
                    " in group # " + iGroup + " (" + nElectronInPadGroup[iGroup]
                    + " electrons @ time " + myFormat(timeForPadGroup[iGroup]) + ")");
                } else {
                    padSymLayoutEventFrame.setDataLabel("Pad # " + iPad);
                }
                // also update the pulse data for the pad, if requested
                if (padSymLayoutEventFrame.showPulseData())
                    padSymLayoutEventFrame.padSymLayoutDataFrame.setData(iPad,padSymLayout.pad[iPad].getData());
            }
        } else {
            padSymLayoutEventFrame.setDataLabel(" ");
        }
    }
    
    int getIPad(int ix, int iy) {
        double x = xmin + ix*pixelSize;
        double y = ymin + (height-iy)*pixelSize;
        if (symLayout.insideElement(x,y)) return symLayout.getNearestIndex(x,y);
        else return -1;
    }
    
    public int getScrollableUnitIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return 10;
    }
    
    public int getScrollableBlockIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return 50;
    }
    
}