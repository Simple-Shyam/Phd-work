package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Panel to provide statistics for current data
 * @author Dean Karlen
 * @version 1.0
 */

class StatData extends JPanel {
    
    int nChan;
    DecimalField nField,xField,xRMSField,yField,yRMSField,xRMSRunField,yRMSRunField;
    PadArrayPanel padArrayPanel;
    FracChan[] fracChan;
    boolean cumul;
    
    StatData(PadArrayPanel padArrayPanel, String name, boolean cumul){
        
        this.padArrayPanel = padArrayPanel;
        this.cumul = cumul;
        // layout the Panel in the Read Out window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder(name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        
        // set up data fields
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(0);
        nField = new DecimalField(0., 6, numberFormat);
        nField.setEditable(false);
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(3);
        xField = new DecimalField(0., 5, numberFormat);
        xField.setEditable(false);
        xRMSField = new DecimalField(0., 5, numberFormat);
        xRMSField.setEditable(false);
        yField = new DecimalField(0., 5, numberFormat);
        yField.setEditable(false);
        yRMSField = new DecimalField(0., 5, numberFormat);
        yRMSField.setEditable(false);
        xRMSRunField = new DecimalField(0., 5, numberFormat);
        xRMSRunField.setEditable(false);
        yRMSRunField = new DecimalField(0., 5, numberFormat);
        yRMSRunField.setEditable(false);
        
        JPanel jBorderPanel = new JPanel(new BorderLayout());
        
        JLabel nLabel,nUnitLabel;
        if (cumul){
            nLabel = new JLabel("Cumulative summary for");
            nUnitLabel = new JLabel("events");
        } else {
            nLabel = new JLabel("Charge distribution for");
            nUnitLabel = new JLabel("electrons");
        }
        
        JPanel jPanel = new JPanel();
        jPanel.add(nLabel);
        jPanel.add(nField);
        jPanel.add(nUnitLabel);
        jBorderPanel.add(jPanel,BorderLayout.NORTH);
        
        JLabel xLabel = new JLabel("Mean x");
        JLabel xRMSLabel = new JLabel("rms");
        JLabel yLabel = new JLabel("Mean y");
        JLabel yRMSLabel = new JLabel("rms");
        JLabel xUnitLabel = new JLabel("mm");
        JLabel yUnitLabel = new JLabel("mm");
        
        JPanel contentPane = new JPanel();
        
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(xLabel);
        jPanel.add(yLabel);
        contentPane.add(jPanel);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(xField);
        jPanel.add(yField);
        contentPane.add(jPanel);
        
        contentPane.add(Box.createRigidArea(new Dimension(20,0)));
        
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(xRMSLabel);
        jPanel.add(yRMSLabel);
        contentPane.add(jPanel);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(xRMSField);
        jPanel.add(yRMSField);
        contentPane.add(jPanel);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(xUnitLabel);
        jPanel.add(yUnitLabel);
        contentPane.add(jPanel);
        
        jBorderPanel.add(contentPane,BorderLayout.CENTER);
        
        if(cumul){
            contentPane = new JPanel();
            jPanel = new JPanel();
            jPanel.setLayout(new GridLayout(0,1));
            jPanel.add(new JLabel("Mean x rms"));
            jPanel.add(new JLabel("Mean y rms"));
            contentPane.add(jPanel);
            jPanel = new JPanel();
            jPanel.setLayout(new GridLayout(0,1));
            jPanel.add(xRMSRunField);
            jPanel.add(yRMSRunField);
            contentPane.add(jPanel);
            jPanel = new JPanel();
            jPanel.setLayout(new GridLayout(0,1));
            jPanel.add(new JLabel("mm"));
            jPanel.add(new JLabel("mm"));
            contentPane.add(jPanel);
            jBorderPanel.add(contentPane,BorderLayout.SOUTH);
        }
        
        add(jBorderPanel,BorderLayout.WEST);
        
        add(Box.createRigidArea(new Dimension(20,0)),BorderLayout.CENTER);
        
        jBorderPanel = new JPanel(new BorderLayout());
        if (cumul){
            jBorderPanel.add(new JLabel("Charge fractions (and RMS) in pads",JLabel.CENTER),
            BorderLayout.NORTH);
        } else {
            jBorderPanel.add(new JLabel("Charge fractions in pads",JLabel.CENTER),
            BorderLayout.NORTH);
        }
        
        JPanel fracPanel = new JPanel();
        nChan = padArrayPanel.readOut.scope.nChan;
        fracChan = new FracChan[nChan];
        for (int i=0; i<nChan; i++){
            fracChan[i] = new FracChan(padArrayPanel,i+1,cumul);
            fracPanel.add(fracChan[i]);
        }
        
        jBorderPanel.add(fracPanel,BorderLayout.CENTER);
        add(jBorderPanel,BorderLayout.EAST);
    }
    
}
