package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.io.Serializable;

/** Preamplifier functionality
 * @author Dean Karlen
 * @version 1.0
 */
class PreAmpPanel extends JPanel {
    
    PreAmp preAmp;
    DecimalField rTField,fTField,gField;
    JCheckBox inductionBox;
    PreAmpPanel(PreAmp iPreAmp){
        
        // layout the Panel in the Read Out window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("PreAmp"),
        BorderFactory.createEmptyBorder(5,5,5,5)));

        preAmp = iPreAmp;
        
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(0);
        // rise Time field
        rTField = new DecimalField(0, 4, numberFormat);
        rTField.setValue(preAmp.riseTime);
        rTField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                preAmp.riseTime=(int)rTField.getValue();
            }
        });
        // fall Time field
        fTField = new DecimalField(0, 4, numberFormat);
        fTField.setValue(preAmp.fallTime);
        fTField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                preAmp.fallTime=(int)fTField.getValue();
            }
        });
        // gain field
        numberFormat.setMaximumFractionDigits(2);
        gField = new DecimalField(0, 4, numberFormat);
        gField.setValue(preAmp.gain);
        gField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                preAmp.gain=gField.getValue();
            }
        });
        inductionBox = new JCheckBox();
        inductionBox.setSelected(preAmp.induction);
        inductionBox.setEnabled(false); // not yet working... disable for now
        inductionBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                preAmp.induction=inductionBox.isSelected();
            }
        });
        
        JLabel rTLabel = new JLabel("rise time");
        JLabel rTUnit = new JLabel("ns");
        JLabel fTLabel = new JLabel("fall time");
        JLabel fTUnit = new JLabel("ns");
        JLabel gLabel = new JLabel("gain");
        JLabel gUnit = new JLabel("mV/fC");
        JLabel iLabel = new JLabel("include induction signals");
        
        JButton setButton = new JButton("Set parameters");
        setButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                preAmp.riseTime=(int)rTField.getValue();
                preAmp.fallTime=(int)fTField.getValue();
                preAmp.gain=gField.getValue();
                preAmp.induction=inductionBox.isSelected();
            }
        });
        
        JPanel contentPane = new JPanel();
        
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(rTLabel);
        jPanel.add(fTLabel);
        contentPane.add(jPanel);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(rTField);
        jPanel.add(fTField);
        contentPane.add(jPanel);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(rTUnit);
        jPanel.add(fTUnit);
        contentPane.add(jPanel);
        
        contentPane.add(Box.createRigidArea(new Dimension(20,0)));
        
        JPanel gPanel = new JPanel();
        gPanel.add(gLabel);
        gPanel.add(gField);
        gPanel.add(gUnit);
        
        JPanel iPanel = new JPanel();
        iPanel.add(inductionBox);
        iPanel.add(iLabel);
        
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(0,1));
        jPanel.add(gPanel);
        jPanel.add(iPanel);
        
        contentPane.add(jPanel);

        contentPane.add(Box.createRigidArea(new Dimension(20,0)));
        
        contentPane.add(setButton);
        
        add(contentPane,BorderLayout.WEST);
    }
}
