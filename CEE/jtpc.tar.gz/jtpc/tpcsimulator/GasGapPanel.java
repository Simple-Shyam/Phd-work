package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author  karlen
 * @version
 */
class GasGapPanel extends TpcPartPanel {
    
    GasPropertiesPanel gasPropertiesPanel;
    GasGap gasGap;
    
    /** Creates new GasGapPanel */
    GasGapPanel(GasGap gasGap, TpcDesign tpcDesign) {
        this.gasGap = gasGap;
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Gas Gap: " + gasGap.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Properties of the Gas Gap:
        gasPropertiesPanel = new GasPropertiesPanel(gasGap);
        add(gasPropertiesPanel,BorderLayout.WEST);
    }
    
    void readPanel(){gasPropertiesPanel.readPanel();}
    
}
