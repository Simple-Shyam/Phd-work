package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Frame to show statistics
 * @author Dean Karlen
 * @version 1.0
 */
class StatsWindow extends JFrame {
    PadArrayPanel padArrayPanel;
    JPanel mainPane;
    JScrollPane scrollPane;
    StatData currentData,cumulativeData;
    int nRun,nChan;
    double xSumRun,ySumRun,x2SumRun,y2SumRun,xRMSSumRun,yRMSSumRun;
    double[] fSumRun,f2SumRun;
    
    StatsWindow(PadArrayPanel padArrayPanel){
        this.padArrayPanel = padArrayPanel;
        mainPane = new JPanel();
        mainPane.setLayout(new BoxLayout(mainPane, BoxLayout.Y_AXIS));
        //    setContentPane(mainPane);
        
        scrollPane = new JScrollPane(mainPane);
        setContentPane(scrollPane);
        
        nChan = padArrayPanel.readOut.scope.nChan;
        fSumRun = new double[nChan];
        f2SumRun = new double[nChan];
        clear();
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
    }
    
    public String toString(){return getTitle();}
    
    void clear(){
        nRun=0;
        xSumRun=0.;
        ySumRun=0.;
        x2SumRun=0.;
        y2SumRun=0.;
        xRMSSumRun=0.;
        yRMSSumRun=0.;
        for (int i=0; i<nChan; i++){
            fSumRun[i]=0.;
            f2SumRun[i]=0.;
        }
    }
    
    void drawStatsWindow(){
        mainPane.removeAll();
        
        currentData = new StatData(padArrayPanel,"Current Data",false);
        mainPane.add(currentData);
        
        cumulativeData = new StatData(padArrayPanel,"Cumulative Data",true);
        mainPane.add(cumulativeData);
        
        pack();
    }
    
    void doCalc(boolean runSum){
        double xsum=0;
        double ysum=0;
        double x2sum=0;
        double y2sum=0;
        double sx2sum=0;
        double sy2sum=0;
        int nsum=0;
        for (int i=1; i<=padArrayPanel.padArray.nPad; i++){
            Cluster cluster = padArrayPanel.padArray.pad[i].firstCluster;
            while (cluster != null){
                xsum += cluster.n*cluster.getX();
                ysum += cluster.n*cluster.getY();
                x2sum += cluster.n*cluster.getX()*cluster.getX();
                y2sum += cluster.n*cluster.getY()*cluster.getY();
                sx2sum += cluster.n*cluster.getSx()*cluster.getSx();
                sy2sum += cluster.n*cluster.getSy()*cluster.getSy();
                nsum += cluster.n;
                cluster = cluster.nextCluster;
            }
        }
        currentData.nField.setValue(nsum);
        if (nsum>0) {
            currentData.xField.setValue(xsum/nsum);
            currentData.yField.setValue(ysum/nsum);
            currentData.xRMSField.setValue(Math.sqrt((sx2sum+x2sum-xsum*xsum/nsum)/nsum));
            currentData.yRMSField.setValue(Math.sqrt((sy2sum+y2sum-ysum*ysum/nsum)/nsum));
        } else {
            currentData.xField.setValue(0.);
            currentData.yField.setValue(0.);
            currentData.xRMSField.setValue(0.);
            currentData.yRMSField.setValue(0.);
        }
        
        // charge fractions in pads
        for (int i=0; i<nChan; i++){
            int ninpad = padArrayPanel.padArray.getNElectron
            (padArrayPanel.readOut.scope.scopeChan[i].padIndex);
            if (nsum > 0) {
                currentData.fracChan[i].fField.setValue(1.*ninpad/nsum);
            } else {
                currentData.fracChan[i].fField.setValue(0.);
            }
            currentData.fracChan[i].updateColor();
        }
        
        if(runSum){
            nRun++;
            xSumRun += xsum/nsum;
            ySumRun += ysum/nsum;
            x2SumRun += (xsum/nsum)*(xsum/nsum);
            y2SumRun += (ysum/nsum)*(ysum/nsum);
            xRMSSumRun += Math.sqrt((sx2sum+x2sum-xsum*xsum/nsum)/nsum);
            yRMSSumRun += Math.sqrt((sy2sum+y2sum-ysum*ysum/nsum)/nsum);
            for (int i=0; i<nChan; i++){
                int ninpad = padArrayPanel.padArray.getNElectron
                (padArrayPanel.readOut.scope.scopeChan[i].padIndex);
                fSumRun[i] += 1.*ninpad/nsum;
                f2SumRun[i] += 1.*ninpad*ninpad/nsum/nsum;
            }
            cumulativeData.nField.setValue(nRun);
            cumulativeData.xField.setValue(xSumRun/nRun);
            cumulativeData.yField.setValue(ySumRun/nRun);
            cumulativeData.xRMSRunField.setValue(xRMSSumRun/nRun);
            cumulativeData.yRMSRunField.setValue(yRMSSumRun/nRun);
            if(nRun>1){
                cumulativeData.xRMSField.setValue(Math.sqrt((x2SumRun-xSumRun*xSumRun/nRun)/(nRun-1)));
                cumulativeData.yRMSField.setValue(Math.sqrt((y2SumRun-ySumRun*ySumRun/nRun)/(nRun-1)));
            }
            for (int i=0; i<nChan; i++){
                cumulativeData.fracChan[i].fField.setValue(fSumRun[i]/nRun);
                cumulativeData.fracChan[i].fRMSField.setValue(Math.sqrt((f2SumRun[i]-fSumRun[i]*fSumRun[i]/nRun)/(nRun-1)));
                cumulativeData.fracChan[i].updateColor();
            }
        }
    }
}
