package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Panel that allows users to change generic foil properties
 * @author Dean Karlen
 * @version 1.0
 */

class FoilPropertiesPanel extends JPanel {
    Foil foil;
    DecimalField gField,tField,colField,extField;
/** Constructor
 * @param iFoil Foil identifier
 */
    FoilPropertiesPanel(Foil iFoil){
        foil = iFoil;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the gain
        gField = new DecimalField(0, 5, numberFormat);
        gField.setValue(foil.gain);
        gField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                foil.gain=gField.getValue();
            }
        });
        JLabel gLabel = new JLabel("Gain");
        JLabel gUnitLabel = new JLabel("     ");
        // code for the collection Efficiency
        colField = new DecimalField(0, 5, numberFormat);
        colField.setValue(foil.collectionEfficiency);
        colField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                foil.collectionEfficiency=colField.getValue();
            }
        });
        JLabel colLabel = new JLabel("Collection eff.");
        JLabel colUnitLabel = new JLabel("     ");
        // code for the extraction Efficiency
        extField = new DecimalField(0, 5, numberFormat);
        extField.setValue(foil.extractionEfficiency);
        extField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                foil.extractionEfficiency=extField.getValue();
            }
        });
        JLabel extLabel = new JLabel("Extraction eff.");
        JLabel extUnitLabel = new JLabel("     ");
        // code for the thickness
        tField = new DecimalField(0, 5, numberFormat);
        tField.setValue(foil.getThickness());
        tField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                foil.setThickness(tField.getValue());
            }
        });
        JLabel tLabel = new JLabel("Thickness ");
        JLabel tUnitLabel = new JLabel("mm");
        
        add(gLabel);
        add(gField);
        add(gUnitLabel);
        
        add(colLabel);
        add(colField);
        add(colUnitLabel);
        
        add(extLabel);
        add(extField);
        add(extUnitLabel);
        
        add(tLabel);
        add(tField);
        add(tUnitLabel);
        
    }
    void readPanel(){
        foil.gain=gField.getValue();
        foil.collectionEfficiency=colField.getValue();
        foil.extractionEfficiency=extField.getValue();
        foil.setThickness(tField.getValue());
    }
}