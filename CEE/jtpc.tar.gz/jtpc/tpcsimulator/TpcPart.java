package tpcsimulator;
import java.io.*;

/** Generic Tpc Part
 * @author Dean Karlen
 * @version 1.0
 */
public abstract class TpcPart implements Serializable {
/** Name of TPC part
 */
    String name;
/** TPC that the part belongs to
 */
    Tpc tpc;
/** TPC part directly below this one (in z coordinate)
 */
    TpcPart partBelow;
/** TPC part directly above this one (in z coordinate)
 */
    TpcPart partAbove;
/** z coordinates of the bottom of this TPC part
 */
    double zBottom;
/** z coordinate of the top of this TPC part
 */
    double zTop;
    double thickness;
    double vDrift; // um/ns for non-gaseous parts, this may be meaningless

    boolean fittable = false;
    
/** Constructor
 * @param tpcPartDesc Descriptor for TPC part
 */
    TpcPart(TpcPartDesc tpcPartDesc){
        name = tpcPartDesc.name;
        partBelow = null;
        partAbove = null;
        zBottom = 0.;
        zTop = 0.;
        vDrift = 40.;
        thickness=tpcPartDesc.thickness;
    }
    
/** Set thickness for TPC part (after which all TPC part z coordinates are recalculated)
 * @param thickness thickness in mm
 */
    public void setThickness(double thickness){
        this.thickness = thickness;
        tpc.calculateTpcPartZCoordinates();
    }
    
/** Return current thickness of TPC part
 * @return current thickness of TPC part (mm)
 */
    public double getThickness(){
        return thickness;
    }

/** Return current drift velocity for electrons in TPC part
 * @return current drift velocity for electrons in TPC part (um/ns)
 */
    public double getVDrift(){
        return vDrift;
    }
        
/** Actions to be taken when clear requested
 */
    void clear(){}
    
    public TpcPart getPartBelow(){
        return partBelow;
    }
    
    public TpcPart getPartAbove(){
        return partAbove;
    }
    
    public boolean isFittable(){
        return fittable;
    }
    
    // useful for menu items:
    public String toString(){return name;}
    
    abstract void propagateElectronCloud(ElectronCloud electronCloud);
    
    abstract TpcPartPanel newPanel(TpcDesign tpcDesign);
}
