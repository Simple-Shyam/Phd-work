package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide panel to control row layout options
 * @author Dean Karlen
 * @version 1.0
 */

class RowLayoutPanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField psField,xnField,ynField,xxField,yxField;
    
    RowLayoutPanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the pixel size:
        psField = new DecimalField(0, 5, numberFormat);
        psField.setValue(lGP.rowLayout.pixelSize);
        psField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.rowLayout.pixelSize = psField.getValue();
            }
        });
        JLabel psLabel = new JLabel("Pixel Size:");
        JLabel psUnitLabel = new JLabel("mm");
        // code for the lower left corner
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((lGP.rowLayout).xMin);
        ynField.setValue((lGP.rowLayout).yMin);
        xnField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.rowLayout.xMin = xnField.getValue();
            }
        });
        ynField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.rowLayout.yMin = ynField.getValue();
            }
        });
        JLabel xnLabel = new JLabel("x_min (left):");
        JLabel ynLabel = new JLabel("y_min (bottom):");
        // code for the upper right corner
        xxField = new DecimalField(0, 5, numberFormat);
        yxField = new DecimalField(0, 5, numberFormat);
        xxField.setValue((lGP.rowLayout).xMax);
        yxField.setValue((lGP.rowLayout).yMax);
        xxField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.rowLayout.xMax = xxField.getValue();
            }
        });
        yxField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lGP.rowLayout.yMax = yxField.getValue();
            }
        });
        JLabel xxLabel = new JLabel("x_max (right):");
        JLabel yxLabel = new JLabel("y_max (top):");
        JLabel xxUnitLabel = new JLabel("mm");
        JLabel yxUnitLabel = new JLabel("mm");
        
        // arrange into a grid
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(psLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(psField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(psUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xxLabel);
        labelPane.add(yxLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xxField);
        fieldPane.add(yxField);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(xxUnitLabel);
        unitPane.add(yxUnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
 
    void readPanel(){
        lGP.rowLayout.pixelSize = psField.getValue();
        lGP.rowLayout.xMin = xnField.getValue();
        lGP.rowLayout.yMin = ynField.getValue();
        lGP.rowLayout.xMax = xxField.getValue();
        lGP.rowLayout.yMax = yxField.getValue();
    }
}