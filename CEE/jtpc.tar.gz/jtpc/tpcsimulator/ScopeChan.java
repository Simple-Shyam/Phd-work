package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import jas.hist.*;
import java.io.Serializable;

/** A single channel of the oscilliscope
 * @author Dean Karlen
 * @version 1.0
 */
class ScopeChan extends JPanel {
    Color color;
    JButton cButton;
    int padIndex,channel;
    DecimalField pField,nField;
    ScopeChan thisScopeChan;
    JASHist1DHistogramStyle jASHist1DHistogramStyle;
    
    ScopeChan(int channel,int padIndex){
        this.channel = channel;
        thisScopeChan = this;
        this.padIndex = padIndex;
        color = Color.red;
        
        jASHist1DHistogramStyle = new JASHist1DHistogramStyle();
        
        // make the GUI here
        
        setLayout(new GridLayout(0,1));
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(0);
        // pad number field
        pField = new DecimalField(0, 4, numberFormat);
        pField.setValue(padIndex);
        
        cButton = new JButton(String.valueOf(channel));
        cButton.setBackground(color);
        cButton.setForeground(Color.white);
        cButton.setToolTipText("Click here to change color of this channel");
        cButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ColorChooser colorChooser = new ColorChooser(thisScopeChan);
                colorChooser.pack();
                colorChooser.setVisible(true);
            }
        });
        
        // electron number field
        nField = new DecimalField(0, 6, numberFormat);
        nField.setEditable(false);
        
        add(cButton);
        add(pField);
        add(nField);
    }
    
    void setColor(Color newColor){
        color=newColor;
        cButton.setBackground(color);
        jASHist1DHistogramStyle.setDataPointColor(color);
        jASHist1DHistogramStyle.setHistogramBarColor(color);
        jASHist1DHistogramStyle.setLineColor(color);
    }
    
}
