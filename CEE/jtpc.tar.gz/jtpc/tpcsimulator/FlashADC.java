/*
 * FlashADC.java
 *
 * Created on April 3, 2002, 9:40 AM
 */

package tpcsimulator;

/**
 *
 * @author  karlen
 * @version 
 */
public class FlashADC {

    public double gain;
    public int bits;
    
    /** Creates new default FlashADC */
    public FlashADC() {
        gain = 1.;
        bits = 8;
    }

    /** Creates new FlashADC */
    public FlashADC(double gain, int bits) {
        this.gain = gain;
        this.bits = bits;
    }

        
/** Convert Signal into data bytes with FADC
     */
    
    public byte[] convert(Signal signal) {

        int nB = 1 + (bits-1)/8;
        int nbyte = signal.nBin*nB;
        byte[] data = new byte[nbyte];
        int pedestal = 1 << (bits-3);

        int mask= (1 << bits) - 1;        
        int iLoc = -1;
        int offSet = mask - pedestal;
        for (int iBin=0; iBin < signal.nBin; iBin++) {
            int chan = Math.max(0,(int) (signal.data[iBin]*gain + offSet));
            int bitchan = chan & mask;
            for (int iB = 1; iB <= nB; iB++) {
                iLoc++;
                data[iLoc] = (byte) (bitchan & 255);
                bitchan >>= 8;
            }
        }
        return data;
    }
    
}