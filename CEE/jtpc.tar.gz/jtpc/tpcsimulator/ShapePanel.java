package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
/** Provide a panel to adjust shape options
 * @author Dean Karlen
 * @version 1.0
 */
class ShapePanel extends JPanel implements ItemListener {
    final static String CIRCLE = "Circle";
    final static String RECTANGLE = "Rectangle";
    final static String SQUARE = "Square";
    LayoutTpcPart lGP;
    CirclePanel circlePanel;
    RectanglePanel rectanglePanel;
    SquarePanel squarePanel;
    JComboBox comboBox;
    
    ShapePanel(LayoutTpcPart lGP, JPanel cbp) {
        // combo Box to decide what kind of shape
        this.lGP = lGP;
        String comboBoxItems[] = {CIRCLE,RECTANGLE,SQUARE};
        comboBox = new JComboBox(comboBoxItems);
        comboBox.setEditable(false);
        comboBox.addItemListener(this);
        cbp.add(comboBox);
        // panel with the options
        setLayout(new CardLayout());
        // Circle options
        circlePanel = new CirclePanel(lGP);
        add(circlePanel,CIRCLE);
        // Rectangle options
        rectanglePanel = new RectanglePanel(lGP);
        add(rectanglePanel,RECTANGLE);
        // Square options
        squarePanel = new SquarePanel(lGP);
        add(squarePanel,SQUARE);
        // decide which to show to start off with
        if ((lGP.layout).getShape() == lGP.circle) {
            comboBox.setSelectedItem(CIRCLE);
        } else if ((lGP.layout).getShape() == lGP.square) {
            comboBox.setSelectedItem(SQUARE);
        } else {
            comboBox.setSelectedItem(RECTANGLE);
        }
    }
    public void itemStateChanged(ItemEvent evt) {
        CardLayout cl = (CardLayout)(this.getLayout());
        cl.show(this, (String)evt.getItem());
        if((String)evt.getItem() == CIRCLE) {
            (lGP.layout).setShape(lGP.circle);
        } if((String)evt.getItem() == SQUARE) {
            (lGP.layout).setShape(lGP.square);
        } else {
            (lGP.layout).setShape(lGP.rectangle);
        }
    }
    void readPanel(){
        circlePanel.readPanel();
        rectanglePanel.readPanel();
        squarePanel.readPanel();
    }
    void setModifiable(boolean enabled){
        comboBox.setEnabled(enabled);
        squarePanel.setModifiable(enabled);
    }
}
