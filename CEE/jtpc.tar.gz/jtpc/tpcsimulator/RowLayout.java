package tpcsimulator;
/** Define the row layout design
 * <PRE>
 * The row layout is a set of recangular pads arranged in rows.
 * The height of all pads in a row must be the same size
 * Pads may be multiplexed... for reliable fitting, the
 * multiplexing should be done within rows only.
 *
 * - designed for tracks to be typically perpendicular to rows
 *
 * @author Dean Karlen
 * @version 1.1
 */

import java.util.Vector;

public class RowLayout extends TwoDimenLayout{
    
    int nRow; // number of rows
    int nPad; // number of rectangular pads that make up the complete design
    double[] rowHeight; // height of row
    double[] padWidth; // width of pad
    double[] rowY; // y coordinate of lower edge of row
    double[] padX; // x coordinate of left edge of pad
    int[][] padInRow; // pad numbers in given row
    int[] rowForPad; // row number for given pad
    
    double xMin,xMax,yMin,yMax,pixelSize;
    
    Shape shape;  // shape of elements that make up grid
    RowLayout()
    { // set a default layout
        nRow = 0;
        nPad = 0;
        xMin = -15.;
        xMax = 15.;
        yMin = -15.;
        yMax = 15.;
        pixelSize = 0.05;
        shape = new Rectangle();
    }
    void setShape(Shape shape) {}
/** return shape of elements
 * @return shape of elements
 */
    public Shape getShape() {return shape;}
/** Return number of division in x coordinate
 * @return number of x divisions
 */
    public int getNX() {return -1;}
/** return number of divisions in y coordinate
 * @return number of y divisions (rows)
 */
    public int getNY() {return nRow;}
/** Return x coordinate of left edge of leftmost element
 * @return left edge of leftmost element (mm)
 */
    public double getXMin() {return xMin;}
/** Return y coordinate of lower edge of lowest element
 * @return low edge of lowest element (mm)
 */
    public double getYMin() {return yMin;}
/** Return x coordinate of right edge of rightmost element
 * @return right edge of rightmost element (mm)
 */
    public double getXMax() {return xMax;}
/** Return y coordinate of top edge of top element
 * @return top edge of top element (mm)
 */
    public double getYMax() {return yMax;}
/** Return x coordinate of centre of first element
 * @return x coordinate of centre of first element (mm)
 */
    public double getX0() {return xMin;}
/** Return y coordinate of centre of first element
 * @return y coordinate of centre of element (mm)
 */
    public double getY0() {return yMin;}
/** Return pitch of elements in x direction
 * @return pitch of elements in x direction (mm)
 */
    public double getDX() {return -1.;}
/** Return pitch of elements in y direction
 * @return pitch of elements in y direction (mm)
 */
    public double getDY() {return -1.;}
    
/** Return the number of elements
 * @return number of elements
 */
    
    public int getNumElement(){return nPad;}
/** Return index of element that is closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return index of element closest to point
 */
    
    public int getNearestIndex(double x, double y)
    {
        // loop over all rows to find right row
        boolean foundRow = false;
        int iPad = -1;
        int iRow = -1;
        int bottomRow = -1;
        int topRow = -1;
        double bottomRowY = 9.E9;
        double topRowY = -9.E9;
        while (!foundRow && iRow < nRow-1) {
            iRow++;
            if (y >= rowY[iRow] && y <= rowY[iRow] + rowHeight[iRow])
                foundRow = true;
            if (rowY[iRow] < bottomRowY) {
                bottomRow = iRow;
                bottomRowY = rowY[iRow];
            }
            if (rowY[iRow]+rowHeight[iRow] > topRowY) {
                topRow = iRow;
                topRowY = rowY[iRow]+rowHeight[iRow];
            }
        }
        
        if (!foundRow) {
            if (y < bottomRowY) {
                iRow = bottomRow;
            } else {
                iRow = topRow;
            }
        }
        
        // now loop inside row to find pad
        if (iRow >= 0) {
            boolean foundPad = false;
            int iPadInRow = -1;
            int leftPad = -1;
            int rightPad = -1;
            double leftPadX = 9.E9;
            double rightPadX = -9.E9;
            while (!foundPad && iPadInRow < padInRow[iRow].length-1) {
                iPadInRow++;
                iPad = padInRow[iRow][iPadInRow];
                if (x >= padX[iPad] && x <= padX[iPad] + padWidth[iPad])
                    foundPad = true;
                if (padX[iPad] < leftPadX) {
                    leftPad = iPad;
                    leftPadX = padX[iPad];
                }
                if (padX[iPad]+padWidth[iPad] > rightPadX) {
                    rightPad = iPad;
                    rightPadX = padX[iPad]+padWidth[iPad];
                }
            }
            
            if (!foundPad) {
                if (x < leftPadX) {
                    iPad = leftPad;
                } else {
                    iPad = rightPad;
                }
            }
        } else {
            iPad = -1;
        }
        
        return iPad;
    }
    
/** Return indicies of elements that are (approx) within distance to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param distance distance
 * @return indicies of elements within distance of point
 */
    public int[] getNearbyIndicies(double x, double y, double distance) {
        Vector vBuf = new Vector(10,10);
        // loop over all rows
        for (int iRow = 0; iRow < nRow; iRow++) {
            if ( (y >= rowY[iRow] && y <= rowY[iRow]) ||
            rowY[iRow] - y < distance ||
            y - (rowY[iRow] + rowHeight[iRow]) < distance) {
                double dy = 0.;
                if (y < rowY[iRow]) {
                    dy = rowY[iRow] - y;
                } else if (y > rowY[iRow] + rowHeight[iRow]) {
                    dy = y - (rowY[iRow] + rowHeight[iRow]);
                }
                // loop over all pads in the row
                for (int iPadInRow = 0; iPadInRow < padInRow[iRow].length; iPadInRow++) {
                    int iPad = padInRow[iRow][iPadInRow];
                    double dx = 0.;
                    if (x < padX[iPad]) {
                        dx = padX[iPad] - x;
                    } else if (x > padX[iPad] + padWidth[iPad]) {
                        dx = x - (padX[iPad] + padWidth[iPad]);
                    }
                    if (Math.sqrt(dx*dx+dy*dy)<distance) {
                        vBuf.addElement(new Integer(iPad));
                    }
                }
            }
        }
        int num = vBuf.size();
        int[] buffer = new int[num];
        // fill buffer
        for (int i=0; i < num; i++) {
            buffer[i] = ((Integer) vBuf.elementAt(i)).intValue();
        }
        return buffer;
    }
    
/** Return centre of element corresponding to specified index
 * @param index element index
 * @param loc location of centre of element (returned)
 */
    public void getCentre(int index, Location loc)
    {
        int iRow = rowForPad[index];
        loc.x = padX[index] + padWidth[index]/2.;
        loc.y = rowY[iRow] + rowHeight[iRow]/2.;
    }
    
/** Return centre of element that is closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param loc location of centre of nearest element (x,y) in mm (returned)
 */
    public void getNearestCentre(double x, double y, Location loc)
    {
        int index=getNearestIndex(x,y);
        getCentre(index,loc);
    }
    
/** Return location of edge of element closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param loc location of nearest edge of element (x,y) in mm (returned)
 */
    public void getNearestEdge(double x, double y, Location loc)
    {
        int iPad = getNearestIndex(x,y);
        int iRow = rowForPad[iPad];
        double dxl = padX[iPad] - x;
        double dxr = x - (padX[iPad] + padWidth[iPad]);
        double dyb = rowY[iRow] - y;
        double dyt = y - (rowY[iRow] + rowHeight[iRow]);
        
        loc.x = x;
        loc.y = y;
        if (dxl > 0.) {
            loc.x = padX[iPad];
        } else if (dxr > 0.) {
            loc.x = padX[iPad] + padWidth[iPad];
        }
        if (dyb > 0.) {
            loc.y = rowY[iRow];
        } else if (dyt > 0.) {
            loc.y = rowY[iRow] + rowHeight[iRow];
        }
    }
    
/** Check if point is within any of the elements
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return True if within an element
 */
    public boolean insideElement(double x, double y)
    {
        if (rowForPad == null)return false;
        int iPad = getNearestIndex(x,y);
        int iRow = rowForPad[iPad];
        double dxl = padX[iPad] - x;
        double dxr = x - (padX[iPad] + padWidth[iPad]);
        double dyb = rowY[iRow] - y;
        double dyt = y - (rowY[iRow] + rowHeight[iRow]);
        return dxl < 0. && dxr < 0. && dyb < 0. && dyt < 0.;
    }

    public boolean insideElement(double x, double y, int iPad) {
        if (rowForPad == null)return false;
        if (iPad < 0 || iPad >= nPad) return false;
        int iRow = rowForPad[iPad];
        double dxl = padX[iPad] - x;
        double dxr = x - (padX[iPad] + padWidth[iPad]);
        double dyb = rowY[iRow] - y;
        double dyt = y - (rowY[iRow] + rowHeight[iRow]);
        return dxl < 0. && dxr < 0. && dyb < 0. && dyt < 0.;
    }

    
}