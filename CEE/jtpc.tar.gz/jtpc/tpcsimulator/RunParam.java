package tpcsimulator;
import java.io.*;
import java.util.Vector;
/**
 *
 * @author  karlen
 * @version
 */
public class RunParam implements Serializable {
    
    static final long serialVersionUID = -6699822252343750864L; // frozen prior to adding preamp gain std dev
    
    public double minX,maxX,minZ,maxZ,minPhi,maxPhi,minPsi,maxPsi;
    public double time,cd,preAmpGain,fadcGain,fadcDT;
    public double lowX,highX,lowY,highY,lowZ,highZ;
    public double sxyz = 0.1; // new parameter
    public double preAmpGainStdDev = 0.; // new parameter
    public int preAmpType = 0; // new parameter
    public boolean makeTrk2=false; // new parameter for 2 track simulation
    public double trk2X=0.,trk2Z=0.,trk2Phi=0.,trk2Psi=0.; // more new parameters
    public boolean geantEvents=false; // new parameter
    public int geantCode=0;
    public double geantXOffset=0.,geantYOffset=0.,geantZOffset=0.;
    public double geantWi=26.;
    public String geantFile="";
    
    public int preAmpRiseTime,preAmpFallTime,fadcBits,fadcBins,run,number;
    public long seed;
    public boolean writeRawData,writeTuple;
    public String filename,tFilename;
    public Vector xyFitterParamVector;
    
    /** Creates new RunParam: parameters for MC run */
    public RunParam() {
        
        minX = -1.; maxX = 1.;
        minZ = 80.; maxZ = 80.;
        minPhi = -0.1; maxPhi = 0.1;
        minPsi = -0.1; maxPsi = 0.1;
        time = 0.; cd = 3.0;
        
        lowX = -10. ; highX = 10.;
        lowY = -15. ; highY = 15.;
        lowZ = 0.; highZ = 180.;
        
        preAmpGain = 3.3;
        preAmpRiseTime = 30;
        preAmpFallTime = 2000;
        
        fadcGain = 1.0; fadcBits = 8;
        fadcDT = 5.0; fadcBins = 4000;
        
        run = -999;
        number = 100;
        seed = -1;
        
        writeRawData = false;
        writeTuple = true;
        filename = new String("filename.mc");
        tFilename = new String("filename.aida");
        xyFitterParamVector = new Vector(5,5);
        
    }
    
}
