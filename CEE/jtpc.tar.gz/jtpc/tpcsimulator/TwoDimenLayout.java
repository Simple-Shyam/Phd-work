package tpcsimulator;
/** abstract class to be extended by specific layouts of elements (shapes)
 * @author Dean Karlen
 * @version 1.1
 */
import java.io.*;
import java.awt.*;
import java.util.Hashtable;

abstract public class TwoDimenLayout implements Serializable{
    //******smallest acceptable value for spacing
    public final double spacing = 0.0000;
    
    // the following methods must be implemented in the extended classes (tested by compiler):
    abstract void setShape(Shape shape); // sets the shape description
    abstract public Shape getShape(); // gets the shape description
    abstract public int[] getNearbyIndicies(double x, double y, double distance);            

    // return an array of indicies whose centre is within distance of (x,y)
    abstract public int getNearestIndex(double x, double y);
    // return index number of element whose centre is nearest to (x,y)
    abstract public void getCentre(int index, Location loc);
    // return location of centre of element
    abstract public void getNearestCentre(double x, double y, Location loc);
    // return location of centre of element whose centre is nearest to (x,y)
    abstract public void getNearestEdge(double x, double y, Location loc);
    // return location of nearest edge of element whose centre is nearest to (x,y)
    abstract public boolean insideElement(double x, double y);
    // return true if location is inside spatial extent of an element
    abstract public boolean insideElement(double x, double y, int index);
    // return true if location is inside spatial extent of specified element
    abstract public int getNumElement(); // return the number of elements in the layout
    abstract public int getNX(); // return the number of elements in x direction
    abstract public int getNY(); // return the number of elements in y direction
    abstract public double getX0(); // return x centre of first element
    abstract public double getY0(); // return y centre of first element
    abstract public double getDX(); // return pitch of elements in x direction
    abstract public double getDY(); // return pitch of elements in y direction
    abstract public double getXMin(); // return low edge in x
    abstract public double getYMin(); // return low edge in y
    abstract public double getXMax(); // return upper edge in x
    abstract public double getYMax(); // return upper edge in y
        
}