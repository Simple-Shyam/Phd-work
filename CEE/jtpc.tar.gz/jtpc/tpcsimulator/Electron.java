package tpcsimulator;
/** Electron
 * @author Dean Karlen
 * @version 1.0
 */
public class Electron{
    
/** x coordinate (mm)
 */
    public double x;
/** y coordinate (mm)
 */
    public double y;
/** z coordinate (mm)
 */
    public double z;
/** time coordinate (ns)
 */
    public double t;
    
/** identifier of primary electron that created this electron
 */
    public int idPrimary; // integer identifier of primary electron
    
/** Constructor
 * @param x x coordinate (mm)
 * @param y y coordinate (mm)
 * @param z z coordinate (mm)
 * @param t time coordinate (ns)
 * @param idPrimary identifier of primary electron that created this electron
 */
    public Electron(double x, double y, double z, double t, int idPrimary){
        this.x = x;
        this.y = y;
        this.z = z;
        this.t = t;
        this.idPrimary = idPrimary;
    }
}
