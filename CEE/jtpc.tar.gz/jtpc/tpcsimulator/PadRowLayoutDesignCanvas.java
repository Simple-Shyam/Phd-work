package tpcsimulator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Vector;
import javax.swing.Scrollable;

class PadRowLayoutDesignCanvas extends PadDesignCanvas implements Scrollable,MouseListener, MouseMotionListener{
    
    PadRowLayout padRowLayout;
    RowLayout rowLayout; // keeps a dynamic version of the layout
    PadRowLayoutDesignFrame padRowLayoutDesignFrame;
    
    // data required to define a row layout:
    int nRow; // number of rows
    int nPad; // number of rectangular pads that make up the complete design
    Vector rowHeight; // height of row
    Vector padWidth; // width of pad
    Vector rowY; // y coordinate of lower edge of row
    Vector padX; // x coordinate of left edge of pad
    Vector padInRow; // pad numbers in given row
    Vector rowForPad; // row number for given pad
    double xmin,xmax,ymin,ymax,pixelSize,xStart=0.;
    boolean noPads=true;
    
    // data required to define pad row layout:
    Vector groupForPad;
    
    PadRowLayoutDesignCanvas(PadRowLayout padRowLayout,
    PadRowLayoutDesignFrame padRowLayoutDesignFrame){
        this.padRowLayout = padRowLayout;
        this.padRowLayoutDesignFrame = padRowLayoutDesignFrame;
        
        xmin = padRowLayout.rowLayout.xMin;
        xmax = padRowLayout.rowLayout.xMax;
        ymin = padRowLayout.rowLayout.yMin;
        ymax = padRowLayout.rowLayout.yMax;
        pixelSize = padRowLayout.rowLayout.pixelSize;
        
        setBackground(Color.black);
        
        width = (int) ((xmax-xmin)/pixelSize + 0.5);
        height =(int) ((ymax-ymin)/pixelSize + 0.5);
        setBounds(0,0,width,height);
        
        addMouseMotionListener(this);
        addMouseListener(this);
        
        // copy the contents of the row Layout into the local data
        nRow = padRowLayout.rowLayout.nRow;
        nPad = padRowLayout.rowLayout.nPad;
        rowHeight = new Vector(nRow,5);
        for (int iRow = 0; iRow < nRow; iRow++)rowHeight.addElement(new Double(padRowLayout.rowLayout.rowHeight[iRow]));
        padWidth = new Vector(nPad,5);
        for (int iPad = 0; iPad < nPad; iPad++)padWidth.addElement(new Double(padRowLayout.rowLayout.padWidth[iPad]));
        rowY = new Vector(nRow,5);
        for (int iRow = 0; iRow < nRow; iRow++)rowY.addElement(new Double(padRowLayout.rowLayout.rowY[iRow]));
        padX = new Vector(nPad,5);
        for (int iPad = 0; iPad < nPad; iPad++)padX.addElement(new Double(padRowLayout.rowLayout.padX[iPad]));
        padInRow = new Vector(nRow,5);
        for (int iRow = 0; iRow < nRow; iRow++) {
            Vector padList = new Vector(padRowLayout.rowLayout.padInRow[iRow].length,5);
            for (int iPad = 0; iPad < padRowLayout.rowLayout.padInRow[iRow].length; iPad++)padList.addElement(new Integer(padRowLayout.rowLayout.padInRow[iRow][iPad]));
            padInRow.addElement(padList);
        }
        rowForPad = new Vector(nPad,5);
        for (int iPad = 0; iPad < nPad; iPad++)rowForPad.addElement(new Integer(padRowLayout.rowLayout.rowForPad[iPad]));
        
        // create a rowLayout with this data:
        rowLayout = makeRowLayout();
        
        // copy the contents of PadGroup into groupForPad
        groupForPad = new Vector(padRowLayout.rowLayout.nPad,5);
        int nPadGroup = padRowLayout.getNumElement();
        int [][] padGroup = padRowLayout.getPadGroup();
        for (int i = 0; i < padRowLayout.rowLayout.nPad; i++) groupForPad.addElement(new Integer(-1));
        for (int iPadGroup = 0; iPadGroup < nPadGroup; iPadGroup++) {
            int nPadInGroup = padGroup[iPadGroup].length;
            for (int iPad = 0; iPad < nPadInGroup; iPad++) {
                int padNumber = padGroup[iPadGroup][iPad];
                groupForPad.setElementAt(new Integer(iPadGroup),padNumber);
            }
        }
        largestPadGroupNumber = nPadGroup - 1;
    }
    
    RowLayout makeRowLayout() {
        // create a rowLayout from the local data
        RowLayout rl = new RowLayout();
        rl.nRow = nRow;
        rl.nPad = nPad;
        rl.xMin = xmin;
        rl.xMax = xmax;
        rl.yMin = ymin;
        rl.yMax = ymax;
        rl.pixelSize = pixelSize;
        
        if (nRow > 0 && nPad > 0) {
            rl.rowHeight = new double[nRow];
            for (int iRow = 0; iRow < nRow; iRow++) rl.rowHeight[iRow] = ((Double) rowHeight.elementAt(iRow)).doubleValue();
            rl.padWidth = new double[nPad];
            for (int iPad = 0; iPad < nPad; iPad++) rl.padWidth[iPad] = ((Double) padWidth.elementAt(iPad)).doubleValue();
            rl.rowY = new double[nRow];
            for (int iRow = 0; iRow < nRow; iRow++) rl.rowY[iRow] = ((Double) rowY.elementAt(iRow)).doubleValue();
            rl.padX = new double[nPad];
            for (int iPad = 0; iPad < nPad; iPad++) rl.padX[iPad] = ((Double) padX.elementAt(iPad)).doubleValue();
            rl.padInRow = new int[nRow][];
            for (int iRow = 0; iRow < nRow; iRow++) {
                Vector padList = (Vector) padInRow.elementAt(iRow);
                rl.padInRow[iRow] = new int[padList.size()];
                for (int iPad = 0; iPad < padList.size(); iPad++) {
                    rl.padInRow[iRow][iPad] = ((Integer) padList.elementAt(iPad)).intValue();
                }
            }
            rl.rowForPad = new int[nPad];
            for (int iPad = 0; iPad < nPad; iPad++) rl.rowForPad[iPad] = ((Integer) rowForPad.elementAt(iPad)).intValue();
        }
        return rl;
    }
    
    void saveLayout() {
        // use the dynamic version of the row layout:
        padRowLayout.layout = rowLayout;
        padRowLayout.rowLayout = rowLayout;
        padRowLayout.reset();
        
        // copy the contents of groupForPad into padGroup
        
        // count the number of pads in each group
        int[] count = new int[largestPadGroupNumber+1];
        int[] point = new int[largestPadGroupNumber+1];
        for (int i = 0; i <= largestPadGroupNumber; i++) count[i]=0;
        for (int i = 0; i < nPad; i++) {
            int igfp = ((Integer) groupForPad.elementAt(i)).intValue();
            if(igfp >=0) count[igfp]++;
        }
        int nPG = 0;
        for (int i=0; i <= largestPadGroupNumber; i++) {
            if (count[i] > 0) nPG++;
        }
        
        // setup the padGroup array
        int[][] pG = new int[nPG][];
        int j = -1;
        for (int i=0; i <= largestPadGroupNumber; i++ ) {
            if (count[i] > 0) {
                j++;
                point[i] = j;
                pG[j] = new int[count[i]];
            }
        }
        
        // fill the padGroup array
        for (int i = 0; i <= largestPadGroupNumber; i++) count[i]=0;
        for (int i = 0; i < nPad; i++) {
            int group = ((Integer) groupForPad.elementAt(i)).intValue();
            if(group >=0) {
                pG[point[group]][count[group]] = i;
                count[group]++;
            }
        }
        padRowLayout.setPadGroup(nPG,pG);
    }
    
    public void update(Graphics g){
        
        if (offGraphics == null) {
            offImage = createImage(width,height);
            offGraphics = offImage.getGraphics();
        }
        
        offGraphics.setColor(getBackground());
        offGraphics.fillRect(0,0,width,height);
        
        // draw in the arranged padRowLayout
        int nColors = Colors.length;
        for (int iRow = 0; iRow < rowLayout.nRow; iRow++) {
            for (int iPadInRow = 0; iPadInRow < rowLayout.padInRow[iRow].length; iPadInRow++) {
                int iPad = rowLayout.padInRow[iRow][iPadInRow];
                int iGroup = ((Integer) groupForPad.elementAt(iPad)).intValue();
                if (iGroup < 0) {
                    offGraphics.setColor(Color.white);
                } else {
                    offGraphics.setColor(colorScale(iGroup));
                }
                // draw pad: leave a pixel around it to show shapes
                int ix = (int) ((rowLayout.padX[iPad]-xmin)/pixelSize + 0.5) + 1;
                int iy = (int) ((rowLayout.rowY[iRow]-ymin)/pixelSize + 0.5) + 1;
                int dx = (int) (rowLayout.padWidth[iPad]/pixelSize + 0.5) - 2;
                int dy = (int) (rowLayout.rowHeight[iRow]/pixelSize + 0.5) - 2;
                offGraphics.fillRect(ix,height-iy-dy,dx,dy);
            }
        }
        
        // Draws the buffered image to the screen.
        g.drawImage(offImage, 0, 0, this);
    }
    
    Color colorScale(int iGroup) {
        int iGroupMax = Math.max(1,largestPadGroupNumber);
        if (iGroup < 0 || iGroup > iGroupMax) return Color.darkGray;
        float frac;
        frac = ((float) iGroup + 1)/(iGroupMax + 1);
        frac *= (float) 0.85; // removes the red near 1
        return new Color(Color.HSBtoRGB(frac, (float) 0.9, (float) 0.7));
    }
    
    void select(MouseEvent e, boolean reset) {
        int iGroup = padRowLayoutDesignFrame.getAssignGroup();
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < nPad) {
            if (((Integer) groupForPad.elementAt(iPad)).intValue() == iGroup && reset) {
                groupForPad.setElementAt(new Integer(-999),iPad);
            } else {
                groupForPad.setElementAt(new Integer(iGroup),iPad);
                largestPadGroupNumber = Math.max(largestPadGroupNumber,iGroup);
            }
        }
        updateLocationLabel(iPad);
        repaint();
    }
    
    public void mouseClicked(MouseEvent e) {
        if ((e.getModifiers() & InputEvent.BUTTON1_MASK)
        == InputEvent.BUTTON1_MASK) {
            select(e,false);
        } else if ((e.getModifiers() & InputEvent.BUTTON2_MASK)
        == InputEvent.BUTTON2_MASK) {
            int iPadGroup = getPadGroup(e);
            if (iPadGroup >= 0) {
                padRowLayoutDesignFrame.setGroupNumber(iPadGroup);
            }
        } else if ((e.getModifiers() & InputEvent.BUTTON3_MASK)
        == InputEvent.BUTTON3_MASK) {
            select(e,false);
            padRowLayoutDesignFrame.setGroupNumber(padRowLayoutDesignFrame.getAssignGroup()+1);
        }
    }
    
    public void mousePressed(MouseEvent e) {
    }
    
    public void mouseDragged(MouseEvent e) {
    }
    
    public void mouseReleased(MouseEvent e) {
    }
    
    public void mouseExited(MouseEvent e) {
        updateLocationLabel(-1);
    }
    
    public void mouseEntered(MouseEvent e) {
    }
    
    public void mouseMoved(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < nPad) {
            updateLocationLabel(iPad);
        }
    }
    
    void updateLocationLabel(int iPad) {
        if (iPad >= 0 && iPad < nPad) {
            int iGroup = ((Integer) groupForPad.elementAt(iPad)).intValue();
            if (iGroup < 0) {
                padRowLayoutDesignFrame.setDataLabel("Pad # " + iPad + " unassigned");
            } else {
                int iRow = rowLayout.rowForPad[iPad];
                padRowLayoutDesignFrame.setDataLabel("Pad # " + iPad +
                ": group " + iGroup +
                ", row " + iRow +
                ", x = " + rowLayout.padX[iPad] +
                ", y = " + rowLayout.rowY[iRow] +
                ", width = " + rowLayout.padWidth[iPad] +
                ", height = " + rowLayout.rowHeight[iRow]);
            }
        } else {
            padRowLayoutDesignFrame.setDataLabel(" ");
        }
    }
    
    int getPadGroup(MouseEvent e) {
        int iPad = getIPad(e);
        if (iPad >= 0 && iPad < nPad) {
            return ((Integer) groupForPad.elementAt(iPad)).intValue();
        }
        return -1;
    }
    
    int getIPad(MouseEvent e) {
        return getIPad(e.getX(),e.getY());
    }
    
    int getIPad(int ix, int iy) {
        double x = xmin + ix*pixelSize;
        double y = ymin + (height-iy)*pixelSize;
        if (rowLayout.insideElement(x,y)) return rowLayout.getNearestIndex(x,y);
        else return -1;
    }
    
    void addRow(double y, double height) {
        rowY.addElement(new Double(y));
        rowHeight.addElement(new Double(height));
        padInRow.addElement(new Vector(5,5));
        padRowLayoutDesignFrame.setDataLabel("Row # " + nRow +
        " added: bottom edge = " + y + ", height = " + height);
        padRowLayoutDesignFrame.setPadRowField(nRow);
        nRow++;
        
        padRowLayoutDesignFrame.setRowYField(y-height);
        padRowLayoutDesignFrame.setPadXField(xStart);
        noPads=true;
        
        repaint();
    }
    
    void addPad(int iRow, double x, double width, int iGroup) {
        if (iRow < nRow) {
            padX.addElement(new Double(x));
            padWidth.addElement(new Double(width));
            Vector padList = (Vector) padInRow.elementAt(iRow);
            padList.addElement(new Integer(nPad));
            padInRow.setElementAt(padList,iRow);
            rowForPad.addElement(new Integer(iRow));
            groupForPad.addElement(new Integer(iGroup));
            largestPadGroupNumber = Math.max(iGroup,largestPadGroupNumber);
            nPad++;
            
            rowLayout = makeRowLayout();
            if (noPads)xStart=x;
            noPads = false;
            padRowLayoutDesignFrame.setPadXField(x+width);
            repaint();
        } else {
            padRowLayoutDesignFrame.setDataLabel("Error: Row # " + iRow +
            " does not exist. Pad not added.");
        }
    }
   
    void clearAll() {
        nRow = 0;
        nPad = 0;
        rowHeight = new Vector(5,5);
        padWidth = new Vector(5,5);
        rowY = new Vector(5,5);
        padX = new Vector(5,5);
        padInRow = new Vector(5,5);
        rowForPad = new Vector(5,5);
        
        rowLayout = makeRowLayout();
        groupForPad = new Vector(5,5);
        largestPadGroupNumber = 0;
        repaint();
    }
    
    public int getScrollableUnitIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return 10;
    }
    
    public int getScrollableBlockIncrement(java.awt.Rectangle p1,int p2,int p3) {
        return 50;
    }

}