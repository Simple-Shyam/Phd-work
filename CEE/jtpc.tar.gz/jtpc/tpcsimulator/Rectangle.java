package tpcsimulator;
/** Define properties of a rectangle for holes and pads
 * @author Dean Karlen
 * @version 1.1
 */

import java.io.*;

public class Rectangle extends Shape{
    double lx,ly;
/** Constructor
 * @param lx width of rectangle (mm)
 * @param ly height of rectangle (mm)
 */
    Rectangle(double lx, double ly)
    {
        this.lx=lx;
        this.ly=ly;
    }
    
    Rectangle() {
        lx = 1.0;
        ly = 1.0;
    }
    
/** Return the location of the nearest edge of a rectangle to a point
 * @param x0 centre of rectangle x coordinate (mm)
 * @param y0 centre of rectangle y coordinate (mm)
 * @param x x coordinate of point
 * @param y y coordinate of point
 * @param loc location on edge of rectangle nearest to point
 */
    public void getNearestEdge(double x0, double y0, double x, double y, Location loc)
    {
        // The nearest edge is along the edge of the rectangle when the point is directly
        // above, below, left, or to the right of the rectangle. Otherwise it is the
        // corner of the rectangle
        double dx=(x-x0);
        double dy=(y-y0);
        boolean xedge = false;
        boolean yedge = false;
        xedge = Math.abs(dx) < lx/2.;
        yedge = Math.abs(dy) < ly/2.;
        if ( xedge && yedge ) {
            if ( Math.abs(Math.abs(dx)-lx/2.) < Math.abs(Math.abs(dy)-ly/2.) ){
                yedge = false;
            } else {
                xedge = false;
            }
        }
        if (xedge) {
            loc.x = x;
            if (dy > 0) {
                loc.y = y0 + ly/2.;
            } else {
                loc.y = y0 - ly/2.;
            }
        } else if (yedge) {
            loc.y = y;
            if (dx > 0) {
                loc.x = x0 + lx/2.;
            } else {
                loc.x = x0 - lx/2.;
            }
        } else {
            loc.x = x0 + lx/2.;
            if (dx < 0) loc.x = x0 - lx/2.;
            loc.y = y0 + ly/2.;
            if (dy < 0) loc.y = y0 - ly/2.;
        }
    }
    
/** test if point is inside rectangle
 * @param x0 centre of rectangle x coordinate
 * @param y0 centre of rectangle y coordinate
 * @param x x coordinate of point
 * @param y y coordinate of point
 * @return true if point is within rectangle
 */
    public boolean insideElement(double x0, double y0, double x, double y)
    {
        // easy to determine
        double dx=(x-x0);
        double dy=(y-y0);
        return Math.abs(dx) < lx/2. && Math.abs(dy) < ly/2.;
    }
    
/** return "radial size" of rectangle
 * @return 1/2 the average of the side lengths (mm) similar
 */
    public double getSize(){
        return (lx+ly)/4.;
    }

}