package tpcsimulator;

class AboveBelowComboBox extends javax.swing.JComboBox {

    /** Creates new AboveBelowComboBox */
    AboveBelowComboBox() {
        addItem("Above");
        addItem("Below");
    }

    boolean isAbove() {
        return getSelectedIndex() == 0;
    }        
}