package tpcsimulator;
/** ElectronCloud: represents the probability density of electrons
 * @author Dean Karlen
 * @version 1.0
 */
public class ElectronCloud{
    
/** n number of electrons in cloud (mm)
 */
    public int n;
/** x coordinate (mm) of centroid
 */
    public double x;
/** y coordinate (mm) of centroid
 */
    public double y;
/** z coordinate (mm) of centroid
 */
    public double z;
/** transverse standard deviation (mm)
 */
    public double sxy;
/** longitudinal standard deviation (mm)
 */
    public double sz;
/** time coordinate (ns)
 */
    public double t;
   
/** identifier of primary cloud that created this cloud
 */
    public int idPrimary; // integer identifier of primary electron
    
/** Constructor
 * @param n number of electrons in cloud
 * @param x x coordinate (mm)
 * @param y y coordinate (mm)
 * @param z z coordinate (mm)
 * @param sxy transverse standard deviation (mm)
 * @param sz longitudinal standard deviation (mm)
 * @param t time coordinate (ns)
 * @param vd drift velocity in most recent gas gap (um/ns)
 * @param idPrimary identifier of primary electron cloud that created this electron cloud
 */
    public ElectronCloud(int n, double x, double y, double z, double sxy, double sz,
    double t, int idPrimary){
        this.n = n;
        this.x = x;
        this.y = y;
        this.z = z;
        this.sxy = sxy;
        this.sz = sz;
        this.t = t;
        this.idPrimary = idPrimary;
    }

    ElectronCloud(){
        n=0;
        x=0.;
        y=0.;
        z=0.;
        sxy=0.;
        sz=0.;
        t=0.;
        idPrimary=0;
    }
}
