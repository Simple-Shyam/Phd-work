package tpcsimulator;
/** Structure that holds description of Tpc Part to be constructed
 */
import java.io.*;
public abstract class TpcPartDesc {
    String name;
    double thickness;
}
