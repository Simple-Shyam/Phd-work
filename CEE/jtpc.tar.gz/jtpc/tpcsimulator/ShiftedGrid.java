package tpcsimulator;
/*
 * ShiftedGrid.java
 *
 * Created on May 17, 2001, 1:28 PM
 */


/** Layout of elements in a grid (holes or pads) with everyother row offset<br>
 * <PRE>
 * The elements are numbered as follows:
 *
 *                    ^
 * 9 10 11 12         |
 *  5  6  7  8        y
 * 1  2  3  4           x ->
 *
 * </PRE>
 * @author Pascal Elahi
 * @version 1.1
 */

import java.awt.Graphics;
import java.awt.Color;
import java.lang.Integer;

public class ShiftedGrid extends TwoDimenLayout {
    double dx,dy; // spacing between centres
    double x0,y0; // location of first element (lower left)
    double offset; //offset from origin
    int nx,ny;    // number of rows and columns
    Shape shape; // shape of elements that make up grid
    
/** Constructor
 */
    /** Creates new ShiftedGrid */
    public ShiftedGrid() {
        // set a default layout
        this.dx=1.0;
        this.dy=1.0;
        this.x0=-1.0;
        this.y0=-1.0;
        this.offset = 1.0;
        this.nx=21;
        this.ny=21;
        this.shape=null;
    }
    
    //returns the centre of the element corresponding to a specific index
    public void getCentre(int index,Location loc) {
        int ix=(index-1)%nx+1;
        int iy=(index-1)/nx+1;
        // when iy is even, the grid is shifted in x by the offset.
        double xoff = 0.;
        if (iy%2 == 0) xoff = this.offset;
        loc.x=x0+(ix-1)*dx+xoff;
        loc.y=y0+(iy-1)*dy;
    }
    
    //return num of divisions in x direction (cols)
    public int getNX() {return nx;}
    
    //return num of divisions in y direction (rows)
    public int getNY() {return ny;}

/** Return x coordinate of centre of first element
 * @return x coordinate of centre of first element (mm)
 */
    public double getX0() {return x0;}
/** Return y coordinate of centre of first element
 * @return y coordinate of centre of element (mm)
 */
    public double getY0() {return y0;}
/** Return pitch of elements in x direction
 * @return pitch of elements in x direction (mm)
 */
    public double getDX() {return dx;}
/** Return pitch of elements in y direction
 * @return pitch of elements in y direction (mm)
 */
    public double getDY() {return dy;}
    
    //gets the centre of the nearest element to an x,y coordinate
    public void getNearestCentre(double x,double y,Location loc) {
        int i = getNearestIndex(x,y);
        getCentre(i,loc);
    }
    
    //gets the nearest element's edge to an x,y coordinate
    public void getNearestEdge(double x,double y,Location loc) {
        Location centre = new Location();
        getNearestCentre(x,y,centre);
        shape.getNearestEdge(centre.x,centre.y,x,y,loc);
    }
    
    //gets the index of the nearest element to a given coordinate
    public int getNearestIndex(double x,double y) {
        int iy= (int)(Math.round((y-y0)/dy)+1.5);
        iy = Math.max(1,Math.min(ny,iy));
        //if iy even then x offset
        double xoff = 0.;
        if (iy%2==0) xoff = this.offset;
        int ix= (int)(Math.round((x-(x0+xoff))/dx)+1.5);
        ix = Math.max(1,Math.min(nx,ix));
        //closest index
        return nx*(iy-1)+ix;
    }
    
 /** Return indicies of elements that are (approx) within distance to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param distance distance
 * @return indicies of elements within distance of point
 */
    public int[] getNearbyIndicies(double x, double y, double distance) {
        /* maximum number of indicies */
        int row = (getNearestIndex(x0,y)-1)/nx + 1;
        int col = getNearestIndex(x,y0);
        int rowMin = (int) Math.max(1,row-distance/dy);
        int rowMax = (int) Math.min(ny,row+distance/dy);
        int colMin = (int) Math.max(1,col-distance/dx);
        int colMax = (int) Math.min(nx,col-distance/dx);
        int num = (rowMax-rowMin+1)*(colMax-colMin+1);
        int[] buffer = new int[num];
        int i=-1;
        for (int iCol = colMin; iCol <= colMax; iCol++) {
            for (int iRow = rowMin; iRow < rowMax; iRow++) {
                i++;
                buffer[i]=nx*(iRow-1)+iCol;
            }
        }
        return buffer;
    }

    //return the number of elemnts in the grid
    public int getNumElement() {return nx*ny;}
    
    //returns the shape
    public Shape getShape() {return shape;}
    
    //returns the x coordinate of the right edge of the right most element
    public double getXMax() {return x0 + (nx-0.5)*dx + offset;}
    
    //returns the x coordinate of the left edge of the left most element
    public double getXMin() {return x0-dx/2.;}
    
    //returns the y coordinate of the bottom edge of lowest element
    public double getYMax() {return y0 + (ny - 0.5)*dy;}
    
    //returns the y coordinate of the top edge of top most element
    public double getYMin() {return y0 - dy/2.;}
    
    //sets the spacing between elements
    void setPitch(double px, double py) {
        dx = px;
        dy = py;
    }
    
    //get the spacing between elements
    public Location getPitch() {
        Location loc = new Location();
        loc.x = dx;
        loc.y = dy;
        return loc;
    }
    
    //does not seem to work ??
    void setTheOffset(double offset) {this.offset = offset;}
    
    public double getTheOffset(){return this.offset;}
    
    //set the origin
    void setOrigin(double x0, double y0) {
        this.x0 = x0;
        this.y0 = y0;
    }
    
    //sets the number of elements
    void setNumber(int nx, int ny) {
        this.nx = nx;
        this.ny = ny;
    }
    
    //returns if x,y coordinate inside an element
    public boolean insideElement(double x,double y) {
        Location centre = new Location();
        getNearestCentre(x,y,centre);
        return shape.insideElement(centre.x,centre.y,x,y);
    }
    
    //returns if x,y coordinate inside an element
    public boolean insideElement(double x,double y, int index) {
        Location centre = new Location();
        getCentre(index,centre);
        return shape.insideElement(centre.x,centre.y,x,y);
    }

    //sets the shape
    public void setShape(Shape shape) {this.shape = shape;}
    
}