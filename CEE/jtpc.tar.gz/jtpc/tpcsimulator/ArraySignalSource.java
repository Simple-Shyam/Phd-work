package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import jas.hist.*;
import java.util.Observable;
import java.io.Serializable;

/** Signal data for a single pad.
 * @author Dean Karlen
 * @version 1.0
 */
class ArraySignalSource extends Observable implements Rebinnable1DHistogramData, HasStyle
{
    private ReadOut readOut;
    private PadArray padArray;
    private int iPad;
    private JASHistStyle jASHistStyle;
    
/** Constructor
 * @param padArray Pad Array
 * @param iPad index of Pad in Pad Array
 * @param jASHistStyle JAS Histogram Style
 */
    public ArraySignalSource(ReadOut readOut, PadArray padArray, int iPad, JASHistStyle jASHistStyle)
    {
        this.readOut = readOut;
        this.padArray = padArray;
        this.iPad = iPad;
        this.jASHistStyle = jASHistStyle;
    }
    public double[][] rebin(int   rBins, double rMin,   double rMax,
    boolean   wantErrors,   boolean   hurry)
    {
        double[][] result = new double[3][rBins];
        for (int i=0; i<3 ; i++){
            for (int j=0; j<rBins; j++){
                result[i][j] = 0.;
            }
        }
        
        Signal signal = new Signal(rBins,rMin,rMax,readOut.preAmpPanel.preAmp);
        if(padArray.getPadSignal(iPad,signal)){
            for (int i=0; i<rBins; i++){
                result[0][i] += signal.data[i];
            }
        }
        
        return result;
    }
    public void updateData(int iPad)
    {
        this.iPad = iPad;
        setChanged(); // notifyObservers needs this
    }
    
    public String[]   getAxisLabels()   { return null; }
    public double getMin() { return   300.; }
    public double getMax() { return   700.; }
    public boolean isRebinnable() {   return true; }
    public int getBins() { return 100; }
    public int getAxisType() { return DOUBLE; }
    public String getTitle() { return "Pad " + iPad;  }
    public JASHistStyle getStyle(){ return jASHistStyle; }
}
