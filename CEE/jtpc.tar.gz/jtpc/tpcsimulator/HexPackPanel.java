package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide panel to control HexPack layout options
 * @author Dean Karlen
 * @version 1.0
 */
class HexPackPanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField pField,xnField,ynField,x0Field,y0Field;
    HexPackPanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the pitch:
        pField = new DecimalField(0, 5, numberFormat);
        pField.setValue((lGP.hexPackLayout).getPitch());
        pField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.hexPackLayout).setPitch(pField.getValue());
            }
        });
        JLabel pLabel = new JLabel("pitch: ");
        JLabel pUnitLabel = new JLabel("mm");
        // code for the number:
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((lGP.hexPackLayout).nx);
        ynField.setValue((lGP.hexPackLayout).ny);
        xnField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.hexPackLayout).setNumber((int)xnField.getValue(),(lGP.hexPackLayout).ny);
                lGP.reset();
            }
        });
        ynField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.hexPackLayout).setNumber((lGP.hexPackLayout).nx,(int)ynField.getValue());
                lGP.reset();
            }
        });
        JLabel xnLabel = new JLabel("x number ");
        JLabel ynLabel = new JLabel("y number ");
        // code for the origin:
        x0Field = new DecimalField(0, 5, numberFormat);
        y0Field = new DecimalField(0, 5, numberFormat);
        x0Field.setValue((lGP.hexPackLayout).x0);
        y0Field.setValue((lGP.hexPackLayout).y0);
        x0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.hexPackLayout).setOrigin(x0Field.getValue(),(lGP.hexPackLayout).y0);
            }
        });
        y0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.hexPackLayout).setOrigin((lGP.hexPackLayout).x0,y0Field.getValue());
            }
        });
        JLabel x0Label = new JLabel("x origin ");
        JLabel y0Label = new JLabel("y origin ");
        JLabel x0UnitLabel = new JLabel("mm");
        JLabel y0UnitLabel = new JLabel("mm");
        
        // arrange into grid
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(pLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(pField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(pUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(x0Label);
        labelPane.add(y0Label);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(x0Field);
        fieldPane.add(y0Field);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(x0UnitLabel);
        unitPane.add(y0UnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
    void readPanel(){
        (lGP.hexPackLayout).setPitch(pField.getValue());
        (lGP.hexPackLayout).setOrigin(x0Field.getValue(),(lGP.hexPackLayout).y0);
        (lGP.hexPackLayout).setOrigin((lGP.hexPackLayout).x0,y0Field.getValue());
        
        if((int)xnField.getValue() != (lGP.hexPackLayout).nx ||
        (int)ynField.getValue() != (lGP.hexPackLayout).ny){
            (lGP.hexPackLayout).setNumber((int)xnField.getValue(),(lGP.hexPackLayout).ny);
            (lGP.hexPackLayout).setNumber((lGP.hexPackLayout).nx,(int)ynField.getValue());
            lGP.reset();
        }
    }
}
