package tpcsimulator;
/*
 * ShiftedGridPanel.java
 *
 * Created on May 17, 2001, 2:23 PM
 */


/** Provides interface to manipulate the shifted grid parameters
 *
 * @author  Pascal Elahi
 * @version 1.0
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

class ShiftedGridPanel extends javax.swing.JPanel {
    
    LayoutTpcPart lGP;
    DecimalField xpField,ypField,offsetField,xnField,ynField,x0Field,y0Field;
    
    /** Creates new ShiftedGridPanel */
    public ShiftedGridPanel(LayoutTpcPart iLGP) {
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        
        //code for the pitch
        xpField = new DecimalField(0, 5, numberFormat);
        ypField = new DecimalField(0, 5, numberFormat);
        xpField.setValue(((lGP.shiftedGridLayout).getPitch()).x);
        ypField.setValue(((lGP.shiftedGridLayout).getPitch()).y);
        xpField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Location loc = (lGP.shiftedGridLayout).getPitch();
                (lGP.shiftedGridLayout).setPitch(xpField.getValue(),loc.y);
            }
        });
        ypField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Location loc = (lGP.shiftedGridLayout).getPitch();
                (lGP.shiftedGridLayout).setPitch(loc.x,ypField.getValue());
            }
        });
        JLabel xpLabel = new JLabel("x pitch:");
        JLabel ypLabel = new JLabel("y pitch:");
        JLabel xpUnitLabel = new JLabel("mm");
        JLabel ypUnitLabel = new JLabel("mm");
        
        //code for offset
        offsetField = new DecimalField(0, 5, numberFormat);
        offsetField.setValue((lGP.shiftedGridLayout).getTheOffset());
        offsetField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.shiftedGridLayout).setTheOffset(offsetField.getValue());
            }
        });
        JLabel offsetLabel = new JLabel("Offset :");
        JLabel offsetUnitLabel = new JLabel("mm");
        
        // code for the number:
        xnField = new DecimalField(0, 5, numberFormat);
        ynField = new DecimalField(0, 5, numberFormat);
        xnField.setValue((lGP.shiftedGridLayout).nx);
        ynField.setValue((lGP.shiftedGridLayout).ny);
        xnField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.shiftedGridLayout).setNumber((int)xnField.getValue(),(lGP.shiftedGridLayout).ny);
                lGP.reset();
            }
        });
        ynField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.shiftedGridLayout).setNumber((lGP.shiftedGridLayout).nx,(int)ynField.getValue());
                lGP.reset();
            }
        });
        JLabel xnLabel = new JLabel("x number:");
        JLabel ynLabel = new JLabel("y number:");
        
        // code for the origin:
        x0Field = new DecimalField(0, 5, numberFormat);
        y0Field = new DecimalField(0, 5, numberFormat);
        x0Field.setValue((lGP.shiftedGridLayout).x0);
        y0Field.setValue((lGP.shiftedGridLayout).y0);
        x0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.shiftedGridLayout).setOrigin(x0Field.getValue(),(lGP.shiftedGridLayout).y0);
            }
        });
        y0Field.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.shiftedGridLayout).setOrigin((lGP.shiftedGridLayout).x0,y0Field.getValue());
            }
        });
        JLabel x0Label = new JLabel("x origin:");
        JLabel y0Label = new JLabel("y origin:");
        JLabel x0UnitLabel = new JLabel("mm");
        JLabel y0UnitLabel = new JLabel("mm");
        
        //arrange into a grid
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xpLabel);
        labelPane.add(ypLabel);
        labelPane.add(offsetLabel);
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xpField);
        fieldPane.add(ypField);
        fieldPane.add(offsetField);
        JPanel unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(xpUnitLabel);
        unitPane.add(ypUnitLabel);
        unitPane.add(offsetUnitLabel);
        
        JPanel col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(xnLabel);
        labelPane.add(ynLabel);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(xnField);
        fieldPane.add(ynField);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        add(col);
        
        labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(x0Label);
        labelPane.add(y0Label);
        fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        fieldPane.add(x0Field);
        fieldPane.add(y0Field);
        unitPane = new JPanel();
        unitPane.setLayout(new GridLayout(0,1));
        unitPane.add(x0UnitLabel);
        unitPane.add(y0UnitLabel);
        
        col = new JPanel();
        col.add(labelPane);
        col.add(fieldPane);
        col.add(unitPane);
        add(col);
    }
    void readPanel(){
        (lGP.shiftedGridLayout).setPitch(xpField.getValue(),ypField.getValue());
        (lGP.shiftedGridLayout).setOrigin(x0Field.getValue(),(lGP.shiftedGridLayout).y0);
        (lGP.shiftedGridLayout).setOrigin((lGP.shiftedGridLayout).x0,y0Field.getValue());
        (lGP.shiftedGridLayout).setTheOffset(offsetField.getValue());
        
        if((int)xnField.getValue() != (lGP.shiftedGridLayout).nx ||
        (int)ynField.getValue() != (lGP.shiftedGridLayout).ny){
            (lGP.shiftedGridLayout).setNumber((int)xnField.getValue(),(lGP.shiftedGridLayout).ny);
            (lGP.shiftedGridLayout).setNumber((lGP.shiftedGridLayout).nx,(int)ynField.getValue());
            lGP.reset();
        }
    }
    
}
