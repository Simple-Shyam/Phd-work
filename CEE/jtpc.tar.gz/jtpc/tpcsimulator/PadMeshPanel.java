package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import tpctracker.FitterControlFrame;

class PadMeshPanel extends PadArrayPanel {
    TpcDesign tpcDesign;
    JButton designButton,resetMeshButton;
    PadMeshEventFrame eventDisplay;
    PadMeshPanel pmpThis;
    FitterControlFrame fitterControl;
    /** Creates new PadArrayPanel */
    PadMeshPanel(PadMesh padMesh, TpcDesign iTpcDesign) {
        padArray = padMesh;
        tpcDesign = iTpcDesign;
        pmpThis = this;
        // layout the Panel in the Tpc Design window:
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder
        (BorderFactory.createTitledBorder("Pad Mesh: " + padArray.name),
        BorderFactory.createEmptyBorder(5,5,5,5)));
        // Layout of the Pad Mesh:
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new BoxLayout(selectionPanel, BoxLayout.Y_AXIS));
        JPanel cbp = new JPanel();
        layoutPanel = new LayoutPanel(padArray,cbp);
        layoutPanel.setModifiable(false);
        JLabel cbpLabel = new JLabel("Pad Mesh layout:");
        cbpLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        selectionPanel.add(cbpLabel);
        selectionPanel.add(cbp);
        add(selectionPanel, BorderLayout.WEST);
        add(layoutPanel,BorderLayout.CENTER);
        // Shape of the Pads:
        JPanel selectShapePanel = new JPanel();
        JPanel cbpShape = new JPanel();
        shapePanel = new ShapePanel(padArray,cbpShape);
        shapePanel.setModifiable(false);
        JLabel cbpShapeLabel = new JLabel("Pad shape:");
        selectShapePanel.add(cbpShapeLabel);
        selectShapePanel.add(cbpShape);
        selectShapePanel.add(shapePanel);
        add(selectShapePanel,BorderLayout.SOUTH);
        // button for design pads from mesh
        JPanel designPanel = new JPanel();
        designPanel.setLayout(new FlowLayout(1,5,5));
        designButton = new JButton("Pad Designer");
        designPanel.add(designButton);
        resetMeshButton = new JButton("Reset Mesh");
        designPanel.add(resetMeshButton);
        add(designPanel,BorderLayout.NORTH);
        addActionListeners();
        
        createAssociatedWindows();
        eventDisplay = new PadMeshEventFrame(padArray);
        eventDisplay.setVisible(false);
        
        fitterControl = new FitterControlFrame(padMesh);
        fitterControl.setVisible(false);
        
    }

    void readPanel(){
        if (layoutPanel != null)layoutPanel.readPanel();
    }
        
    int nWindow(){return 4;}
    JFrame window(int i) {
        if(i==1){
            return readOut;
        } else if (i==2){
            return statsWindow;
        }
        else if (i==3) {
            return eventDisplay;
        } else 
            return fitterControl;
    }
    
    public void addActionListeners() {
        designButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PadDesignFrame padDesignFrame = new PadDesignFrame(tpcDesign, padArray, pmpThis);
                padDesignFrame.setVisible(true);
            }
        });
        resetMeshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                readPanel();
                padArray.reset();
                resetPadMeshEventFrame();
            }
        });
    }
    
    void resetPadMeshEventFrame() {
        eventDisplay.setVisible(false);
        eventDisplay = new PadMeshEventFrame(padArray);
        eventDisplay.setVisible(false);
    }
}
