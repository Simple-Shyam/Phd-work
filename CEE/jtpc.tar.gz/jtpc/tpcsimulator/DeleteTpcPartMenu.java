package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Provides menu to delete Tpc parts from TPC
 */
class DeleteTpcPartMenu extends JFrame{
    TpcGui tpcGui;
    JComboBox comboBox;
/** Constructor
 * @param iTpc Time Projection Chamber
 */
    DeleteTpcPartMenu(TpcGui iTpcGui){
        super("Delete a TPC component");
        tpcGui = iTpcGui;
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0,1));
        labelPane.add(new JLabel("Component to be deleted:"));
        
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0,1));
        comboBox = new JComboBox();
        
        TpcPart tpcPart = tpcGui.tpc.topPart;
        while (tpcPart != null){
            comboBox.addItem(tpcPart);
            tpcPart = tpcPart.partBelow;
        }
        
        fieldPane.add(comboBox);
        
        getContentPane().add(labelPane, BorderLayout.WEST);
        getContentPane().add(fieldPane, BorderLayout.CENTER);
        
        JButton cancelButton = new JButton("Cancel");
        JButton okButton = new JButton("Ok");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cancelButton);
        buttonPanel.add(okButton);
        
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TpcPart tpcPart = (TpcPart) comboBox.getSelectedItem();
                boolean l = tpcGui.tpc.deletePart(tpcPart);
                tpcGui.tpcDesign.drawTpc();
                setVisible(false);
            }
        });
    }
}
