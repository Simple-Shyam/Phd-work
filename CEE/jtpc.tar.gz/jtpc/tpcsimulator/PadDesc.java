package tpcsimulator;

/** Descriptor for Pads
 * @author Dean Karlen
 * @version 1.0
 */

class PadDesc extends LayoutTpcPartDesc{

    

    PadDesc(String name){

        this.name = name;
        
        // define default pad geometry
        
        Circle padCircle = new Circle(0.5);
        Rectangle padRectangle = new Rectangle(0.99,0.99);
        Square padSquare = new Square(1.0);
        
        Grid padGrid = new Grid();
        padGrid.setPitch(1.0,1.0);
        padGrid.setOrigin(0.,0.);
        padGrid.setNumber(40,40);
        
        Mesh padMesh = new Mesh();
        padMesh.setPitch(0.2); 
        padMesh.setOrigin(-10.,-10.);
        padMesh.setNumber(100,100);
        
        RowLayout aRowLayout = new RowLayout();
        SymLayout aSymLayout = new SymLayout();
        HexPack padHexPack = new HexPack();
        padHexPack.setOrigin(0.,0.);
        ShiftedGrid aShiftedGridPad = new ShiftedGrid();
                
        thickness=0.0;
        
        gridLayout = padGrid;
        meshLayout = padMesh;
        rowLayout = aRowLayout;
        symLayout = aSymLayout;
        hexPackLayout = padHexPack;
        shiftedGridLayout = aShiftedGridPad;
        
        circle = padCircle;
        rectangle = padRectangle;
        square = padSquare;
        
        padGrid.setShape(circle);
        padMesh.setShape(square);
        padHexPack.setShape(circle);
        aShiftedGridPad.setShape(circle);
        
        layout = gridLayout;
    }
}