package tpcsimulator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

/** Provide a panel to adjust rectangle options
 * @author Dean Karlen
 * @version 1.0
 */
class RectanglePanel extends JPanel {
    LayoutTpcPart lGP;
    DecimalField lxField,lyField;
    RectanglePanel(LayoutTpcPart iLGP){
        lGP = iLGP;
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(2);
        // code for the lx,ly:
        lxField = new DecimalField(0, 5, numberFormat);
        lxField.setValue((lGP.rectangle).lx);
        lxField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.rectangle).lx=lxField.getValue();
            }
        });
        lyField = new DecimalField(0, 5, numberFormat);
        lyField.setValue((lGP.rectangle).ly);
        lyField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                (lGP.rectangle).ly=lyField.getValue();
            }
        });
        JLabel lxLabel = new JLabel("x size: ");
        JLabel lxUnitLabel = new JLabel("mm");
        add(lxLabel);
        add(lxField);
        add(lxUnitLabel);
        JLabel lyLabel = new JLabel("y size: ");
        JLabel lyUnitLabel = new JLabel("mm");
        add(lyLabel);
        add(lyField);
        add(lyUnitLabel);
    }
    void readPanel(){
        (lGP.rectangle).lx=lxField.getValue();
        (lGP.rectangle).ly=lyField.getValue();
    }
}
