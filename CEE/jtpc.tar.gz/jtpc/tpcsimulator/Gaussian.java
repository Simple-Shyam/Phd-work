package tpcsimulator;
/** Functions related to Gaussian distributions
 * @author Dean Karlen
 * @version 1.0
 */
class Gaussian{
/** uses 2D transformation to produce Gaussian deviates: 
 NO LONGER USED: random.nextGaussian is used instead!
 * @return Gaussian deviate
 */
    static public double random(){
        double u = Math.log(Math.random());
        double r = Math.sqrt(-2.*u);
        double t = 2.*Math.PI*Math.random();
        return r*Math.cos(t);
    }
/** evaluate the error function
 * @param x x value
 * @return error function erf(x)
 */
    static public double erf(double x){
        final double p = 0.47947;
        final double a1 = 0.3480242;
        final double a2 = -0.0958798;
        final double a3 = 0.7478556;
        double t = 1./(1.+p*Math.abs(x));
        double coeff = (a1 + (a2 + a3*t)*t)*t;
        double ans = 1. - coeff*Math.exp(-x*x);
        if (x<0) ans = -ans;
        return ans;
    }
}
