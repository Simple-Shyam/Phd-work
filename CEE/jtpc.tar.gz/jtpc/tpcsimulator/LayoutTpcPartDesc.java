package tpcsimulator;

/** descriptor for generic class of TpcParts that are layed out in a pattern (foil holes and pads)

 * @author Dean Karlen

 * @version 1.0

 */

abstract class LayoutTpcPartDesc extends TpcPartDesc{

    // structure to hold data for a LayoutTpcPart to be constructed

    TwoDimenLayout layout;

    Grid gridLayout;

    Mesh meshLayout;

    HexPack hexPackLayout;

    ShiftedGrid shiftedGridLayout;

    RowLayout rowLayout;
    
    SymLayout symLayout;

    Circle circle;

    Rectangle rectangle;

    Square square;

}

