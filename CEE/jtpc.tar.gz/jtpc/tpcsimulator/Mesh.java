package tpcsimulator;

/** A Grid that has equal pitch in x and y
 *
 *  Just to be confusing: The mesh counting of pads starts at zero instead of 1!
 *
 */

public class Mesh extends Grid {
    
    /** Creates new Mesh */
    public Mesh() {
        super();
        setPitch(dx);
    }

    void setPitch(double pitch) {
        dx = pitch;
        dy = pitch;
    }

    public double getMeshPitch() {
        return dx;
    }
    
/** Return index of element that is closest to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @return index of element closest to point
 */
    public int getNearestIndex(double x, double y)
    {
        return super.getNearestIndex(x,y)-1;
    }
/** Return indicies of elements that are (approx) within distance to a specified point
 * @param x x coordinate of point (mm)
 * @param y y coordinate of point (mm)
 * @param distance distance
 * @return indicies of elements within distance of point
 */
    public int[] getNearbyIndicies(double x, double y, double distance) {
        /* maximum number of indicies */
        int buffer[] = super.getNearbyIndicies(x,y,distance);
        int n = buffer.length;
        for (int i=0; i < n; i++) {
            buffer[i]--;
        }
        return buffer;
    }
    
/** Return centre of element corresponding to specified index
 * @param index element index
 * @param loc location of centre of element (returned)
 */
    public void getCentre(int index, Location loc)
    {
        super.getCentre(index+1,loc);
    }

}